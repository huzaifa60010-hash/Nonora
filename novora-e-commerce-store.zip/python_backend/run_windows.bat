@echo off
TITLE NOVORA - Local SQLite & REST API Backend
COLOR 0B
echo ========================================================
echo NOVORA LUXURY E-COMMERCE - LOCAL WINDOWS SQLITE BACKEND
echo School Project Local Persistence Engine
echo ========================================================
echo.
echo Database Directory: C:\Novora_Project\data\novora.db
echo Checking Python installation...

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not found in your Windows PATH.
    echo Please install Python 3.10+ from python.org and check "Add Python to PATH".
    pause
    exit /b
)

echo Python is installed.
echo Creating C:\Novora_Project\data directory if missing...
if not exist "C:\Novora_Project\data" mkdir "C:\Novora_Project\data"
if not exist "C:\Novora_Project\uploads" mkdir "C:\Novora_Project\uploads"

echo Starting NOVORA Local Backend on http://127.0.0.1:5000 ...
python app.py 5000
pause
