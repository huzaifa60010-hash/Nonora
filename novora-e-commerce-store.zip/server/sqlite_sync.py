import os
import sys
import json
import sqlite3
import shutil
from datetime import datetime

DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data'))
DB_PATH = os.path.join(DATA_DIR, 'novora.db')
STORE_JSON_PATH = os.path.join(DATA_DIR, 'store.json')
BACKUPS_DIR = os.path.join(DATA_DIR, 'backups')

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(BACKUPS_DIR, exist_ok=True)

def init_tables(conn):
    cursor = conn.cursor()
    cursor.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'customer',
        phone TEXT,
        created_at TEXT,
        updated_at TEXT
    );

    CREATE TABLE IF NOT EXISTS addresses (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        user_email TEXT,
        full_name TEXT,
        phone TEXT,
        country TEXT,
        state TEXT,
        city TEXT,
        street_address TEXT,
        house_number TEXT,
        apartment_details TEXT,
        postal_code TEXT,
        is_default INTEGER DEFAULT 0,
        created_at TEXT
    );

    CREATE TABLE IF NOT EXISTS categories (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        image TEXT,
        description TEXT,
        subcategories TEXT,
        display_order INTEGER DEFAULT 1,
        status TEXT DEFAULT 'active',
        created_at TEXT
    );

    CREATE TABLE IF NOT EXISTS products (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        sku TEXT UNIQUE,
        description TEXT,
        category TEXT,
        subcategory TEXT,
        brand TEXT,
        original_price REAL,
        selling_price REAL NOT NULL,
        discount_percentage REAL DEFAULT 0,
        stock INTEGER DEFAULT 0,
        status TEXT DEFAULT 'published',
        featured INTEGER DEFAULT 0,
        best_seller INTEGER DEFAULT 0,
        images TEXT,
        variants TEXT,
        rating REAL DEFAULT 5.0,
        reviews_count INTEGER DEFAULT 0,
        created_at TEXT,
        updated_at TEXT
    );

    CREATE TABLE IF NOT EXISTS banners (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        subtitle TEXT,
        badge_text TEXT,
        button_text TEXT,
        link_url TEXT,
        image_url TEXT,
        display_order INTEGER DEFAULT 1,
        is_active INTEGER DEFAULT 1,
        created_at TEXT
    );

    CREATE TABLE IF NOT EXISTS orders (
        id TEXT PRIMARY KEY,
        order_number TEXT UNIQUE NOT NULL,
        user_id TEXT,
        customer_name TEXT,
        customer_email TEXT,
        customer_phone TEXT,
        delivery_address TEXT,
        items TEXT,
        subtotal REAL,
        discount REAL,
        coupon_code TEXT,
        shipping_fee REAL,
        tax_amount REAL,
        total REAL,
        currency TEXT,
        payment_method TEXT,
        payment_status TEXT,
        order_status TEXT,
        tracking_number TEXT,
        carrier TEXT,
        settled_to_merchant_card TEXT,
        notes TEXT,
        created_at TEXT
    );

    CREATE TABLE IF NOT EXISTS coupons (
        id TEXT PRIMARY KEY,
        code TEXT UNIQUE NOT NULL,
        discount_type TEXT,
        discount_value REAL,
        min_order_value REAL,
        expiry_date TEXT,
        is_active INTEGER DEFAULT 1,
        usage_count INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS reviews (
        id TEXT PRIMARY KEY,
        product_id TEXT,
        product_name TEXT,
        customer_name TEXT,
        rating REAL,
        comment TEXT,
        date TEXT,
        verified INTEGER DEFAULT 1,
        status TEXT DEFAULT 'approved'
    );

    CREATE TABLE IF NOT EXISTS store_settings (
        id TEXT PRIMARY KEY,
        store_name TEXT,
        tagline TEXT,
        currency TEXT,
        currency_symbol TEXT,
        shipping_charge REAL,
        free_shipping_threshold REAL,
        tax_rate_percentage REAL,
        contact_email TEXT,
        contact_phone TEXT,
        address TEXT,
        seo_title TEXT,
        seo_description TEXT,
        show_promotional_bar INTEGER,
        promotional_bar_text TEXT
    );

    CREATE TABLE IF NOT EXISTS payment_gateway (
        id TEXT PRIMARY KEY,
        provider TEXT,
        provider_name TEXT,
        is_test_mode INTEGER,
        mode TEXT,
        merchant_id_masked TEXT,
        is_connected INTEGER,
        payout_status TEXT,
        payout_account_masked TEXT,
        merchant_card_last4 TEXT,
        merchant_card_brand TEXT,
        merchant_card_holder TEXT,
        bank_name TEXT,
        bank_iban_masked TEXT,
        updated_at TEXT
    );

    CREATE TABLE IF NOT EXISTS backups (
        id TEXT PRIMARY KEY,
        filename TEXT NOT NULL,
        size_bytes INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        description TEXT
    );
    """)
    conn.commit()

def sync_store_to_sqlite():
    if not os.path.exists(STORE_JSON_PATH):
        print(f"Store json not found at {STORE_JSON_PATH}")
        return

    with open(STORE_JSON_PATH, 'r', encoding='utf-8') as f:
        store = json.load(f)

    conn = sqlite3.connect(DB_PATH)
    init_tables(conn)
    cursor = conn.cursor()

    # Begin transaction
    cursor.execute("BEGIN TRANSACTION")

    try:
        # 1. Users & Addresses
        cursor.execute("DELETE FROM users")
        cursor.execute("DELETE FROM addresses")
        for u in store.get('users', []):
            pwd = u.get('password', '')
            if not pwd.startswith('hash_') and not pwd.startswith('$2'):
                import hashlib
                pwd = 'hash_sha256_' + hashlib.sha256(pwd.encode('utf-8')).hexdigest()[:32]
            
            cursor.execute("""
            INSERT INTO users (id, email, password_hash, full_name, role, phone, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                u.get('id'),
                u.get('email'),
                pwd,
                u.get('fullName'),
                u.get('role', 'customer'),
                u.get('phone', ''),
                u.get('createdAt', datetime.utcnow().isoformat()),
                u.get('updatedAt', datetime.utcnow().isoformat()),
            ))

            for addr in u.get('savedAddresses', []):
                cursor.execute("""
                INSERT INTO addresses (id, user_id, user_email, full_name, phone, country, state, city,
                                      street_address, house_number, apartment_details, postal_code, is_default, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    addr.get('id'),
                    u.get('id'),
                    u.get('email'),
                    addr.get('fullName', u.get('fullName')),
                    addr.get('phone', u.get('phone', '')),
                    addr.get('country', ''),
                    addr.get('state', ''),
                    addr.get('city', ''),
                    addr.get('streetAddress', ''),
                    addr.get('houseNumber', ''),
                    addr.get('apartmentDetails', ''),
                    addr.get('postalCode', ''),
                    1 if addr.get('isDefault') else 0,
                    u.get('createdAt', datetime.utcnow().isoformat()),
                ))

        # 2. Categories
        cursor.execute("DELETE FROM categories")
        for c in store.get('categories', []):
            cursor.execute("""
            INSERT INTO categories (id, name, slug, image, description, subcategories, display_order, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                c.get('id'),
                c.get('name'),
                c.get('slug'),
                c.get('image', ''),
                c.get('description', ''),
                json.dumps(c.get('subcategories', [])),
                c.get('displayOrder', 1),
                c.get('status', 'active'),
                datetime.utcnow().isoformat()
            ))

        # 3. Products
        cursor.execute("DELETE FROM products")
        for p in store.get('products', []):
            cursor.execute("""
            INSERT INTO products (id, name, sku, description, category, subcategory, brand, original_price,
                                  selling_price, discount_percentage, stock, status, featured, best_seller,
                                  images, variants, rating, reviews_count, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                p.get('id'),
                p.get('name'),
                p.get('sku', ''),
                p.get('description', ''),
                p.get('category', ''),
                p.get('subcategory', ''),
                p.get('brand', 'NOVORA'),
                p.get('originalPrice', p.get('sellingPrice', 0)),
                p.get('sellingPrice', 0),
                p.get('discountPercentage', 0),
                p.get('stock', 0),
                p.get('status', 'published'),
                1 if p.get('featured') else 0,
                1 if p.get('bestSeller') else 0,
                json.dumps(p.get('images', [])),
                json.dumps(p.get('variants', {})),
                p.get('rating', 5.0),
                p.get('reviewsCount', 0),
                p.get('createdAt', datetime.utcnow().isoformat()),
                p.get('updatedAt', datetime.utcnow().isoformat()),
            ))

        # 4. Banners
        cursor.execute("DELETE FROM banners")
        for b in store.get('banners', []):
            cursor.execute("""
            INSERT INTO banners (id, title, subtitle, badge_text, button_text, link_url, image_url, display_order, is_active, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                b.get('id'),
                b.get('title'),
                b.get('subtitle', ''),
                b.get('badgeText', ''),
                b.get('buttonText', 'Shop Now'),
                b.get('linkUrl', '/shop'),
                b.get('imageUrl', ''),
                b.get('displayOrder', 1),
                1 if b.get('isActive') else 0,
                datetime.utcnow().isoformat()
            ))

        # 5. Orders
        cursor.execute("DELETE FROM orders")
        for o in store.get('orders', []):
            cursor.execute("""
            INSERT INTO orders (id, order_number, user_id, customer_name, customer_email, customer_phone,
                                delivery_address, items, subtotal, discount, coupon_code, shipping_fee,
                                tax_amount, total, currency, payment_method, payment_status, order_status,
                                tracking_number, carrier, settled_to_merchant_card, notes, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                o.get('id'),
                o.get('orderNumber'),
                o.get('userId', ''),
                o.get('customer', {}).get('fullName', ''),
                o.get('customer', {}).get('email', ''),
                o.get('customer', {}).get('phone', ''),
                json.dumps(o.get('deliveryAddress', {})),
                json.dumps(o.get('items', [])),
                o.get('subtotal', 0),
                o.get('discount', 0),
                o.get('couponCode', ''),
                o.get('shippingFee', 0),
                o.get('taxAmount', 0),
                o.get('total', 0),
                o.get('currency', 'USD'),
                o.get('paymentMethod', ''),
                o.get('paymentStatus', 'pending'),
                o.get('orderStatus', 'Processing'),
                o.get('trackingNumber', ''),
                o.get('carrier', ''),
                o.get('settledToMerchantCard', ''),
                o.get('notes', ''),
                o.get('createdAt', datetime.utcnow().isoformat()),
            ))

        # 6. Coupons
        cursor.execute("DELETE FROM coupons")
        for cp in store.get('coupons', []):
            cursor.execute("""
            INSERT INTO coupons (id, code, discount_type, discount_value, min_order_value, expiry_date, is_active, usage_count)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                cp.get('id'),
                cp.get('code'),
                cp.get('discountType', 'percentage'),
                cp.get('discountValue', 0),
                cp.get('minOrderValue', 0),
                cp.get('expiryDate', '2027-12-31'),
                1 if cp.get('isActive') else 0,
                cp.get('usageCount', 0),
            ))

        # 7. Reviews
        cursor.execute("DELETE FROM reviews")
        for r in store.get('reviews', []):
            cursor.execute("""
            INSERT INTO reviews (id, product_id, product_name, customer_name, rating, comment, date, verified, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                r.get('id'),
                r.get('productId'),
                r.get('productName', ''),
                r.get('customerName', 'Patron'),
                r.get('rating', 5),
                r.get('comment', ''),
                r.get('date', datetime.utcnow().strftime('%Y-%m-%d')),
                1 if r.get('verified') else 0,
                r.get('status', 'approved')
            ))

        # 8. Store Settings
        cursor.execute("DELETE FROM store_settings")
        s = store.get('settings', {})
        cursor.execute("""
        INSERT INTO store_settings (id, store_name, tagline, currency, currency_symbol, shipping_charge,
                                    free_shipping_threshold, tax_rate_percentage, contact_email, contact_phone,
                                    address, seo_title, seo_description, show_promotional_bar, promotional_bar_text)
        VALUES ('main_settings', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            s.get('storeName', 'NOVORA'),
            s.get('tagline', ''),
            s.get('currency', 'USD'),
            s.get('currencySymbol', '$'),
            s.get('shippingCharge', 15),
            s.get('freeShippingThreshold', 150),
            s.get('taxRatePercentage', 5),
            s.get('contactEmail', 'concierge@novora.store'),
            s.get('contactPhone', ''),
            s.get('address', ''),
            s.get('seoTitle', 'NOVORA'),
            s.get('seoDescription', ''),
            1 if s.get('showPromotionalBar') else 0,
            s.get('promotionalBarText', '')
        ))

        # 9. Payment Gateway Settings
        cursor.execute("DELETE FROM payment_gateway")
        gw = store.get('paymentGateway', {})
        mc = gw.get('merchantCard', {})
        ba = gw.get('payoutAccount', {})
        cursor.execute("""
        INSERT INTO payment_gateway (id, provider, provider_name, is_test_mode, mode, merchant_id_masked,
                                     is_connected, payout_status, payout_account_masked, merchant_card_last4,
                                     merchant_card_brand, merchant_card_holder, bank_name, bank_iban_masked, updated_at)
        VALUES ('active_gateway', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            gw.get('provider', 'safepay'),
            gw.get('providerName', 'Safepay Pakistan & Global'),
            1 if gw.get('isTestMode') else 0,
            gw.get('mode', 'test'),
            gw.get('merchantIdMasked', ''),
            1 if gw.get('isConnected') else 0,
            gw.get('payoutStatus', 'Active'),
            gw.get('payoutAccountMasked', ''),
            mc.get('last4', '9922'),
            mc.get('brand', 'Visa'),
            mc.get('cardholderName', 'NOVORA Luxury E-Commerce'),
            ba.get('bankName', 'Meezan Bank Ltd'),
            ba.get('maskedIban', ''),
            datetime.utcnow().isoformat()
        ))

        conn.commit()
        print(f"[SQLite Sync] Successfully synchronized {len(store.get('products', []))} products, {len(store.get('orders', []))} orders, {len(store.get('users', []))} users to {DB_PATH}")

    except Exception as e:
        cursor.execute("ROLLBACK")
        print(f"[SQLite Sync Error] Failed transaction: {e}")
        raise e
    finally:
        conn.close()

def create_backup(description="Manual Admin Backup"):
    sync_store_to_sqlite()
    timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    backup_filename = f"novora_backup_{timestamp}.db"
    backup_filepath = os.path.join(BACKUPS_DIR, backup_filename)
    
    shutil.copy2(DB_PATH, backup_filepath)
    size_bytes = os.path.getsize(backup_filepath)

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    backup_id = f"bak_{int(datetime.utcnow().timestamp())}"
    cursor.execute("""
    INSERT INTO backups (id, filename, size_bytes, created_at, description)
    VALUES (?, ?, ?, ?, ?)
    """, (backup_id, backup_filename, size_bytes, datetime.utcnow().isoformat(), description))
    conn.commit()
    conn.close()

    print(json.dumps({
        "success": True,
        "backupId": backup_id,
        "filename": backup_filename,
        "sizeBytes": size_bytes,
        "createdAt": datetime.utcnow().isoformat(),
        "description": description
    }))

def list_backups():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, filename, size_bytes, created_at, description FROM backups ORDER BY created_at DESC")
    rows = cursor.fetchall()
    conn.close()

    backups = []
    for r in rows:
        backups.append({
            "id": r[0],
            "filename": r[1],
            "sizeBytes": r[2],
            "createdAt": r[3],
            "description": r[4]
        })
    print(json.dumps(backups))

def restore_backup(filename):
    backup_filepath = os.path.join(BACKUPS_DIR, filename)
    if not os.path.exists(backup_filepath):
        print(json.dumps({"success": False, "error": f"Backup file {filename} not found"}))
        return

    # Replace novora.db with the backup
    shutil.copy2(backup_filepath, DB_PATH)
    
    # Read back from SQLite to store.json
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # Re-export to store.json
    cursor.execute("SELECT id, email, password_hash, full_name, role, phone, created_at, updated_at FROM users")
    user_rows = cursor.fetchall()
    
    cursor.execute("SELECT id, user_id, full_name, phone, country, state, city, street_address, house_number, apartment_details, postal_code, is_default FROM addresses")
    addr_rows = cursor.fetchall()

    cursor.execute("SELECT id, name, sku, description, category, subcategory, brand, original_price, selling_price, discount_percentage, stock, status, featured, best_seller, images, variants, rating, reviews_count, created_at, updated_at FROM products")
    prod_rows = cursor.fetchall()

    cursor.execute("SELECT id, name, slug, image, description, subcategories, display_order, status FROM categories")
    cat_rows = cursor.fetchall()

    cursor.execute("SELECT id, title, subtitle, badge_text, button_text, link_url, image_url, display_order, is_active FROM banners")
    ban_rows = cursor.fetchall()

    cursor.execute("SELECT id, order_number, user_id, customer_name, customer_email, customer_phone, delivery_address, items, subtotal, discount, coupon_code, shipping_fee, tax_amount, total, currency, payment_method, payment_status, order_status, tracking_number, carrier, settled_to_merchant_card, notes, created_at FROM orders")
    ord_rows = cursor.fetchall()

    conn.close()

    # Reconstruct store.json
    with open(STORE_JSON_PATH, 'r', encoding='utf-8') as f:
        store = json.load(f)

    # Re-map restored data
    addresses_by_user = {}
    for a in addr_rows:
        u_id = a[1]
        if u_id not in addresses_by_user:
            addresses_by_user[u_id] = []
        addresses_by_user[u_id].append({
            "id": a[0],
            "fullName": a[2],
            "phone": a[3],
            "country": a[4],
            "state": a[5],
            "city": a[6],
            "streetAddress": a[7],
            "houseNumber": a[8],
            "apartmentDetails": a[9],
            "postalCode": a[10],
            "isDefault": bool(a[11])
        })

    store['users'] = [{
        "id": u[0],
        "email": u[1],
        "password": u[2],
        "fullName": u[3],
        "role": u[4],
        "phone": u[5],
        "savedAddresses": addresses_by_user.get(u[0], []),
        "wishlist": [],
        "createdAt": u[6],
        "updatedAt": u[7]
    } for u in user_rows]

    store['products'] = [{
        "id": p[0],
        "name": p[1],
        "sku": p[2],
        "description": p[3],
        "category": p[4],
        "subcategory": p[5],
        "brand": p[6],
        "originalPrice": p[7],
        "sellingPrice": p[8],
        "discountPercentage": p[9],
        "stock": p[10],
        "status": p[11],
        "featured": bool(p[12]),
        "bestSeller": bool(p[13]),
        "images": json.loads(p[14]) if p[14] else [],
        "variants": json.loads(p[15]) if p[15] else {},
        "rating": p[16],
        "reviewsCount": p[17],
        "createdAt": p[18],
        "updatedAt": p[19]
    } for p in prod_rows]

    with open(STORE_JSON_PATH, 'w', encoding='utf-8') as f:
        json.dump(store, f, indent=2)

    print(json.dumps({"success": True, "message": f"Successfully restored database from {filename}"}))

if __name__ == '__main__':
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == '--backup':
            desc = sys.argv[2] if len(sys.argv) > 2 else "Manual Admin Backup"
            create_backup(desc)
        elif cmd == '--list-backups':
            list_backups()
        elif cmd == '--restore' and len(sys.argv) > 2:
            restore_backup(sys.argv[2])
        else:
            sync_store_to_sqlite()
    else:
        sync_store_to_sqlite()
