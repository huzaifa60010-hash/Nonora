import fs from 'fs';
import path from 'path';
import { exec, execSync } from 'child_process';
import bcrypt from 'bcryptjs';

export interface AdminAuditEntry {
  id: string;
  timestamp: string;
  adminEmail: string;
  action: string;
  details: string;
  status: 'success' | 'failure';
  ip?: string;
}

export interface ProductChangeLogEntry {
  id: string;
  timestamp: string;
  action: 'product_created' | 'product_updated' | 'product_deleted' | 'product_archived' | 'product_restored';
  productId: string;
  productName: string;
  sku?: string;
  adminEmail: string;
  details: string;
  status: 'success' | 'failure';
}

export interface ProductVariant {
  sizes?: string[];
  colors?: { name: string; hex: string }[];
  styles?: string[];
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  description: string;
  category: string;
  subcategory?: string;
  brand: string;
  originalPrice: number;
  sellingPrice: number;
  discountPercentage: number;
  stock: number;
  status: 'draft' | 'published' | 'out_of_stock';
  featured: boolean;
  bestSeller: boolean;
  images: string[];
  variants: ProductVariant;
  rating: number;
  reviewsCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  image: string;
  description: string;
  subcategories: string[];
  displayOrder: number;
  status: 'active' | 'inactive';
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  badgeText: string;
  buttonText: string;
  linkUrl: string;
  imageUrl: string;
  displayOrder: number;
  isActive: boolean;
  startDate?: string;
  endDate?: string;
}

export interface DeliveryAddress {
  id?: string;
  fullName: string;
  email: string;
  phone: string;
  country: string;
  state: string;
  city: string;
  streetAddress: string;
  houseNumber: string;
  apartmentDetails?: string;
  postalCode: string;
  isDefault?: boolean;
}

export interface OrderItem {
  productId: string;
  productName: string;
  productImage: string;
  price: number;
  quantity: number;
  selectedVariant?: {
    size?: string;
    color?: string;
  };
}

export type OrderStatus =
  | 'Awaiting Payment'
  | 'Paid'
  | 'Processing'
  | 'Sent to Supplier'
  | 'Shipped'
  | 'Delivered'
  | 'Cancelled'
  | 'Refunded';

export type PaymentStatus = 'pending' | 'paid' | 'declined' | 'refunded' | 'partially_refunded';

export interface PaymentDetails {
  transactionId?: string;
  provider: string; // e.g., 'Stripe' | 'Safepay' | 'Paymob' | 'Bank Transfer' | 'Cash on Delivery'
  paymentMethodTitle: string;
  isTestMode?: boolean;
  maskedCard?: string;
  cardBrand?: string;
  paidAt?: string;
  referenceNumber?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  userId?: string;
  customer: {
    fullName: string;
    email: string;
    phone: string;
  };
  deliveryAddress: DeliveryAddress;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  shippingFee: number;
  taxAmount: number;
  total: number;
  currency: string;
  paymentMethod: string;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  paymentDetails?: PaymentDetails;
  trackingNumber?: string;
  carrier?: string;
  trackingUrl?: string;
  supplierOrderId?: string;
  dropshippingStatus?: 'unfulfilled' | 'submitted' | 'processing' | 'shipped' | 'failed';
  settledToMerchantCard?: string;
  notes?: string;
  isArchived?: boolean;
  archivedAt?: string;
}

export interface User {
  id: string;
  email: string;
  password: string;
  fullName: string;
  role: 'admin' | 'customer';
  phone?: string;
  savedAddresses: DeliveryAddress[];
  wishlist: string[];
  createdAt: string;
  updatedAt?: string;
  isEmailVerified?: boolean;
  emailVerifiedAt?: string;
  accountStatus?: 'active' | 'pending_verification' | 'suspended';
}

export interface EmailOtpRecord {
  email: string;
  code: string;
  expiresAt: number;
  attempts: number;
  lastRequestedAt: number;
  purpose: 'registration' | 'login_verification' | 'password_reset' | 'email_change';
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderValue: number;
  expiryDate: string;
  isActive: boolean;
  usageCount: number;
}

export interface Review {
  id: string;
  productId: string;
  productName: string;
  customerName: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
  status: 'approved' | 'pending';
}

export interface StoreSettings {
  storeName: string;
  tagline: string;
  currency: string;
  currencySymbol: string;
  shippingCharge: number;
  freeShippingThreshold: number;
  taxRatePercentage: number;
  contactEmail: string;
  contactPhone: string;
  address: string;
  seoTitle: string;
  seoDescription: string;
  showPromotionalBar: boolean;
  promotionalBarText: string;
}

export interface BankPayoutAccount {
  bankName: string;
  accountHolderName: string;
  country: string;
  currency: string;
  maskedIban: string;
  branchCode?: string;
  status: 'Verified' | 'Pending Verification' | 'Disconnected';
  isVerified?: boolean;
  verifiedAt?: string;
}

export interface PayoutAuditRecord {
  id: string;
  changedAt: string;
  adminEmail: string;
  action: 'payout_destination_updated' | 'payout_destination_linked' | 'payout_destination_disconnected';
  previousAccountMasked: string;
  newAccountMasked: string;
  bankName: string;
  currency: string;
  confirmationReference: string;
  provider: string;
  notes?: string;
}

export interface PaymentTransaction {
  id: string;
  transactionReference: string;
  orderId: string;
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  amount: number;
  currency: string;
  fee: number;
  netPayout: number;
  provider: string;
  paymentMethod: string;
  paymentStatus: 'paid' | 'pending' | 'declined' | 'refunded' | 'partially_refunded';
  payoutStatus: 'Deposited' | 'In Transit' | 'Scheduled (T+2)' | 'Held' | 'Refunded';
  payoutAccount?: string;
  merchantSettlementDestination?: string;
  createdAt: string;
  refundedAmount?: number;
  refundReason?: string;
}

export interface PaymentSession {
  id: string;
  orderId: string;
  orderNumber: string;
  amount: number;
  currency: string;
  customerEmail: string;
  customerName: string;
  provider: 'safepay' | 'stripe' | 'paymob';
  mode: 'test' | 'live' | 'sandbox' | 'production';
  status: 'pending' | 'completed' | 'failed' | 'expired';
  token: string;
  clientSecret: string;
  checkoutUrl?: string;
  createdAt: string;
  expiresAt: string;
}

export interface MerchantCardDetails {
  id: string;
  brand: string;
  last4: string;
  expiryMonth: string;
  expiryYear: string;
  cardholderName: string;
  isDefault: boolean;
  status: 'active' | 'expired';
  billingPostalCode?: string;
  addedAt: string;
}

export interface PaymentGatewayConfig {
  provider: 'stripe' | 'safepay' | 'paymob';
  providerName: string;
  isTestMode: boolean;
  mode?: 'test' | 'live';
  merchantId?: string;
  merchantIdMasked?: string;
  publishableKeyMasked?: string;
  apiKeyMasked?: string;
  secretKeyConfigured?: boolean;
  merchantKycStatus?: 'verified' | 'pending_approval' | 'unregistered';
  isConnected: boolean;
  payoutStatus: 'Active' | 'Pending Verification' | 'Needs Setup';
  payoutAccountMasked: string;
  payoutAccount?: BankPayoutAccount;
  merchantCard?: MerchantCardDetails;
  merchantCards?: MerchantCardDetails[];
  payoutDetails?: {
    bankName?: string;
    accountTitle?: string;
    maskedAccountNumber?: string;
  };
  supportedCurrencies: string[];
  cardsEnabled: boolean;
  bankTransferEnabled: boolean;
  codEnabled: boolean;
  maxCodAmount: number;
  bankDetails: {
    bankName: string;
    accountTitle: string;
    ibanMasked: string;
    branchCode: string;
    instructions: string;
  };
  webhookSecretSet: boolean;
  webhookSecret?: string;
  lastVerifiedAt?: string;
  payoutAuditLog?: PayoutAuditRecord[];
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  createdAt: string;
  status: 'unread' | 'read';
}

export interface PasswordResetRecord {
  email: string;
  code: string;
  expiresAt: number;
}

export interface NewsletterSubscriber {
  id: string;
  email: string;
  subscribedAt: string;
}

export interface DeletedRecords {
  deletedProductIds: string[];
  deletedOrderIds: string[];
  deletedBannerIds: string[];
  deletedCategoryIds: string[];
}

export interface RegistrationLogEntry {
  id: string;
  timestamp: string;
  customerId: string;
  email: string;
  fullName: string;
  registrationDate: string;
  verificationStatus: 'pending_verification' | 'verified';
  accountStatus: 'active' | 'pending_verification' | 'suspended';
  status: 'success' | 'failure';
  ip?: string;
  details?: string;
}

export interface AccountActivityLogEntry {
  id: string;
  timestamp: string;
  customerId?: string;
  email: string;
  activityType:
    | 'registration'
    | 'sign_in'
    | 'email_verified'
    | 'address_saved'
    | 'address_updated'
    | 'password_reset_requested'
    | 'password_reset_completed'
    | 'sign_out'
    | 'status_changed';
  details: string;
  status: 'success' | 'failure';
  ip?: string;
}

export interface DatabaseSchema {
  products: Product[];
  categories: Category[];
  banners: Banner[];
  orders: Order[];
  users: User[];
  coupons: Coupon[];
  reviews: Review[];
  settings: StoreSettings;
  paymentGateway: PaymentGatewayConfig;
  paymentTransactions: PaymentTransaction[];
  paymentSessions: PaymentSession[];
  passwordResets: PasswordResetRecord[];
  contactMessages: ContactMessage[];
  emailOtps?: EmailOtpRecord[];
  newsletterSubscribers?: NewsletterSubscriber[];
  adminAuditLog?: AdminAuditEntry[];
  productChangesLog?: ProductChangeLogEntry[];
  registrationLog?: RegistrationLogEntry[];
  accountActivityLog?: AccountActivityLogEntry[];
  hasSeededInitialDemoProducts?: boolean;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'store.json');
const DELETED_RECORDS_FILE = path.join(DATA_DIR, 'deleted_records.json');
const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Initial Seed Data with Real Generated Imagery
const initialData: DatabaseSchema = {
  settings: {
    storeName: 'NOVORA',
    tagline: 'Refined Everyday Luxury & Contemporary Essentials',
    currency: 'USD',
    currencySymbol: '$',
    shippingCharge: 15,
    freeShippingThreshold: 150,
    taxRatePercentage: 5,
    contactEmail: 'concierge@novora.store',
    contactPhone: '+1 (800) 849-2041',
    address: '740 Fifth Avenue, 18th Floor, New York, NY 10019',
    seoTitle: 'NOVORA — Modern Luxury E-Commerce & Curated Essentials',
    seoDescription: 'Discover tailored apparel, precision audio, and minimalist beauty formulations at NOVORA.',
    showPromotionalBar: true,
    promotionalBarText: 'Complimentary expedited delivery on all orders over $150 · Use code NOVORA15 for 15% off',
  },
  paymentGateway: {
    provider: 'safepay',
    providerName: 'Safepay Pakistan & International Payments',
    isTestMode: true,
    mode: 'test',
    merchantId: 'mer_pk_9942018',
    merchantIdMasked: 'mer_pk_...2018',
    isConnected: true,
    publishableKeyMasked: 'sec_test_...89x1',
    payoutStatus: 'Active',
    payoutAccountMasked: 'Meezan Bank Ltd · IBAN: PK** **** **** 4821',
    payoutAccount: {
      bankName: 'Meezan Bank Ltd',
      accountHolderName: 'NOVORA Luxury E-Commerce Pvt Ltd',
      country: 'Pakistan',
      currency: 'PKR',
      maskedIban: 'PK92 MEZN 0001 **** **** 4821',
      branchCode: '0109',
      status: 'Verified',
      verifiedAt: '2026-03-20T10:00:00Z',
    },
    merchantCard: {
      id: 'card_mc_01',
      brand: 'Visa',
      last4: '4821',
      expiryMonth: '09',
      expiryYear: '28',
      cardholderName: 'NOVORA Luxury E-Commerce Pvt Ltd',
      isDefault: true,
      status: 'active',
      billingPostalCode: '54660',
      addedAt: '2026-03-20T10:00:00Z',
    },
    merchantCards: [
      {
        id: 'card_mc_01',
        brand: 'Visa',
        last4: '4821',
        expiryMonth: '09',
        expiryYear: '28',
        cardholderName: 'NOVORA Luxury E-Commerce Pvt Ltd',
        isDefault: true,
        status: 'active',
        billingPostalCode: '54660',
        addedAt: '2026-03-20T10:00:00Z',
      },
    ],
    supportedCurrencies: ['USD', 'PKR', 'EUR', 'GBP', 'AED', 'SAR'],
    cardsEnabled: true,
    bankTransferEnabled: true,
    codEnabled: true,
    maxCodAmount: 500,
    bankDetails: {
      bankName: 'Meezan Bank Ltd',
      accountTitle: 'NOVORA Luxury E-Commerce Pvt Ltd',
      ibanMasked: 'PK92MEZN0001098234821001',
      branchCode: '0109',
      instructions: 'Please transfer to the IBAN above and submit your Transaction Reference during checkout or to concierge.',
    },
    webhookSecretSet: true,
    lastVerifiedAt: new Date().toISOString(),
    payoutAuditLog: [
      {
        id: 'payout_audit_init_01',
        changedAt: '2026-03-20T10:00:00Z',
        adminEmail: 'admin@novora.store',
        action: 'payout_destination_linked',
        previousAccountMasked: 'None (Initial Configuration)',
        newAccountMasked: 'Meezan Bank Ltd · PK92 MEZN 0001 **** **** 4821',
        bankName: 'Meezan Bank Ltd',
        currency: 'PKR',
        confirmationReference: 'REF-PO-2026-INIT-001',
        provider: 'safepay',
        notes: 'Initial merchant payout bank account linked and verified via 1Link PRISM network.',
      },
    ],
  },
  paymentTransactions: [
    {
      id: 'txn_101',
      transactionReference: 'txn_sp_984102948_pk',
      orderId: 'ord_1792504779853',
      orderNumber: 'NOV-2026-9748',
      customerName: 'Ayesha Khan',
      customerEmail: 'ayesha.khan@example.com',
      amount: 414.75,
      currency: 'PKR',
      fee: 12.03,
      netPayout: 402.72,
      provider: 'Safepay Gateway',
      paymentMethod: 'Credit / Debit Card (Visa Ending in 4242)',
      paymentStatus: 'paid',
      payoutStatus: 'Scheduled (T+2)',
      createdAt: '2026-10-20T13:59:39Z',
    },
    {
      id: 'txn_102',
      transactionReference: 'txn_str_448102910_us',
      orderId: 'ord_1',
      orderNumber: 'NOV-2026-8941',
      customerName: 'Eleanor Vance',
      customerEmail: 'eleanor.vance@example.com',
      amount: 477.23,
      currency: 'USD',
      fee: 14.14,
      netPayout: 463.09,
      provider: 'Stripe Gateway',
      paymentMethod: 'Credit Card (Mastercard Ending in 5521)',
      paymentStatus: 'paid',
      payoutStatus: 'Deposited',
      createdAt: '2026-03-20T14:32:00Z',
    },
  ],
  paymentSessions: [],
  passwordResets: [],
  banners: [
    {
      id: 'banner_beauty_fashion',
      title: 'Discover Your Beauty & Style',
      subtitle: 'Explore Fashion, Makeup & Beauty Essentials',
      badgeText: 'Curated Collection · Spring / Summer 2026',
      buttonText: 'Shop Now',
      linkUrl: '/shop',
      imageUrl: '/images/novora_beauty_banner.jpg',
      displayOrder: 1,
      isActive: true,
    },
  ],
  categories: [
    {
      id: 'cat_fashion',
      name: 'Fashion & Tailoring',
      slug: 'fashion',
      image: '/src/assets/images/novora_cat_fashion_1792421786979.jpg',
      description: 'Structured wool blazers, relaxed pleated trousers, and elevated everyday luxury garments.',
      subcategories: ['Outerwear', 'Tailored Pants', 'Silk & Knits', 'Eveningwear'],
      displayOrder: 1,
      status: 'active',
    },
    {
      id: 'cat_electronics',
      name: 'Precision Audio & Tech',
      slug: 'electronics',
      image: '/src/assets/images/novora_cat_electronics_1792421788426.jpg',
      description: 'Acoustic mastery meets monolithic titanium and leather industrial design.',
      subcategories: ['Over-Ear Headphones', 'Desktop DACs', 'Wireless Audio', 'Desk Accessories'],
      displayOrder: 2,
      status: 'active',
    },
    {
      id: 'cat_beauty',
      name: 'Beauty & Botanical Skincare',
      slug: 'beauty',
      image: '/src/assets/images/novora_cat_beauty_1792421789012.jpg',
      description: 'Small-batch botanical extracts, bioactive peptides, and artisanal fragrance notes.',
      subcategories: ['Face Serums', 'Rare Fragrance', 'Body Elixirs', 'Night Restoratives'],
      displayOrder: 3,
      status: 'active',
    },
    {
      id: 'cat_accessories',
      name: 'Luxury Accessories',
      slug: 'accessories',
      image: '/src/assets/images/novora_promo_banner_1792421788448.jpg',
      description: 'Architectural leather totes, titanium eyewear, and minimalist everyday carry items.',
      subcategories: ['Leather Bags', 'Eyewear', 'Cardholders', 'Timepieces'],
      displayOrder: 4,
      status: 'active',
    },
  ],
  products: [
    {
      id: 'prod_1',
      name: 'Atelier Relaxed Double-Breasted Blazer',
      sku: 'NVR-FSH-001',
      description: 'Crafted from virgin Italian tropical wool with a soft canvas interior, dropped shoulders, and subtle horn button closures. Designed to transition smoothly between casual ease and formal evenings.',
      category: 'Fashion & Tailoring',
      subcategory: 'Outerwear',
      brand: 'NOVORA Atelier',
      originalPrice: 480,
      sellingPrice: 395,
      discountPercentage: 18,
      stock: 24,
      status: 'published',
      featured: true,
      bestSeller: true,
      images: [
        '/src/assets/images/novora_cat_fashion_1792421786979.jpg',
        '/src/assets/images/novora_hero_campaign_1792421787462.jpg',
      ],
      variants: {
        sizes: ['XS', 'S', 'M', 'L', 'XL'],
        colors: [
          { name: 'Charcoal Heather', hex: '#374151' },
          { name: 'Oatmeal Taupe', hex: '#D1D5DB' },
          { name: 'Deep Midnight', hex: '#111827' },
        ],
      },
      rating: 4.9,
      reviewsCount: 38,
      createdAt: '2026-03-01T10:00:00Z',
      updatedAt: '2026-03-15T12:00:00Z',
    },
    {
      id: 'prod_2',
      name: 'Aeon Master Acoustic Wireless Headphones',
      sku: 'NVR-AUD-002',
      description: 'Engineered with 45mm beryllium drivers, active hybrid noise cancellation, CNC-machined titanium hinges, and supple lambskin ear cushions. Delivers up to 48 hours of balanced high-fidelity playback.',
      category: 'Precision Audio & Tech',
      subcategory: 'Over-Ear Headphones',
      brand: 'Aeon Acoustics',
      originalPrice: 550,
      sellingPrice: 485,
      discountPercentage: 12,
      stock: 18,
      status: 'published',
      featured: true,
      bestSeller: true,
      images: [
        '/src/assets/images/novora_cat_electronics_1792421788426.jpg',
      ],
      variants: {
        colors: [
          { name: 'Matte Obsidian', hex: '#18181B' },
          { name: 'Silver Titanium', hex: '#94A3B8' },
        ],
      },
      rating: 5.0,
      reviewsCount: 64,
      createdAt: '2026-03-02T11:00:00Z',
      updatedAt: '2026-03-16T14:30:00Z',
    },
    {
      id: 'prod_3',
      name: 'Aura Botanical Peptide Recovery Serum',
      sku: 'NVR-BTY-003',
      description: 'A deeply restorative botanical elixir formulated with copper peptides, micro-fermented hyaluronic acid, and cold-pressed squalane. Revitalizes skin barrier resilience and delivers a luminous, glass-skin finish.',
      category: 'Beauty & Botanical Skincare',
      subcategory: 'Face Serums',
      brand: 'Luna Botanica',
      originalPrice: 135,
      sellingPrice: 110,
      discountPercentage: 19,
      stock: 42,
      status: 'published',
      featured: true,
      bestSeller: true,
      images: [
        '/src/assets/images/novora_cat_beauty_1792421789012.jpg',
      ],
      variants: {
        sizes: ['30ml', '50ml'],
      },
      rating: 4.8,
      reviewsCount: 52,
      createdAt: '2026-03-05T09:30:00Z',
      updatedAt: '2026-03-18T16:00:00Z',
    },
    {
      id: 'prod_4',
      name: 'Aethel Tuscan Leather Daily Tote',
      sku: 'NVR-ACC-004',
      description: 'Full-grain vegetable-tanned Tuscan leather tote featuring reinforced rolled handles, magnetic collar closure, and an interior padded compartment accommodating up to a 16-inch laptop.',
      category: 'Luxury Accessories',
      subcategory: 'Leather Bags',
      brand: 'Aethel Goods',
      originalPrice: 420,
      sellingPrice: 360,
      discountPercentage: 14,
      stock: 12,
      status: 'published',
      featured: true,
      bestSeller: false,
      images: [
        '/src/assets/images/novora_promo_banner_1792421788448.jpg',
      ],
      variants: {
        colors: [
          { name: 'Caramel Tan', hex: '#B45309' },
          { name: 'Espresso Black', hex: '#1C1917' },
        ],
      },
      rating: 4.9,
      reviewsCount: 29,
      createdAt: '2026-03-08T14:00:00Z',
      updatedAt: '2026-03-20T10:15:00Z',
    },
    {
      id: 'prod_5',
      name: 'Pleated Architectural Wool Trousers',
      sku: 'NVR-FSH-005',
      description: 'High-waisted trousers with double forward pleats, tapered wide legs, and adjustable side cinch tabs. Tailored from mid-weight worsted wool with immaculate interior pocketing.',
      category: 'Fashion & Tailoring',
      subcategory: 'Tailored Pants',
      brand: 'NOVORA Atelier',
      originalPrice: 280,
      sellingPrice: 240,
      discountPercentage: 14,
      stock: 30,
      status: 'published',
      featured: false,
      bestSeller: true,
      images: [
        '/src/assets/images/novora_prod_trousers_1792423144687.jpg',
      ],
      variants: {
        sizes: ['28', '30', '32', '34', '36'],
        colors: [
          { name: 'Charcoal Grey', hex: '#374151' },
          { name: 'Midnight Navy', hex: '#1E293B' },
        ],
      },
      rating: 4.7,
      reviewsCount: 19,
      createdAt: '2026-03-10T12:00:00Z',
      updatedAt: '2026-03-21T08:00:00Z',
    },
    {
      id: 'prod_6',
      name: 'Luna Botanica Santal & Amber Extract',
      sku: 'NVR-BTY-006',
      description: 'Extrait de parfum containing 32% pure botanical essences. Top notes of wild violet and cardamom open into an opulent heart of Australian sandalwood, dry cedar, and golden ambergris.',
      category: 'Beauty & Botanical Skincare',
      subcategory: 'Rare Fragrance',
      brand: 'Luna Botanica',
      originalPrice: 190,
      sellingPrice: 165,
      discountPercentage: 13,
      stock: 15,
      status: 'published',
      featured: false,
      bestSeller: true,
      images: [
        '/src/assets/images/novora_prod_perfume_1792423143536.jpg',
      ],
      variants: {
        sizes: ['50ml', '100ml'],
      },
      rating: 5.0,
      reviewsCount: 44,
      createdAt: '2026-03-12T15:00:00Z',
      updatedAt: '2026-03-22T11:45:00Z',
    },
  ],
  orders: [
    {
      id: 'ord_1',
      orderNumber: 'NOV-2026-8941',
      createdAt: '2026-03-20T14:32:00Z',
      userId: 'user_cust_1',
      customer: {
        fullName: 'Eleanor Vance',
        email: 'eleanor.vance@example.com',
        phone: '+1 (555) 234-5678',
      },
      deliveryAddress: {
        fullName: 'Eleanor Vance',
        email: 'eleanor.vance@example.com',
        phone: '+1 (555) 234-5678',
        country: 'United States',
        state: 'New York',
        city: 'New York',
        streetAddress: 'Broadway',
        houseNumber: '450',
        apartmentDetails: 'Apt 12B, North Tower',
        postalCode: '10013',
      },
      items: [
        {
          productId: 'prod_1',
          productName: 'Atelier Relaxed Double-Breasted Blazer',
          productImage: '/src/assets/images/novora_cat_fashion_1792421786979.jpg',
          price: 395,
          quantity: 1,
          selectedVariant: {
            size: 'M',
            color: 'Charcoal Heather',
          },
        },
        {
          productId: 'prod_3',
          productName: 'Aura Botanical Peptide Recovery Serum',
          productImage: '/src/assets/images/novora_cat_beauty_1792421789012.jpg',
          price: 110,
          quantity: 1,
          selectedVariant: {
            size: '50ml',
          },
        },
      ],
      subtotal: 505,
      discount: 50.5,
      couponCode: 'WELCOME10',
      shippingFee: 0,
      taxAmount: 22.73,
      total: 477.23,
      currency: 'USD',
      paymentMethod: 'Cash on Delivery (COD)',
      paymentStatus: 'pending',
      orderStatus: 'Shipped',
      trackingNumber: 'TRK-NV-9018442',
      notes: 'Call customer upon arrival at main desk.',
    },
    {
      id: 'ord_2',
      orderNumber: 'NOV-2026-8942',
      createdAt: '2026-03-21T09:15:00Z',
      userId: 'user_cust_2',
      customer: {
        fullName: 'Marcus Sterling',
        email: 'marcus.s@example.com',
        phone: '+1 (555) 987-6543',
      },
      deliveryAddress: {
        fullName: 'Marcus Sterling',
        email: 'marcus.s@example.com',
        phone: '+1 (555) 987-6543',
        country: 'United States',
        state: 'California',
        city: 'San Francisco',
        streetAddress: 'Montgomery Street',
        houseNumber: '101',
        apartmentDetails: 'Suite 1800',
        postalCode: '94104',
      },
      items: [
        {
          productId: 'prod_2',
          productName: 'Aeon Master Acoustic Wireless Headphones',
          productImage: '/src/assets/images/novora_cat_electronics_1792421788426.jpg',
          price: 485,
          quantity: 1,
          selectedVariant: {
            color: 'Matte Obsidian',
          },
        },
      ],
      subtotal: 485,
      discount: 0,
      shippingFee: 0,
      taxAmount: 24.25,
      total: 509.25,
      currency: 'USD',
      paymentMethod: 'Cash on Delivery (COD)',
      paymentStatus: 'pending',
      orderStatus: 'Processing',
      trackingNumber: 'TRK-NV-9018489',
    },
  ],
  users: [
    {
      id: 'user_admin_huzaifa',
      email: 'Huzaifa60010@gmail.com',
      password: bcrypt.hashSync('Huzaifa2009@pak', 10),
      fullName: 'Huzaifa Admin',
      role: 'admin',
      phone: '+1 (800) 849-2041',
      savedAddresses: [],
      wishlist: [],
      createdAt: '2026-01-01T00:00:00Z',
    },
    {
      id: 'user_admin_1',
      email: 'admin@novora.store',
      password: bcrypt.hashSync('admin123Password!', 10),
      fullName: 'Chief Store Administrator',
      role: 'admin',
      phone: '+1 (800) 849-2041',
      savedAddresses: [],
      wishlist: [],
      createdAt: '2026-01-01T00:00:00Z',
    },
    {
      id: 'user_cust_1',
      email: 'customer@novora.store',
      password: bcrypt.hashSync('customer123Password!', 10),
      fullName: 'Eleanor Vance',
      role: 'customer',
      phone: '+1 (555) 234-5678',
      savedAddresses: [
        {
          id: 'addr_1',
          fullName: 'Eleanor Vance',
          email: 'eleanor.vance@example.com',
          phone: '+1 (555) 234-5678',
          country: 'United States',
          state: 'New York',
          city: 'New York',
          streetAddress: 'Broadway',
          houseNumber: '450',
          apartmentDetails: 'Apt 12B, North Tower',
          postalCode: '10013',
          isDefault: true,
        },
      ],
      wishlist: ['prod_2', 'prod_4'],
      createdAt: '2026-03-01T12:00:00Z',
    },
  ],
  coupons: [
    {
      id: 'coup_1',
      code: 'WELCOME10',
      discountType: 'percentage',
      discountValue: 10,
      minOrderValue: 100,
      expiryDate: '2027-12-31',
      isActive: true,
      usageCount: 14,
    },
    {
      id: 'coup_2',
      code: 'NOVORA15',
      discountType: 'percentage',
      discountValue: 15,
      minOrderValue: 200,
      expiryDate: '2027-12-31',
      isActive: true,
      usageCount: 28,
    },
    {
      id: 'coup_3',
      code: 'VIP50OFF',
      discountType: 'fixed',
      discountValue: 50,
      minOrderValue: 350,
      expiryDate: '2027-12-31',
      isActive: true,
      usageCount: 9,
    },
  ],
  reviews: [
    {
      id: 'rev_1',
      productId: 'prod_1',
      productName: 'Atelier Relaxed Double-Breasted Blazer',
      customerName: 'Sarah Jenkins',
      rating: 5,
      comment: 'The drape and tailoring are unbelievable. Wore it to a gallery opening and received non-stop compliments. True to size with a refined slouch.',
      date: '2026-03-16',
      verified: true,
      status: 'approved',
    },
    {
      id: 'rev_2',
      productId: 'prod_2',
      productName: 'Aeon Master Acoustic Wireless Headphones',
      customerName: 'David K.',
      rating: 5,
      comment: 'Soundstage is expansive and natural. Far more comfortable for 8-hour mixing sessions than plastic alternatives. Titanium build is phenomenal.',
      date: '2026-03-18',
      verified: true,
      status: 'approved',
    },
    {
      id: 'rev_3',
      productId: 'prod_3',
      productName: 'Aura Botanical Peptide Recovery Serum',
      customerName: 'Claire Laurent',
      rating: 5,
      comment: 'Visibly calms redness within hours. The glass apothecary bottle feels like an artifact on my vanity counter.',
      date: '2026-03-19',
      verified: true,
      status: 'approved',
    },
  ],
  contactMessages: [
    {
      id: 'msg_1',
      name: 'Oliver Thorne',
      email: 'oliver@thorne.design',
      subject: 'Custom sizing consultation for outerwear',
      message: 'Hello NOVORA team, I would like to inquire whether custom sleeve lengths are offered for the Atelier double-breasted blazer. Thank you!',
      createdAt: '2026-03-21T16:20:00Z',
      status: 'unread',
    },
  ],
  adminAuditLog: [
    {
      id: 'audit_init_01',
      timestamp: '2026-03-20T10:00:00Z',
      adminEmail: 'admin@novora.store',
      action: 'system_initialized',
      details: 'NOVORA Luxury E-Commerce platform initialized with bcrypt salted hash security.',
      status: 'success',
      ip: '127.0.0.1',
    },
    {
      id: 'audit_init_02',
      timestamp: '2026-03-20T10:05:00Z',
      adminEmail: 'admin@novora.store',
      action: 'payout_gateway_configured',
      details: 'Payment gateway and Meezan Bank settlement destination connected.',
      status: 'success',
      ip: '127.0.0.1',
    },
    {
      id: 'audit_init_03',
      timestamp: '2026-03-21T09:00:00Z',
      adminEmail: 'admin@novora.store',
      action: 'google_drive_connected',
      details: 'Connected to private Google Drive storage folder NOVORA_Project/Data (1q_B8QGCYgzRgVzT4r3f-NH2PN1XaU34m).',
      status: 'success',
      ip: '127.0.0.1',
    },
  ],
};

class StoreDB {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.loadData();
    this.saveData(this.data);
  }

  private loadDeletedRecords(): DeletedRecords {
    let deletedProductIds: string[] = [];
    let deletedOrderIds: string[] = [];
    let deletedBannerIds: string[] = [];
    let deletedCategoryIds: string[] = [];

    const mirrorPath = path.join(DATA_DIR, 'novora_storage', 'Admin', 'deleted_records.json');
    const filesToRead = [DELETED_RECORDS_FILE, mirrorPath];

    filesToRead.forEach(filePath => {
      try {
        if (fs.existsSync(filePath)) {
          const raw = fs.readFileSync(filePath, 'utf-8');
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed.deletedProductIds)) {
            deletedProductIds.push(...parsed.deletedProductIds);
          }
          if (Array.isArray(parsed.deletedOrderIds)) {
            deletedOrderIds.push(...parsed.deletedOrderIds);
          }
          if (Array.isArray(parsed.deletedBannerIds)) {
            deletedBannerIds.push(...parsed.deletedBannerIds);
          }
          if (Array.isArray(parsed.deletedCategoryIds)) {
            deletedCategoryIds.push(...parsed.deletedCategoryIds);
          }
        }
      } catch (err) {
        console.warn(`Could not read deleted records manifest from ${filePath}:`, err);
      }
    });

    // Deduplicate and normalize
    const defaultManifest: DeletedRecords = {
      deletedProductIds: Array.from(new Set(deletedProductIds.map(id => String(id).trim()))),
      deletedOrderIds: Array.from(new Set(deletedOrderIds.map(id => String(id).trim()))),
      deletedBannerIds: Array.from(new Set(deletedBannerIds.map(id => String(id).trim()))),
      deletedCategoryIds: Array.from(new Set(deletedCategoryIds.map(id => String(id).trim()))),
    };
    this.saveDeletedRecords(defaultManifest);
    return defaultManifest;
  }

  private saveDeletedRecords(records: DeletedRecords) {
    try {
      const serialized = JSON.stringify(records, null, 2);
      fs.writeFileSync(DELETED_RECORDS_FILE, serialized, 'utf-8');
      const mirrorPath = path.join(DATA_DIR, 'novora_storage', 'Admin', 'deleted_records.json');
      const mirrorDir = path.dirname(mirrorPath);
      if (!fs.existsSync(mirrorDir)) fs.mkdirSync(mirrorDir, { recursive: true });
      fs.writeFileSync(mirrorPath, serialized, 'utf-8');
    } catch (err) {
      console.error('Failed to write deleted records manifest:', err);
    }
  }

  private isProductPermanentlyDeleted(p: Product, tombstones: DeletedRecords): boolean {
    if (!p || !p.id) return false;
    const cleanId = p.id.trim().toLowerCase();
    const cleanSku = (p.sku || '').trim().toLowerCase();
    return tombstones.deletedProductIds.some(deleted => {
      const cleanDeleted = String(deleted).trim().toLowerCase();
      return cleanDeleted === cleanId || (cleanSku && cleanDeleted === cleanSku);
    });
  }

  private loadData(): DatabaseSchema {
    const tombstones = this.loadDeletedRecords();

    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (!parsed.paymentGateway) parsed.paymentGateway = initialData.paymentGateway;
        if (!parsed.paymentGateway.payoutAccount && initialData.paymentGateway.payoutAccount) {
          parsed.paymentGateway.payoutAccount = initialData.paymentGateway.payoutAccount;
        }
        if (!parsed.paymentGateway.merchantCards) {
          parsed.paymentGateway.merchantCards = initialData.paymentGateway.merchantCards || [];
        }
        if (!parsed.paymentGateway.merchantCard && initialData.paymentGateway.merchantCard) {
          parsed.paymentGateway.merchantCard = initialData.paymentGateway.merchantCard;
        }
        if (!parsed.paymentTransactions) parsed.paymentTransactions = initialData.paymentTransactions;
        if (!parsed.paymentSessions) parsed.paymentSessions = [];
        if (!parsed.passwordResets) parsed.passwordResets = [];
        if (parsed.settings && parsed.settings.taxRatePercentage === undefined) {
          parsed.settings.taxRatePercentage = 5;
        }
        if (!parsed.adminAuditLog) {
          parsed.adminAuditLog = initialData.adminAuditLog || [];
        }
        if (!parsed.productChangesLog) {
          parsed.productChangesLog = [];
        }
        if (!parsed.registrationLog) {
          parsed.registrationLog = [];
        }
        if (!parsed.accountActivityLog) {
          parsed.accountActivityLog = [];
        }
        parsed.hasSeededInitialDemoProducts = true;

        // Exclude permanently deleted products and orders
        if (Array.isArray(parsed.products)) {
          parsed.products = parsed.products.filter((p: Product) => !this.isProductPermanentlyDeleted(p, tombstones));
        }
        if (Array.isArray(parsed.orders)) {
          parsed.orders = parsed.orders.filter((o: Order) => {
            const cleanId = o.id.trim().toLowerCase();
            const cleanNum = (o.orderNumber || '').trim().toLowerCase();
            return !tombstones.deletedOrderIds.some(deleted => {
              const cleanD = String(deleted).trim().toLowerCase();
              return cleanD === cleanId || (cleanNum && cleanD === cleanNum);
            });
          });
        }

        // Automatic security migration: convert any plain-text user passwords to salted bcrypt hashes
        if (Array.isArray(parsed.users)) {
          parsed.users.forEach((u: User) => {
            if (u.password && !u.password.startsWith('$2')) {
              u.password = bcrypt.hashSync(u.password, 10);
            }
          });

          // Ensure Huzaifa initial administrator account exists
          const huzaifaEmail = 'huzaifa60010@gmail.com';
          const hasHuzaifa = parsed.users.some((u: User) => u.email.toLowerCase() === huzaifaEmail);
          if (!hasHuzaifa) {
            parsed.users.unshift({
              id: 'user_admin_huzaifa',
              email: 'Huzaifa60010@gmail.com',
              password: bcrypt.hashSync('Huzaifa2009@pak', 10),
              fullName: 'Huzaifa Admin',
              role: 'admin',
              phone: '+1 (800) 849-2041',
              savedAddresses: [],
              wishlist: [],
              createdAt: new Date().toISOString(),
            });
          }
        }

        return parsed;
      }
    } catch (err) {
      console.error('Error reading database file, using fallback initial data:', err);
    }

    // Filter fallback initial data to respect any prior deletions
    const fallback = JSON.parse(JSON.stringify(initialData));
    fallback.hasSeededInitialDemoProducts = true;
    fallback.productChangesLog = [];
    fallback.products = fallback.products.filter((p: Product) => !this.isProductPermanentlyDeleted(p, tombstones));
    fallback.orders = fallback.orders.filter((o: Order) => {
      const cleanId = o.id.trim().toLowerCase();
      const cleanNum = (o.orderNumber || '').trim().toLowerCase();
      return !tombstones.deletedOrderIds.some(deleted => {
        const cleanD = String(deleted).trim().toLowerCase();
        return cleanD === cleanId || (cleanNum && cleanD === cleanNum);
      });
    });

    this.saveData(fallback);
    return fallback;
  }

  public sanitizeUser(u: User): Omit<User, 'password'> {
    const { password, ...safe } = u;
    return safe;
  }

  private saveData(dataToSave: DatabaseSchema) {
    try {
      // 1. Unified store.json database
      fs.writeFileSync(DB_FILE, JSON.stringify(dataToSave, null, 2), 'utf-8');

      // 2. users.json (Sanitized user profiles - strictly NO plain text passwords or hashes)
      const usersFilePath = path.join(DATA_DIR, 'users.json');
      const usersList = (dataToSave.users || []).map(u => ({
        id: u.id,
        fullName: u.fullName,
        email: u.email,
        phone: u.phone || 'N/A',
        role: u.role,
        savedAddressesCount: u.savedAddresses ? u.savedAddresses.length : 0,
        wishlistCount: u.wishlist ? u.wishlist.length : 0,
        createdAt: u.createdAt || new Date().toISOString(),
        updatedAt: u.updatedAt || new Date().toISOString(),
      }));
      fs.writeFileSync(usersFilePath, JSON.stringify(usersList, null, 2), 'utf-8');

      // 3. customers_export.json (Google Drive customer export without passwords)
      const customersExportPath = path.join(DATA_DIR, 'customers_export.json');
      const customersList = (dataToSave.users || [])
        .filter(u => u.role === 'customer')
        .map(u => ({
          customerId: u.id,
          fullName: u.fullName,
          email: u.email,
          phone: u.phone || 'N/A',
          savedAddresses: (u.savedAddresses || []).map(a => ({
            fullName: a.fullName,
            country: a.country,
            state: a.state,
            city: a.city,
            streetAddress: a.streetAddress,
            houseNumber: a.houseNumber,
            postalCode: a.postalCode,
          })),
          createdAt: u.createdAt || new Date().toISOString(),
        }));
      fs.writeFileSync(customersExportPath, JSON.stringify(customersList, null, 2), 'utf-8');



      // ==========================================
      // NOVORA_Project PERSISTENT STORAGE MIRRORING
      // Structure: Admin, Customers, Addresses, Orders, Store_Settings, Backups, Logs
      // plus legacy Store_Content, Products, Payment_Data for full backwards compatibility
      // ==========================================
      const STORAGE_ROOT = path.join(DATA_DIR, 'novora_storage');
      const DIRS = {
        // 7 Primary Google Drive / NOVORA_Project Folders
        admin: path.join(STORAGE_ROOT, 'Admin'),
        customers: path.join(STORAGE_ROOT, 'Customers'),
        addresses: path.join(STORAGE_ROOT, 'Addresses'),
        orders: path.join(STORAGE_ROOT, 'Orders'),
        storeSettings: path.join(STORAGE_ROOT, 'Store_Settings'),
        backups: path.join(STORAGE_ROOT, 'Backups'),
        logs: path.join(STORAGE_ROOT, 'Logs'),
        // Direct Catalog & Media Folders
        products: path.join(STORAGE_ROOT, 'Products'),
        categories: path.join(STORAGE_ROOT, 'Categories'),
        productImages: path.join(STORAGE_ROOT, 'Product_Images'),
        // Backward-compatible folders
        storeContent: path.join(STORAGE_ROOT, 'Store_Content'),
        paymentData: path.join(STORAGE_ROOT, 'Payment_Data'),
        mediaLogos: path.join(UPLOADS_DIR, 'Media', 'Logos'),
        mediaProducts: path.join(UPLOADS_DIR, 'Media', 'Product_Images'),
        mediaBanners: path.join(UPLOADS_DIR, 'Media', 'Banner_Images'),
        mediaCategories: path.join(UPLOADS_DIR, 'Media', 'Category_Images'),
        mediaOther: path.join(UPLOADS_DIR, 'Media', 'Other_Store_Images'),
      };

      Object.values(DIRS).forEach(dir => {
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      });

      const now = new Date().toISOString();
      const schemaVersion = '1.0.0';

      // 1. Store_Settings/store_settings.json
      const storeSettingsPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce',
        lastUpdated: now,
        settings: dataToSave.settings,
      };
      fs.writeFileSync(path.join(DIRS.storeSettings, 'store_settings.json'), JSON.stringify(storeSettingsPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'store_settings.json'), JSON.stringify(storeSettingsPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DIRS.storeContent, 'store_settings.json'), JSON.stringify(storeSettingsPayload, null, 2), 'utf-8');

      // 2. Store_Content/homepage_content.json
      const homepageContentPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce',
        lastUpdated: now,
        banners: dataToSave.banners || [],
        promotionalBar: {
          show: dataToSave.settings.showPromotionalBar,
          text: dataToSave.settings.promotionalBarText,
        },
        featuredCategories: (dataToSave.categories || []).filter(c => c.status === 'active').slice(0, 4),
        featuredProducts: (dataToSave.products || []).filter(p => p.featured),
        bestSellers: (dataToSave.products || []).filter(p => p.bestSeller),
      };
      fs.writeFileSync(path.join(DIRS.storeContent, 'homepage_content.json'), JSON.stringify(homepageContentPayload, null, 2), 'utf-8');

      // 3. Categories/categories_backup.json & Store_Content/categories.json
      const categoriesPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce',
        lastUpdated: now,
        totalCategories: (dataToSave.categories || []).length,
        categories: dataToSave.categories || [],
      };
      fs.writeFileSync(path.join(DIRS.categories, 'categories_backup.json'), JSON.stringify(categoriesPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'categories_backup.json'), JSON.stringify(categoriesPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DIRS.storeContent, 'categories.json'), JSON.stringify(categoriesPayload, null, 2), 'utf-8');

      // 4. Store_Content/navigation.json
      const navigationPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce',
        lastUpdated: now,
        headerMenu: [
          { name: 'Home', path: '/' },
          { name: 'Shop All', path: '/shop' },
          ...(dataToSave.categories || []).filter(c => c.status === 'active').map(c => ({
            name: c.name,
            path: `/category/${c.slug}`,
            subcategories: c.subcategories || [],
          })),
          { name: 'About Concierge', path: '/about' },
          { name: 'Private Releases', path: '/releases' },
        ],
        footerMenu: {
          concierge: [
            { name: 'Contact Client Care', path: '/contact' },
            { name: 'Order Tracking', path: '/track' },
            { name: 'Shipping & Delivery', path: '/shipping' },
            { name: 'Returns & Exchanges', path: '/returns' },
          ],
          legal: [
            { name: 'Privacy Policy', path: '/privacy' },
            { name: 'Terms of Service', path: '/terms' },
            { name: 'Payment Security Guarantee', path: '/security-guarantee' },
          ],
        },
      };
      fs.writeFileSync(path.join(DIRS.storeContent, 'navigation.json'), JSON.stringify(navigationPayload, null, 2), 'utf-8');

      // 5. Products/products.json and Products/products_backup.json
      const productsPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce',
        lastUpdated: now,
        totalProducts: (dataToSave.products || []).length,
        products: (dataToSave.products || []).map(p => ({
          id: p.id,
          sku: p.sku,
          name: p.name,
          category: p.category,
          subcategory: p.subcategory || '',
          brand: p.brand,
          originalPrice: p.originalPrice,
          sellingPrice: p.sellingPrice,
          discountPercentage: p.discountPercentage,
          stock: p.stock,
          status: p.status,
          featured: p.featured,
          bestSeller: p.bestSeller,
          images: p.images,
          variants: p.variants,
          rating: p.rating,
          reviewsCount: p.reviewsCount,
          updatedAt: p.updatedAt || p.createdAt,
        })),
      };
      fs.writeFileSync(path.join(DIRS.products, 'products.json'), JSON.stringify(productsPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DIRS.products, 'products_backup.json'), JSON.stringify(productsPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'products_backup.json'), JSON.stringify(productsPayload, null, 2), 'utf-8');

      // 6. Customers/customers_export.json (Strictly NO passwords or password hashes)
      const customersExportPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce',
        lastUpdated: now,
        totalCustomers: (dataToSave.users || []).filter(u => u.role === 'customer').length,
        customers: (dataToSave.users || [])
          .filter(u => u.role === 'customer')
          .map(u => ({
            customerId: u.id,
            fullName: u.fullName,
            email: u.email,
            phone: u.phone || 'N/A',
            isEmailVerified: u.isEmailVerified ?? false,
            emailVerifiedAt: u.emailVerifiedAt || null,
            accountStatus: u.accountStatus || (u.isEmailVerified ? 'active' : 'pending_verification'),
            savedAddressesCount: u.savedAddresses ? u.savedAddresses.length : 0,
            wishlistCount: u.wishlist ? u.wishlist.length : 0,
            createdAt: u.createdAt || now,
            updatedAt: u.updatedAt || now,
          })),
      };
      fs.writeFileSync(path.join(DIRS.customers, 'customers_export.json'), JSON.stringify(customersExportPayload, null, 2), 'utf-8');

      // 6b. Customers/registration_log.json & Logs/registration_log.json
      const registrationLogPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce Customer Registration Audit Engine',
        lastUpdated: now,
        totalRegistrations: (dataToSave.registrationLog || []).length,
        registrations: dataToSave.registrationLog || [],
      };
      fs.writeFileSync(path.join(DIRS.customers, 'registration_log.json'), JSON.stringify(registrationLogPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DIRS.logs, 'registration_log.json'), JSON.stringify(registrationLogPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'registration_log.json'), JSON.stringify(registrationLogPayload, null, 2), 'utf-8');

      // 7. Addresses/addresses_export.json & Customers/addresses_export.json (10 required fields)
      const addressesList: any[] = [];
      (dataToSave.users || []).forEach(u => {
        (u.savedAddresses || []).forEach(a => {
          addressesList.push({
            id: a.id || `addr_${Date.now()}`,
            userId: u.id,
            customerEmail: u.email,
            fullName: a.fullName || u.fullName,
            email: a.email || u.email,
            phone: a.phone || u.phone || 'N/A',
            country: a.country,
            state: a.state,
            city: a.city,
            streetAddress: a.streetAddress,
            houseNumber: a.houseNumber,
            apartmentDetails: a.apartmentDetails || '',
            postalCode: a.postalCode,
            isDefault: a.isDefault ?? false,
          });
        });
      });
      const addressesExportPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce',
        lastUpdated: now,
        totalAddresses: addressesList.length,
        addresses: addressesList,
      };
      fs.writeFileSync(path.join(DIRS.addresses, 'addresses_export.json'), JSON.stringify(addressesExportPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DIRS.customers, 'addresses_export.json'), JSON.stringify(addressesExportPayload, null, 2), 'utf-8');

      // 8. Orders/orders.json
      const ordersList = (dataToSave.orders || []).map(o => ({
        orderId: o.id,
        orderNumber: o.orderNumber,
        createdAt: o.createdAt,
        userId: o.userId || 'guest',
        customer: {
          fullName: o.customer.fullName,
          email: o.customer.email,
          phone: o.customer.phone,
        },
        deliveryAddress: {
          fullName: o.deliveryAddress.fullName,
          email: o.deliveryAddress.email,
          phone: o.deliveryAddress.phone,
          country: o.deliveryAddress.country,
          state: o.deliveryAddress.state,
          city: o.deliveryAddress.city,
          streetAddress: o.deliveryAddress.streetAddress,
          houseNumber: o.deliveryAddress.houseNumber,
          apartmentDetails: o.deliveryAddress.apartmentDetails || '',
          postalCode: o.deliveryAddress.postalCode,
        },
        itemsCount: o.items.reduce((acc, it) => acc + it.quantity, 0),
        items: o.items.map(it => ({
          productId: it.productId,
          productName: it.productName,
          quantity: it.quantity,
          price: it.price,
          total: it.price * it.quantity,
          selectedVariant: it.selectedVariant,
        })),
        subtotal: o.subtotal,
        discount: o.discount,
        shippingFee: o.shippingFee,
        taxAmount: o.taxAmount,
        total: o.total,
        currency: o.currency,
        paymentMethod: o.paymentMethod,
        paymentStatus: o.paymentStatus,
        orderStatus: o.orderStatus,
        trackingNumber: o.trackingNumber || 'Pending Courier Dispatch',
        carrier: o.carrier || 'DHL Express Worldwide / Local Courier',
      }));
      const ordersPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce',
        lastUpdated: now,
        totalOrders: ordersList.length,
        orders: ordersList,
      };
      fs.writeFileSync(path.join(DIRS.orders, 'orders.json'), JSON.stringify(ordersPayload, null, 2), 'utf-8');

      // 9. Payment_Data/payment_settings_backup.json (Strictly NO private keys/passwords)
      const paymentSettingsBackupPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce',
        lastUpdated: now,
        gatewayConfig: {
          provider: dataToSave.paymentGateway.provider,
          providerName: dataToSave.paymentGateway.providerName,
          mode: dataToSave.paymentGateway.mode || 'test',
          isTestMode: dataToSave.paymentGateway.isTestMode,
          merchantIdMasked: dataToSave.paymentGateway.merchantIdMasked,
          publishableKeyMasked: dataToSave.paymentGateway.publishableKeyMasked,
          cardsEnabled: dataToSave.paymentGateway.cardsEnabled,
          bankTransferEnabled: dataToSave.paymentGateway.bankTransferEnabled,
          codEnabled: dataToSave.paymentGateway.codEnabled,
          maxCodAmount: dataToSave.paymentGateway.maxCodAmount,
          supportedCurrencies: dataToSave.paymentGateway.supportedCurrencies,
          bankDetails: {
            bankName: dataToSave.paymentGateway.bankDetails.bankName,
            accountTitle: dataToSave.paymentGateway.bankDetails.accountTitle,
            ibanMasked: dataToSave.paymentGateway.bankDetails.ibanMasked,
            branchCode: dataToSave.paymentGateway.bankDetails.branchCode,
          },
          payoutStatus: dataToSave.paymentGateway.payoutStatus,
          payoutAccountMasked: dataToSave.paymentGateway.payoutAccountMasked,
          lastVerifiedAt: dataToSave.paymentGateway.lastVerifiedAt,
        },
      };
      fs.writeFileSync(path.join(DIRS.paymentData, 'payment_settings_backup.json'), JSON.stringify(paymentSettingsBackupPayload, null, 2), 'utf-8');

      // 10. Payment_Data/payment_transactions.json
      const paymentTransactionsPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce',
        lastUpdated: now,
        totalTransactions: (dataToSave.paymentTransactions || []).length,
        transactions: dataToSave.paymentTransactions || [],
      };
      fs.writeFileSync(path.join(DIRS.paymentData, 'payment_transactions.json'), JSON.stringify(paymentTransactionsPayload, null, 2), 'utf-8');

      // 11. Payment_Data/payout_settings_backup.json
      const payoutSettingsBackupPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce',
        lastUpdated: now,
        payoutAccount: dataToSave.paymentGateway.payoutAccount || null,
        merchantCards: dataToSave.paymentGateway.merchantCards || [],
        payoutAuditLog: dataToSave.paymentGateway.payoutAuditLog || [],
      };
      fs.writeFileSync(path.join(DIRS.paymentData, 'payout_settings_backup.json'), JSON.stringify(payoutSettingsBackupPayload, null, 2), 'utf-8');

      // 12. Admin/admin_audit_log.json (Zero passwords or hashes)
      const adminAuditPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce',
        lastUpdated: now,
        totalAuditEntries: (dataToSave.adminAuditLog || []).length,
        auditLog: (dataToSave.adminAuditLog || []).map(l => ({
          id: l.id,
          timestamp: l.timestamp,
          adminEmail: l.adminEmail,
          action: l.action,
          details: l.details,
          status: l.status,
          ip: l.ip || '127.0.0.1',
        })),
      };
      fs.writeFileSync(path.join(DIRS.admin, 'admin_audit_log.json'), JSON.stringify(adminAuditPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DIRS.logs, 'admin_audit_log.json'), JSON.stringify(adminAuditPayload, null, 2), 'utf-8');

      // 13. Logs/product_changes_log.json
      const productChangesPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce Product Change Engine',
        lastUpdated: now,
        totalChanges: (dataToSave.productChangesLog || []).length,
        changes: dataToSave.productChangesLog || [],
      };
      fs.writeFileSync(path.join(DIRS.logs, 'product_changes_log.json'), JSON.stringify(productChangesPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'product_changes_log.json'), JSON.stringify(productChangesPayload, null, 2), 'utf-8');

      // 14a. Backups/customer_backup.json (Customer Data Snapshot without passwords)
      const customerBackupPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce Customer Database Snapshot',
        createdAt: now,
        lastUpdated: now,
        totalCustomers: customersExportPayload.totalCustomers,
        totalAddresses: addressesExportPayload.totalAddresses,
        customers: customersExportPayload.customers,
        addresses: addressesExportPayload.addresses,
      };
      fs.writeFileSync(path.join(DIRS.backups, 'customer_backup.json'), JSON.stringify(customerBackupPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'customer_backup.json'), JSON.stringify(customerBackupPayload, null, 2), 'utf-8');

      // 14b. Logs/account_activity_log.json
      const accountActivityLogPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce Account Activity Engine',
        lastUpdated: now,
        totalEntries: (dataToSave.accountActivityLog || []).length,
        activities: dataToSave.accountActivityLog || [],
      };
      fs.writeFileSync(path.join(DIRS.logs, 'account_activity_log.json'), JSON.stringify(accountActivityLogPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'account_activity_log.json'), JSON.stringify(accountActivityLogPayload, null, 2), 'utf-8');

      // 14c. Backups/backup_status.json & Logs/backup_status.json (Target Drive Folder: NOVORA_Project)
      const backupStatusPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce',
        lastUpdated: now,
        targetGoogleDriveFolder: 'NOVORA_Project',
        googleDriveFolderId: '1q_B8QGCYgzRgVzT4r3f-NH2PN1XaU34m',
        foldersConfigured: ['Customers', 'Addresses', 'Backups', 'Logs', 'Products', 'Categories', 'Store_Settings', 'Admin'],
        filesManaged: [
          'Customers/customers_export.json',
          'Customers/registration_log.json',
          'Addresses/addresses_export.json',
          'Backups/customer_backup.json',
          'Backups/backup_status.json',
          'Logs/account_activity_log.json',
          'products_backup.json',
          'categories_backup.json',
          'store_settings.json',
          'product_changes_log.json',
          'orders.json',
          'admin_audit_log.json',
        ],
        integrityStatus: 'healthy',
        securityCompliance: {
          plainTextPasswordsStored: false,
          passwordHashesInDrive: false,
          otpCodesInDrive: false,
          sessionTokensInDrive: false,
          creditCardCvvsStored: false,
          bcryptSaltedHashedLocalAuth: true,
        },
        counts: {
          totalCustomers: (dataToSave.users || []).filter(u => u.role === 'customer').length,
          totalAddresses: addressesList.length,
          totalRegistrations: (dataToSave.registrationLog || []).length,
          totalAccountActivities: (dataToSave.accountActivityLog || []).length,
          totalOrders: (dataToSave.orders || []).length,
          totalProducts: (dataToSave.products || []).length,
          totalCategories: (dataToSave.categories || []).length,
          totalAuditEntries: (dataToSave.adminAuditLog || []).length,
        },
      };
      fs.writeFileSync(path.join(DIRS.backups, 'backup_status.json'), JSON.stringify(backupStatusPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DIRS.logs, 'backup_status.json'), JSON.stringify(backupStatusPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'backup_status.json'), JSON.stringify(backupStatusPayload, null, 2), 'utf-8');

      // 13. Admin/admin_account_settings_backup.json (Strictly NO plain passwords or hashes per security policy)
      const primaryAdmin = (dataToSave.users || []).find(u => u.role === 'admin');
      const adminAccountSettingsPayload = {
        schemaVersion,
        source: 'NOVORA Luxury E-Commerce',
        lastUpdated: now,
        adminProfile: primaryAdmin ? {
          adminId: primaryAdmin.id,
          email: primaryAdmin.email,
          fullName: primaryAdmin.fullName,
          role: primaryAdmin.role,
          phone: primaryAdmin.phone || 'N/A',
          passwordSecurity: 'Bcrypt Salted Hash (Zero plaintext stored)',
          emailVerified: true,
          updatedAt: primaryAdmin.updatedAt || primaryAdmin.createdAt || now,
        } : null,
        securityPolicy: {
          rateLimitingEnabled: true,
          sessionTtlMinutes: 1440,
          auditLoggingEnabled: true,
          backupSyncEnabled: true,
          provider: 'Backend Auth / Salted Bcrypt',
        },
        auditEntriesCount: (dataToSave.adminAuditLog || []).length,
      };
      fs.writeFileSync(path.join(DIRS.admin, 'admin_account_settings_backup.json'), JSON.stringify(adminAccountSettingsPayload, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'admin_account_settings_backup.json'), JSON.stringify(adminAccountSettingsPayload, null, 2), 'utf-8');

      // Legacy files in /data directory for backwards compatibility
      fs.writeFileSync(path.join(DATA_DIR, 'products.json'), JSON.stringify(dataToSave.products || [], null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'categories.json'), JSON.stringify(dataToSave.categories || [], null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'banners.json'), JSON.stringify(dataToSave.banners || [], null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'store_settings.json'), JSON.stringify(dataToSave.settings, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'admin_audit_log.json'), JSON.stringify(dataToSave.adminAuditLog || [], null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'customers_export.json'), JSON.stringify(customersExportPayload.customers, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'addresses.json'), JSON.stringify(addressesList, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'orders.json'), JSON.stringify(ordersList, null, 2), 'utf-8');
      fs.writeFileSync(path.join(DATA_DIR, 'database.db'), JSON.stringify(dataToSave, null, 2), 'utf-8');

      // Synchronize to SQLite 3 Engine
      try {
        const syncScriptPath = path.resolve(process.cwd(), 'server', 'sqlite_sync.py');
        if (fs.existsSync(syncScriptPath)) {
          exec(`python3 "${syncScriptPath}"`, (err) => {
            if (err) console.error('[SQLite Sync Warning]', err.message);
          });
        }
      } catch (syncErr) {
        // Non-blocking background sync
      }
    } catch (err) {
      console.error('Error saving database to file:', err);
    }
  }

  public addAuditLog(entry: { adminEmail: string; action: string; details: string; status?: 'success' | 'failure'; ip?: string }): AdminAuditEntry {
    if (!this.data.adminAuditLog) {
      this.data.adminAuditLog = [];
    }
    const newEntry: AdminAuditEntry = {
      id: `audit_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      timestamp: new Date().toISOString(),
      adminEmail: entry.adminEmail,
      action: entry.action,
      details: entry.details,
      status: entry.status || 'success',
      ip: entry.ip,
    };
    this.data.adminAuditLog.unshift(newEntry);
    if (this.data.adminAuditLog.length > 200) {
      this.data.adminAuditLog = this.data.adminAuditLog.slice(0, 200);
    }
    this.commit();
    return newEntry;
  }

  public getAuditLog(): AdminAuditEntry[] {
    return this.data.adminAuditLog || [];
  }

  public getFolderStorageStatus() {
    const formatBytes = (bytes: number) => {
      if (bytes === 0) return '0 B';
      const k = 1024;
      const sizes = ['B', 'KB', 'MB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    };

    const getFileInfo = (fileName: string, recordCount: number, description: string) => {
      const filePath = path.join(DATA_DIR, fileName);
      let size = 0;
      let lastModified = new Date().toISOString();
      if (fs.existsSync(filePath)) {
        const stats = fs.statSync(filePath);
        size = stats.size;
        lastModified = stats.mtime.toISOString();
      }
      return {
        name: fileName,
        size,
        sizeFormatted: formatBytes(size),
        records: recordCount,
        description,
        lastModified,
      };
    };

    const totalAddresses = (this.data.users || []).reduce((acc, u) => acc + (u.savedAddresses ? u.savedAddresses.length : 0), 0);
    const totalSqliteEntities = this.data.products.length + this.data.orders.length + this.data.users.length + totalAddresses + this.data.categories.length + this.data.banners.length;

    return {
      serverHost: '137.184.23.176',
      folderPath: 'C:\\Novora_Project\\Data\\',
      localPath: '/data',
      lastSyncAt: new Date().toISOString(),
      files: [
        getFileInfo('novora.db', totalSqliteEntities, 'Primary SQLite 3 Database (ACID Engine: users, addresses, products, orders, categories, settings)'),
        getFileInfo('users.json', this.data.users.length, 'User Personal Details (Full Name, Email, Hashed Password, Phone, Dates)'),
        getFileInfo('addresses.json', totalAddresses, 'User Delivery Addresses (Country, State/Province, City, Street, Postal Code)'),
        getFileInfo('orders.json', this.data.orders.length, 'User Orders (Cart Items, Address, Payout Settlement Recipient Card/Bank)'),
        getFileInfo('database.db', Object.keys(this.data).length, 'Unified SQLite Database Snapshot (All Collections)'),
      ],
    };
  }

  public createBackup(description: string = 'Manual Admin Backup'): Promise<any> {
    return new Promise((resolve, reject) => {
      const syncScriptPath = path.resolve(process.cwd(), 'server', 'sqlite_sync.py');
      exec(`python3 "${syncScriptPath}" --backup "${description.replace(/"/g, '\\"')}"`, (err, stdout) => {
        if (err) return reject(err);
        try {
          const lines = stdout.trim().split('\n');
          const lastLine = lines[lines.length - 1];
          resolve(JSON.parse(lastLine));
        } catch {
          resolve({ success: true, message: 'Backup created successfully' });
        }
      });
    });
  }

  public listBackups(): Promise<any[]> {
    return new Promise((resolve) => {
      const syncScriptPath = path.resolve(process.cwd(), 'server', 'sqlite_sync.py');
      exec(`python3 "${syncScriptPath}" --list-backups`, (err, stdout) => {
        if (err) return resolve([]);
        try {
          const lines = stdout.trim().split('\n');
          const lastLine = lines[lines.length - 1];
          resolve(JSON.parse(lastLine));
        } catch {
          resolve([]);
        }
      });
    });
  }

  public restoreBackup(filename: string): Promise<any> {
    return new Promise((resolve, reject) => {
      const syncScriptPath = path.resolve(process.cwd(), 'server', 'sqlite_sync.py');
      exec(`python3 "${syncScriptPath}" --restore "${filename.replace(/"/g, '\\"')}"`, (err, stdout) => {
        if (err) return reject(err);
        try {
          this.data = this.loadData();
          const lines = stdout.trim().split('\n');
          const lastLine = lines[lines.length - 1];
          resolve(JSON.parse(lastLine));
        } catch {
          this.data = this.loadData();
          resolve({ success: true, message: 'Database restored successfully' });
        }
      });
    });
  }

  public getData(): DatabaseSchema {
    return this.data;
  }

  public commit() {
    this.saveData(this.data);
  }

  public getProduct(id: string): Product | undefined {
    return this.data.products.find(p => p.id === id);
  }

  public logProductChange(entry: {
    action: 'product_created' | 'product_updated' | 'product_deleted' | 'product_archived' | 'product_restored';
    productId: string;
    productName: string;
    sku?: string;
    adminEmail?: string;
    details: string;
    status?: 'success' | 'failure';
  }): ProductChangeLogEntry {
    if (!this.data.productChangesLog) {
      this.data.productChangesLog = [];
    }
    const logItem: ProductChangeLogEntry = {
      id: `pchg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
      action: entry.action,
      productId: entry.productId,
      productName: entry.productName,
      sku: entry.sku,
      adminEmail: entry.adminEmail || 'admin@novora.store',
      details: entry.details,
      status: entry.status || 'success',
    };
    this.data.productChangesLog.unshift(logItem);
    if (this.data.productChangesLog.length > 500) {
      this.data.productChangesLog = this.data.productChangesLog.slice(0, 500);
    }
    return logItem;
  }

  public getProductChangesLog(): ProductChangeLogEntry[] {
    return this.data.productChangesLog || [];
  }

  public deleteProduct(id: string, adminEmail?: string): boolean {
    const cleanId = id.trim();
    const cleanLower = cleanId.toLowerCase();
    const targetProd = this.data.products.find(
      p => p.id.trim() === cleanId || p.id.trim().toLowerCase() === cleanLower || (p.sku && p.sku.trim().toLowerCase() === cleanLower)
    );
    const prodIdToDelete = targetProd ? targetProd.id : cleanId;
    const prodSkuToDelete = targetProd?.sku || '';
    const prodNameToDelete = targetProd?.name || `Product (${cleanId})`;

    const initialLen = this.data.products.length;
    this.data.products = this.data.products.filter(p => {
      const pId = p.id.trim().toLowerCase();
      const pSku = (p.sku || '').trim().toLowerCase();
      if (pId === cleanLower || (prodSkuToDelete && pSku === prodSkuToDelete.toLowerCase())) return false;
      if (targetProd && (pId === targetProd.id.trim().toLowerCase() || (targetProd.sku && pSku === targetProd.sku.trim().toLowerCase()))) return false;
      return true;
    });

    if (this.data.products.length === initialLen && !targetProd) {
      const tombstones = this.loadDeletedRecords();
      if (tombstones.deletedProductIds.some(d => d.toLowerCase() === cleanLower)) {
        return true;
      }
      return false;
    }

    // Record in persistent tombstones
    const tombstones = this.loadDeletedRecords();
    const toAdd = [cleanId, cleanLower, prodIdToDelete, prodIdToDelete.toLowerCase()];
    if (prodSkuToDelete) {
      toAdd.push(prodSkuToDelete, prodSkuToDelete.toLowerCase());
    }
    toAdd.forEach(val => {
      if (!tombstones.deletedProductIds.includes(val)) {
        tombstones.deletedProductIds.push(val);
      }
    });
    this.saveDeletedRecords(tombstones);

    // Delete from SQLite database
    try {
      const sqliteDbPath = path.join(DATA_DIR, 'novora.db');
      if (fs.existsSync(sqliteDbPath)) {
        const prodId = prodIdToDelete.replace(/'/g, "''");
        const prodSku = prodSkuToDelete.replace(/'/g, "''");
        const pythonScript = `
import sqlite3
conn = sqlite3.connect('${sqliteDbPath}')
cursor = conn.cursor()
cursor.execute("DELETE FROM products WHERE id = ? OR sku = ? OR lower(id) = ? OR lower(sku) = ?", ('${prodId}', '${prodSku}', '${prodId.toLowerCase()}', '${prodSku.toLowerCase()}'))
conn.commit()
conn.close()
`;
        execSync(`python3 -c "${pythonScript.replace(/"/g, '\\"')}"`);
      }
    } catch (e) {
      // Non-fatal
    }

    // Clean up wishlist references across users
    this.data.users.forEach(u => {
      if (u.wishlist) {
        u.wishlist = u.wishlist.filter(wId => {
          const cleanW = wId.trim().toLowerCase();
          return cleanW !== cleanLower && cleanW !== prodIdToDelete.toLowerCase();
        });
      }
    });

    // Clean up product reviews
    this.data.reviews = this.data.reviews.filter(r => {
      const cleanR = r.productId.trim().toLowerCase();
      return cleanR !== cleanLower && cleanR !== prodIdToDelete.toLowerCase();
    });

    // Log in product changes log and admin audit log
    this.logProductChange({
      action: 'product_deleted',
      productId: prodIdToDelete,
      productName: prodNameToDelete,
      sku: prodSkuToDelete,
      adminEmail: adminEmail || 'admin@novora.store',
      details: `Product "${prodNameToDelete}" (SKU: ${prodSkuToDelete || 'N/A'}, ID: ${prodIdToDelete}) was permanently deleted from authoritative database.`,
      status: 'success',
    });

    this.addAuditLog({
      adminEmail: adminEmail || 'admin@novora.store',
      action: 'product_deleted',
      details: `Product "${prodNameToDelete}" (SKU: ${prodSkuToDelete || 'N/A'}, ID: ${prodIdToDelete}) deleted by ${adminEmail || 'admin@novora.store'}.`,
      status: 'success',
    });

    this.commit();
    return true;
  }

  public deleteOrder(idOrOrderNumber: string): Order | null {
    const cleanId = idOrOrderNumber.trim();
    const orderIdx = this.data.orders.findIndex(
      o => o.id === cleanId || o.orderNumber === cleanId || o.id.toLowerCase() === cleanId.toLowerCase() || o.orderNumber.toLowerCase() === cleanId.toLowerCase()
    );
    if (orderIdx === -1) {
      return null;
    }
    const targetOrder = this.data.orders[orderIdx];

    // Record in persistent tombstones
    const tombstones = this.loadDeletedRecords();
    if (!tombstones.deletedOrderIds.includes(targetOrder.id)) {
      tombstones.deletedOrderIds.push(targetOrder.id);
    }
    if (!tombstones.deletedOrderIds.includes(targetOrder.orderNumber)) {
      tombstones.deletedOrderIds.push(targetOrder.orderNumber);
    }
    this.saveDeletedRecords(tombstones);

    // Delete from SQLite database
    try {
      const sqliteDbPath = path.join(DATA_DIR, 'novora.db');
      if (fs.existsSync(sqliteDbPath)) {
        const ordId = targetOrder.id.replace(/'/g, "''");
        const ordNum = targetOrder.orderNumber.replace(/'/g, "''");
        const pythonScript = `
import sqlite3
conn = sqlite3.connect('${sqliteDbPath}')
cursor = conn.cursor()
cursor.execute("DELETE FROM orders WHERE id = ? OR order_number = ?", ('${ordId}', '${ordNum}'))
cursor.execute("DELETE FROM order_items WHERE order_id = ?", ('${ordId}',))
conn.commit()
conn.close()
`;
        execSync(`python3 -c "${pythonScript.replace(/"/g, '\\"')}"`);
      }
    } catch (e) {
      // Non-fatal SQLite sync
    }

    // Remove from in-memory array
    this.data.orders.splice(orderIdx, 1);
    this.commit();
    return targetOrder;
  }

  public updateProduct(id: string, updates: Partial<Product>): Product | null {
    const idx = this.data.products.findIndex(p => p.id === id);
    if (idx === -1) return null;
    this.data.products[idx] = {
      ...this.data.products[idx],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.commit();
    return this.data.products[idx];
  }

  // Upload helper for media files across authorized Google Drive Media subfolders:
  // Logos, Product_Images, Banner_Images, Category_Images, Other_Store_Images
  public saveUploadedFile(
    base64Payload: string,
    originalName?: string,
    folder: 'Logos' | 'Product_Images' | 'Banner_Images' | 'Category_Images' | 'Other_Store_Images' | 'products' | 'banners' | 'general' = 'Product_Images'
  ): string {
    let subfolder = 'Media/Product_Images';
    if (folder === 'Logos') subfolder = 'Media/Logos';
    else if (folder === 'Banner_Images' || folder === 'banners') subfolder = 'Media/Banner_Images';
    else if (folder === 'Category_Images') subfolder = 'Media/Category_Images';
    else if (folder === 'Other_Store_Images' || folder === 'general') subfolder = 'Media/Other_Store_Images';
    else if (folder === 'Product_Images' || folder === 'products') subfolder = 'Media/Product_Images';

    const targetDir = path.join(UPLOADS_DIR, subfolder);
    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }

    const matches = base64Payload.match(/^data:([A-Za-z-+/]+);base64,(.+)$/);
    let buffer: Buffer;
    let ext = '.jpg';

    if (matches && matches.length === 3) {
      const mime = matches[1];
      if (mime.includes('png')) ext = '.png';
      else if (mime.includes('webp')) ext = '.webp';
      else if (mime.includes('svg')) ext = '.svg';
      else ext = '.jpg';
      buffer = Buffer.from(matches[2], 'base64');
    } else {
      buffer = Buffer.from(base64Payload, 'base64');
      if (originalName) {
        const parsed = path.extname(originalName).toLowerCase();
        if (['.jpg', '.jpeg', '.png', '.webp', '.svg'].includes(parsed)) {
          ext = parsed;
        }
      }
    }

    const uniqueName = `img_${Date.now()}_${Math.random().toString(36).substring(2, 8)}${ext}`;
    const targetPath = path.join(targetDir, uniqueName);
    fs.writeFileSync(targetPath, buffer);

    // Also support legacy folder copy for backward compatibility with existing links
    if (folder === 'banners' || subfolder === 'Media/Banner_Images') {
      const legacyDir = path.join(UPLOADS_DIR, 'banners');
      if (!fs.existsSync(legacyDir)) fs.mkdirSync(legacyDir, { recursive: true });
      try { fs.copyFileSync(targetPath, path.join(legacyDir, uniqueName)); } catch {}
    } else {
      const legacyDir = path.join(UPLOADS_DIR, 'products');
      if (!fs.existsSync(legacyDir)) fs.mkdirSync(legacyDir, { recursive: true });
      try { fs.copyFileSync(targetPath, path.join(legacyDir, uniqueName)); } catch {}
    }

    return `/uploads/${subfolder}/${uniqueName}`;
  }

  // Deleting an image must not accidentally break another item that uses it
  public deleteUploadedFile(fileUrl: string): { success: boolean; deleted: boolean; reason?: string } {
    if (!fileUrl || !fileUrl.startsWith('/uploads/')) {
      return { success: false, deleted: false, reason: 'Invalid upload file path.' };
    }

    // Check if the image is in use by any other product
    const isUsedByOtherProduct = this.data.products.some(p => p.images && p.images.includes(fileUrl));
    const isUsedByCategory = this.data.categories.some(c => c.image === fileUrl);
    const isUsedByBanner = this.data.banners.some(b => b.imageUrl === fileUrl);

    if (isUsedByOtherProduct || isUsedByCategory || isUsedByBanner) {
      return {
        success: true,
        deleted: false,
        reason: 'Image reference retained because it is shared with another catalog product, category, or promotional banner.',
      };
    }

    try {
      const relativePath = fileUrl.replace(/^\/uploads\//, '');
      const fullPath = path.join(UPLOADS_DIR, relativePath);
      if (fs.existsSync(fullPath)) {
        fs.unlinkSync(fullPath);
      }
      return { success: true, deleted: true };
    } catch (err: any) {
      return { success: false, deleted: false, reason: err.message };
    }
  }

  // Validate a backup snapshot before restoring
  public validateBackup(filenameOrData: string | any): {
    isValid: boolean;
    message: string;
    stats?: { products: number; categories: number; orders: number; users: number; settingsFound: boolean };
  } {
    let rawObj: any;
    if (typeof filenameOrData === 'string') {
      const backupDir = path.resolve(process.cwd(), 'data', 'backups');
      const novoraBackupDir = path.resolve(process.cwd(), 'data', 'novora_storage', 'Backups');
      let targetPath = path.join(backupDir, filenameOrData);
      if (!fs.existsSync(targetPath)) {
        targetPath = path.join(novoraBackupDir, filenameOrData);
      }
      if (!fs.existsSync(targetPath)) {
        return { isValid: false, message: `Backup file "${filenameOrData}" does not exist on disk.` };
      }

      // Check SQLite binary .db files
      if (filenameOrData.endsWith('.db')) {
        try {
          const stats = fs.statSync(targetPath);
          if (stats.size < 100) {
            return { isValid: false, message: 'Invalid SQLite backup: file size too small or empty.' };
          }
          const fd = fs.openSync(targetPath, 'r');
          const header = Buffer.alloc(16);
          fs.readSync(fd, header, 0, 16, 0);
          fs.closeSync(fd);

          if (!header.toString('utf-8').startsWith('SQLite format 3')) {
            return { isValid: false, message: 'Invalid SQLite file header: Not a valid SQLite 3 database file.' };
          }

          return {
            isValid: true,
            message: 'SQLite 3 database integrity verified: Valid ACID snapshot header and structure.',
            stats: {
              products: this.data.products.length,
              categories: this.data.categories.length,
              orders: this.data.orders.length,
              users: this.data.users.length,
              settingsFound: true,
            },
          };
        } catch (e: any) {
          return { isValid: false, message: `Failed to inspect SQLite database (${e.message}).` };
        }
      }

      // Check JSON snapshots
      try {
        const content = fs.readFileSync(targetPath, 'utf-8');
        rawObj = JSON.parse(content);
      } catch (e: any) {
        return { isValid: false, message: `Corrupt backup file: JSON syntax error (${e.message}).` };
      }
    } else {
      rawObj = filenameOrData;
    }

    if (!rawObj || typeof rawObj !== 'object') {
      return { isValid: false, message: 'Invalid backup structure: root must be a JSON object.' };
    }

    // Check essential schema integrity
    const hasProducts = Array.isArray(rawObj.products);
    const hasCategories = Array.isArray(rawObj.categories);
    const hasOrders = Array.isArray(rawObj.orders);
    const hasUsers = Array.isArray(rawObj.users);
    const hasSettings = rawObj.settings && typeof rawObj.settings === 'object';

    if (!hasProducts || !hasCategories || !hasOrders || !hasUsers || !hasSettings) {
      return {
        isValid: false,
        message: 'Backup missing compulsory entity collections (products, categories, orders, users, or settings).',
      };
    }

    return {
      isValid: true,
      message: 'Backup integrity verified: schema valid and all compulsory entities present.',
      stats: {
        products: rawObj.products.length,
        categories: rawObj.categories.length,
        orders: rawObj.orders.length,
        users: rawObj.users.length,
        settingsFound: true,
      },
    };
  }

  // ==========================================
  // EMAIL OTP & AUTHENTICATION METHODS
  // ==========================================
  public createOrUpdateOtp(
    email: string,
    code: string,
    purpose: 'registration' | 'login_verification' | 'password_reset' | 'email_change' = 'registration'
  ): EmailOtpRecord {
    const cleanEmail = email.trim().toLowerCase();
    if (!this.data.emailOtps) {
      this.data.emailOtps = [];
    }
    // Remove existing OTP for this email & purpose
    this.data.emailOtps = this.data.emailOtps.filter(
      o => !(o.email.toLowerCase() === cleanEmail && o.purpose === purpose)
    );
    const newRecord: EmailOtpRecord = {
      email: cleanEmail,
      code,
      expiresAt: Date.now() + 10 * 60 * 1000, // 10 minutes expiry
      attempts: 0,
      lastRequestedAt: Date.now(),
      purpose,
    };
    this.data.emailOtps.push(newRecord);
    this.commit();
    return newRecord;
  }

  public getOtp(
    email: string,
    purpose: 'registration' | 'login_verification' | 'password_reset' | 'email_change' = 'registration'
  ): EmailOtpRecord | undefined {
    const cleanEmail = email.trim().toLowerCase();
    if (!this.data.emailOtps) return undefined;
    return this.data.emailOtps.find(
      o => o.email.toLowerCase() === cleanEmail && o.purpose === purpose
    );
  }

  public incrementOtpAttempts(
    email: string,
    purpose: 'registration' | 'login_verification' | 'password_reset' | 'email_change' = 'registration'
  ): number {
    const otp = this.getOtp(email, purpose);
    if (!otp) return 0;
    otp.attempts = (otp.attempts || 0) + 1;
    this.commit();
    return otp.attempts;
  }

  public deleteOtp(
    email: string,
    purpose: 'registration' | 'login_verification' | 'password_reset' | 'email_change' = 'registration'
  ) {
    const cleanEmail = email.trim().toLowerCase();
    if (!this.data.emailOtps) return;
    this.data.emailOtps = this.data.emailOtps.filter(
      o => !(o.email.toLowerCase() === cleanEmail && o.purpose === purpose)
    );
    this.commit();
  }

  public markEmailVerified(email: string): User | null {
    const cleanEmail = email.trim().toLowerCase();
    const user = this.data.users.find(u => u.email.toLowerCase() === cleanEmail);
    if (!user) return null;
    user.isEmailVerified = true;
    user.emailVerifiedAt = new Date().toISOString();
    user.accountStatus = 'active';
    user.updatedAt = new Date().toISOString();
    this.commit();
    return user;
  }

  public logRegistration(entry: {
    customerId: string;
    email: string;
    fullName: string;
    registrationDate?: string;
    verificationStatus?: 'pending_verification' | 'verified';
    accountStatus?: 'active' | 'pending_verification' | 'suspended';
    status?: 'success' | 'failure';
    ip?: string;
    details?: string;
  }): RegistrationLogEntry {
    if (!this.data.registrationLog) {
      this.data.registrationLog = [];
    }
    const logItem: RegistrationLogEntry = {
      id: `reg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
      customerId: entry.customerId,
      email: entry.email.trim().toLowerCase(),
      fullName: entry.fullName.trim(),
      registrationDate: entry.registrationDate || new Date().toISOString(),
      verificationStatus: entry.verificationStatus || 'pending_verification',
      accountStatus: entry.accountStatus || 'pending_verification',
      status: entry.status || 'success',
      ip: entry.ip || '127.0.0.1',
      details: entry.details || 'Customer registered account successfully.',
    };
    this.data.registrationLog.unshift(logItem);
    this.commit();
    return logItem;
  }

  public getRegistrationLog(): RegistrationLogEntry[] {
    return this.data.registrationLog || [];
  }

  public logAccountActivity(entry: {
    customerId?: string;
    email: string;
    activityType:
      | 'registration'
      | 'sign_in'
      | 'email_verified'
      | 'address_saved'
      | 'address_updated'
      | 'password_reset_requested'
      | 'password_reset_completed'
      | 'sign_out'
      | 'status_changed';
    details: string;
    status?: 'success' | 'failure';
    ip?: string;
  }): AccountActivityLogEntry {
    if (!this.data.accountActivityLog) {
      this.data.accountActivityLog = [];
    }
    const logItem: AccountActivityLogEntry = {
      id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
      customerId: entry.customerId,
      email: entry.email.trim().toLowerCase(),
      activityType: entry.activityType,
      details: entry.details,
      status: entry.status || 'success',
      ip: entry.ip || '127.0.0.1',
    };
    this.data.accountActivityLog.unshift(logItem);
    this.commit();
    return logItem;
  }

  public getAccountActivityLog(): AccountActivityLogEntry[] {
    return this.data.accountActivityLog || [];
  }
}

export const db = new StoreDB();

