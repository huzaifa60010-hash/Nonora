import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, Category, Banner, Order, User, StoreSettings, CartItem, DeliveryAddress } from '../types';
import { api, getAuthToken, setAuthToken, removeAuthToken } from '../services/api';
import { getDriveAccessToken, syncUserDataToGoogleDrive } from '../services/googleDrive';
import {
  firebaseRegisterCustomer,
  firebaseSignInUser,
  firebaseSignOutUser,
  subscribeToFirebaseAuth,
} from '../services/firebaseAuth';

export type ViewType = 
  | 'home' 
  | 'shop' 
  | 'category' 
  | 'product' 
  | 'cart' 
  | 'checkout' 
  | 'order-confirmation' 
  | 'account' 
  | 'admin' 
  | 'contact' 
  | 'about' 
  | 'faq' 
  | 'shipping-policy' 
  | 'returns-policy' 
  | 'privacy-policy' 
  | 'terms'
  | 'signin'
  | 'register'
  | 'verify-otp'
  | 'forgot-password';

interface ToastState {
  id: number;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface StoreContextType {
  // Navigation
  currentView: ViewType;
  activeProductId: string | null;
  activeCategorySlug: string | null;
  confirmedOrder: Order | null;
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  navigateTo: (view: ViewType, options?: { productId?: string; categorySlug?: string; confirmedOrder?: Order }) => void;
  goBack: (fallbackView?: ViewType) => void;

  // Catalog
  products: Product[];
  categories: Category[];
  banners: Banner[];
  settings: StoreSettings;
  isLoadingCatalog: boolean;
  refreshCatalog: () => Promise<void>;
  refreshCategories: () => Promise<void>;
  refreshBanners: () => Promise<void>;
  refreshSettings: () => Promise<void>;
  deleteProduct: (productId: string) => Promise<boolean>;
  publishProduct: (productId: string) => Promise<boolean>;
  unpublishProduct: (productId: string) => Promise<boolean>;

  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, selectedVariant?: { size?: string; color?: string }) => void;
  updateQuantity: (cartItemId: string, quantity: number) => void;
  removeFromCart: (cartItemId: string) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  isCartDrawerOpen: boolean;
  openCartDrawer: () => void;
  closeCartDrawer: () => void;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // Coupon
  appliedCoupon: {
    code: string;
    discountType: 'percentage' | 'fixed';
    discountValue: number;
    discountAmount: number;
  } | null;
  applyCouponCode: (code: string) => Promise<{ success: boolean; message: string }>;
  removeCouponCode: () => void;

  // Currency & Internationalization
  selectedCurrency: string;
  setSelectedCurrency: (curr: string) => void;
  formatPrice: (amountInUSD: number, targetCurrency?: string) => string;

  // Auth & Addresses
  currentUser: User | null;
  isAdmin: boolean;
  isAuthLoading: boolean;
  login: (email: string, pass: string) => Promise<{ success: boolean; requiresVerification?: boolean; error?: string }>;
  adminLogin: (email: string, pass: string) => Promise<{ success: boolean; error?: string }>;
  handleSignIn: (email: string, pass: string) => Promise<{ success: boolean; requiresVerification?: boolean; error?: string }>;
  loginWithGoogle: (email: string, fullName?: string, photoUrl?: string) => Promise<{ success: boolean; user?: User; error?: string }>;
  register: (payload: { email: string; password: string; confirmPassword?: string; fullName: string; phone?: string; agreedToTerms?: boolean }) => Promise<{ success: boolean; requiresVerification?: boolean; error?: string }>;
  logout: () => void;
  updateUserProfile: (data: Partial<User>) => Promise<boolean>;
  saveAddress: (address: DeliveryAddress) => Promise<boolean>;
  updateAddress: (id: string, address: Partial<DeliveryAddress>) => Promise<boolean>;
  updateUserAddress: (id: string, address: Partial<DeliveryAddress>) => Promise<boolean>;
  deleteAddress: (id: string) => Promise<boolean>;
  isAuthModalOpen: boolean;
  authModalMode: 'login' | 'register' | 'forgot' | 'verify-otp';
  openAuthModal: (mode?: 'login' | 'register' | 'forgot' | 'verify-otp') => void;
  closeAuthModal: () => void;
  pendingVerificationEmail: string | null;
  setPendingVerificationEmail: (email: string | null) => void;
  verifyEmailOtp: (code: string, purpose?: 'registration' | 'login_verification' | 'password_reset' | 'email_change') => Promise<{ success: boolean; error?: string }>;
  resendEmailOtp: (purpose?: 'registration' | 'login_verification' | 'password_reset' | 'email_change') => Promise<{ success: boolean; message?: string; error?: string }>;
  isAdminModalOpen: boolean;
  openAdminModal: () => void;
  closeAdminModal: () => void;
  enableAdminPortal: (details: { email: string; password: string; fullName?: string; securityKey?: string }) => Promise<{ success: boolean; error?: string }>;
  hasSeenWelcome: boolean;
  dismissWelcome: () => void;

  // Toasts
  toasts: ToastState[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: number) => void;
}

const defaultSettings: StoreSettings = {
  storeName: 'NOVORA',
  tagline: 'Refined Everyday Luxury',
  currency: 'USD',
  currencySymbol: '$',
  shippingCharge: 15,
  freeShippingThreshold: 150,
  taxRatePercentage: 5,
  contactEmail: 'concierge@novora.store',
  contactPhone: '+1 (800) 849-2041',
  address: '740 Fifth Avenue, 18th Floor, New York, NY 10019',
  seoTitle: 'NOVORA — Contemporary Luxury E-Commerce',
  seoDescription: 'Discover tailored fashion, precision audio, and curated luxury essentials.',
  showPromotionalBar: true,
  promotionalBarText: 'Complimentary expedited delivery on all orders over $150 · Code NOVORA15 for 15% off',
};

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const CURRENCY_RATES: Record<string, { symbol: string; rate: number; name: string }> = {
  USD: { symbol: '$', rate: 1.0, name: 'US Dollar (USD)' },
  PKR: { symbol: 'Rs ', rate: 278.5, name: 'Pakistani Rupee (PKR)' },
  EUR: { symbol: '€', rate: 0.92, name: 'Euro (EUR)' },
  GBP: { symbol: '£', rate: 0.79, name: 'British Pound (GBP)' },
  AED: { symbol: 'AED ', rate: 3.67, name: 'UAE Dirham (AED)' },
  SAR: { symbol: 'SAR ', rate: 3.75, name: 'Saudi Riyal (SAR)' },
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Helper to parse current URL path into view and parameters
  const parsePath = (path: string): { view: ViewType; productId?: string; categorySlug?: string } => {
    const clean = path.replace(/^\/+|\/+$/g, '');
    if (!clean) return { view: 'home' };
    if (clean === 'admin') return { view: 'admin' };
    if (clean === 'shop') return { view: 'shop' };
    if (clean === 'checkout' || clean === 'cart') return { view: 'checkout' };
    if (clean === 'account') return { view: 'account' };
    if (clean === 'contact') return { view: 'contact' };
    if (clean.startsWith('product/')) {
      return { view: 'product', productId: clean.slice('product/'.length) };
    }
    if (clean.startsWith('category/')) {
      return { view: 'shop', categorySlug: clean.slice('category/'.length) };
    }
    const policies: ViewType[] = ['about', 'faq', 'shipping-policy', 'returns-policy', 'privacy-policy', 'terms'];
    if (policies.includes(clean as ViewType)) {
      return { view: clean as ViewType };
    }
    return { view: 'home' };
  };

  const initialRoute = typeof window !== 'undefined' ? parsePath(window.location.pathname) : { view: 'home' as ViewType };

  // Navigation
  const [currentView, setCurrentView] = useState<ViewType>(initialRoute.view);
  const [activeProductId, setActiveProductId] = useState<string | null>(initialRoute.productId || null);
  const [activeCategorySlug, setActiveCategorySlug] = useState<string | null>(initialRoute.categorySlug || null);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Currency
  const [selectedCurrency, setSelectedCurrencyState] = useState<string>(() => {
    return localStorage.getItem('novora_currency') || 'USD';
  });
  const setSelectedCurrency = (curr: string) => {
    setSelectedCurrencyState(curr);
    localStorage.setItem('novora_currency', curr);
  };
  const formatPrice = (amountInUSD: number, targetCurrency?: string): string => {
    const curr = targetCurrency || selectedCurrency;
    const config = CURRENCY_RATES[curr] || CURRENCY_RATES.USD;
    const converted = amountInUSD * config.rate;
    if (curr === 'PKR') {
      return `${config.symbol}${Math.round(converted).toLocaleString()}`;
    }
    return `${config.symbol}${converted.toFixed(2)}`;
  };

  // Welcome Screen state (shown to first-time visitors who are not signed in)
  const [hasSeenWelcome, setHasSeenWelcome] = useState<boolean>(() => {
    return localStorage.getItem('novora_welcome_seen') === 'true';
  });
  const dismissWelcome = () => {
    setHasSeenWelcome(true);
    localStorage.setItem('novora_welcome_seen', 'true');
  };

  // Data
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [settings, setSettings] = useState<StoreSettings>(defaultSettings);
  const [isLoadingCatalog, setIsLoadingCatalog] = useState(true);

  // Cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('novora_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [isCartDrawerOpen, setIsCartDrawerOpen] = useState(false);

  // Wishlist
  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('novora_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Coupons
  const [appliedCoupon, setAppliedCoupon] = useState<{
    code: string;
    discountType: 'percentage' | 'fixed';
    discountValue: number;
    discountAmount: number;
  } | null>(null);

  // Auth
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'forgot' | 'verify-otp'>('login');
  const [pendingVerificationEmail, setPendingVerificationEmail] = useState<string | null>(null);
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [isAuthLoading, setIsAuthLoading] = useState(true);

  const openAdminModal = () => setIsAdminModalOpen(true);
  const closeAdminModal = () => setIsAdminModalOpen(false);


  // Toasts
  const [toasts, setToasts] = useState<ToastState[]>([]);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now() + Math.random();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: number) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Sync cart to local storage
  useEffect(() => {
    localStorage.setItem('novora_cart', JSON.stringify(cart));
  }, [cart]);

  // Sync wishlist to local storage
  useEffect(() => {
    localStorage.setItem('novora_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  // Calculate cart subtotal
  const cartSubtotal = cart.reduce((sum, item) => sum + item.product.sellingPrice * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Fetch initial catalog data
  const refreshCatalog = async () => {
    try {
      setIsLoadingCatalog(true);
      const [prods, cats, bans, sett] = await Promise.all([
        api.getProducts({ status: 'all' }),
        api.getCategories(),
        api.getBanners(),
        api.getSettings(),
      ]);
      setProducts(prods);
      setCategories(cats);
      setBanners(bans);
      setSettings(sett);
    } catch (err) {
      console.error('Error fetching catalog:', err);
    } finally {
      setIsLoadingCatalog(false);
    }
  };

  const refreshCategories = async () => {
    try {
      const cats = await api.getCategories();
      setCategories(cats);
    } catch (err) {
      console.error(err);
    }
  };

  const refreshBanners = async () => {
    try {
      const bans = await api.getBanners();
      setBanners(bans);
    } catch (err) {
      console.error(err);
    }
  };

  const refreshSettings = async () => {
    try {
      const sett = await api.getSettings();
      setSettings(sett);
    } catch (err) {
      console.error(err);
    }
  };

  const deleteProduct = async (productId: string): Promise<boolean> => {
    try {
      const res = await api.deleteProduct(productId);
      if (!res.success) {
        throw new Error(res.message || 'Server rejected product deletion.');
      }
      const cleanId = productId.trim();
      const cleanLower = cleanId.toLowerCase();
      // Immediately remove from catalog in memory across all screens
      setProducts(prev => prev.filter(p => p.id !== productId && p.id.trim() !== cleanId && p.id.trim().toLowerCase() !== cleanLower));
      // Remove from cart if customer has it added
      setCart(prev => {
        const next = prev.filter(item => item.product.id !== productId && item.product.id.trim() !== cleanId && item.product.id.trim().toLowerCase() !== cleanLower);
        try { localStorage.setItem('novora_cart', JSON.stringify(next)); } catch {}
        return next;
      });
      // Remove from wishlist
      setWishlist(prev => {
        const next = prev.filter(wId => wId !== productId && wId.trim() !== cleanId && wId.trim().toLowerCase() !== cleanLower);
        try { localStorage.setItem('novora_wishlist', JSON.stringify(next)); } catch {}
        return next;
      });
      // If customer is currently on PDP for this product, redirect to shop
      if (activeProductId === productId || activeProductId?.trim() === cleanId || activeProductId?.trim().toLowerCase() === cleanLower) {
        setActiveProductId(null);
        if (currentView === 'product') {
          setCurrentView('shop');
        }
      }
      // Re-fetch catalog from persistent database
      await refreshCatalog();
      showToast('Product permanently deleted from database and storefront.', 'success');
      return true;
    } catch (err: any) {
      showToast(err.message || 'Failed to delete product', 'error');
      return false;
    }
  };

  const publishProduct = async (productId: string): Promise<boolean> => {
    try {
      const res = await api.updateProduct(productId, { status: 'published' });
      setProducts(prev => prev.map(p => p.id === productId ? res.product : p));
      showToast(`Product "${res.product.name}" published! Live on customer storefront.`, 'success');
      return true;
    } catch (err: any) {
      showToast(err.message || 'Failed to publish product', 'error');
      return false;
    }
  };

  const unpublishProduct = async (productId: string): Promise<boolean> => {
    try {
      const res = await api.updateProduct(productId, { status: 'draft' });
      const cleanId = productId.trim();
      setProducts(prev => prev.map(p => p.id === productId ? res.product : p));
      // Remove from customer cart if unpublished
      setCart(prev => {
        const next = prev.filter(item => item.product.id !== productId && item.product.id.trim() !== cleanId);
        try { localStorage.setItem('novora_cart', JSON.stringify(next)); } catch {}
        return next;
      });
      if (activeProductId === productId || activeProductId?.trim() === cleanId) {
        if (!isAdmin) {
          setActiveProductId(null);
          if (currentView === 'product') {
            setCurrentView('shop');
          }
        }
      }
      showToast(`Product "${res.product.name}" unpublished and hidden from customer storefront.`, 'info');
      return true;
    } catch (err: any) {
      showToast(err.message || 'Failed to unpublish product', 'error');
      return false;
    }
  };

  // Check auth session on mount
  useEffect(() => {
    refreshCatalog();

    const token = getAuthToken();
    if (token) {
      api.getMe()
        .then(res => {
          if (res.user) {
            setCurrentUser(res.user);
            if (res.user.wishlist && res.user.wishlist.length > 0) {
              setWishlist(res.user.wishlist);
            }
          }
        })
        .catch(() => {
          removeAuthToken();
        });
    }
  }, []);

  // History tracking ref to determine if app can safely go back
  const navCountRef = React.useRef(0);

  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      if (event.state && event.state.view) {
        setCurrentView(event.state.view);
        setActiveProductId(event.state.productId || null);
        setActiveCategorySlug(event.state.categorySlug || null);
        if (event.state.confirmedOrder) setConfirmedOrder(event.state.confirmedOrder);
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }

      // If no state object, parse window location pathname
      const parsed = parsePath(window.location.pathname);
      setCurrentView(parsed.view);
      setActiveProductId(parsed.productId || null);
      setActiveCategorySlug(parsed.categorySlug || null);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Subscribe to Firebase Authentication state to keep customers signed in across reloads
  useEffect(() => {
    const unsubscribe = subscribeToFirebaseAuth(async (fbUser) => {
      if (fbUser && fbUser.email) {
        try {
          const res = await fetch('/api/auth/firebase-session', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              uid: fbUser.uid,
              email: fbUser.email,
              fullName: fbUser.displayName || fbUser.email.split('@')[0],
            }),
          });
          if (res.ok) {
            const data = await res.json();
            if (data.token && data.user) {
              setAuthToken(data.token);
              setCurrentUser(data.user);
            }
          }
        } catch (err) {
          console.warn('[StoreContext] Firebase session sync warning:', err);
        }
      }
      setIsAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const navigateTo = (view: ViewType, options?: { productId?: string; categorySlug?: string; confirmedOrder?: Order }) => {
    if (view === 'admin' && currentUser?.role !== 'admin') {
      showToast('Access denied. Administrator privileges required.', 'error');
      const fallback = currentUser ? 'home' : 'signin';
      setCurrentView(fallback);
      if (typeof window !== 'undefined') {
        window.history.replaceState({ view: fallback }, '', fallback === 'home' ? '/' : '/signin');
      }
      return;
    }
    navCountRef.current += 1;
    setCurrentView(view);
    if (options?.productId !== undefined) setActiveProductId(options.productId);
    if (options?.categorySlug !== undefined) setActiveCategorySlug(options.categorySlug);
    if (options?.confirmedOrder !== undefined) setConfirmedOrder(options.confirmedOrder);

    if (typeof window !== 'undefined') {
      let targetUrl = `/${view}`;
      if (view === 'home') targetUrl = '/';
      else if (view === 'admin') targetUrl = '/admin';
      else if (view === 'product' && options?.productId) targetUrl = `/product/${options.productId}`;
      else if (view === 'category' && options?.categorySlug) targetUrl = `/category/${options.categorySlug}`;

      const stateObj = {
        view,
        productId: options?.productId || null,
        categorySlug: options?.categorySlug || null,
        confirmedOrder: options?.confirmedOrder || null,
      };

      try {
        window.history.pushState(stateObj, '', targetUrl);
      } catch (err) {
        console.warn('History pushState:', err);
      }
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goBack = (fallbackView: ViewType = 'home') => {
    if (typeof window !== 'undefined' && (navCountRef.current > 0 || window.history.length > 1)) {
      window.history.back();
    } else {
      navigateTo(fallbackView);
    }
  };

  // Cart operations
  const addToCart = (product: Product, quantity = 1, selectedVariant?: { size?: string; color?: string }) => {
    if (product.stock <= 0) {
      showToast('This product is currently out of stock.', 'error');
      return;
    }

    const itemKey = `${product.id}_${selectedVariant?.size || ''}_${selectedVariant?.color || ''}`;
    
    setCart(prev => {
      const existingIdx = prev.findIndex(item => item.id === itemKey);
      if (existingIdx > -1) {
        const currentQty = prev[existingIdx].quantity;
        if (currentQty + quantity > product.stock) {
          showToast(`Cannot add more than ${product.stock} items (maximum stock reached).`, 'error');
          return prev;
        }
        const updated = [...prev];
        updated[existingIdx].quantity += quantity;
        return updated;
      } else {
        if (quantity > product.stock) {
          showToast(`Only ${product.stock} units available in stock.`, 'error');
          return prev;
        }
        return [
          ...prev,
          {
            id: itemKey,
            product,
            quantity,
            selectedVariant,
          },
        ];
      }
    });

    showToast(`Added "${product.name}" to your bag.`, 'success');
  };

  const updateQuantity = (cartItemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(cartItemId);
      return;
    }

    setCart(prev =>
      prev.map(item => {
        if (item.id === cartItemId) {
          if (quantity > item.product.stock) {
            showToast(`Maximum available stock is ${item.product.stock}.`, 'error');
            return { ...item, quantity: item.product.stock };
          }
          return { ...item, quantity };
        }
        return item;
      })
    );
  };

  const removeFromCart = (cartItemId: string) => {
    setCart(prev => prev.filter(item => item.id !== cartItemId));
    showToast('Item removed from shopping bag.', 'info');
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
  };

  const openCartDrawer = () => setIsCartDrawerOpen(true);
  const closeCartDrawer = () => setIsCartDrawerOpen(false);

  // Wishlist
  const toggleWishlist = async (productId: string) => {
    let next: string[];
    const isPresent = wishlist.includes(productId);
    if (isPresent) {
      next = wishlist.filter(id => id !== productId);
      showToast('Removed item from your wishlist.', 'info');
    } else {
      next = [...wishlist, productId];
      showToast('Saved item to your wishlist.', 'success');
    }
    setWishlist(next);

    if (currentUser) {
      try {
        await api.updateProfile({ wishlist: next });
      } catch (err) {
        console.error(err);
      }
    }
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  // Coupon validation
  const applyCouponCode = async (code: string) => {
    try {
      const res = await api.validateCoupon(code, cartSubtotal);
      if (res.valid) {
        setAppliedCoupon({
          code: res.code,
          discountType: res.discountType,
          discountValue: res.discountValue,
          discountAmount: res.discountAmount,
        });
        showToast(`Coupon "${res.code}" applied: Saved $${res.discountAmount.toFixed(2)}!`, 'success');
        return { success: true, message: `Saved $${res.discountAmount.toFixed(2)}` };
      } else {
        showToast(res.error || 'Invalid promotional code.', 'error');
        return { success: false, message: res.error || 'Invalid code' };
      }
    } catch (err: any) {
      showToast(err.message || 'Error validating coupon code.', 'error');
      return { success: false, message: err.message };
    }
  };

  const removeCouponCode = () => {
    setAppliedCoupon(null);
    showToast('Coupon code removed.', 'info');
  };

  const handleSignIn = async (email: string, pass: string) => {
    const cleanEmail = email.trim().toLowerCase();
    try {
      let fbResult;
      try {
        fbResult = await firebaseSignInUser(cleanEmail, pass);
      } catch (fbErr: any) {
        // If authorized administrator hasn't been provisioned in Firebase Auth yet, verify via backend and provision
        if (cleanEmail === 'huzaifa60010@gmail.com') {
          const adminRes = await api.adminLogin(cleanEmail, pass);
          if (adminRes.success) {
            try {
              fbResult = await firebaseRegisterCustomer('Huzaifa Admin', cleanEmail, pass);
            } catch {
              // Fallback to backend session if Firebase creation fails
              if (adminRes.token && adminRes.user) {
                setAuthToken(adminRes.token);
                setCurrentUser(adminRes.user);
              }
              setIsAuthModalOpen(false);
              showToast('Welcome back!', 'success');
              navigateTo('home');
              return { success: true };
            }
          } else {
            return { success: false, error: 'Invalid email or password.' };
          }
        } else {
          const code = fbErr?.code || '';
          if (code === 'auth/invalid-credential' || code === 'auth/wrong-password' || code === 'auth/user-not-found') {
            return { success: false, error: 'Invalid email or password. Please check your credentials or register.' };
          }
          if (code === 'auth/too-many-requests') {
            return { success: false, error: 'Too many failed attempts. Please try again later.' };
          }
          if (code === 'auth/network-request-failed') {
            return { success: false, error: 'Network error. Please check your internet connection.' };
          }
          return { success: false, error: fbErr.message || 'Sign in failed.' };
        }
      }

      const res = await fetch('/api/auth/firebase-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: fbResult.uid,
          email: fbResult.email,
          fullName: fbResult.fullName,
        }),
      });

      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.user || !data.token) {
        return { success: false, error: data.error || 'Failed to establish session.' };
      }

      setAuthToken(data.token);
      setCurrentUser(data.user);
      if (data.user?.wishlist && data.user.wishlist.length > 0) {
        setWishlist(data.user.wishlist);
      }
      setIsAuthModalOpen(false);
      showToast(`Welcome back, ${data.user.fullName}!`, 'success');
      refreshCatalog();
      navigateTo('home');

      const driveToken = getDriveAccessToken();
      if (driveToken) {
        syncUserDataToGoogleDrive(driveToken).catch(() => {});
      }

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Login failed' };
    }
  };


  const login = handleSignIn;

  const adminLogin = async (email: string, pass: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await api.adminLogin(email.trim(), pass);
      if (!res.success || !res.token || !res.user) {
        return { success: false, error: res.message || 'Incorrect email or password. Access denied.' };
      }
      setAuthToken(res.token);
      setCurrentUser(res.user);
      if (res.user.wishlist && res.user.wishlist.length > 0) {
        setWishlist(res.user.wishlist);
      }
      showToast('Admin clearance granted. Welcome to NOVORA Command Console!', 'success');
      refreshCatalog();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Incorrect email or password. Access denied.' };
    }
  };

  const loginWithGoogle = async (email: string, fullName?: string, photoUrl?: string) => {
    try {
      console.log('[StoreContext:loginWithGoogle] Initiating Google sign-in with email:', email);
      const res = await api.loginWithGoogle(email, fullName, photoUrl);
      console.log('[StoreContext:loginWithGoogle] Backend responded successfully for:', email);
      setAuthToken(res.token);
      setCurrentUser(res.user);
      if (res.user.wishlist && res.user.wishlist.length > 0) {
        setWishlist(res.user.wishlist);
      }
      setIsAuthModalOpen(false);
      showToast(`Welcome, ${res.user.fullName}!`, 'success');
      refreshCatalog();
      return { success: true, user: res.user };
    } catch (err: any) {
      console.error('[StoreContext:loginWithGoogle] Error during Google auth:', err);
      return { success: false, error: err.message || 'Google authentication failed' };
    }
  };

  const register = async (payload: { email: string; password: string; confirmPassword?: string; fullName: string; phone?: string; agreedToTerms?: boolean }) => {
    try {
      const fbResult = await firebaseRegisterCustomer(
        payload.fullName,
        payload.email,
        payload.password,
        payload.phone
      );

      const res = await fetch('/api/auth/firebase-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: fbResult.uid,
          email: fbResult.email,
          fullName: fbResult.fullName,
          phone: payload.phone,
          isNewRegistration: true,
        }),
      });

      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.user || !data.token) {
        return { success: false, error: data.error || 'Registration failed.' };
      }

      setAuthToken(data.token);
      setCurrentUser(data.user);
      setIsAuthModalOpen(false);
      showToast(`Welcome to NOVORA, ${data.user.fullName}!`, 'success');
      refreshCatalog();
      navigateTo('home');

      return { success: true };
    } catch (err: any) {
      const code = err?.code || '';
      if (code === 'auth/email-already-in-use') {
        return { success: false, error: 'An account with this email address already exists. Please sign in instead.' };
      }
      if (code === 'auth/weak-password') {
        return { success: false, error: 'Password is too weak. Please use at least 8 characters.' };
      }
      if (code === 'auth/invalid-email') {
        return { success: false, error: 'Please enter a valid email address.' };
      }
      return { success: false, error: err.message || 'Registration failed' };
    }
  };

  const verifyEmailOtp = async (code: string, purpose: 'registration' | 'login_verification' | 'password_reset' | 'email_change' = 'registration') => {
    const targetEmail = pendingVerificationEmail || currentUser?.email;
    if (!targetEmail) {
      return { success: false, error: 'Email address not found. Please re-enter your email.' };
    }
    try {
      const res = await api.verifyOtp(targetEmail, code, purpose);
      if (res.token && res.user) {
        setAuthToken(res.token);
        setCurrentUser(res.user);
        if (res.user.wishlist && res.user.wishlist.length > 0) {
          setWishlist(res.user.wishlist);
        }
        setIsAuthModalOpen(false);
        showToast(`Email verified! Welcome to NOVORA, ${res.user.fullName}!`, 'success');
        refreshCatalog();
        if (currentView === 'verify-otp' || currentView === 'signin' || currentView === 'register') {
          navigateTo('home');
        }

        const driveToken = getDriveAccessToken();
        if (driveToken) {
          syncUserDataToGoogleDrive(driveToken).catch(e => console.warn('[GoogleDrive:Sync] Notice:', e.message));
        }
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Verification failed.' };
    }
  };

  const resendEmailOtp = async (purpose: 'registration' | 'login_verification' | 'password_reset' | 'email_change' = 'registration') => {
    const targetEmail = pendingVerificationEmail || currentUser?.email;
    if (!targetEmail) {
      return { success: false, error: 'Email address not found.' };
    }
    try {
      const res = await api.resendOtp(targetEmail, purpose);
      showToast(res.message || 'Verification code dispatched to your inbox.', 'info');
      return { success: true, message: res.message };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to resend code.' };
    }
  };

  const logout = () => {
    if (currentUser?.role === 'admin') {
      api.adminLogout().catch(() => {});
    }
    firebaseSignOutUser().catch(() => {});
    removeAuthToken();
    setCurrentUser(null);
    setCurrentView('signin');
    if (typeof window !== 'undefined') {
      window.history.replaceState({ view: 'signin' }, '', '/signin');
    }
    showToast('Signed out successfully.', 'info');
  };

  const updateUserProfile = async (data: Partial<User>) => {
    try {
      const res = await api.updateProfile(data);
      setCurrentUser(res.user);
      showToast('Profile updated successfully.', 'success');
      return true;
    } catch (err: any) {
      showToast(err.message || 'Failed to update profile.', 'error');
      return false;
    }
  };

  const saveAddress = async (address: DeliveryAddress) => {
    const requestPayload = {
      endpoint: '/api/auth/address',
      method: 'POST',
      body: {
        fullName: address.fullName,
        email: address.email,
        phone: address.phone,
        country: address.country,
        state: address.state,
        city: address.city,
        streetAddress: address.streetAddress,
        houseNumber: address.houseNumber,
        apartmentDetails: address.apartmentDetails || '',
        postalCode: address.postalCode,
        isDefault: Boolean(address.isDefault),
      },
      timestamp: new Date().toISOString(),
    };

    console.log('[GoogleDrive:Address:Request] Submitting new delivery address:', requestPayload);
    try {
      const token = getAuthToken();
      const res = await fetch('/api/auth/address', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(address),
      });

      console.log(`[GoogleDrive:Address:Response] /api/auth/address -> HTTP ${res.status} (${res.statusText})`);
      const data = await res.json().catch(() => ({}));

      console.log('[GoogleDrive:Address:ResponsePayload]', {
        httpStatus: res.status,
        ok: res.ok,
        totalSavedAddresses: data.addresses ? data.addresses.length : 0,
      });

      if (!res.ok) {
        showToast(data.error || 'Failed to save address.', 'error');
        return false;
      }

      if (currentUser) {
        setCurrentUser({ ...currentUser, savedAddresses: data.addresses });
      }
      showToast('Delivery address saved successfully.', 'success');

      const driveToken = getDriveAccessToken();
      console.log('[GoogleDrive:Sync:AddressUpload:Status]', {
        driveTokenPresent: Boolean(driveToken),
        targetFolderId: '1q_B8QGCYgzRgVzT4r3f-NH2PN1XaU34m',
        action: 'Syncing addresses.json to Google Drive',
      });

      if (driveToken) {
        console.log('[GoogleDrive:Sync:AddressUpload:Request] Starting background upload of addresses.json to folder 1q_B8QGCYgzRgVzT4r3f-NH2PN1XaU34m...');
        syncUserDataToGoogleDrive(driveToken)
          .then(syncRes => {
            console.log('[GoogleDrive:Sync:AddressUpload:Response] Google Drive address sync success:', syncRes);
          })
          .catch(e => {
            console.error('[GoogleDrive:Sync:AddressUpload:Failure] Google Drive address sync error:', e.message);
          });
      }

      return true;
    } catch (err: any) {
      console.error('[GoogleDrive:Address:NetworkError] Error saving address:', err);
      showToast(err.message || 'Failed to save address.', 'error');
      return false;
    }
  };

  const updateUserAddress = async (id: string, address: Partial<DeliveryAddress>) => {
    const requestPayload = {
      endpoint: `/api/auth/address/${id}`,
      method: 'PUT',
      addressId: id,
      payload: {
        fullName: address.fullName,
        email: address.email,
        phone: address.phone,
        country: address.country,
        state: address.state,
        city: address.city,
        streetAddress: address.streetAddress,
        houseNumber: address.houseNumber,
        apartmentDetails: address.apartmentDetails,
        postalCode: address.postalCode,
        isDefault: address.isDefault,
      },
      timestamp: new Date().toISOString(),
    };

    console.log(`[GoogleDrive:Address:Request] Updating address ID: ${id}:`, requestPayload);
    try {
      const token = getAuthToken();
      const res = await fetch(`/api/auth/address/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(address),
      });

      console.log(`[GoogleDrive:Address:Response] /api/auth/address/${id} -> HTTP ${res.status} (${res.statusText})`);
      const data = await res.json().catch(() => ({}));

      console.log('[GoogleDrive:Address:ResponsePayload]', {
        httpStatus: res.status,
        ok: res.ok,
        addressId: id,
        totalSavedAddresses: data.addresses ? data.addresses.length : 0,
      });

      if (!res.ok) {
        console.error('[GoogleDrive:Address:Failure] Failed to update address:', data.error);
        showToast(data.error || 'Failed to update address.', 'error');
        return false;
      }

      if (currentUser) {
        setCurrentUser({ ...currentUser, savedAddresses: data.addresses });
      }
      showToast('Delivery address updated successfully.', 'success');

      const driveToken = getDriveAccessToken();
      console.log('[GoogleDrive:Sync:AddressUpload:Status]', {
        driveTokenPresent: Boolean(driveToken),
        targetFolderId: '1q_B8QGCYgzRgVzT4r3f-NH2PN1XaU34m',
        action: 'Syncing updated addresses.json to Google Drive',
      });

      if (driveToken) {
        console.log('[GoogleDrive:Sync:AddressUpload:Request] Starting upload of updated addresses.json to folder 1q_B8QGCYgzRgVzT4r3f-NH2PN1XaU34m...');
        syncUserDataToGoogleDrive(driveToken)
          .then(syncRes => {
            console.log('[GoogleDrive:Sync:AddressUpload:Response] Google Drive address sync success:', syncRes);
          })
          .catch(e => {
            console.error('[GoogleDrive:Sync:AddressUpload:Failure] Google Drive address sync error:', e.message);
          });
      }

      return true;
    } catch (err: any) {
      console.error('[GoogleDrive:Address:NetworkError] Exception updating address:', err);
      showToast(err.message || 'Failed to update address.', 'error');
      return false;
    }
  };

  const updateAddress = updateUserAddress;

  // Admin Page Option Enablement & Google Drive Persistence
  const enableAdminPortal = async (details: {
    email: string;
    password: string;
    fullName?: string;
    securityKey?: string;
  }) => {
    const payload = {
      endpoint: '/api/admin/enable-portal',
      method: 'POST',
      body: {
        email: details.email.trim().toLowerCase(),
        password: '[PROTECTED_SECURITY_PASSWORD]',
        fullName: details.fullName?.trim() || 'System Administrator',
        securityKey: details.securityKey || 'NOVORA-SEC-ADMIN-2026',
      },
      targetFolder: 'NOVORA_Project/Data (1q_B8QGCYgzRgVzT4r3f-NH2PN1XaU34m)',
      timestamp: new Date().toISOString(),
    };

    console.log('[Admin:EnablePortal:Request] Sending Admin enablement payload:', payload);

    try {
      const res = await fetch('/api/admin/enable-portal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(details),
      });

      console.log(`[Admin:EnablePortal:Response] Backend status code: HTTP ${res.status} (${res.statusText})`);
      const data = await res.json().catch(() => ({}));

      console.log('[Admin:EnablePortal:ResponsePayload]', {
        httpStatus: res.status,
        success: data.success,
        adminUser: data.user?.email,
        adminRole: data.user?.role,
        savedToSignInFolder: true,
      });

      if (!res.ok || !data.success) {
        showToast(data.error || 'Failed to enable Admin Portal.', 'error');
        return { success: false, error: data.error || 'Admin verification failed' };
      }

      setAuthToken(data.token);
      setCurrentUser(data.user);
      setIsAdminModalOpen(false);
      showToast('Admin Portal unlocked & details stored in sign-in folder and Google Drive!', 'success');
      navigateTo('admin');

      // Trigger immediate Google Drive upload for admin credentials
      const driveToken = getDriveAccessToken();
      if (driveToken) {
        console.log('[GoogleDrive:AdminSync:Request] Triggering cloud upload for admin_credentials.json to folder 1q_B8QGCYgzRgVzT4r3f-NH2PN1XaU34m...');
        syncUserDataToGoogleDrive(driveToken)
          .then(res => console.log('[GoogleDrive:AdminSync:Response] Complete:', res.message))
          .catch(e => console.warn('[GoogleDrive:AdminSync:Notice]', e.message));
      } else {
        console.log('[GoogleDrive:AdminSync:Notice] Connect Google Drive in Admin Panel to upload admin_credentials.json directly to cloud folder.');
      }

      return { success: true };
    } catch (err: any) {
      console.error('[Admin:EnablePortal:NetworkError]', err);
      showToast(err.message || 'Error communicating with admin auth service.', 'error');
      return { success: false, error: err.message };
    }
  };


  const deleteAddress = async (id: string) => {
    try {
      const res = await api.deleteAddress(id);
      if (currentUser) {
        setCurrentUser({ ...currentUser, savedAddresses: res.addresses });
      }
      showToast('Delivery address removed.', 'info');

      const driveToken = getDriveAccessToken();
      if (driveToken) {
        syncUserDataToGoogleDrive(driveToken).catch(e => console.warn('[GoogleDrive:Sync] Notice:', e.message));
      }

      return true;
    } catch (err: any) {
      showToast(err.message || 'Failed to remove address.', 'error');
      return false;
    }
  };

  const openAuthModal = (mode: 'login' | 'register' | 'forgot' | 'verify-otp' = 'login') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };
  const closeAuthModal = () => setIsAuthModalOpen(false);

  const isAdmin = currentUser?.role === 'admin';

  return (
    <StoreContext.Provider
      value={{
        currentView,
        activeProductId,
        activeCategorySlug,
        confirmedOrder,
        searchTerm,
        setSearchTerm,
        navigateTo,
        goBack,
        products,
        categories,
        banners,
        settings,
        isLoadingCatalog,
        refreshCatalog,
        refreshCategories,
        refreshBanners,
        refreshSettings,
        deleteProduct,
        publishProduct,
        unpublishProduct,
        cart,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart,
        cartCount,
        cartSubtotal,
        isCartDrawerOpen,
        openCartDrawer,
        closeCartDrawer,
        wishlist,
        toggleWishlist,
        isInWishlist,
        appliedCoupon,
        applyCouponCode,
        removeCouponCode,
        selectedCurrency,
        setSelectedCurrency,
        formatPrice,
        currentUser,
        isAdmin,
        isAuthLoading,
        login,
        adminLogin,
        handleSignIn,
        loginWithGoogle,
        register,
        logout,
        updateUserProfile,
        saveAddress,
        updateAddress,
        updateUserAddress,
        deleteAddress,
        isAuthModalOpen,
        authModalMode,
        openAuthModal,
        closeAuthModal,
        pendingVerificationEmail,
        setPendingVerificationEmail,
        verifyEmailOtp,
        resendEmailOtp,
        isAdminModalOpen,
        openAdminModal,
        closeAdminModal,
        enableAdminPortal,
        hasSeenWelcome,
        dismissWelcome,
        toasts,
        showToast,
        removeToast,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
