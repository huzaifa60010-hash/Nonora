import { useEffect, useRef } from 'react';

const FOCUSABLE_SELECTOR = [
  'a[href]',
  'area[href]',
  'input:not([disabled]):not([type="hidden"])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  'button:not([disabled])',
  'iframe',
  'object',
  'embed',
  '[tabindex]:not([tabindex="-1"])',
  '[contenteditable]',
].join(', ');

interface UseFocusTrapOptions {
  isOpen: boolean;
  onClose?: () => void;
  initialFocusRef?: React.RefObject<HTMLElement | null>;
  returnFocus?: boolean;
}

/**
 * WCAG-compliant Focus Trap and Keyboard Management Hook
 * - Traps Tab / Shift+Tab cycling within modal boundaries
 * - Closes modal on Escape key press
 * - Auto-focuses the initial element or the first focusable element ONCE upon opening
 * - Preserves active typing focus without interruption or focus-stealing during input typing
 * - Restores focus to the trigger element when the modal is closed
 */
export function useFocusTrap<T extends HTMLElement = HTMLDivElement>({
  isOpen,
  onClose,
  initialFocusRef,
  returnFocus = true,
}: UseFocusTrapOptions) {
  const containerRef = useRef<T | null>(null);
  const previouslyFocusedElementRef = useRef<HTMLElement | null>(null);
  const wasOpenRef = useRef(false);

  // Keep latest callbacks/refs in refs so changes don't re-trigger focus logic or steal focus on typing
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  const initialFocusRefLatest = useRef(initialFocusRef);
  initialFocusRefLatest.current = initialFocusRef;

  const returnFocusRef = useRef(returnFocus);
  returnFocusRef.current = returnFocus;

  // Handle focus initiation and restoration ONLY when isOpen transitions
  useEffect(() => {
    if (!isOpen) {
      if (wasOpenRef.current) {
        // Modal just transitioned from open to closed -> restore previous focus
        wasOpenRef.current = false;
        if (
          returnFocusRef.current &&
          previouslyFocusedElementRef.current &&
          typeof previouslyFocusedElementRef.current.focus === 'function'
        ) {
          try {
            previouslyFocusedElementRef.current.focus();
          } catch {}
        }
      }
      return;
    }

    // Modal just transitioned from closed to open
    if (!wasOpenRef.current) {
      wasOpenRef.current = true;
      previouslyFocusedElementRef.current = document.activeElement as HTMLElement | null;

      const container = containerRef.current;
      if (container) {
        const timer = setTimeout(() => {
          // If the user is already typing or focused on an element inside the modal, do NOT steal focus!
          if (container.contains(document.activeElement)) {
            return;
          }

          if (initialFocusRefLatest.current && initialFocusRefLatest.current.current) {
            initialFocusRefLatest.current.current.focus();
            return;
          }

          const focusable = container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR);
          if (focusable.length > 0) {
            focusable[0].focus();
          } else {
            container.focus();
          }
        }, 30);

        return () => clearTimeout(timer);
      }
    }
  }, [isOpen]);

  // Handle keyboard events (Tab trapping and Escape)
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // 1. Escape key handling
      if (e.key === 'Escape' || e.key === 'Esc') {
        if (onCloseRef.current) {
          e.preventDefault();
          e.stopPropagation();
          onCloseRef.current();
        }
        return;
      }

      // 2. Tab key trapping
      if (e.key === 'Tab') {
        const container = containerRef.current;
        if (!container) return;

        const focusables = Array.from(
          container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)
        ).filter(el => el.offsetParent !== null && !el.hasAttribute('aria-hidden'));

        if (focusables.length === 0) {
          e.preventDefault();
          return;
        }

        const first = focusables[0];
        const last = focusables[focusables.length - 1];

        if (e.shiftKey) {
          // Shift + Tab: if on first element, cycle to last
          if (document.activeElement === first || !container.contains(document.activeElement)) {
            e.preventDefault();
            last.focus();
          }
        } else {
          // Tab: if on last element, cycle to first
          if (document.activeElement === last || !container.contains(document.activeElement)) {
            e.preventDefault();
            first.focus();
          }
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown, true);
    return () => {
      document.removeEventListener('keydown', handleKeyDown, true);
    };
  }, [isOpen]);

  return containerRef;
}
