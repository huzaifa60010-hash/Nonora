import React from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { AuthModal } from './components/AuthModal';
import { ToastContainer } from './components/ToastContainer';
import { HomePage } from './pages/HomePage';
import { ShopPage } from './pages/ShopPage';
import { ProductDetailsPage } from './pages/ProductDetailsPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { OrderConfirmationPage } from './pages/OrderConfirmationPage';
import { AccountPage } from './pages/AccountPage';
import { AdminDashboard } from './pages/AdminDashboard';
import { ContactPage } from './pages/ContactPage';
import { PoliciesPage } from './pages/PoliciesPage';
import { RegisterPage } from './pages/RegisterPage';
import { SignInPage } from './pages/SignInPage';
import { OtpVerificationPage } from './pages/OtpVerificationPage';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage';
import { ScrollControls } from './components/ScrollControls';

const AppContent: React.FC = () => {
  const { currentView, currentUser, isAdmin, isAuthLoading } = useStore();

  if (isAuthLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-stone-950 text-white font-sans">
        <div className="flex items-baseline gap-1.5 mb-3">
          <span className="text-3xl font-extrabold tracking-widest font-display">NOVORA</span>
          <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
        </div>
        <p className="text-xs text-stone-400 tracking-wider uppercase">Verifying Session...</p>
      </div>
    );
  }

  // First Page – Login Required: Block access to shopping website until signed in or registered
  if (!currentUser) {
    return (
      <div className="min-h-screen flex flex-col bg-stone-50 font-sans text-stone-900 antialiased selection:bg-purple-100 selection:text-purple-900">
        <main className="flex-1">
          {currentView === 'register' ? (
            <RegisterPage />
          ) : currentView === 'forgot-password' ? (
            <ForgotPasswordPage />
          ) : (
            <SignInPage />
          )}
        </main>
        <ToastContainer />
      </div>
    );
  }

  const renderCurrentView = () => {
    switch (currentView) {
      case 'home':
      case 'signin':
      case 'register':
        return <HomePage />;
      case 'shop':
      case 'category':
        return <ShopPage />;
      case 'product':
        return <ProductDetailsPage />;
      case 'checkout':
        return <CheckoutPage />;
      case 'order-confirmation':
        return <OrderConfirmationPage />;
      case 'account':
        return <AccountPage />;
      case 'admin':
        return isAdmin ? <AdminDashboard /> : <HomePage />;
      case 'contact':
        return <ContactPage />;
      case 'verify-otp':
        return <OtpVerificationPage />;
      case 'forgot-password':
        return <ForgotPasswordPage />;
      case 'about':
      case 'faq':
      case 'shipping-policy':
      case 'returns-policy':
      case 'privacy-policy':
      case 'terms':
        return <PoliciesPage type={currentView} />;
      case 'cart':
        return <CheckoutPage />;
      default:
        return <HomePage />;
    }
  };

  // When inside Admin Dashboard (and verified as authorized administrator), render full admin console
  if (currentView === 'admin' && isAdmin) {
    return (
      <div className="min-h-screen flex flex-col bg-stone-100 font-sans text-stone-900 antialiased selection:bg-purple-100 selection:text-purple-900">
        <main className="flex-1">
          <AdminDashboard />
        </main>
        <ScrollControls />
        <ToastContainer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-white font-sans text-stone-900 antialiased selection:bg-purple-100 selection:text-purple-900">
      <Header />
      <main className="flex-1">
        {renderCurrentView()}
      </main>
      <Footer />
      <CartDrawer />
      <AuthModal />
      <ScrollControls />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <AppContent />
    </StoreProvider>
  );
}
