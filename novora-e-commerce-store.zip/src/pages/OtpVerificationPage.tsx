import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldCheck,
  Mail,
  ArrowRight,
  RotateCw,
  AlertCircle,
  CheckCircle2,
  Clock,
  KeyRound,
  Edit2,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const OtpVerificationPage: React.FC = () => {
  const {
    pendingVerificationEmail,
    setPendingVerificationEmail,
    verifyEmailOtp,
    resendEmailOtp,
    navigateTo,
    showToast,
    currentUser,
  } = useStore();

  const [emailInput, setEmailInput] = useState(pendingVerificationEmail || currentUser?.email || '');
  const [isEditingEmail, setIsEditingEmail] = useState(!pendingVerificationEmail && !currentUser?.email);
  const [digits, setDigits] = useState<string[]>(['', '', '', '', '', '']);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [cooldown, setCooldown] = useState(60);
  const [expirySeconds, setExpirySeconds] = useState(600); // 10 minutes

  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Cooldown timer
  useEffect(() => {
    if (cooldown <= 0) return;
    const interval = setInterval(() => {
      setCooldown(c => Math.max(0, c - 1));
    }, 1000);
    return () => clearInterval(interval);
  }, [cooldown]);

  // Expiry countdown timer (10 mins)
  useEffect(() => {
    if (expirySeconds <= 0) return;
    const interval = setInterval(() => {
      setExpirySeconds(s => Math.max(0, s - 1));
    }, 1000);
    return () => clearInterval(interval);
  }, [expirySeconds]);

  // Focus on first box on mount
  useEffect(() => {
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, []);

  const handleDigitChange = (index: number, value: string) => {
    // Handle pasted 6-digit code
    if (value.length > 1) {
      const cleanDigits = value.replace(/\D/g, '').slice(0, 6).split('');
      const newDigits = [...digits];
      cleanDigits.forEach((d, i) => {
        newDigits[i] = d;
      });
      setDigits(newDigits);
      const nextFocus = Math.min(5, cleanDigits.length);
      inputRefs.current[nextFocus]?.focus();
      return;
    }

    const cleanChar = value.replace(/\D/g, '');
    const newDigits = [...digits];
    newDigits[index] = cleanChar;
    setDigits(newDigits);

    // Auto-advance
    if (cleanChar && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !digits[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const code = digits.join('');

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    if (code.length !== 6) {
      setErrorMessage('Please enter all 6 digits of the verification code.');
      return;
    }

    if (expirySeconds <= 0) {
      setErrorMessage('Verification code has expired. Please request a new code below.');
      return;
    }

    if (isEditingEmail && emailInput.trim()) {
      setPendingVerificationEmail(emailInput.trim().toLowerCase());
    }

    setIsLoading(true);
    try {
      const res = await verifyEmailOtp(code, 'registration');
      if (!res.success) {
        setErrorMessage(res.error || 'Verification failed. Please check the code and try again.');
      } else {
        setSuccessMessage('Email verified successfully! You will be redirected shortly.');
        showToast('Your NOVORA account is now fully active!', 'success');
        setTimeout(() => {
          navigateTo('home');
        }, 1200);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'An error occurred during verification.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResend = async () => {
    if (cooldown > 0) return;
    setErrorMessage('');
    setSuccessMessage('');
    setIsResending(true);

    if (isEditingEmail && emailInput.trim()) {
      setPendingVerificationEmail(emailInput.trim().toLowerCase());
    }

    try {
      const res = await resendEmailOtp('registration');
      if (res.success) {
        setCooldown(60);
        setExpirySeconds(600);
        setDigits(['', '', '', '', '', '']);
        showToast('A fresh 6-digit code has been dispatched to your email.', 'info');
        inputRefs.current[0]?.focus();
      } else {
        setErrorMessage(res.error || 'Failed to resend code. Please try again shortly.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to resend verification code.');
    } finally {
      setIsResending(false);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const activeEmail = pendingVerificationEmail || currentUser?.email || emailInput;

  return (
    <div className="min-h-[85vh] bg-stone-50 py-12 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl border border-stone-200/80 p-8 sm:p-10 text-center">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-600 mb-5 shadow-sm">
          <KeyRound className="w-7 h-7" />
        </div>

        <h1 className="text-2xl sm:text-3xl font-serif font-light text-stone-900 tracking-tight">
          Verify Your Email
        </h1>
        <p className="text-sm text-stone-500 mt-2 font-light">
          We have dispatched a 6-digit one-time security code (OTP) to your email address:
        </p>

        {/* Email badge & edit */}
        <div className="my-4 flex items-center justify-center gap-2 bg-stone-100/80 py-2 px-4 rounded-xl max-w-sm mx-auto border border-stone-200/60">
          <Mail className="w-4 h-4 text-stone-500 flex-shrink-0" />
          {isEditingEmail ? (
            <input
              type="email"
              value={emailInput}
              onChange={e => setEmailInput(e.target.value)}
              placeholder="Enter your email"
              className="bg-transparent text-xs text-stone-900 font-mono font-medium focus:outline-none w-48 text-center"
            />
          ) : (
            <span className="text-xs text-stone-900 font-mono font-medium truncate max-w-[220px]">
              {activeEmail || 'No email provided'}
            </span>
          )}
          <button
            type="button"
            onClick={() => setIsEditingEmail(!isEditingEmail)}
            className="text-stone-400 hover:text-stone-700 p-1"
            title="Edit recipient email"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Expiration Timer Banner */}
        <div className="flex items-center justify-center gap-1.5 text-xs text-stone-500 mb-6 font-mono">
          <Clock className="w-3.5 h-3.5 text-stone-400" />
          <span>Code valid for:</span>
          <span className={`font-semibold ${expirySeconds < 120 ? 'text-rose-600' : 'text-stone-700'}`}>
            {formatTime(expirySeconds)}
          </span>
        </div>

        {errorMessage && (
          <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 flex items-start gap-3 text-rose-700 text-sm text-left">
            <AlertCircle className="w-5 h-5 flex-shrink-0 text-rose-500 mt-0.5" />
            <div className="flex-1 leading-relaxed">{errorMessage}</div>
          </div>
        )}

        {successMessage && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-start gap-3 text-emerald-800 text-sm text-left">
            <CheckCircle2 className="w-5 h-5 flex-shrink-0 text-emerald-600 mt-0.5" />
            <div className="flex-1 leading-relaxed">{successMessage}</div>
          </div>
        )}

        <form onSubmit={handleVerify} className="space-y-6">
          {/* 6 Digit Split Inputs */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-stone-500 mb-3">
              Enter 6-Digit Verification Code
            </label>
            <div className="flex justify-center gap-2 sm:gap-3">
              {digits.map((digit, idx) => (
                <input
                  key={idx}
                  ref={el => {
                    inputRefs.current[idx] = el;
                  }}
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={e => handleDigitChange(idx, e.target.value)}
                  onKeyDown={e => handleKeyDown(idx, e)}
                  className="w-11 h-13 sm:w-12 sm:h-14 text-center text-xl sm:text-2xl font-mono font-semibold rounded-xl border border-stone-300 bg-white text-stone-900 focus:outline-none focus:ring-2 focus:ring-stone-900/10 focus:border-stone-900 transition-all shadow-sm"
                />
              ))}
            </div>
          </div>

          {/* Verify Button */}
          <button
            type="submit"
            disabled={isLoading || code.length !== 6 || expirySeconds <= 0}
            className="w-full py-3.5 px-6 rounded-xl bg-stone-900 hover:bg-stone-800 active:bg-black text-white font-medium text-sm flex items-center justify-center gap-2 transition-all shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <span className="inline-flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Verifying Code...
              </span>
            ) : (
              <>
                Confirm & Activate Account <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Resend Cooldown Section */}
        <div className="mt-6 pt-5 border-t border-stone-100 flex flex-col items-center gap-2">
          <p className="text-xs text-stone-500 font-light">
            Didn't receive the code or need a new one?
          </p>
          <button
            type="button"
            onClick={handleResend}
            disabled={cooldown > 0 || isResending}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-stone-800 hover:text-stone-900 disabled:text-stone-400 disabled:cursor-not-allowed transition-colors"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isResending ? 'animate-spin' : ''}`} />
            {cooldown > 0 ? `Resend code in ${cooldown}s` : 'Resend Verification Code'}
          </button>
        </div>

        <div className="mt-6 pt-4 border-t border-stone-100 text-center">
          <button
            onClick={() => navigateTo('signin')}
            className="text-xs text-stone-500 hover:text-stone-800 underline font-light"
          >
            Back to Sign In
          </button>
        </div>
      </div>
    </div>
  );
};
