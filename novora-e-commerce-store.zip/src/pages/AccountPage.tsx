import React, { useState, useEffect } from 'react';
import { Package, MapPin, Heart, User, LogOut, Plus, Trash2, CheckCircle2, Clock, Truck, Shield, ExternalLink } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { api } from '../services/api';
import { Order, DeliveryAddress } from '../types';
import { TARGET_DRIVE_FOLDER_URL } from '../services/googleDrive';
import { BackButton } from '../components/BackButton';

export const AccountPage: React.FC = () => {
  const {
    currentUser,
    logout,
    openAuthModal,
    navigateTo,
    products,
    addToCart,
    toggleWishlist,
    updateUserProfile,
    showToast,
    isAdmin,
  } = useStore();

  const [activeTab, setActiveTab] = useState<'orders' | 'tracking' | 'addresses' | 'wishlist' | 'profile'>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoadingOrders, setIsLoadingOrders] = useState(false);

  // Tracking state
  const [trackingOrderNumber, setTrackingOrderNumber] = useState('');
  const [trackedOrderData, setTrackedOrderData] = useState<any | null>(null);
  const [isTrackingLoading, setIsTrackingLoading] = useState(false);
  const [trackingError, setTrackingError] = useState<string | null>(null);

  // Address form
  const [isAddingAddress, setIsAddingAddress] = useState(false);
  const [newAddr, setNewAddr] = useState<DeliveryAddress>({
    fullName: currentUser?.fullName || '',
    email: currentUser?.email || '',
    phone: currentUser?.phone || '',
    country: 'United States',
    state: '',
    city: '',
    streetAddress: '',
    houseNumber: '',
    apartmentDetails: '',
    postalCode: '',
    isDefault: true,
  });

  // Profile form
  const [profileName, setProfileName] = useState(currentUser?.fullName || '');
  const [profilePhone, setProfilePhone] = useState(currentUser?.phone || '');
  const [isSavingProfile, setIsSavingProfile] = useState(false);

  useEffect(() => {
    if (currentUser) {
      setProfileName(currentUser.fullName);
      setProfilePhone(currentUser.phone || '');
      loadOrders();
    }
  }, [currentUser?.id]);

  const loadOrders = async () => {
    setIsLoadingOrders(true);
    try {
      const data = await api.getOrders();
      setOrders(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingOrders(false);
    }
  };

  const handleTrackOrderSubmit = async (orderNum?: string) => {
    const query = (orderNum || trackingOrderNumber).trim();
    if (!query) return;
    setIsTrackingLoading(true);
    setTrackingError(null);
    try {
      const res = await api.trackOrder(query);
      if (res.success && res.order) {
        setTrackedOrderData(res.order);
        setTrackingOrderNumber(res.order.orderNumber);
      } else {
        setTrackingError('Order record not found. Please verify the order number.');
      }
    } catch (err: any) {
      setTrackingError(err.message || 'Unable to load order tracking details.');
    } finally {
      setIsTrackingLoading(false);
    }
  };

  if (!currentUser) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-stone-100 flex items-center justify-center mx-auto text-stone-400">
          <User className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-stone-900">Patron Authentication Required</h2>
        <p className="text-xs text-stone-500">
          Please sign in to view your order history, delivery addresses, and personal wishlist.
        </p>
        <button
          onClick={() => openAuthModal('login')}
          className="px-6 py-2.5 bg-stone-900 hover:bg-purple-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
        >
          Sign In to Your Account
        </button>
      </div>
    );
  }

  const wishlistProducts = products.filter(p => currentUser.wishlist?.includes(p.id));

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingProfile(true);
    await updateUserProfile({
      fullName: profileName.trim(),
      phone: profilePhone.trim(),
    });
    setIsSavingProfile(false);
  };

  const handleAddAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAddr.fullName || !newAddr.city || !newAddr.streetAddress || !newAddr.houseNumber || !newAddr.postalCode) {
      showToast('Please fill in compulsory address fields.', 'error');
      return;
    }

    const updatedAddresses = [...(currentUser.savedAddresses || []), { ...newAddr, id: `addr_${Date.now()}` }];
    const ok = await updateUserProfile({ savedAddresses: updatedAddresses });
    if (ok) {
      setIsAddingAddress(false);
      showToast('New delivery address saved.', 'success');
    }
  };

  const handleDeleteAddress = async (addrId?: string) => {
    if (!addrId) return;
    const updated = (currentUser.savedAddresses || []).filter(a => a.id !== addrId);
    await updateUserProfile({ savedAddresses: updated });
    showToast('Address removed.', 'info');
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Delivered':
        return <span className="px-2.5 py-0.5 text-[11px] font-bold text-emerald-800 bg-emerald-100 rounded-md">Delivered</span>;
      case 'Shipped':
        return <span className="px-2.5 py-0.5 text-[11px] font-bold text-purple-800 bg-purple-100 rounded-md">Shipped</span>;
      case 'Sent to Supplier':
        return <span className="px-2.5 py-0.5 text-[11px] font-bold text-teal-800 bg-teal-100 rounded-md">Sent to Supplier (CJ)</span>;
      case 'Processing':
        return <span className="px-2.5 py-0.5 text-[11px] font-bold text-blue-800 bg-blue-100 rounded-md">Processing</span>;
      case 'Paid':
        return <span className="px-2.5 py-0.5 text-[11px] font-bold text-indigo-800 bg-indigo-100 rounded-md">Paid & Validated</span>;
      case 'Cancelled':
        return <span className="px-2.5 py-0.5 text-[11px] font-bold text-rose-800 bg-rose-100 rounded-md">Cancelled</span>;
      case 'Refunded':
        return <span className="px-2.5 py-0.5 text-[11px] font-bold text-stone-700 bg-stone-200 rounded-md">Refunded</span>;
      case 'Awaiting Payment':
      default:
        return <span className="px-2.5 py-0.5 text-[11px] font-bold text-amber-800 bg-amber-100 rounded-md">Awaiting Payment</span>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24 space-y-6">
      
      {/* Top navigation row */}
      <div className="flex items-center justify-between">
        <BackButton fallbackView="home" label="Back to Storefront" />
        {activeTab !== 'orders' && (
          <button
            onClick={() => setActiveTab('orders')}
            className="text-xs font-semibold text-purple-700 hover:text-purple-900 transition-colors cursor-pointer"
          >
            ← Back to Orders Overview
          </button>
        )}
      </div>

      {/* Header bar */}
      <div className="p-6 bg-stone-950 text-white rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-purple-400 uppercase tracking-widest">
            Patron Profile
          </span>
          <h1 className="text-2xl font-extrabold font-display text-white mt-1">
            {currentUser.fullName}
          </h1>
          <p className="text-xs text-stone-400">{currentUser.email}</p>
        </div>

        <div className="flex items-center gap-3">
          {isAdmin && (
            <button
              onClick={() => navigateTo('admin')}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin Portal</span>
            </button>
          )}

          <button
            onClick={logout}
            className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Tabs navigation */}
      <div className="flex border-b border-stone-200 gap-8 text-sm font-semibold overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab('orders')}
          className={`pb-3.5 flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'orders' ? 'text-purple-700 border-b-2 border-purple-700' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>My Orders ({orders.length})</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('tracking');
            if (!trackedOrderData && orders.length > 0) {
              handleTrackOrderSubmit(orders[0].orderNumber);
            }
          }}
          className={`pb-3.5 flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'tracking' ? 'text-purple-700 border-b-2 border-purple-700' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <Truck className="w-4 h-4" />
          <span>Track My Order</span>
        </button>

        <button
          onClick={() => setActiveTab('addresses')}
          className={`pb-3.5 flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'addresses' ? 'text-purple-700 border-b-2 border-purple-700' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <MapPin className="w-4 h-4" />
          <span>Saved Delivery Addresses</span>
        </button>

        <button
          onClick={() => setActiveTab('wishlist')}
          className={`pb-3.5 flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'wishlist' ? 'text-purple-700 border-b-2 border-purple-700' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>Private Wishlist ({wishlistProducts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`pb-3.5 flex items-center gap-2 whitespace-nowrap cursor-pointer ${
            activeTab === 'profile' ? 'text-purple-700 border-b-2 border-purple-700' : 'text-stone-500 hover:text-stone-900'
          }`}
        >
          <User className="w-4 h-4" />
          <span>Profile Settings</span>
        </button>
      </div>

      {/* Tab Content */}
      <div className="pt-2">
        {/* ORDERS TAB */}
        {activeTab === 'orders' && (
          <div className="space-y-6">
            {isLoadingOrders ? (
              <p className="text-xs text-stone-500">Loading order history...</p>
            ) : orders.length === 0 ? (
              <div className="p-12 text-center bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                <Package className="w-10 h-10 text-stone-400 mx-auto" />
                <h3 className="text-sm font-bold text-stone-800">No past orders found</h3>
                <p className="text-xs text-stone-500 max-w-sm mx-auto">
                  When you place orders on NOVORA, your receipt history and live tracking details will appear here.
                </p>
                <button
                  onClick={() => navigateTo('shop')}
                  className="px-5 py-2 bg-stone-900 hover:bg-purple-700 text-white text-xs font-semibold rounded-lg"
                >
                  Browse Collections
                </button>
              </div>
            ) : (
              orders.map(order => (
                <div key={order.id} className="bg-white rounded-2xl border border-stone-200 p-6 space-y-4 shadow-xs">
                  <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-stone-100">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-stone-950 font-mono">{order.orderNumber}</span>
                        {getStatusBadge(order.orderStatus)}
                      </div>
                      <p className="text-xs text-stone-500 mt-0.5">
                        Placed on {new Date(order.createdAt).toLocaleDateString()} · {order.items.length} items
                      </p>
                    </div>

                    <div className="text-right">
                      <p className="text-xs text-stone-500">Order Total</p>
                      <p className="text-base font-bold text-stone-950 tabular-nums">${order.total.toFixed(2)}</p>
                    </div>
                  </div>

                  {/* Delivery destination */}
                  <div className="bg-stone-50 p-3.5 rounded-xl text-xs text-stone-700 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <p>
                      <strong className="text-stone-900">Destination: </strong>
                      {order.deliveryAddress.houseNumber} {order.deliveryAddress.streetAddress}, {order.deliveryAddress.city}, {order.deliveryAddress.state} {order.deliveryAddress.postalCode}
                    </p>
                    {order.trackingNumber && (
                      <p className="font-mono text-purple-900 bg-purple-100/60 px-2 py-0.5 rounded">
                        Track: {order.trackingNumber}
                      </p>
                    )}
                  </div>

                  {/* Items list */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    {order.items.map((it, idx) => (
                      <div key={idx} className="flex gap-3 text-xs p-2 rounded-lg bg-stone-50/70">
                        <img
                          src={it.productImage || '/src/assets/images/novora_cat_fashion_1792421786979.jpg'}
                          alt={it.productName}
                          className="w-12 h-14 object-cover rounded bg-stone-200 border border-stone-200"
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            (e.currentTarget as HTMLImageElement).src = '/src/assets/images/novora_cat_fashion_1792421786979.jpg';
                          }}
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-stone-900 truncate">{it.productName}</p>
                          <p className="text-[11px] text-stone-500">
                            Qty: {it.quantity} {it.selectedVariant?.size && `· ${it.selectedVariant.size}`}
                          </p>
                          <p className="font-bold text-stone-950 tabular-nums mt-0.5">${(it.price * it.quantity).toFixed(2)}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Order Footer Actions */}
                  <div className="flex items-center justify-between pt-3 border-t border-stone-100 text-xs">
                    <div className="text-stone-400 text-[11px] font-mono">
                      Payment: <span className="font-semibold text-stone-700 uppercase">{order.paymentMethod || 'Online'}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setActiveTab('tracking');
                        setTrackingOrderNumber(order.orderNumber);
                        handleTrackOrderSubmit(order.orderNumber);
                      }}
                      className="px-3.5 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-800 text-xs font-bold rounded-xl border border-purple-200 transition-colors flex items-center gap-1.5 cursor-pointer"
                    >
                      <Truck className="w-3.5 h-3.5 text-purple-700" />
                      <span>Track Package &amp; Timeline →</span>
                    </button>
                  </div>

                </div>
              ))
            )}
          </div>
        )}

        {/* TRACK MY ORDER TAB */}
        {activeTab === 'tracking' && (
          <div className="space-y-6">
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-xs space-y-6">
              <div className="space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-widest text-purple-700">
                  Live Fulfillment &amp; Courier Tracking
                </span>
                <h2 className="text-xl font-black text-stone-950 font-display">
                  Track My Shipment
                </h2>
                <p className="text-xs text-stone-500">
                  Enter your NOVORA order reference number to track fulfillment stages and courier tracking updates.
                </p>
              </div>

              {/* Order lookup form */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleTrackOrderSubmit();
                }}
                className="flex flex-col sm:flex-row gap-2 max-w-xl"
              >
                <div className="relative flex-1">
                  <input
                    type="text"
                    placeholder="e.g. NOV-174000-8822"
                    value={trackingOrderNumber}
                    onChange={(e) => setTrackingOrderNumber(e.target.value)}
                    className="w-full pl-3.5 pr-4 py-2.5 text-xs bg-stone-50 border border-stone-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-600 font-mono font-bold uppercase"
                  />
                </div>
                <button
                  type="submit"
                  disabled={isTrackingLoading || !trackingOrderNumber.trim()}
                  className="px-5 py-2.5 bg-stone-950 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
                >
                  <Truck className="w-3.5 h-3.5" />
                  <span>{isTrackingLoading ? 'Querying...' : 'Track Order'}</span>
                </button>
              </form>

              {/* Quick Order Selection Pills from recent orders */}
              {orders.length > 0 && (
                <div className="flex items-center gap-2 flex-wrap pt-1">
                  <span className="text-[11px] font-semibold text-stone-400">Your recent orders:</span>
                  {orders.slice(0, 4).map((o) => (
                    <button
                      key={o.id}
                      type="button"
                      onClick={() => {
                        setTrackingOrderNumber(o.orderNumber);
                        handleTrackOrderSubmit(o.orderNumber);
                      }}
                      className="px-2.5 py-1 bg-stone-100 hover:bg-purple-100 hover:text-purple-800 text-stone-700 text-[11px] font-mono rounded-lg transition-colors cursor-pointer border border-stone-200"
                    >
                      {o.orderNumber}
                    </button>
                  ))}
                </div>
              )}

              {trackingError && (
                <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl">
                  {trackingError}
                </div>
              )}

              {/* Tracked Order Details Card */}
              {trackedOrderData && (
                <div className="mt-6 pt-6 border-t border-stone-100 space-y-6">
                  {/* Top Status Banner */}
                  <div className="bg-stone-50 p-5 rounded-2xl border border-stone-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-base font-black text-stone-950">
                          {trackedOrderData.orderNumber}
                        </span>
                        {getStatusBadge(trackedOrderData.orderStatus)}
                      </div>
                      <p className="text-xs text-stone-500 mt-1">
                        Ordered on {new Date(trackedOrderData.createdAt).toLocaleDateString()} · Total: ${Number(trackedOrderData.total || 0).toFixed(2)}
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-white rounded-xl border border-stone-200 text-xs text-stone-700">
                        <span className="text-[10px] text-stone-400 block font-semibold uppercase">Carrier / Logistics</span>
                        <strong className="text-stone-900 font-bold">{trackedOrderData.carrier || 'DHL Express Global'}</strong>
                        {trackedOrderData.trackingNumber && (
                          <span className="block font-mono text-purple-700 text-[11px] font-bold mt-0.5">
                            #{trackedOrderData.trackingNumber}
                          </span>
                        )}
                      </div>

                      {trackedOrderData.trackingUrl && (
                        <a
                          href={trackedOrderData.trackingUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3.5 py-2 bg-stone-900 hover:bg-purple-700 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors shadow-xs"
                        >
                          <span>Carrier Portal</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>
                  </div>

                  {/* 5-Stage Visual Progress Timeline */}
                  <div className="p-6 bg-white rounded-2xl border border-stone-200 space-y-4">
                    <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                      Fulfillment Stages
                    </h3>

                    <div className="relative">
                      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                        {(trackedOrderData.timeline || [
                          { title: 'Order Confirmed', completed: true, detail: 'Payment validated' },
                          { title: 'Quality Inspection', completed: true, detail: 'Processing at atelier' },
                          { title: 'Dispatched', completed: trackedOrderData.orderStatus === 'Shipped' || trackedOrderData.orderStatus === 'Delivered', detail: 'Handed to courier' },
                          { title: 'Out for Delivery', completed: trackedOrderData.orderStatus === 'Delivered', detail: 'Local courier van' },
                          { title: 'Delivered', completed: trackedOrderData.orderStatus === 'Delivered', detail: 'Signed & complete' },
                        ]).map((step: any, idx: number) => (
                          <div key={idx} className="relative flex md:flex-col items-start gap-3 md:gap-2">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${
                              step.completed
                                ? 'bg-emerald-600 text-white shadow-sm'
                                : 'bg-stone-200 text-stone-500'
                            }`}>
                              {step.completed ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                            </div>
                            <div>
                              <h4 className={`text-xs font-bold ${step.completed ? 'text-stone-900' : 'text-stone-400'}`}>
                                {step.title}
                              </h4>
                              <p className="text-[11px] text-stone-500 mt-0.5 leading-snug">
                                {step.detail}
                              </p>
                              {step.timestamp && (
                                <p className="text-[10px] font-mono text-purple-700 mt-1">
                                  {step.timestamp}
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Delivery Destination */}
                  {trackedOrderData.deliveryAddress && (
                    <div className="bg-stone-50 p-4 rounded-xl text-xs space-y-1 border border-stone-200">
                      <span className="text-[10px] font-bold uppercase text-stone-400">Destination Address</span>
                      <p className="font-semibold text-stone-900">{trackedOrderData.deliveryAddress.fullName}</p>
                      <p className="text-stone-600">
                        {trackedOrderData.deliveryAddress.city}, {trackedOrderData.deliveryAddress.state} {trackedOrderData.deliveryAddress.postalCode}, {trackedOrderData.deliveryAddress.country}
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ADDRESSES TAB */}
        {activeTab === 'addresses' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-stone-900">Registered Delivery Locations</h3>
                <p className="text-xs text-stone-500">Manage addresses for one-click checkout.</p>
              </div>
              {!isAddingAddress && (
                <button
                  onClick={() => setIsAddingAddress(true)}
                  className="px-4 py-2 bg-stone-900 hover:bg-purple-700 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add New Address</span>
                </button>
              )}
            </div>

            <div className="p-3.5 bg-blue-50/70 rounded-2xl border border-blue-200/80 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="p-1 bg-blue-100 rounded-lg text-blue-700">
                  <Shield className="w-4 h-4" />
                </span>
                <span className="text-blue-900 font-medium">
                  Delivery addresses are synchronized to Google Drive folder <code className="font-mono text-purple-700 font-bold">NOVORA_Project/Data</code> (<code className="font-mono text-purple-700 font-bold">addresses.json</code>).
                </span>
              </div>
              <a
                href={TARGET_DRIVE_FOLDER_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] font-bold text-blue-700 hover:text-blue-900 inline-flex items-center gap-1 shrink-0"
              >
                <span>Google Drive Folder</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            {isAddingAddress && (
              <form onSubmit={handleAddAddress} className="p-6 bg-stone-50 rounded-2xl border border-stone-200 space-y-4">
                <h4 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                  New Delivery Address (Compulsory Fields)
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Full Legal Name *</label>
                    <input
                      type="text"
                      value={newAddr.fullName}
                      onChange={e => setNewAddr({ ...newAddr, fullName: e.target.value })}
                      className="w-full p-2.5 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Phone Number *</label>
                    <input
                      type="tel"
                      value={newAddr.phone}
                      onChange={e => setNewAddr({ ...newAddr, phone: e.target.value })}
                      className="w-full p-2.5 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Country *</label>
                    <input
                      type="text"
                      value={newAddr.country}
                      onChange={e => setNewAddr({ ...newAddr, country: e.target.value })}
                      className="w-full p-2.5 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">State or Province *</label>
                    <input
                      type="text"
                      value={newAddr.state}
                      onChange={e => setNewAddr({ ...newAddr, state: e.target.value })}
                      className="w-full p-2.5 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">City *</label>
                    <input
                      type="text"
                      value={newAddr.city}
                      onChange={e => setNewAddr({ ...newAddr, city: e.target.value })}
                      className="w-full p-2.5 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Street Address *</label>
                    <input
                      type="text"
                      value={newAddr.streetAddress}
                      onChange={e => setNewAddr({ ...newAddr, streetAddress: e.target.value })}
                      className="w-full p-2.5 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">House or Building # *</label>
                    <input
                      type="text"
                      value={newAddr.houseNumber}
                      onChange={e => setNewAddr({ ...newAddr, houseNumber: e.target.value })}
                      className="w-full p-2.5 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Postal / ZIP Code *</label>
                    <input
                      type="text"
                      value={newAddr.postalCode}
                      onChange={e => setNewAddr({ ...newAddr, postalCode: e.target.value })}
                      className="w-full p-2.5 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                      required
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Apartment, Floor, or Additional Details</label>
                    <input
                      type="text"
                      value={newAddr.apartmentDetails}
                      onChange={e => setNewAddr({ ...newAddr, apartmentDetails: e.target.value })}
                      className="w-full p-2.5 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                    />
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="submit"
                    className="px-5 py-2 bg-purple-700 text-white text-xs font-semibold rounded-lg"
                  >
                    Save Address
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsAddingAddress(false)}
                    className="px-5 py-2 bg-stone-200 text-stone-700 text-xs font-semibold rounded-lg"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {(currentUser.savedAddresses || []).map(addr => (
                <div key={addr.id} className="p-5 bg-white rounded-2xl border border-stone-200 space-y-2 relative">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-stone-900">{addr.fullName}</h4>
                      <p className="text-[11px] text-stone-500">{addr.phone}</p>
                    </div>
                    <button
                      onClick={() => handleDeleteAddress(addr.id)}
                      className="text-stone-400 hover:text-rose-600 transition-colors p-1"
                      title="Remove address"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-xs text-stone-600 leading-relaxed pt-1">
                    {addr.houseNumber} {addr.streetAddress} {addr.apartmentDetails && `· ${addr.apartmentDetails}`}
                    <br />
                    {addr.city}, {addr.state} {addr.postalCode}
                    <br />
                    <span className="font-semibold text-stone-800">{addr.country}</span>
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* WISHLIST TAB */}
        {activeTab === 'wishlist' && (
          <div className="space-y-6">
            <h3 className="text-sm font-bold text-stone-900">Curated Wishlist</h3>
            {wishlistProducts.length === 0 ? (
              <div className="p-12 text-center bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                <Heart className="w-10 h-10 text-stone-400 mx-auto" />
                <h4 className="text-sm font-bold text-stone-800">Your wishlist is empty</h4>
                <p className="text-xs text-stone-500">
                  Tap the heart on any product card or details page to bookmark it here.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {wishlistProducts.map(prod => (
                  <div key={prod.id} className="p-4 bg-white rounded-2xl border border-stone-200 space-y-3">
                    <img
                      src={prod.images[0] || '/src/assets/images/novora_cat_fashion_1792421786979.jpg'}
                      alt={prod.name}
                      className="w-full aspect-4/3 object-cover rounded-xl bg-stone-100 cursor-pointer"
                      onClick={() => navigateTo('product', { productId: prod.id })}
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).src = '/src/assets/images/novora_cat_fashion_1792421786979.jpg';
                      }}
                    />
                    <div>
                      <h4
                        onClick={() => navigateTo('product', { productId: prod.id })}
                        className="text-xs font-bold text-stone-900 hover:text-purple-700 cursor-pointer truncate"
                      >
                        {prod.name}
                      </h4>
                      <p className="text-xs font-bold text-stone-950 mt-1 tabular-nums">
                        ${prod.sellingPrice.toFixed(2)}
                      </p>
                    </div>

                    <div className="flex gap-2 pt-2 border-t border-stone-100">
                      <button
                        onClick={() => {
                          addToCart(prod, 1);
                          toggleWishlist(prod.id);
                        }}
                        className="flex-1 py-2 bg-stone-900 hover:bg-purple-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                      >
                        Move to Bag
                      </button>
                      <button
                        onClick={() => toggleWishlist(prod.id)}
                        className="p-2 text-stone-400 hover:text-rose-600 transition-colors"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* PROFILE SETTINGS TAB */}
        {activeTab === 'profile' && (
          <div className="max-w-lg bg-stone-50 p-6 rounded-2xl border border-stone-200 space-y-4">
            <h3 className="text-sm font-bold text-stone-900">Personal Details</h3>
            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Full Legal Name</label>
                <input
                  type="text"
                  value={profileName}
                  onChange={e => setProfileName(e.target.value)}
                  className="w-full p-2.5 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Registered Email</label>
                <input
                  type="email"
                  value={currentUser.email}
                  disabled
                  className="w-full p-2.5 text-xs bg-stone-200/60 border border-stone-300 rounded-lg text-stone-500 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Telephone Contact</label>
                <input
                  type="tel"
                  value={profilePhone}
                  onChange={e => setProfilePhone(e.target.value)}
                  className="w-full p-2.5 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                />
              </div>

              <button
                type="submit"
                disabled={isSavingProfile}
                className="px-6 py-2.5 bg-stone-900 hover:bg-purple-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                {isSavingProfile ? 'Saving...' : 'Save Profile Changes'}
              </button>
            </form>
          </div>
        )}

      </div>

    </div>
  );
};
