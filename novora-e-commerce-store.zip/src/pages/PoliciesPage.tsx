import React from 'react';
import { ShieldCheck, Truck, RotateCcw, HelpCircle, FileText, Lock } from 'lucide-react';
import { useStore, ViewType } from '../context/StoreContext';
import { BackButton } from '../components/BackButton';

export const PoliciesPage: React.FC<{ type: ViewType }> = ({ type }) => {
  const { navigateTo, settings } = useStore();

  const getPageContent = () => {
    switch (type) {
      case 'about':
        return {
          title: 'About the House of NOVORA',
          icon: <ShieldCheck className="w-6 h-6 text-purple-700" />,
          subtitle: 'Architectural minimalism, uncompromising craftsmanship, and everyday utility.',
          content: (
            <div className="space-y-4 text-xs sm:text-sm text-stone-700 leading-relaxed">
              <p>
                Founded on the belief that everyday luxury should feel effortless and architectural, NOVORA brings together refined tailoring, precision audio engineering, and pure botanical skincare under one cohesive aesthetic philosophy.
              </p>
              <p>
                Every silhouette in our collection begins with provenance: virgin tropical wools woven in Biella, Italy; CNC-machined lightweight titanium hinges finished by audio masters in Japan; and micro-batch bio-peptide elixirs formulated in small glass apothecary jars.
              </p>
              <h3 className="text-base font-bold text-stone-950 font-display pt-2">Our Craftsmanship Ethos</h3>
              <p>
                We reject seasonal obsolescence and fast fashion cycles. Instead, each NOVORA piece is designed with generous proportions, double-needle interior bindings, and enduring longevity.
              </p>
            </div>
          ),
        };

      case 'faq':
        return {
          title: 'Frequently Asked Questions',
          icon: <HelpCircle className="w-6 h-6 text-purple-700" />,
          subtitle: 'Common questions regarding ordering, sizing, delivery, and payment.',
          content: (
            <div className="space-y-6 text-xs sm:text-sm text-stone-700">
              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                <h4 className="font-bold text-stone-950">How does Cash on Delivery (COD) operate?</h4>
                <p className="text-stone-600">
                  When choosing Cash on Delivery at checkout, you pay nothing online upfront. Our courier desk verifies your phone number and delivery location. Once the package arrives at your doorstep, you hand cash or swipe an authorized courier mobile terminal.
                </p>
              </div>

              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                <h4 className="font-bold text-stone-950">How do I track my order status?</h4>
                <p className="text-stone-600">
                  You can track your order at any moment by navigating to your Customer Account or checking the unique tracking code (e.g. TRK-NV-9018442) assigned to your order.
                </p>
              </div>

              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                <h4 className="font-bold text-stone-950">What is the complimentary shipping threshold?</h4>
                <p className="text-stone-600">
                  Complimentary expedited courier shipping is provided automatically on all orders exceeding ${settings.freeShippingThreshold}. Standard shipping below this threshold is ${settings.shippingCharge}.
                </p>
              </div>

              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                <h4 className="font-bold text-stone-950">Are product variants like size and color interchangeable?</h4>
                <p className="text-stone-600">
                  Yes, within 30 days of receiving your order, you can contact concierge@novora.store to request a size or color exchange free of charge.
                </p>
              </div>
            </div>
          ),
        };

      case 'shipping-policy':
        return {
          title: 'Shipping & Fulfillment Policy',
          icon: <Truck className="w-6 h-6 text-purple-700" />,
          subtitle: 'Expedited climate-controlled dispatch from our central fulfillment center.',
          content: (
            <div className="space-y-4 text-xs sm:text-sm text-stone-700 leading-relaxed">
              <p>
                All orders are dispatched Monday through Friday from our central fulfillment center in New York, NY. Orders placed before 14:00 EST are processed and packed on the same business day.
              </p>
              <h4 className="font-bold text-stone-900">Domestic & International Rates</h4>
              <p>
                Orders over ${settings.freeShippingThreshold} qualify for complimentary standard courier delivery. Standard courier shipping for orders below this threshold is billed at a flat rate of ${settings.shippingCharge}.
              </p>
              <h4 className="font-bold text-stone-900">Doorstep Verification</h4>
              <p>
                To prevent fraud and misdelivery, high-value audio electronics and tailoring require a signature or telephone confirmation upon delivery.
              </p>
            </div>
          ),
        };

      case 'returns-policy':
        return {
          title: 'Returns & Exchanges Policy',
          icon: <RotateCcw className="w-6 h-6 text-purple-700" />,
          subtitle: '30-day effortless returns on all unworn items.',
          content: (
            <div className="space-y-4 text-xs sm:text-sm text-stone-700 leading-relaxed">
              <p>
                We want you to be completely satisfied with your NOVORA pieces. If an item does not meet your expectations, you may return it within 30 days of receipt.
              </p>
              <h4 className="font-bold text-stone-900">Return Conditions</h4>
              <ul className="list-disc pl-5 space-y-1 text-stone-600">
                <li>Apparel must be unworn, unwashed, and with all original tags attached.</li>
                <li>Audio equipment must include all original cables, documentation, and protective carry cases.</li>
                <li>Skincare bottles must be unopened with the original tamper seal intact.</li>
              </ul>
            </div>
          ),
        };

      case 'privacy-policy':
        return {
          title: 'Privacy Policy',
          icon: <Lock className="w-6 h-6 text-purple-700" />,
          subtitle: 'How NOVORA collects, protects, and handles your personal information.',
          content: (
            <div className="space-y-4 text-xs sm:text-sm text-stone-700 leading-relaxed">
              <p>
                NOVORA is committed to safeguarding your personal data and respecting your privacy rights.
              </p>
              <h4 className="font-bold text-stone-900">Information We Collect</h4>
              <p>
                We collect your delivery information (full name, email, phone number, physical address, and postal code) strictly for the purpose of order fulfillment, tracking updates, and courier delivery verification.
              </p>
              <h4 className="font-bold text-stone-900">Data Security</h4>
              <p>
                We do not sell, rent, or trade your personal information to third-party advertisers. All order records are stored with role-based access controls so that only authorized administrators can access delivery addresses.
              </p>
            </div>
          ),
        };

      case 'terms':
      default:
        return {
          title: 'Terms & Conditions of Service',
          icon: <FileText className="w-6 h-6 text-purple-700" />,
          subtitle: 'Agreement governing the use of the NOVORA e-commerce store.',
          content: (
            <div className="space-y-4 text-xs sm:text-sm text-stone-700 leading-relaxed">
              <p>
                Welcome to NOVORA. By accessing this store and placing orders, you agree to comply with and be bound by the following terms of service.
              </p>
              <h4 className="font-bold text-stone-900">Demonstration Store Notice</h4>
              <p>
                This application is developed as an academic and professional college engineering project. Cash on Delivery is provided as a demonstration fulfillment option. Product listings and imagery are curated for exhibition purposes.
              </p>
              <h4 className="font-bold text-stone-900">Governing Law</h4>
              <p>
                These terms are governed by standard fair commercial practices and e-commerce consumer protection regulations.
              </p>
            </div>
          ),
        };
    }
  };

  const { title, subtitle, icon, content } = getPageContent();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24 space-y-6">
      <BackButton fallbackView="home" label="Back to Previous Page" />

      <div className="space-y-3 pb-6 border-b border-stone-200">
        <div className="w-12 h-12 rounded-xl bg-purple-50 flex items-center justify-center">
          {icon}
        </div>
        <h1 className="text-3xl font-extrabold text-stone-950 font-display">
          {title}
        </h1>
        <p className="text-xs text-stone-500">
          {subtitle}
        </p>
      </div>

      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs">
        {content}
      </div>
    </div>
  );
};
