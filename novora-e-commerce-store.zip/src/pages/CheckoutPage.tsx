import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Truck,
  ArrowLeft,
  Check,
  AlertCircle,
  ShoppingBag,
  Lock,
  CreditCard,
  Building2,
  Banknote,
  Globe,
  Plus,
  MapPin,
  CheckCircle2,
  HelpCircle,
} from 'lucide-react';
import { useStore, CURRENCY_RATES } from '../context/StoreContext';
import { api } from '../services/api';
import { DeliveryAddress, PaymentGatewayConfig, PaymentSession, Order } from '../types';
import { SecurePaymentModal } from '../components/SecurePaymentModal';
import { BackButton } from '../components/BackButton';

export const CheckoutPage: React.FC = () => {
  const {
    cart,
    cartSubtotal,
    appliedCoupon,
    settings,
    clearCart,
    navigateTo,
    currentUser,
    openAuthModal,
    openCartDrawer,
    saveAddress,
    selectedCurrency,
    setSelectedCurrency,
    formatPrice,
    showToast,
  } = useStore();

  // Gateway config state
  const [gatewayConfig, setGatewayConfig] = useState<PaymentGatewayConfig | null>(null);

  useEffect(() => {
    api.getPublicPaymentSettings()
      .then(cfg => setGatewayConfig(cfg))
      .catch(() => {});
  }, []);

  // Pre-fill from default saved address or user
  const savedAddresses = currentUser?.savedAddresses || [];
  const defaultAddress = savedAddresses.find(a => a.isDefault) || savedAddresses[0];

  const [selectedSavedAddrId, setSelectedSavedAddrId] = useState<string>(
    defaultAddress?.id || 'new'
  );

  // 10 Compulsory Delivery Address Fields
  const [fullName, setFullName] = useState(defaultAddress?.fullName || currentUser?.fullName || '');
  const [email, setEmail] = useState(defaultAddress?.email || currentUser?.email || '');
  const [phone, setPhone] = useState(defaultAddress?.phone || currentUser?.phone || '');
  const [country, setCountry] = useState(defaultAddress?.country || 'Pakistan');
  const [state, setState] = useState(defaultAddress?.state || '');
  const [city, setCity] = useState(defaultAddress?.city || '');
  const [streetAddress, setStreetAddress] = useState(defaultAddress?.streetAddress || '');
  const [houseNumber, setHouseNumber] = useState(defaultAddress?.houseNumber || '');
  const [apartmentDetails, setApartmentDetails] = useState(defaultAddress?.apartmentDetails || '');
  const [postalCode, setPostalCode] = useState(defaultAddress?.postalCode || '');
  const [saveToAccount, setSaveToAccount] = useState(true);

  // Payment Selection
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'cod' | 'bank_transfer'>('card');
  
  // Card Tokenized Input States
  const [cardholderName, setCardholderName] = useState(currentUser?.fullName || '');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  const [bankRefCode, setBankRefCode] = useState('');

  const [orderNotes, setOrderNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [submissionError, setSubmissionError] = useState<string | null>(null);
  const [activePaymentSession, setActivePaymentSession] = useState<PaymentSession | null>(null);
  const [pendingOrderForPayment, setPendingOrderForPayment] = useState<Order | null>(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);

  // When user chooses an existing saved address
  const handleSelectSavedAddress = (addrId: string) => {
    setSelectedSavedAddrId(addrId);
    if (addrId === 'new') {
      setFullName(currentUser?.fullName || '');
      setEmail(currentUser?.email || '');
      setPhone(currentUser?.phone || '');
      setCountry('Pakistan');
      setState('');
      setCity('');
      setStreetAddress('');
      setHouseNumber('');
      setApartmentDetails('');
      setPostalCode('');
    } else {
      const match = savedAddresses.find(a => a.id === addrId);
      if (match) {
        setFullName(match.fullName);
        setEmail(match.email);
        setPhone(match.phone);
        setCountry(match.country);
        setState(match.state);
        setCity(match.city);
        setStreetAddress(match.streetAddress);
        setHouseNumber(match.houseNumber);
        setApartmentDetails(match.apartmentDetails || '');
        setPostalCode(match.postalCode);
      }
    }
  };

  // If cart is empty, show empty state
  if (cart.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-stone-100 flex items-center justify-center mx-auto text-stone-400">
          <ShoppingBag className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-stone-900 font-display">Your shopping bag is empty</h2>
        <p className="text-xs text-stone-500">
          Add items to your bag before proceeding to checkout.
        </p>
        <button
          onClick={() => navigateTo('shop')}
          className="px-6 py-2.5 bg-stone-900 text-white text-xs font-semibold rounded-lg hover:bg-purple-700 transition-colors cursor-pointer"
        >
          Explore Collections
        </button>
      </div>
    );
  }

  // Currency & Financial Calculations
  const discountAmount = appliedCoupon ? appliedCoupon.discountAmount : 0;
  const taxableSubtotal = Math.max(0, cartSubtotal - discountAmount);
  const shippingFee = cartSubtotal >= settings.freeShippingThreshold ? 0 : settings.shippingCharge;
  const taxRate = settings.taxRatePercentage !== undefined ? settings.taxRatePercentage : 5;
  const taxAmount = Math.round((taxableSubtotal * (taxRate / 100)) * 100) / 100;
  const finalTotalUSD = Math.max(0, Math.round((taxableSubtotal + shippingFee + taxAmount) * 100) / 100);

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!fullName.trim()) errors.fullName = 'Full legal name is compulsory for courier receipt.';
    if (!email.trim() || !email.includes('@')) errors.email = 'Valid email is required for tracking updates.';
    if (!phone.trim()) errors.phone = 'Phone number is compulsory for courier delivery contact.';
    if (!country.trim()) errors.country = 'Country is compulsory.';
    if (!state.trim()) errors.state = 'State / Province is compulsory.';
    if (!city.trim()) errors.city = 'City is compulsory.';
    if (!streetAddress.trim()) errors.streetAddress = 'Street address is compulsory.';
    if (!houseNumber.trim()) errors.houseNumber = 'House or building number is compulsory.';
    if (!postalCode.trim()) errors.postalCode = 'Postal / ZIP code is compulsory.';

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmissionError(null);

    if (currentUser && currentUser.isEmailVerified === false) {
      showToast('Please verify your email address to complete your order.', 'error');
      navigateTo('verify-otp');
      return;
    }

    if (!validateForm()) {
      showToast('Please complete all compulsory delivery fields before continuing.', 'error');
      const firstError = document.querySelector('.border-rose-500');
      if (firstError) {
        firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }

    setIsSubmitting(true);

    try {
      const deliveryAddress: DeliveryAddress = {
        fullName: fullName.trim(),
        email: email.trim().toLowerCase(),
        phone: phone.trim(),
        country: country.trim(),
        state: state.trim(),
        city: city.trim(),
        streetAddress: streetAddress.trim(),
        houseNumber: houseNumber.trim(),
        apartmentDetails: apartmentDetails.trim(),
        postalCode: postalCode.trim(),
      };

      // If user checked "Save address" and is logged in
      if (saveToAccount && currentUser && selectedSavedAddrId === 'new') {
        await saveAddress(deliveryAddress);
      }

      // If card payment: create a payment session through the backend and launch the secure provider checkout
      if (paymentMethod === 'card') {
        const sessionPayload = {
          items: cart.map(item => ({
            productId: item.product.id,
            productName: item.product.name,
            productImage: item.product.images[0] || '',
            price: item.product.sellingPrice,
            quantity: item.quantity,
            selectedVariant: item.selectedVariant,
          })),
          deliveryAddress,
          couponCode: appliedCoupon?.code,
          currency: selectedCurrency,
          notes: orderNotes?.trim(),
        };

        const res = await api.createPaymentSession(sessionPayload);
        const checkoutUrl = (res as any).checkoutUrl || res.session?.checkoutUrl;
        if (checkoutUrl && checkoutUrl.startsWith('http')) {
          window.location.assign(checkoutUrl);
          return;
        }
        if (res.success && res.session && res.order) {
          setActivePaymentSession(res.session);
          setPendingOrderForPayment(res.order);
          setIsPaymentModalOpen(true);
        }
        return;
      }

      // Offline payments: COD or Bank Transfer
      let paymentMethodTitle = 'Cash on Delivery (COD)';
      if (paymentMethod === 'bank_transfer') {
        paymentMethodTitle = 'Direct Bank Transfer / EasyPaisa / JazzCash';
      }

      const orderPayload = {
        items: cart.map(item => ({
          productId: item.product.id,
          productName: item.product.name,
          productImage: item.product.images[0] || '',
          price: item.product.sellingPrice,
          quantity: item.quantity,
          selectedVariant: item.selectedVariant,
        })),
        deliveryAddress,
        couponCode: appliedCoupon?.code,
        paymentMethod: paymentMethodTitle,
        currency: selectedCurrency,
        notes: (orderNotes ? orderNotes.trim() + (bankRefCode ? ` [Bank Ref: ${bankRefCode}]` : '') : bankRefCode ? `[Bank Ref: ${bankRefCode}]` : '').trim(),
      };

      const res = await api.createOrder(orderPayload);

      if (res.success && res.order) {
        clearCart();
        showToast(`Order ${res.order.orderNumber} successfully registered!`, 'success');
        navigateTo('order-confirmation', { confirmedOrder: res.order });
      }
    } catch (err: any) {
      const msg = err.message || 'Payment processing failed. Please check your details.';
      setSubmissionError(msg);
      showToast(msg, 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const hasUnsavedAddressData = Boolean(
    (fullName.trim() && fullName !== currentUser?.fullName) ||
    streetAddress.trim() ||
    city.trim() ||
    phone.trim()
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-28">
      
      {/* Return to cart & collections button */}
      <div className="flex items-center justify-between mb-8">
        <BackButton
          fallbackView="shop"
          label="Return to Shopping Bag / Catalog"
          confirmMessage={
            hasUnsavedAddressData
              ? 'You have entered delivery information. Are you sure you want to leave checkout? Your progress may be lost.'
              : undefined
          }
          onClick={() => {
            openCartDrawer();
          }}
        />

        {/* Currency Switcher in Checkout */}
        <div className="flex items-center gap-2 text-xs">
          <Globe className="w-3.5 h-3.5 text-stone-400" />
          <span className="text-stone-500 font-medium">Billing Currency:</span>
          <select
            value={selectedCurrency}
            onChange={e => setSelectedCurrency(e.target.value)}
            className="px-2.5 py-1 text-xs font-bold bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600 cursor-pointer"
          >
            {Object.entries(CURRENCY_RATES).map(([code, meta]) => (
              <option key={code} value={code}>
                {code} ({meta.name})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Guest Notice if not signed in */}
      {!currentUser && (
        <div className="mb-8 p-4 bg-purple-50/70 border border-purple-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-purple-700 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-stone-900">Checking out as a Guest</p>
              <p className="text-stone-600 mt-0.5">
                Sign in or create an account to automatically save your delivery address, track orders, and view packing slips.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => openAuthModal('login')}
            className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white font-semibold rounded-lg shrink-0 transition-colors cursor-pointer"
          >
            Sign In / Register
          </button>
        </div>
      )}

      {/* Email Verification Required Alert if logged in but unverified */}
      {currentUser && currentUser.isEmailVerified === false && (
        <div className="mb-8 p-4 bg-amber-50 border border-amber-300 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-amber-900">
          <div className="flex items-start gap-2.5">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-amber-950">Email Verification Required</p>
              <p className="text-amber-800 mt-0.5">
                Per store security policy, please verify your email address before finalizing your order. A 6-digit OTP code was dispatched to your email.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => navigateTo('verify-otp')}
            className="px-4 py-2 bg-amber-900 hover:bg-amber-800 text-white font-bold rounded-lg transition-colors shrink-0 cursor-pointer"
          >
            Enter 6-Digit OTP
          </button>
        </div>
      )}


      {/* Submission Error Alert */}
      {submissionError && (
        <div className="mb-8 p-4 bg-rose-50 border border-rose-300 rounded-xl flex items-start gap-3 text-xs text-rose-800">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold">Order Payment Notice</p>
            <p className="mt-0.5 leading-relaxed">{submissionError}</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        
        {/* Left Column: Delivery Address & Payment Methods */}
        <div className="lg:col-span-7 space-y-8">
          
          <form onSubmit={handlePlaceOrder} id="checkout-form" className="space-y-8">
            
            {/* Delivery Address Section */}
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs space-y-6">
              <div className="border-b border-stone-100 pb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-stone-950 font-display">
                    1. Required Delivery Address
                  </h2>
                  <p className="text-xs text-stone-500 mt-0.5">
                    All 9 compulsory address fields are required before courier dispatch.
                  </p>
                </div>
                <Truck className="w-5 h-5 text-purple-700" />
              </div>

              {/* Saved Address Picker if Authenticated */}
              {currentUser && savedAddresses.length > 0 && (
                <div className="space-y-2">
                  <label className="block text-xs font-semibold text-stone-700">
                    Select a Saved Delivery Address
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {savedAddresses.map(addr => (
                      <div
                        key={addr.id}
                        onClick={() => handleSelectSavedAddress(addr.id!)}
                        className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                          selectedSavedAddrId === addr.id
                            ? 'border-purple-600 bg-purple-50/50 ring-1 ring-purple-600'
                            : 'border-stone-200 bg-stone-50 hover:bg-white'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-bold text-stone-900">{addr.fullName}</span>
                          {addr.isDefault && (
                            <span className="text-[10px] bg-purple-100 text-purple-800 font-bold px-1.5 py-0.2 rounded">
                              Default
                            </span>
                          )}
                        </div>
                        <p className="text-stone-600 truncate">{addr.houseNumber}, {addr.streetAddress}</p>
                        <p className="text-stone-500">{addr.city}, {addr.state} · {addr.country}</p>
                      </div>
                    ))}
                    <div
                      onClick={() => handleSelectSavedAddress('new')}
                      className={`p-3 rounded-xl border border-dashed text-xs cursor-pointer flex items-center justify-center gap-1.5 transition-all ${
                        selectedSavedAddrId === 'new'
                          ? 'border-purple-600 bg-purple-50/50 text-purple-800 font-bold'
                          : 'border-stone-300 text-stone-600 hover:border-purple-500'
                      }`}
                    >
                      <Plus className="w-4 h-4" />
                      <span>Enter a New Address</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Compulsory Fields Form */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* 1. Full name */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    1. Full Legal Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="Recipient's first and last name"
                    value={fullName}
                    onChange={e => setFullName(e.target.value)}
                    className={`w-full px-3.5 py-2.5 text-xs bg-stone-50 border rounded-lg focus:outline-none focus:bg-white transition-all ${
                      validationErrors.fullName ? 'border-rose-500 bg-rose-50/30' : 'border-stone-300 focus:border-purple-600'
                    }`}
                  />
                  {validationErrors.fullName && (
                    <p className="text-[11px] text-rose-600 mt-1">{validationErrors.fullName}</p>
                  )}
                </div>

                {/* 2. Email address */}
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    2. Email Address <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="email"
                    placeholder="name@example.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className={`w-full px-3.5 py-2.5 text-xs bg-stone-50 border rounded-lg focus:outline-none focus:bg-white transition-all ${
                      validationErrors.email ? 'border-rose-500 bg-rose-50/30' : 'border-stone-300 focus:border-purple-600'
                    }`}
                  />
                  {validationErrors.email && (
                    <p className="text-[11px] text-rose-600 mt-1">{validationErrors.email}</p>
                  )}
                </div>

                {/* 3. Phone number */}
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    3. Contact Phone Number <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    placeholder="+92 300 1234567 or +1 (555) 000-0000"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    className={`w-full px-3.5 py-2.5 text-xs bg-stone-50 border rounded-lg focus:outline-none focus:bg-white transition-all ${
                      validationErrors.phone ? 'border-rose-500 bg-rose-50/30' : 'border-stone-300 focus:border-purple-600'
                    }`}
                  />
                  {validationErrors.phone && (
                    <p className="text-[11px] text-rose-600 mt-1">{validationErrors.phone}</p>
                  )}
                </div>

                {/* 4. Country */}
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    4. Country <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={country}
                    onChange={e => setCountry(e.target.value)}
                    className={`w-full px-3.5 py-2.5 text-xs bg-stone-50 border rounded-lg focus:outline-none focus:bg-white transition-all ${
                      validationErrors.country ? 'border-rose-500' : 'border-stone-300 focus:border-purple-600'
                    }`}
                  >
                    <option value="Pakistan">Pakistan</option>
                    <option value="United States">United States</option>
                    <option value="United Kingdom">United Kingdom</option>
                    <option value="United Arab Emirates">United Arab Emirates</option>
                    <option value="Saudi Arabia">Saudi Arabia</option>
                    <option value="Canada">Canada</option>
                    <option value="Germany">Germany</option>
                    <option value="France">France</option>
                    <option value="Australia">Australia</option>
                  </select>
                </div>

                {/* 5. State / Province */}
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    5. State / Province / Territory <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Punjab, Sindh, NY, California"
                    value={state}
                    onChange={e => setState(e.target.value)}
                    className={`w-full px-3.5 py-2.5 text-xs bg-stone-50 border rounded-lg focus:outline-none focus:bg-white transition-all ${
                      validationErrors.state ? 'border-rose-500 bg-rose-50/30' : 'border-stone-300 focus:border-purple-600'
                    }`}
                  />
                  {validationErrors.state && (
                    <p className="text-[11px] text-rose-600 mt-1">{validationErrors.state}</p>
                  )}
                </div>

                {/* 6. City */}
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    6. City <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Lahore, Karachi, Islamabad, New York"
                    value={city}
                    onChange={e => setCity(e.target.value)}
                    className={`w-full px-3.5 py-2.5 text-xs bg-stone-50 border rounded-lg focus:outline-none focus:bg-white transition-all ${
                      validationErrors.city ? 'border-rose-500 bg-rose-50/30' : 'border-stone-300 focus:border-purple-600'
                    }`}
                  />
                  {validationErrors.city && (
                    <p className="text-[11px] text-rose-600 mt-1">{validationErrors.city}</p>
                  )}
                </div>

                {/* 7. Postal / ZIP code */}
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    7. Postal / ZIP Code <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 54000 or 10001"
                    value={postalCode}
                    onChange={e => setPostalCode(e.target.value)}
                    className={`w-full px-3.5 py-2.5 text-xs bg-stone-50 border rounded-lg focus:outline-none focus:bg-white transition-all ${
                      validationErrors.postalCode ? 'border-rose-500 bg-rose-50/30' : 'border-stone-300 focus:border-purple-600'
                    }`}
                  />
                  {validationErrors.postalCode && (
                    <p className="text-[11px] text-rose-600 mt-1">{validationErrors.postalCode}</p>
                  )}
                </div>

                {/* 8. Street address */}
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    8. Street Address <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="Main Road, Boulevard, Street Name"
                    value={streetAddress}
                    onChange={e => setStreetAddress(e.target.value)}
                    className={`w-full px-3.5 py-2.5 text-xs bg-stone-50 border rounded-lg focus:outline-none focus:bg-white transition-all ${
                      validationErrors.streetAddress ? 'border-rose-500 bg-rose-50/30' : 'border-stone-300 focus:border-purple-600'
                    }`}
                  />
                  {validationErrors.streetAddress && (
                    <p className="text-[11px] text-rose-600 mt-1">{validationErrors.streetAddress}</p>
                  )}
                </div>

                {/* 9. House / Building Number */}
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    9. Street / House Number <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="House #, Plot #, Building #"
                    value={houseNumber}
                    onChange={e => setHouseNumber(e.target.value)}
                    className={`w-full px-3.5 py-2.5 text-xs bg-stone-50 border rounded-lg focus:outline-none focus:bg-white transition-all ${
                      validationErrors.houseNumber ? 'border-rose-500 bg-rose-50/30' : 'border-stone-300 focus:border-purple-600'
                    }`}
                  />
                  {validationErrors.houseNumber && (
                    <p className="text-[11px] text-rose-600 mt-1">{validationErrors.houseNumber}</p>
                  )}
                </div>

                {/* 10. Apartment / Suite / Floor (Optional) */}
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    10. Apartment, Suite, Floor (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="Apt 4B, 3rd Floor, Suite 201"
                    value={apartmentDetails}
                    onChange={e => setApartmentDetails(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:bg-white focus:border-purple-600 transition-all"
                  />
                </div>

              </div>

              {/* Save Address Checkbox */}
              {currentUser && selectedSavedAddrId === 'new' && (
                <label className="flex items-center gap-2 cursor-pointer pt-2">
                  <input
                    type="checkbox"
                    checked={saveToAccount}
                    onChange={e => setSaveToAccount(e.target.checked)}
                    className="w-4 h-4 text-purple-600 rounded border-stone-300 accent-purple-600"
                  />
                  <span className="text-xs text-stone-700 font-medium">
                    Save this delivery address to my account for future orders
                  </span>
                </label>
              )}

            </div>

            {/* Payment Method Selection */}
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs space-y-5">
              <div className="border-b border-stone-100 pb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-bold text-stone-950 font-display">
                    2. Secure Payment Method
                  </h2>
                  <p className="text-xs text-stone-500 mt-0.5">
                    Select your preferred verified payment method.
                  </p>
                </div>
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
              </div>

              <div className="space-y-3">
                
                {/* Method 1: Credit / Debit Card (Stripe / Safepay) */}
                <div className={`p-4 rounded-xl border transition-all ${
                  paymentMethod === 'card'
                    ? 'border-purple-600 bg-purple-50/30 ring-1 ring-purple-600'
                    : 'border-stone-200 bg-stone-50'
                }`}>
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === 'card'}
                      onChange={() => setPaymentMethod('card')}
                      className="mt-1 text-purple-600 accent-purple-600"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-stone-950 flex items-center gap-1.5">
                          <CreditCard className="w-4 h-4 text-purple-700" />
                          <span>Credit or Debit Card (Visa, Mastercard, PayPak)</span>
                        </span>
                        <span className="px-2 py-0.5 text-[10px] font-bold text-purple-800 bg-purple-100 rounded">
                          Instant Confirmation
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 mt-0.5">
                        Processed via authorized payment gateway (Stripe & Safepay Pakistan).
                      </p>
                    </div>
                  </label>

                  {/* Provider Secure Hosted Checkout Explanation */}
                  {paymentMethod === 'card' && (
                    <div className="mt-3.5 pt-3.5 border-t border-purple-200/60 space-y-2 text-xs">
                      <div className="p-3.5 bg-white rounded-xl border border-purple-200 text-stone-700 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-stone-900 flex items-center gap-1.5">
                            <ShieldCheck className="w-4 h-4 text-emerald-600" />
                            Official Provider Secure Checkout
                          </span>
                          <span className="text-[10px] font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                            Safepay & Stripe
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-500 leading-relaxed">
                          Clicking <strong>"Proceed to Secure Payment"</strong> below initializes a secure payment session. Payment credentials (Visa, Mastercard, PayPak) are tokenized directly through the provider's PCI-DSS Level 1 compliant checkout. Sensitive credentials never touch or get stored on store servers.
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Method 2: Cash on Delivery (COD) */}
                <div className={`p-4 rounded-xl border transition-all ${
                  paymentMethod === 'cod'
                    ? 'border-purple-600 bg-purple-50/30 ring-1 ring-purple-600'
                    : 'border-stone-200 bg-stone-50'
                }`}>
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === 'cod'}
                      onChange={() => setPaymentMethod('cod')}
                      className="mt-1 text-purple-600 accent-purple-600"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-stone-950 flex items-center gap-1.5">
                          <Banknote className="w-4 h-4 text-emerald-700" />
                          <span>Cash on Delivery (COD)</span>
                        </span>
                        <span className="px-2 py-0.5 text-[10px] font-bold text-emerald-800 bg-emerald-100 rounded">
                          Pay Upon Delivery
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 mt-0.5">
                        Pay cash directly to the courier when receiving the parcel at your delivery address.
                      </p>
                    </div>
                  </label>
                </div>

                {/* Method 3: Direct Bank Transfer / EasyPaisa / JazzCash */}
                <div className={`p-4 rounded-xl border transition-all ${
                  paymentMethod === 'bank_transfer'
                    ? 'border-purple-600 bg-purple-50/30 ring-1 ring-purple-600'
                    : 'border-stone-200 bg-stone-50'
                }`}>
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === 'bank_transfer'}
                      onChange={() => setPaymentMethod('bank_transfer')}
                      className="mt-1 text-purple-600 accent-purple-600"
                    />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-stone-950 flex items-center gap-1.5">
                          <Building2 className="w-4 h-4 text-blue-700" />
                          <span>Direct Bank Transfer / EasyPaisa / JazzCash</span>
                        </span>
                        <span className="px-2 py-0.5 text-[10px] font-bold text-blue-800 bg-blue-100 rounded">
                          Pakistan & Regional
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 mt-0.5">
                        Transfer to our verified business IBAN and provide transaction reference.
                      </p>
                    </div>
                  </label>

                  {/* Bank Details View */}
                  {paymentMethod === 'bank_transfer' && (
                    <div className="mt-4 pt-4 border-t border-purple-200/60 space-y-3">
                      <div className="p-3 bg-white rounded-lg border border-stone-200 text-xs space-y-1.5">
                        <p className="font-bold text-stone-900">
                          {gatewayConfig?.bankDetails?.bankName || 'Meezan Bank Ltd'}
                        </p>
                        <p className="text-[11px] text-stone-600">
                          Account Title: <span className="font-semibold text-stone-900">{gatewayConfig?.bankDetails?.accountTitle || 'NOVORA Luxury E-Commerce'}</span>
                        </p>
                        <p className="text-[11px] font-mono text-purple-900 bg-purple-50 p-1.5 rounded border border-purple-100">
                          IBAN: {gatewayConfig?.bankDetails?.ibanMasked || 'PK92MEZN0001098234821001'}
                        </p>
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                          Bank Transfer / EasyPaisa / JazzCash Transaction ID
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. TID-984210 or Bank Ref #"
                          value={bankRefCode}
                          onChange={e => setBankRefCode(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                        />
                      </div>
                    </div>
                  )}
                </div>

              </div>

              {/* Delivery Notes */}
              <div className="pt-2">
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Delivery Instructions / Gate Code (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Leave with security guard, or call upon arrival..."
                  value={orderNotes}
                  onChange={e => setOrderNotes(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:bg-white focus:border-purple-600"
                />
              </div>

            </div>

          </form>

        </div>

        {/* Right Column: Order Review Summary & Place Order */}
        <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-28">
          
          <div className="bg-stone-50 p-6 rounded-2xl border border-stone-200 shadow-xs space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h3 className="text-base font-bold text-stone-950 font-display">
                Order Review ({cart.length} items)
              </h3>
              <span className="text-xs font-bold text-purple-800 bg-purple-100 px-2 py-0.5 rounded">
                {selectedCurrency}
              </span>
            </div>

            {/* Items List */}
            <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
              {cart.map(item => (
                <div key={item.id} className="flex gap-3 text-xs">
                  <img
                    src={item.product.images[0] || '/src/assets/images/novora_cat_fashion_1792421786979.jpg'}
                    alt={item.product.name}
                    className="w-12 h-14 object-cover rounded bg-stone-200 shrink-0 border border-stone-200"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = '/src/assets/images/novora_cat_fashion_1792421786979.jpg';
                    }}
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-stone-900 truncate">{item.product.name}</p>
                    <p className="text-[11px] text-stone-500">
                      Qty: {item.quantity} {item.selectedVariant?.size && `· Size: ${item.selectedVariant.size}`}
                    </p>
                    <p className="text-[10px] text-stone-400 font-mono">
                      Unit: {formatPrice(item.product.sellingPrice)}
                    </p>
                  </div>
                  <span className="font-semibold text-stone-900 tabular-nums">
                    {formatPrice(item.product.sellingPrice * item.quantity)}
                  </span>
                </div>
              ))}
            </div>

            {/* Calculations Breakdown */}
            <div className="space-y-2 text-xs text-stone-600 border-t border-stone-200 pt-4">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-semibold text-stone-900 tabular-nums">
                  {formatPrice(cartSubtotal)}
                </span>
              </div>

              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-700 font-medium">
                  <span>Coupon Discount ({appliedCoupon?.code})</span>
                  <span className="tabular-nums">-{formatPrice(discountAmount)}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Shipping & Delivery</span>
                <span className="font-semibold text-stone-900 tabular-nums">
                  {shippingFee === 0 ? (
                    <span className="text-emerald-700 font-bold">Complimentary</span>
                  ) : (
                    formatPrice(shippingFee)
                  )}
                </span>
              </div>

              <div className="flex justify-between">
                <span>Applicable Tax ({taxRate}%)</span>
                <span className="font-semibold text-stone-900 tabular-nums">
                  {formatPrice(taxAmount)}
                </span>
              </div>

              <div className="flex justify-between text-base font-black text-stone-950 border-t border-stone-200 pt-3">
                <span>Final Total Due</span>
                <span className="text-purple-900 tabular-nums text-lg font-bold">
                  {formatPrice(finalTotalUSD)}
                </span>
              </div>
            </div>

            {/* Security Guarantee Strip */}
            <div className="p-3 bg-white rounded-xl border border-stone-200 text-stone-600 text-[11px] space-y-1">
              <p className="flex items-center gap-1.5 font-semibold text-stone-900">
                <Lock className="w-3.5 h-3.5 text-purple-700" />
                <span>SSL Encrypted Checkout</span>
              </p>
              <p>
                Stock and delivery address are verified server-side prior to order commitment.
              </p>
            </div>

            {/* Place Order CTA Button */}
            <button
              type="submit"
              form="checkout-form"
              disabled={isSubmitting}
              className="w-full py-3.5 px-4 bg-stone-950 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer"
            >
              {isSubmitting ? (
                <span>Initializing Payment Session...</span>
              ) : paymentMethod === 'card' ? (
                <>
                  <CreditCard className="w-4 h-4 text-purple-300" />
                  <span>Proceed to Secure Checkout · {formatPrice(finalTotalUSD)}</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Place Order · {formatPrice(finalTotalUSD)}</span>
                </>
              )}
            </button>

          </div>

        </div>

      </div>

      {/* Official Provider Secure Hosted Checkout Modal */}
      {activePaymentSession && pendingOrderForPayment && (
        <SecurePaymentModal
          session={activePaymentSession}
          order={pendingOrderForPayment}
          isOpen={isPaymentModalOpen}
          onClose={() => setIsPaymentModalOpen(false)}
          onPaymentSuccess={(paidOrder) => {
            setIsPaymentModalOpen(false);
            clearCart();
            showToast(`Payment confirmed! Order ${paidOrder.orderNumber} is registered.`, 'success');
            navigateTo('order-confirmation', { confirmedOrder: paidOrder });
          }}
          onPaymentDecline={(msg) => {
            showToast(msg, 'error');
          }}
        />
      )}

    </div>
  );
};
