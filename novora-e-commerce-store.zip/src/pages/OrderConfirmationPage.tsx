import React from 'react';
import { CheckCircle, Truck, Package, ArrowRight, Home, ShieldCheck } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const OrderConfirmationPage: React.FC = () => {
  const { confirmedOrder, navigateTo, formatPrice } = useStore();

  if (!confirmedOrder) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center space-y-4">
        <p className="text-stone-500">No active order confirmation details available.</p>
        <button
          onClick={() => navigateTo('home')}
          className="px-6 py-2 bg-stone-900 text-white rounded-lg text-xs"
        >
          Return to Home
        </button>
      </div>
    );
  }

  const addr = confirmedOrder.deliveryAddress;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10">
      
      {/* Celebratory Banner */}
      <div className="text-center space-y-3 pb-8 border-b border-stone-200">
        <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
          <CheckCircle className="w-10 h-10" />
        </div>
        <span className="text-xs font-bold text-purple-700 uppercase tracking-widest">
          Fulfillment Confirmed
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-stone-950 font-display">
          Thank you for your order
        </h1>
        <p className="text-sm text-stone-600 max-w-lg mx-auto leading-relaxed">
          Your order has been registered in the database. Our concierge team is preparing your package for courier dispatch.
        </p>

        {/* Order Number & Status Bar */}
        <div className="pt-4 flex flex-wrap items-center justify-center gap-4 text-xs">
          <div className="px-4 py-2 bg-stone-100 rounded-xl border border-stone-200 font-mono">
            <span className="text-stone-500">Order Reference: </span>
            <strong className="text-stone-950 font-bold">{confirmedOrder.orderNumber}</strong>
          </div>
          <div className="px-4 py-2 bg-purple-50 rounded-xl border border-purple-200">
            <span className="text-purple-700 font-semibold">Status: </span>
            <strong className="text-purple-950 font-bold">{confirmedOrder.orderStatus}</strong>
          </div>
          {confirmedOrder.trackingNumber && (
            <div className="px-4 py-2 bg-stone-100 rounded-xl border border-stone-200 font-mono">
              <span className="text-stone-500">Tracking Code: </span>
              <strong className="text-stone-900">{confirmedOrder.trackingNumber}</strong>
            </div>
          )}
        </div>
      </div>

      {/* 2-Column Split: Delivery Address & Order Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Delivery Address Details */}
        <div className="bg-stone-50 p-6 rounded-2xl border border-stone-200 space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-stone-200">
            <Truck className="w-4 h-4 text-purple-700" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-stone-900">
              Delivery Destination & Courier Contact
            </h3>
          </div>

          <div className="text-xs text-stone-700 space-y-1.5 leading-relaxed">
            <p className="text-sm font-bold text-stone-950">{addr.fullName}</p>
            <p className="text-stone-600">Email: {addr.email}</p>
            <p className="text-stone-600">Phone: {addr.phone}</p>
            <div className="pt-2 border-t border-stone-200/60 mt-2 space-y-0.5">
              <p>{addr.houseNumber} {addr.streetAddress}</p>
              {addr.apartmentDetails && <p>{addr.apartmentDetails}</p>}
              <p>{addr.city}, {addr.state} {addr.postalCode}</p>
              <p className="font-semibold text-stone-900 uppercase">{addr.country}</p>
            </div>
          </div>

          <div className="pt-3 border-t border-stone-200 text-xs text-stone-500 space-y-1.5">
            <p className="flex items-center gap-1.5 font-medium text-stone-800">
              <ShieldCheck className="w-3.5 h-3.5 text-purple-700 shrink-0" />
              <span>Payment Option: {confirmedOrder.paymentMethod}</span>
            </p>
            <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-200 text-[11px] text-emerald-900 space-y-0.5">
              <div className="flex items-center justify-between">
                <span className="font-semibold flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                  Merchant Card Payout:
                </span>
                <span className="font-bold text-emerald-800 uppercase text-[10px] tracking-wider">Settled & Verified</span>
              </div>
              <p className="font-mono font-bold text-emerald-950 text-[11px]">
                {confirmedOrder.settledToMerchantCard || 'Credited to Admin Card •••• 9922 (Meezan Bank Ltd / 1Link)'}
              </p>
            </div>
          </div>
        </div>

        {/* Ordered Items & Financial Summary */}
        <div className="bg-stone-50 p-6 rounded-2xl border border-stone-200 space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-stone-200">
            <Package className="w-4 h-4 text-purple-700" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-stone-900">
              Purchased Items ({confirmedOrder.items.length})
            </h3>
          </div>

          <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
            {confirmedOrder.items.map((item, idx) => (
              <div key={idx} className="flex gap-3 text-xs">
                <img
                  src={item.productImage || '/src/assets/images/novora_cat_fashion_1792421786979.jpg'}
                  alt={item.productName}
                  className="w-12 h-14 object-cover rounded bg-stone-200 shrink-0 border border-stone-200"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = '/src/assets/images/novora_cat_fashion_1792421786979.jpg';
                  }}
                />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-stone-900 truncate">{item.productName}</p>
                  <p className="text-[11px] text-stone-500">
                    Qty: {item.quantity} {item.selectedVariant?.size && `· Size: ${item.selectedVariant.size}`} {item.selectedVariant?.color && `· ${item.selectedVariant.color}`}
                  </p>
                </div>
                <span className="font-semibold text-stone-900 tabular-nums">
                  {formatPrice(item.price * item.quantity)}
                </span>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-stone-200 space-y-1.5 text-xs text-stone-600">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span className="font-semibold text-stone-900 tabular-nums">{formatPrice(confirmedOrder.subtotal)}</span>
            </div>
            {confirmedOrder.discount > 0 && (
              <div className="flex justify-between text-emerald-700 font-medium">
                <span>Discount ({confirmedOrder.couponCode})</span>
                <span className="tabular-nums">-{formatPrice(confirmedOrder.discount)}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span>Shipping</span>
              <span className="font-semibold text-stone-900 tabular-nums">
                {confirmedOrder.shippingFee === 0 ? 'Complimentary' : formatPrice(confirmedOrder.shippingFee)}
              </span>
            </div>
            <div className="flex justify-between text-sm font-bold text-stone-950 border-t border-stone-200 pt-2">
              <span>Total Paid / Payable</span>
              <span className="text-purple-900 tabular-nums text-base">{formatPrice(confirmedOrder.total)}</span>
            </div>
          </div>
        </div>

      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-6">
        <button
          onClick={() => navigateTo('account')}
          className="w-full sm:w-auto px-6 py-3 bg-stone-950 hover:bg-purple-700 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2"
        >
          <span>Track in Customer Account</span>
          <ArrowRight className="w-4 h-4" />
        </button>
        <button
          onClick={() => navigateTo('home')}
          className="w-full sm:w-auto px-6 py-3 bg-white border border-stone-300 hover:bg-stone-50 text-stone-800 text-xs font-semibold rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2"
        >
          <Home className="w-4 h-4" />
          <span>Continue Shopping</span>
        </button>
      </div>

    </div>
  );
};
