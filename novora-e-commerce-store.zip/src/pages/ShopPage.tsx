import React, { useState, useMemo, useRef } from 'react';
import { Filter, SlidersHorizontal, Search, X, Check, Star, ChevronLeft, ChevronRight } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { ProductCard } from './HomePage';
import { BackButton } from '../components/BackButton';

export const ShopPage: React.FC = () => {
  const categoryScrollRef = useRef<HTMLDivElement>(null);

  const scrollCategories = (offset: number) => {
    if (categoryScrollRef.current) {
      categoryScrollRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    }
  };

  const {
    products,
    categories,
    searchTerm,
    setSearchTerm,
    activeCategorySlug,
    navigateTo,
    addToCart,
    toggleWishlist,
    isInWishlist,
  } = useStore();

  const [selectedCategory, setSelectedCategory] = useState<string>(() => {
    if (activeCategorySlug) {
      const match = categories.find(c => c.slug === activeCategorySlug);
      return match ? match.name : 'all';
    }
    return 'all';
  });

  const [sortOption, setSortOption] = useState<string>('newest');
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [selectedBrand, setSelectedBrand] = useState<string>('all');
  const [maxPrice, setMaxPrice] = useState<number>(600);
  const [minRating, setMinRating] = useState<number>(0);
  const [isFilterDrawerOpen, setIsFilterDrawerOpen] = useState(false);

  // Extract all brands
  const brands = useMemo(() => {
    const set = new Set<string>();
    products.forEach(p => {
      if (p.brand) set.add(p.brand);
    });
    return Array.from(set);
  }, [products]);

  // Filtered and sorted products
  const filteredProducts = useMemo(() => {
    let result = products.filter(p => p.status === 'published');

    if (selectedCategory !== 'all') {
      result = result.filter(p => p.category.toLowerCase() === selectedCategory.toLowerCase());
    }

    if (selectedBrand !== 'all') {
      result = result.filter(p => p.brand === selectedBrand);
    }

    if (inStockOnly) {
      result = result.filter(p => p.stock > 0);
    }

    if (maxPrice > 0) {
      result = result.filter(p => p.sellingPrice <= maxPrice);
    }

    if (minRating > 0) {
      result = result.filter(p => p.rating >= minRating);
    }

    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase().trim();
      result = result.filter(
        p =>
          p.name.toLowerCase().includes(term) ||
          p.description.toLowerCase().includes(term) ||
          p.brand.toLowerCase().includes(term) ||
          p.category.toLowerCase().includes(term) ||
          p.sku.toLowerCase().includes(term)
      );
    }

    // Sort
    if (sortOption === 'price-low') {
      result.sort((a, b) => a.sellingPrice - b.sellingPrice);
    } else if (sortOption === 'price-high') {
      result.sort((a, b) => b.sellingPrice - a.sellingPrice);
    } else if (sortOption === 'best-selling') {
      result.sort((a, b) => (b.bestSeller ? 1 : 0) - (a.bestSeller ? 1 : 0));
    } else if (sortOption === 'highest-rated') {
      result.sort((a, b) => b.rating - a.rating);
    } else {
      result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    return result;
  }, [products, selectedCategory, selectedBrand, inStockOnly, maxPrice, minRating, searchTerm, sortOption]);

  const resetFilters = () => {
    setSelectedCategory('all');
    setSelectedBrand('all');
    setInStockOnly(false);
    setMaxPrice(600);
    setMinRating(0);
    setSearchTerm('');
    setSortOption('newest');
  };

  const hasActiveFilters =
    selectedCategory !== 'all' ||
    selectedBrand !== 'all' ||
    inStockOnly ||
    maxPrice < 600 ||
    minRating > 0 ||
    searchTerm.trim().length > 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24 space-y-6">
      
      {/* Navigation bar with Back button & breadcrumbs */}
      <div className="flex items-center justify-between gap-4">
        <BackButton fallbackView="home" label="Back to Home" />
        {selectedCategory !== 'all' && (
          <button
            onClick={() => setSelectedCategory('all')}
            className="text-xs font-semibold text-purple-700 hover:text-purple-900 cursor-pointer"
          >
            Show All Collections
          </button>
        )}
      </div>

      {/* Header Banner */}
      <div className="pb-6 border-b border-stone-200">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-semibold text-purple-700 uppercase tracking-widest">
              The Complete Register
            </span>
            <h1 className="text-3xl font-extrabold text-stone-950 font-display mt-1">
              {selectedCategory === 'all' ? 'All Catalog Products' : selectedCategory}
            </h1>
            <p className="text-xs text-stone-500 mt-1">
              Showing <span className="font-semibold text-stone-800 tabular-nums">{filteredProducts.length}</span> curated items
              {searchTerm && <span> matching "{searchTerm}"</span>}
            </p>
          </div>

          {/* Sort Dropdown & Mobile Filter Button */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsFilterDrawerOpen(!isFilterDrawerOpen)}
              className="lg:hidden px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Filter className="w-3.5 h-3.5" />
              <span>Filters {hasActiveFilters && '•'}</span>
            </button>

            <div className="flex items-center gap-2 text-xs">
              <span className="text-stone-500 font-medium">Sort by:</span>
              <select
                value={sortOption}
                onChange={e => setSortOption(e.target.value)}
                className="bg-white border border-stone-300 rounded-lg px-3 py-1.5 text-xs font-semibold text-stone-800 focus:outline-none focus:border-purple-600 cursor-pointer"
              >
                <option value="newest">Newest Arrivals</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="best-selling">Best Sellers</option>
                <option value="highest-rated">Highest Rated</option>
              </select>
            </div>
          </div>
        </div>

        {/* Category Pills Bar with Horizontal Scroll Controls */}
        <div className="relative mt-6 flex items-center gap-2">
          {/* Scroll Left Button (desktop) */}
          <button
            type="button"
            onClick={() => scrollCategories(-200)}
            aria-label="Scroll categories left"
            className="hidden md:flex shrink-0 w-7 h-7 rounded-full bg-white hover:bg-stone-100 border border-stone-200 text-stone-700 items-center justify-center shadow-xs cursor-pointer focus:outline-none"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <div
            ref={categoryScrollRef}
            className="flex-1 flex items-center gap-2 overflow-x-auto py-1 scrollbar-none scroll-smooth"
          >
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-4 py-2 text-xs font-semibold rounded-xl whitespace-nowrap transition-colors cursor-pointer shrink-0 ${
                selectedCategory === 'all'
                  ? 'bg-stone-900 text-white shadow-xs'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              All Collections
            </button>
            {categories.map(c => (
              <button
                key={c.id}
                onClick={() => setSelectedCategory(c.name)}
                className={`px-4 py-2 text-xs font-semibold rounded-xl whitespace-nowrap transition-colors cursor-pointer shrink-0 ${
                  selectedCategory.toLowerCase() === c.name.toLowerCase()
                    ? 'bg-purple-700 text-white shadow-xs'
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                }`}
              >
                {c.name}
              </button>
            ))}
          </div>

          {/* Scroll Right Button (desktop) */}
          <button
            type="button"
            onClick={() => scrollCategories(200)}
            aria-label="Scroll categories right"
            className="hidden md:flex shrink-0 w-7 h-7 rounded-full bg-white hover:bg-stone-100 border border-stone-200 text-stone-700 items-center justify-center shadow-xs cursor-pointer focus:outline-none"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Layout: Sidebar Filters + Products Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 pt-8">
        
        {/* Desktop Sidebar Filter Panel */}
        <div className="hidden lg:block space-y-6 pr-4 border-r border-stone-200">
          <div className="flex items-center justify-between pb-2 border-b border-stone-200">
            <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider flex items-center gap-1.5">
              <SlidersHorizontal className="w-3.5 h-3.5 text-purple-700" />
              <span>Refine Catalog</span>
            </h3>
            {hasActiveFilters && (
              <button
                onClick={resetFilters}
                className="text-[11px] font-semibold text-purple-700 hover:underline cursor-pointer"
              >
                Reset All
              </button>
            )}
          </div>

          {/* Search Term Filter */}
          {searchTerm && (
            <div className="p-2.5 bg-purple-50 rounded-lg flex items-center justify-between text-xs text-purple-900">
              <span className="truncate">Search: "{searchTerm}"</span>
              <button onClick={() => setSearchTerm('')} className="p-0.5 hover:text-purple-950">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Price Range Filter */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-semibold text-stone-800">
              <span>Max Price</span>
              <span className="tabular-nums text-purple-800 font-bold">${maxPrice}</span>
            </div>
            <input
              type="range"
              min="50"
              max="600"
              step="25"
              value={maxPrice}
              onChange={e => setMaxPrice(Number(e.target.value))}
              className="w-full accent-purple-700 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-stone-400 font-mono">
              <span>$50</span>
              <span>$300</span>
              <span>$600+</span>
            </div>
          </div>

          {/* Availability Toggle */}
          <div className="pt-2">
            <label className="flex items-center gap-2.5 text-xs font-medium text-stone-800 cursor-pointer">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={e => setInStockOnly(e.target.checked)}
                className="w-4 h-4 rounded text-purple-600 accent-purple-600 border-stone-300 focus:ring-purple-500"
              />
              <span>In Stock Only</span>
            </label>
          </div>

          {/* Brand Filter */}
          <div className="pt-3 border-t border-stone-200 space-y-2">
            <h4 className="text-xs font-bold text-stone-900">Brand / Atelier</h4>
            <div className="space-y-1.5">
              <button
                onClick={() => setSelectedBrand('all')}
                className={`block w-full text-left text-xs transition-colors py-0.5 ${
                  selectedBrand === 'all' ? 'font-bold text-purple-700' : 'text-stone-600 hover:text-stone-950'
                }`}
              >
                All Brands
              </button>
              {brands.map(brand => (
                <button
                  key={brand}
                  onClick={() => setSelectedBrand(brand)}
                  className={`block w-full text-left text-xs transition-colors py-0.5 ${
                    selectedBrand === brand ? 'font-bold text-purple-700' : 'text-stone-600 hover:text-stone-950'
                  }`}
                >
                  {brand}
                </button>
              ))}
            </div>
          </div>

          {/* Rating Filter */}
          <div className="pt-3 border-t border-stone-200 space-y-2">
            <h4 className="text-xs font-bold text-stone-900">Minimum Rating</h4>
            <div className="space-y-1">
              {[4.5, 4.0, 3.5].map(rating => (
                <button
                  key={rating}
                  onClick={() => setMinRating(minRating === rating ? 0 : rating)}
                  className={`flex items-center gap-1.5 w-full text-left text-xs py-1 transition-colors ${
                    minRating === rating ? 'text-purple-700 font-bold' : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span>{rating} Stars & Up</span>
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Product Grid Area */}
        <div className="lg:col-span-3">
          {filteredProducts.length === 0 ? (
            <div className="py-20 text-center space-y-4 bg-stone-50 rounded-2xl border border-stone-200 p-8">
              <div className="w-14 h-14 rounded-full bg-stone-200 flex items-center justify-center mx-auto text-stone-500">
                <Search className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-stone-900">No products found</h3>
                <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
                  We could not find any items matching your selected criteria. Try adjusting your filters or search keywords.
                </p>
              </div>
              <button
                onClick={resetFilters}
                className="px-5 py-2.5 bg-stone-900 hover:bg-purple-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredProducts.map(product => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onSelect={() => navigateTo('product', { productId: product.id })}
                  onAddToCart={() => addToCart(product, 1)}
                  onToggleWishlist={() => toggleWishlist(product.id)}
                  isWishlisted={isInWishlist(product.id)}
                />
              ))}
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
