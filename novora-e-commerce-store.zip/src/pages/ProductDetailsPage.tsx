import React, { useState, useEffect } from 'react';
import { Star, Heart, ShoppingBag, Truck, ShieldCheck, ArrowLeft, Check, Sparkles, MessageSquare, ChevronRight } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { Product, Review } from '../types';
import { api } from '../services/api';
import { ProductCard } from './HomePage';
import { BackButton } from '../components/BackButton';

export const ProductDetailsPage: React.FC = () => {
  const {
    activeProductId,
    products,
    navigateTo,
    addToCart,
    toggleWishlist,
    isInWishlist,
    settings,
    showToast,
    currentUser,
    formatPrice,
    isAdmin,
  } = useStore();

  const product = products.find(p => p.id === activeProductId);

  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string | undefined>(undefined);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(undefined);
  const [quantity, setQuantity] = useState(1);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [newReviewComment, setNewReviewComment] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'shipping' | 'reviews'>('details');

  useEffect(() => {
    if (product) {
      setSelectedImageIdx(0);
      if (product.variants?.sizes && product.variants.sizes.length > 0) {
        setSelectedSize(product.variants.sizes[0]);
      }
      if (product.variants?.colors && product.variants.colors.length > 0) {
        setSelectedColor(product.variants.colors[0].name);
      }
      setQuantity(1);

      // Load reviews
      api.getReviews(product.id).then(res => setReviews(res)).catch(() => {});
    }
  }, [product?.id]);

  if (!product || (!isAdmin && product.status !== 'published')) {
    return (
      <div className="max-w-xl mx-auto px-4 py-24 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-stone-100 flex items-center justify-center mx-auto text-stone-400">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <span className="text-[11px] font-bold text-purple-700 uppercase tracking-widest">
          Archived / Unavailable
        </span>
        <h2 className="text-2xl font-bold text-stone-950 font-display">Product No Longer Available</h2>
        <p className="text-xs text-stone-500 max-w-sm mx-auto leading-relaxed">
          This piece has been removed from the catalog or unpublished by the store owner. Please browse our active collection for available items.
        </p>
        <button
          onClick={() => navigateTo('shop')}
          className="px-6 py-2.5 bg-stone-900 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold transition-colors cursor-pointer"
        >
          Return to Shop Catalog
        </button>
      </div>
    );
  }

  const isWishlisted = isInWishlist(product.id);
  const maxAvailable = product.stock;

  const handleAddToCart = () => {
    if (quantity > maxAvailable) {
      showToast(`Cannot order more than available stock (${maxAvailable}).`, 'error');
      return;
    }
    addToCart(product, quantity, { size: selectedSize, color: selectedColor });
  };

  const handleBuyNow = () => {
    if (quantity > maxAvailable) {
      showToast(`Cannot order more than available stock (${maxAvailable}).`, 'error');
      return;
    }
    addToCart(product, quantity, { size: selectedSize, color: selectedColor });
    navigateTo('checkout');
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewComment.trim()) {
      showToast('Please enter your review text.', 'error');
      return;
    }
    setIsSubmittingReview(true);
    try {
      const res = await api.submitReview({
        productId: product.id,
        rating: newReviewRating,
        comment: newReviewComment,
        customerName: currentUser?.fullName || 'Verified Buyer',
      });
      setReviews(prev => [res.review, ...prev]);
      setNewReviewComment('');
      showToast('Review submitted and published! Thank you.', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to submit review', 'error');
    } finally {
      setIsSubmittingReview(false);
    }
  };

  const relatedProducts = products
    .filter(p => p.id !== product.id && p.category === product.category && p.status === 'published')
    .slice(0, 4);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12 pb-24">
      
      {/* Back button & Breadcrumb Navigation */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-200/60 pb-4">
        <BackButton fallbackView="shop" label="Back to Collections" />

        <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-xs text-stone-500">
          <button
            onClick={() => navigateTo('home')}
            className="hover:text-stone-900 transition-colors cursor-pointer"
          >
            Home
          </button>
          <ChevronRight className="w-3 h-3 text-stone-400" />
          <button
            onClick={() => navigateTo('shop', { categorySlug: product.category.toLowerCase() })}
            className="hover:text-stone-900 transition-colors cursor-pointer capitalize"
          >
            {product.category}
          </button>
          <ChevronRight className="w-3 h-3 text-stone-400" />
          <span className="text-stone-900 font-semibold truncate max-w-[180px] sm:max-w-xs">
            {product.name}
          </span>
        </nav>
      </div>

      {/* Main PDP Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        
        {/* Left: Gallery Component */}
        <div className="lg:col-span-7 space-y-4">
          <div className="aspect-4/3 w-full rounded-2xl overflow-hidden bg-stone-100 border border-stone-200">
            <img
              src={product.images[selectedImageIdx] || product.images[0] || '/src/assets/images/novora_cat_fashion_1792421786979.jpg'}
              alt={product.name}
              className="w-full h-full object-cover transition-all duration-300"
              referrerPolicy="no-referrer"
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).src = '/src/assets/images/novora_cat_fashion_1792421786979.jpg';
              }}
            />
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex items-center gap-3 overflow-x-auto pb-2">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImageIdx(idx)}
                  className={`w-20 h-20 rounded-xl overflow-hidden border-2 transition-all cursor-pointer shrink-0 ${
                    selectedImageIdx === idx ? 'border-purple-600 ring-2 ring-purple-100' : 'border-stone-200 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img
                    src={img}
                    alt={`${product.name} thumbnail ${idx + 1}`}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = '/src/assets/images/novora_cat_fashion_1792421786979.jpg';
                    }}
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Contiguous Purchase Module */}
        <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-28">
          
          {/* Header Info */}
          <div>
            <div className="flex items-center justify-between text-xs text-stone-500 font-medium">
              <span className="uppercase tracking-widest">{product.brand}</span>
              <span className="font-mono text-[11px]">SKU: {product.sku}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-display mt-1 text-balance">
              {product.name}
            </h1>

            {/* Ratings & Reviews */}
            <div className="flex items-center gap-2 mt-2">
              <div className="flex items-center text-amber-500 gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < Math.floor(product.rating) ? 'fill-amber-400 text-amber-400' : 'text-stone-300'
                    }`}
                  />
                ))}
              </div>
              <span className="text-xs font-bold text-stone-800 tabular-nums">
                {product.rating.toFixed(1)}
              </span>
              <span className="text-xs text-stone-400">·</span>
              <button
                onClick={() => setActiveTab('reviews')}
                className="text-xs text-stone-500 hover:text-purple-700 underline"
              >
                {reviews.length || product.reviewsCount} reviews
              </button>
            </div>
          </div>

          {/* Pricing Module */}
          <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200/80 flex items-baseline justify-between">
            <div className="flex items-baseline gap-3">
              <span className="text-2xl font-black text-stone-950 tabular-nums">
                {formatPrice(product.sellingPrice)}
              </span>
              {product.originalPrice > product.sellingPrice && (
                <span className="text-sm text-stone-400 line-through tabular-nums">
                  {formatPrice(product.originalPrice)}
                </span>
              )}
            </div>

            {product.discountPercentage > 0 && (
              <span className="px-2.5 py-1 text-xs font-bold text-purple-900 bg-purple-100 rounded-lg">
                Save {product.discountPercentage}%
              </span>
            )}
          </div>

          {/* Color Selection Variant */}
          {product.variants?.colors && product.variants.colors.length > 0 && (
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold text-stone-800">
                <span>Color</span>
                <span className="text-purple-800 font-bold">{selectedColor}</span>
              </div>
              <div className="flex items-center gap-2.5">
                {product.variants.colors.map(col => (
                  <button
                    key={col.name}
                    onClick={() => setSelectedColor(col.name)}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-medium flex items-center gap-2 transition-all cursor-pointer ${
                      selectedColor === col.name
                        ? 'border-purple-600 bg-purple-50 text-purple-900 font-bold ring-1 ring-purple-600'
                        : 'border-stone-200 bg-white text-stone-700 hover:border-stone-300'
                    }`}
                  >
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-stone-300 shrink-0"
                      style={{ backgroundColor: col.hex }}
                    />
                    <span>{col.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Size Selection Variant */}
          {product.variants?.sizes && product.variants.sizes.length > 0 && (
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold text-stone-800">
                <span>Select Size</span>
                <span className="text-purple-800 font-bold">{selectedSize}</span>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                {product.variants.sizes.map(size => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`min-w-10 px-3.5 py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                      selectedSize === size
                        ? 'bg-stone-900 text-white border-stone-900 shadow-xs'
                        : 'bg-white text-stone-700 border-stone-200 hover:border-stone-300'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Stock Level Indicator */}
          <div className="pt-2 text-xs">
            {product.stock > 10 ? (
              <span className="text-emerald-700 font-semibold flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5" /> In Stock & Ready for Immediate Dispatch
              </span>
            ) : product.stock > 0 ? (
              <span className="text-amber-700 font-semibold">
                Low Stock Alert: Only {product.stock} units remaining in inventory.
              </span>
            ) : (
              <span className="text-rose-600 font-bold">
                Currently Out of Stock
              </span>
            )}
          </div>

          {/* Quantity and Action Buttons */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-3">
              {/* Stepper */}
              <div className="flex items-center border border-stone-300 rounded-xl bg-white overflow-hidden h-12">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  disabled={quantity <= 1 || product.stock <= 0}
                  className="px-3.5 h-full text-stone-600 hover:bg-stone-100 disabled:opacity-40 text-sm font-bold"
                >
                  -
                </button>
                <span className="px-4 text-xs font-bold text-stone-900 tabular-nums">
                  {quantity}
                </span>
                <button
                  onClick={() => {
                    if (quantity < maxAvailable) {
                      setQuantity(quantity + 1);
                    } else {
                      showToast(`Cannot exceed maximum available stock (${maxAvailable}).`, 'error');
                    }
                  }}
                  disabled={quantity >= maxAvailable || product.stock <= 0}
                  className="px-3.5 h-full text-stone-600 hover:bg-stone-100 disabled:opacity-40 text-sm font-bold"
                >
                  +
                </button>
              </div>

              {/* Add to Bag */}
              <button
                onClick={handleAddToCart}
                disabled={product.stock <= 0}
                className="flex-1 h-12 bg-stone-950 hover:bg-purple-700 disabled:opacity-40 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add to Bag</span>
              </button>

              {/* Wishlist */}
              <button
                onClick={() => toggleWishlist(product.id)}
                className={`h-12 w-12 rounded-xl border flex items-center justify-center transition-colors cursor-pointer shrink-0 ${
                  isWishlisted
                    ? 'bg-rose-50 border-rose-200 text-rose-600'
                    : 'bg-white border-stone-300 text-stone-700 hover:text-stone-950 hover:border-stone-400'
                }`}
                title={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-rose-500' : ''}`} />
              </button>
            </div>

            {/* Buy Now Button */}
            <button
              onClick={handleBuyNow}
              disabled={product.stock <= 0}
              className="w-full h-12 bg-purple-600 hover:bg-purple-700 disabled:opacity-40 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Instant Buy Now · Cash on Delivery</span>
            </button>
          </div>

          {/* Quick Confidence Strip */}
          <div className="pt-4 border-t border-stone-200 space-y-2 text-xs text-stone-500">
            <p className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-purple-600 shrink-0" />
              <span>Complimentary worldwide courier delivery on orders over ${settings.freeShippingThreshold}</span>
            </p>
            <p className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-purple-600 shrink-0" />
              <span>Official 1-year atelier warranty and certified authenticity guarantee</span>
            </p>
          </div>

        </div>

      </div>

      {/* Tabs Section: Description & Specs, Shipping, Reviews */}
      <div className="pt-10 border-t border-stone-200">
        <div className="flex border-b border-stone-200 gap-8 text-sm font-semibold">
          <button
            onClick={() => setActiveTab('details')}
            className={`pb-4 transition-colors cursor-pointer ${
              activeTab === 'details'
                ? 'text-purple-700 border-b-2 border-purple-700'
                : 'text-stone-500 hover:text-stone-900'
            }`}
          >
            Product Description
          </button>
          <button
            onClick={() => setActiveTab('shipping')}
            className={`pb-4 transition-colors cursor-pointer ${
              activeTab === 'shipping'
                ? 'text-purple-700 border-b-2 border-purple-700'
                : 'text-stone-500 hover:text-stone-900'
            }`}
          >
            Shipping & Return Policies
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`pb-4 transition-colors cursor-pointer ${
              activeTab === 'reviews'
                ? 'text-purple-700 border-b-2 border-purple-700'
                : 'text-stone-500 hover:text-stone-900'
            }`}
          >
            Customer Reviews ({reviews.length})
          </button>
        </div>

        <div className="py-8">
          {activeTab === 'details' && (
            <div className="space-y-6 max-w-3xl">
              <div className="text-stone-700 text-sm leading-relaxed whitespace-pre-line">
                {product.description}
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-stone-100 text-xs">
                <div>
                  <span className="font-bold text-stone-900">Department:</span> {product.category}
                </div>
                <div>
                  <span className="font-bold text-stone-900">Atelier / Brand:</span> {product.brand}
                </div>
                <div>
                  <span className="font-bold text-stone-900">Inventory Status:</span> {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
                </div>
                <div>
                  <span className="font-bold text-stone-900">Serial Identifier:</span> {product.sku}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'shipping' && (
            <div className="space-y-4 max-w-2xl text-xs text-stone-600 leading-relaxed">
              <h4 className="text-sm font-bold text-stone-900">Delivery Information</h4>
              <p>
                All orders are dispatched from our central climate-controlled fulfillment warehouse within 24 business hours. Complimentary courier delivery applies automatically to all orders exceeding ${settings.freeShippingThreshold}. Standard shipping is ${settings.shippingCharge}.
              </p>
              <h4 className="text-sm font-bold text-stone-900 pt-2">Cash on Delivery Verification</h4>
              <p>
                For Cash on Delivery orders, our concierge desk contacts you via telephone to confirm delivery instructions prior to dispatch. Please ensure your delivery telephone and full address fields are complete.
              </p>
              <h4 className="text-sm font-bold text-stone-900 pt-2">30-Day Guaranteed Exchanges</h4>
              <p>
                If your item does not fit or satisfy your standards, return it within 30 days in its original presentation packaging for a prompt replacement or refund.
              </p>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="space-y-8 max-w-3xl">
              {/* Write Review Form */}
              <div className="p-6 bg-stone-50 rounded-2xl border border-stone-200">
                <h4 className="text-sm font-bold text-stone-900 flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-purple-700" />
                  <span>Write a Customer Review</span>
                </h4>
                <form onSubmit={handleReviewSubmit} className="mt-4 space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Your Rating (Stars)
                    </label>
                    <div className="flex items-center gap-1.5">
                      {[1, 2, 3, 4, 5].map(star => (
                        <button
                          type="button"
                          key={star}
                          onClick={() => setNewReviewRating(star)}
                          className="p-1 cursor-pointer focus:outline-none"
                        >
                          <Star
                            className={`w-5 h-5 ${
                              star <= newReviewRating
                                ? 'fill-amber-400 text-amber-400'
                                : 'text-stone-300'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Your Review & Experience
                    </label>
                    <textarea
                      rows={3}
                      placeholder="Describe the fabric quality, comfort, fit, or performance..."
                      value={newReviewComment}
                      onChange={e => setNewReviewComment(e.target.value)}
                      className="w-full p-3 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmittingReview || !newReviewComment.trim()}
                    className="px-5 py-2.5 bg-stone-900 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                  >
                    {isSubmittingReview ? 'Submitting...' : 'Post Verified Review'}
                  </button>
                </form>
              </div>

              {/* Reviews List */}
              <div className="space-y-4">
                {reviews.length === 0 ? (
                  <p className="text-xs text-stone-500 italic">
                    Be the first patron to review this piece!
                  </p>
                ) : (
                  reviews.map(r => (
                    <div key={r.id} className="p-4 bg-white rounded-xl border border-stone-200 space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-stone-900">{r.customerName}</span>
                        <span className="text-[11px] text-stone-400">{r.date}</span>
                      </div>
                      <div className="flex items-center text-amber-500 gap-0.5">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3.5 h-3.5 ${
                              i < r.rating ? 'fill-amber-400 text-amber-400' : 'text-stone-200'
                            }`}
                          />
                        ))}
                      </div>
                      <p className="text-xs text-stone-700 leading-relaxed">{r.comment}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Related Products Grid */}
      {relatedProducts.length > 0 && (
        <div className="pt-12 border-t border-stone-200">
          <h2 className="text-xl font-bold text-stone-950 font-display mb-6">
            You May Also Admire
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map(rel => (
              <ProductCard
                key={rel.id}
                product={rel}
                onSelect={() => navigateTo('product', { productId: rel.id })}
                onAddToCart={() => addToCart(rel, 1)}
                onToggleWishlist={() => toggleWishlist(rel.id)}
                isWishlisted={isInWishlist(rel.id)}
              />
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
