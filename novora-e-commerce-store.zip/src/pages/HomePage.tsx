import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowRight,
  Star,
  Heart,
  Shield,
  RefreshCw,
  Truck,
  Award,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  Gem,
  SlidersHorizontal,
  Flame,
  Clock,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { Product } from '../types';
import beautyBannerImg from '../assets/images/novora_beauty_banner_1793803668180.jpg';

export const HomePage: React.FC = () => {
  const {
    banners,
    categories,
    products,
    navigateTo,
    addToCart,
    toggleWishlist,
    isInWishlist,
    settings,
  } = useStore();

  const [activeBannerIdx, setActiveBannerIdx] = useState(0);

  // Local storage banner listener (per user specification for novora_homepage_banner)
  const [localBanner, setLocalBanner] = useState<{
    image?: string;
    heading?: string;
    subtitle?: string;
    published?: boolean;
  } | null>(null);

  useEffect(() => {
    function loadLocalBanner() {
      try {
        const saved = localStorage.getItem('novora_homepage_banner');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (parsed && parsed.published) {
            setLocalBanner(parsed);
          }
        }
      } catch (e) {
        // non-fatal
      }
    }
    loadLocalBanner();
    window.addEventListener('storage', loadLocalBanner);
    window.addEventListener('novora-banner-updated', loadLocalBanner);
    return () => {
      window.removeEventListener('storage', loadLocalBanner);
      window.removeEventListener('novora-banner-updated', loadLocalBanner);
    };
  }, []);

  // Horizontal slide rail references
  const catRailRef = useRef<HTMLDivElement>(null);
  const featuredRailRef = useRef<HTMLDivElement>(null);
  const bestSellersRailRef = useRef<HTMLDivElement>(null);
  const newArrivalsRailRef = useRef<HTMLDivElement>(null);

  const scrollRail = (ref: React.RefObject<HTMLDivElement | null>, direction: 'left' | 'right') => {
    if (ref.current) {
      const scrollAmount = direction === 'left' ? -340 : 340;
      ref.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  const activeBanners = banners.filter(b => b.isActive);
  const baseBanner = activeBanners[activeBannerIdx] || activeBanners[0] || {
    title: 'Discover Your Beauty & Style',
    subtitle: 'Explore Fashion, Makeup & Beauty Essentials',
    badgeText: 'Curated Collection · Spring / Summer 2026',
    buttonText: 'Shop Now',
    linkUrl: '/shop',
    imageUrl: '/images/novora_beauty_banner.jpg',
  };

  const currentBanner = localBanner && localBanner.published
    ? {
        ...baseBanner,
        title: localBanner.heading || baseBanner.title,
        subtitle: localBanner.subtitle || baseBanner.subtitle,
        imageUrl: localBanner.image || baseBanner.imageUrl,
      }
    : baseBanner;

  const featuredProducts = products.filter(p => p.featured && p.status === 'published');
  const bestSellers = products.filter(p => p.bestSeller && p.status === 'published');
  const newArrivals = [...products].filter(p => p.status === 'published');

  return (
    <div className="space-y-16 lg:space-y-24 pb-20">
      
      {/* 1. HERO CAMPAIGN BANNER (Fashion, Makeup & Beauty Promotional Banner) */}
      <section className="relative bg-stone-950 text-white overflow-hidden min-h-[580px] lg:min-h-[660px] flex items-center">
        {/* Background Image with Contrast Scrim */}
        <div className="absolute inset-0 z-0">
          <img
            src={currentBanner.imageUrl || beautyBannerImg}
            alt={currentBanner.title}
            onError={(e) => {
              if (e.currentTarget.src !== beautyBannerImg) {
                e.currentTarget.src = beautyBannerImg;
              }
            }}
            className="w-full h-full object-cover object-center sm:object-right lg:object-center opacity-85 scale-100 transition-all duration-700"
            referrerPolicy="no-referrer"
          />
          {/* Elegant Scrim: Cream / Dark Alabaster subtle gradient ensuring high contrast readability */}
          <div className="absolute inset-0 bg-gradient-to-r from-stone-950/95 via-stone-950/75 to-stone-950/30 sm:to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-transparent to-stone-950/40" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full">
          <div className="max-w-2xl space-y-6">
            
            {/* NOVORA Brand Banner Kicker */}
            <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-stone-900/80 backdrop-blur-md border border-rose-200/20 text-rose-200 text-xs font-semibold tracking-wider uppercase shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-rose-300" />
              <span className="font-bold tracking-widest text-white">NOVORA ATELIER</span>
              <span className="text-stone-400" aria-hidden="true">·</span>
              <span className="text-stone-300 font-normal">{currentBanner.badgeText || 'Curated Collection · Spring / Summer 2026'}</span>
            </div>

            {/* Attractive Promotional Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight font-display text-balance drop-shadow-sm">
              {currentBanner.title || 'Discover Your Beauty & Style'}
            </h1>

            {/* Supporting Text */}
            <p className="text-sm sm:text-base text-stone-200/90 leading-relaxed max-w-xl font-normal drop-shadow-xs">
              {currentBanner.subtitle || 'Explore Fashion, Makeup & Beauty Essentials'}
            </p>

            {/* Call to Action Buttons */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={() => navigateTo('shop')}
                className="px-8 py-3.5 bg-white hover:bg-rose-50 text-stone-950 text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-xl hover:shadow-2xl flex items-center gap-2 cursor-pointer border border-white"
              >
                <span>{currentBanner.buttonText || 'Shop Now'}</span>
                <ArrowRight className="w-4 h-4 text-purple-700" />
              </button>

              <button
                onClick={() => navigateTo('shop', { categorySlug: 'beauty' })}
                className="px-6 py-3.5 bg-stone-900/85 hover:bg-stone-800 text-rose-100 text-xs font-semibold rounded-xl border border-rose-300/30 backdrop-blur-sm transition-colors cursor-pointer flex items-center gap-2"
              >
                <Gem className="w-3.5 h-3.5 text-rose-300" />
                <span>Explore Beauty &amp; Fashion</span>
              </button>
            </div>

            {/* Banner Dots if multiple */}
            {activeBanners.length > 1 && (
              <div className="flex items-center gap-2 pt-6">
                {activeBanners.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveBannerIdx(idx)}
                    className={`h-1.5 rounded-full transition-all cursor-pointer ${
                      activeBannerIdx === idx ? 'w-8 bg-purple-500' : 'w-2 bg-stone-600 hover:bg-stone-400'
                    }`}
                    aria-label={`Slide ${idx + 1}`}
                  />
                ))}
              </div>
            )}

          </div>
        </div>
      </section>

      {/* 2. VALUE PROPOSITION & TRUST STRIP */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 py-8 border-y border-stone-200">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-stone-900">Complimentary Shipping</h4>
              <p className="text-[11px] text-stone-500">On all orders over ${settings.freeShippingThreshold}</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center shrink-0">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-stone-900">30-Day Guaranteed Returns</h4>
              <p className="text-[11px] text-stone-500">Effortless concierge exchanges</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center shrink-0">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-stone-900">100% Verified Quality</h4>
              <p className="text-[11px] text-stone-500">Rigorous atelier standards</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center shrink-0">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-stone-900">Cash on Delivery</h4>
              <p className="text-[11px] text-stone-500">Pay directly upon doorstep arrival</p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. FEATURED CATEGORIES SECTION (Horizontal Slide Rail with Slider Controls) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-purple-700 uppercase tracking-widest">
                Curated Departments
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 text-[10px] font-bold">
                <SlidersHorizontal className="w-3 h-3" />
                <span>Horizontal Slide</span>
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 mt-1 font-display">
              Shop by Category
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => scrollRail(catRailRef, 'left')}
              className="p-2.5 rounded-xl border border-stone-300 hover:bg-stone-100 text-stone-700 transition-colors cursor-pointer shadow-xs"
              title="Slide Categories Left"
              aria-label="Slide Left"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => scrollRail(catRailRef, 'right')}
              className="p-2.5 rounded-xl border border-stone-300 hover:bg-stone-100 text-stone-700 transition-colors cursor-pointer shadow-xs"
              title="Slide Categories Right"
              aria-label="Slide Right"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => navigateTo('shop')}
              className="text-xs font-bold text-stone-900 hover:text-purple-700 flex items-center gap-1 transition-colors cursor-pointer ml-2"
            >
              <span>View All</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Category Rail with Visible Scrollbar */}
        <div
          ref={catRailRef}
          className="show-horizontal-scroll horizontal-scroll pb-4 -mx-4 px-4 sm:mx-0 sm:px-0"
        >
          <div className="product-container gap-6">
            {categories.map(cat => (
              <div
                key={cat.id}
                onClick={() => navigateTo('shop', { categorySlug: cat.slug })}
                className="w-[280px] sm:w-[320px] shrink-0 group relative rounded-2xl overflow-hidden bg-stone-100 border border-stone-200 cursor-pointer transition-all hover:shadow-xl hover:-translate-y-1"
              >
                <div className="aspect-4/3 w-full overflow-hidden bg-stone-200">
                  <img
                    src={cat.image || '/src/assets/images/novora_cat_fashion_1792421786979.jpg'}
                    alt={cat.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="p-5">
                  <h3 className="text-base font-bold text-stone-900 group-hover:text-purple-700 transition-colors">
                    {cat.name}
                  </h3>
                  <p className="text-xs text-stone-500 mt-1 line-clamp-2 leading-relaxed">
                    {cat.description}
                  </p>
                  <div className="mt-3 flex items-center text-xs font-semibold text-stone-900 group-hover:text-purple-700 gap-1">
                    <span>Browse Products</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. FEATURED PRODUCTS (Horizontal Slide Rail with Slider Controls) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-purple-700 uppercase tracking-widest">
                Editorial Selection
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 text-[10px] font-bold">
                <SlidersHorizontal className="w-3 h-3" />
                <span>Horizontal Slide Rail</span>
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 mt-1 font-display">
              Featured Products
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => scrollRail(featuredRailRef, 'left')}
              className="p-2.5 rounded-xl border border-stone-300 hover:bg-stone-100 text-stone-700 transition-colors cursor-pointer shadow-xs"
              title="Slide Products Left"
              aria-label="Slide Left"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => scrollRail(featuredRailRef, 'right')}
              className="p-2.5 rounded-xl border border-stone-300 hover:bg-stone-100 text-stone-700 transition-colors cursor-pointer shadow-xs"
              title="Slide Products Right"
              aria-label="Slide Right"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => navigateTo('shop')}
              className="text-xs font-bold text-stone-900 hover:text-purple-700 flex items-center gap-1 transition-colors cursor-pointer ml-2"
            >
              <span>See Entire Catalog</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Horizontal Scrolling Products Container with Visible Scrollbar */}
        <div
          ref={featuredRailRef}
          className="show-horizontal-scroll horizontal-scroll pb-6 -mx-4 px-4 sm:mx-0 sm:px-0"
        >
          <div className="product-container gap-6">
            {(featuredProducts.length > 0 ? featuredProducts : products.slice(0, 8)).map(product => (
              <div key={product.id} className="w-[260px] sm:w-[280px] shrink-0">
                <ProductCard
                  product={product}
                  onSelect={() => navigateTo('product', { productId: product.id })}
                  onAddToCart={() => addToCart(product, 1)}
                  onToggleWishlist={() => toggleWishlist(product.id)}
                  isWishlisted={isInWishlist(product.id)}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. SECONDARY EDITORIAL PROMO BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl overflow-hidden bg-stone-950 text-white border border-stone-800 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch min-h-[420px]">
            <div className="lg:col-span-7 p-8 sm:p-12 lg:p-16 flex flex-col justify-center space-y-6 z-10">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-purple-400">
                <Sparkles className="w-4 h-4" />
                <span>Limited Edition Capsule</span>
              </div>
              <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight font-display text-white">
                The Tuscan Leather &amp; Titanium Series
              </h2>
              <p className="text-stone-300 text-sm leading-relaxed max-w-lg">
                Crafted in limited numbers with vegetable-tanned leather and aerospace grade hardware. Each piece is individually stamped and certified for lifetime resilience.
              </p>
              <div className="pt-2 flex items-center gap-4">
                <button
                  onClick={() => navigateTo('shop', { categorySlug: 'accessories' })}
                  className="px-7 py-3 bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow-md"
                >
                  Shop Capsule Series
                </button>
                <span className="text-xs text-stone-400">From $360 · Complimentary Express Delivery</span>
              </div>
            </div>

            <div className="lg:col-span-5 relative min-h-[280px] lg:min-h-full">
              <img
                src="/src/assets/images/novora_promo_banner_1792421788448.jpg"
                alt="Leather & Accessories Capsule"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-stone-950/70 via-transparent to-transparent" />
            </div>
          </div>
        </div>
      </section>

      {/* 6. BEST SELLERS SECTION (Horizontal Slide Rail with Slider Controls) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-purple-700 uppercase tracking-widest">
                Client Favorites
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 text-[10px] font-bold">
                <Flame className="w-3 h-3 text-rose-600" />
                <span>Horizontal Slide Rail</span>
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 mt-1 font-display">
              Best-Selling Essentials
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => scrollRail(bestSellersRailRef, 'left')}
              className="p-2.5 rounded-xl border border-stone-300 hover:bg-stone-100 text-stone-700 transition-colors cursor-pointer shadow-xs"
              title="Slide Best Sellers Left"
              aria-label="Slide Left"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => scrollRail(bestSellersRailRef, 'right')}
              className="p-2.5 rounded-xl border border-stone-300 hover:bg-stone-100 text-stone-700 transition-colors cursor-pointer shadow-xs"
              title="Slide Best Sellers Right"
              aria-label="Slide Right"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => navigateTo('shop')}
              className="text-xs font-bold text-stone-900 hover:text-purple-700 flex items-center gap-1 transition-colors cursor-pointer ml-2"
            >
              <span>View All</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Horizontal Scrolling Products Container with Visible Scrollbar */}
        <div
          ref={bestSellersRailRef}
          className="show-horizontal-scroll horizontal-scroll pb-6 -mx-4 px-4 sm:mx-0 sm:px-0"
        >
          <div className="product-container gap-6">
            {(bestSellers.length > 0 ? bestSellers : products.slice(0, 8)).map(product => (
              <div key={product.id} className="w-[260px] sm:w-[280px] shrink-0">
                <ProductCard
                  product={product}
                  onSelect={() => navigateTo('product', { productId: product.id })}
                  onAddToCart={() => addToCart(product, 1)}
                  onToggleWishlist={() => toggleWishlist(product.id)}
                  isWishlisted={isInWishlist(product.id)}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. NEW SEASONAL ARRIVALS (Horizontal Slide Rail with Slider Controls) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between mb-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-purple-700 uppercase tracking-widest">
                Just Released
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                <Clock className="w-3 h-3 text-emerald-600" />
                <span>Horizontal Slide Rail</span>
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 mt-1 font-display">
              New Seasonal Arrivals
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => scrollRail(newArrivalsRailRef, 'left')}
              className="p-2.5 rounded-xl border border-stone-300 hover:bg-stone-100 text-stone-700 transition-colors cursor-pointer shadow-xs"
              title="Slide New Arrivals Left"
              aria-label="Slide Left"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => scrollRail(newArrivalsRailRef, 'right')}
              className="p-2.5 rounded-xl border border-stone-300 hover:bg-stone-100 text-stone-700 transition-colors cursor-pointer shadow-xs"
              title="Slide New Arrivals Right"
              aria-label="Slide Right"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => navigateTo('shop')}
              className="text-xs font-bold text-stone-900 hover:text-purple-700 flex items-center gap-1 transition-colors cursor-pointer ml-2"
            >
              <span>Explore All</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Horizontal Scrolling Products Container with Visible Scrollbar */}
        <div
          ref={newArrivalsRailRef}
          className="show-horizontal-scroll horizontal-scroll pb-6 -mx-4 px-4 sm:mx-0 sm:px-0"
        >
          <div className="product-container gap-6">
            {newArrivals.slice(0, 10).map(product => (
              <div key={product.id} className="w-[260px] sm:w-[280px] shrink-0">
                <ProductCard
                  product={product}
                  onSelect={() => navigateTo('product', { productId: product.id })}
                  onAddToCart={() => addToCart(product, 1)}
                  onToggleWishlist={() => toggleWishlist(product.id)}
                  isWishlisted={isInWishlist(product.id)}
                />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 8. CUSTOMER RATINGS & REVIEWS SECTION */}
      <section className="bg-stone-50 py-16 border-y border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-xl mx-auto mb-12 space-y-2">
            <span className="text-xs font-semibold text-purple-700 uppercase tracking-widest">
              Authentic Feedback
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-display">
              Loved by Discerning Patrons
            </h2>
            <p className="text-xs text-stone-500">
              Verified reviews from customers across the United States and Europe.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 bg-white rounded-2xl border border-stone-200/80 shadow-xs space-y-3">
              <div className="flex items-center text-amber-500 gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="text-xs text-stone-700 leading-relaxed italic">
                "The drape and tailoring on the double-breasted blazer are unbelievable. Wore it to a gallery opening and received non-stop compliments. True to size with a refined slouch."
              </p>
              <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                <div>
                  <h4 className="font-bold text-stone-900">Sarah Jenkins</h4>
                  <p className="text-[11px] text-stone-400">Atelier Blazer · Verified Buyer</p>
                </div>
                <span className="text-[10px] text-purple-700 font-bold bg-purple-50 px-2 py-0.5 rounded">
                  5.0 ★
                </span>
              </div>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-stone-200/80 shadow-xs space-y-3">
              <div className="flex items-center text-amber-500 gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="text-xs text-stone-700 leading-relaxed italic">
                "The Tuscan weekender bag smells extraordinary. Thick full-grain leather and heavy brass zippers that glide smoothly. This is built for decades of travel."
              </p>
              <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                <div>
                  <h4 className="font-bold text-stone-900">Marcus Sterling</h4>
                  <p className="text-[11px] text-stone-400">Leather Weekender · Verified Buyer</p>
                </div>
                <span className="text-[10px] text-purple-700 font-bold bg-purple-50 px-2 py-0.5 rounded">
                  5.0 ★
                </span>
              </div>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-stone-200/80 shadow-xs space-y-3">
              <div className="flex items-center text-amber-500 gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="text-xs text-stone-700 leading-relaxed italic">
                "Customer concierge responded within 10 minutes when I needed to adjust my delivery address. Effortless white-glove experience and pristine packaging."
              </p>
              <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                <div>
                  <h4 className="font-bold text-stone-900">Elena Rostova</h4>
                  <p className="text-[11px] text-stone-400">Silk Blouse · Verified Buyer</p>
                </div>
                <span className="text-[10px] text-purple-700 font-bold bg-purple-50 px-2 py-0.5 rounded">
                  5.0 ★
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 9. VIP CONCIERGE NEWSLETTER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-stone-900 text-white p-8 sm:p-12 lg:p-16 relative overflow-hidden">
          <div className="absolute -right-20 -bottom-20 w-80 h-80 rounded-full bg-purple-600/10 blur-3xl pointer-events-none" />

          <div className="max-w-2xl space-y-4 relative z-10">
            <span className="text-xs font-semibold text-purple-400 uppercase tracking-widest">
              Private Salon Membership
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight font-display">
              Receive Invitations to Private Drops
            </h2>
            <p className="text-stone-400 text-xs sm:text-sm leading-relaxed">
              Join over 24,000 patrons who receive our quarterly lookbooks, private salon invitations, and advance access to numbered production runs.
            </p>

            <form
              onSubmit={e => {
                e.preventDefault();
                alert('Thank you for subscribing to NOVORA Private Salon.');
              }}
              className="flex flex-col sm:flex-row gap-3 pt-4 max-w-md"
            >
              <input
                type="email"
                placeholder="Enter your personal email"
                required
                className="px-4 py-3 bg-stone-800/80 border border-stone-700 rounded-xl text-xs text-white placeholder-stone-500 focus:outline-none focus:border-purple-500 flex-1"
              />
              <button
                type="submit"
                className="px-6 py-3 bg-white hover:bg-stone-100 text-stone-950 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer whitespace-nowrap"
              >
                Join Salon
              </button>
            </form>
            <p className="text-[10px] text-stone-500">
              Discreet communication only. Unsubscribe at any time with a single click.
            </p>
          </div>
        </div>
      </section>

    </div>
  );
};

interface ProductCardProps {
  product: Product;
  onSelect: () => void;
  onAddToCart: () => void;
  onToggleWishlist: () => void;
  isWishlisted: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onSelect,
  onAddToCart,
  onToggleWishlist,
  isWishlisted,
}) => {
  const { formatPrice } = useStore();

  const mainImg = (product as any).mainImage || (product.images && product.images[0]) || '/src/assets/images/novora_cat_fashion_1792421786979.jpg';

  return (
    <div className="group bg-white rounded-2xl border border-stone-200/80 overflow-hidden flex flex-col justify-between transition-all hover:shadow-xl hover:-translate-y-1 h-full">
      {/* Product Image Box */}
      <div
        onClick={onSelect}
        className="aspect-3/4 w-full bg-stone-100 relative overflow-hidden cursor-pointer"
      >
        <img
          src={mainImg}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 items-start">
          {product.featured && (
            <span className="px-2.5 py-0.5 rounded-full bg-stone-950/80 backdrop-blur-xs text-[10px] font-bold text-white uppercase tracking-wider">
              Featured
            </span>
          )}
          {product.discountPercentage > 0 && (
            <span className="px-2 py-0.5 rounded-full bg-purple-700 text-[10px] font-bold text-white uppercase tracking-wider">
              {product.discountPercentage}% OFF
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={e => {
            e.stopPropagation();
            onToggleWishlist();
          }}
          className={`absolute top-3 right-3 p-2 rounded-full transition-colors cursor-pointer ${
            isWishlisted
              ? 'bg-rose-50 text-rose-600'
              : 'bg-white/80 text-stone-600 hover:text-stone-950 hover:bg-white'
          }`}
          title={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-rose-500' : ''}`} />
        </button>
      </div>

      {/* Card Content */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between text-[11px] text-stone-500 font-medium mb-1">
            <span className="uppercase tracking-wider">{product.brand}</span>
            <div className="flex items-center gap-1 text-amber-500">
              <Star className="w-3 h-3 fill-amber-400" />
              <span className="text-stone-700 font-semibold">{product.rating.toFixed(1)}</span>
            </div>
          </div>

          <h3
            onClick={onSelect}
            className="text-sm font-semibold text-stone-900 hover:text-purple-700 transition-colors cursor-pointer line-clamp-1"
          >
            {product.name}
          </h3>

          <p className="text-xs text-stone-500 mt-1 line-clamp-1">
            {product.description}
          </p>
        </div>

        <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between">
          <div className="flex items-baseline gap-1.5">
            <span className="text-sm font-bold text-stone-950 tabular-nums">
              {formatPrice(product.sellingPrice)}
            </span>
            {product.originalPrice > product.sellingPrice && (
              <span className="text-xs text-stone-400 line-through tabular-nums">
                {formatPrice(product.originalPrice)}
              </span>
            )}
          </div>

          <button
            onClick={e => {
              e.stopPropagation();
              onAddToCart();
            }}
            disabled={product.stock <= 0}
            className="px-3.5 py-1.5 bg-stone-950 hover:bg-purple-700 disabled:opacity-40 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
          >
            {product.stock <= 0 ? 'Out of Stock' : 'Add to Bag'}
          </button>
        </div>
      </div>
    </div>
  );
};
