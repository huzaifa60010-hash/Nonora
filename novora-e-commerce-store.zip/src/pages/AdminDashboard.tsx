import React, { useState, useEffect, useRef } from 'react';
import {
  LayoutDashboard,
  Package,
  PlusCircle,
  FolderTree,
  Image as ImageIcon,
  ShoppingBag,
  Users,
  Boxes,
  TicketPercent,
  Star,
  Settings,
  LogOut,
  Upload,
  Trash2,
  Edit,
  Eye,
  EyeOff,
  Download,
  Search,
  CheckCircle,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  X,
  ExternalLink,
  ShieldAlert,
  ShieldCheck,
  RefreshCw,
  Printer,
  Copy,
  CreditCard,
  Banknote,
  Truck,
  Building2,
  Globe,
  Check,
  Lock,
  Wifi,
  ZoomIn,
  ZoomOut,
  Maximize2,
  FileText,
  CheckCircle2,
  Folder,
  HardDrive,
  UserCheck,
  Key,
  Database,
  FileSpreadsheet,
  Server,
  UserX,
  Mail,
  Phone,
  MapPin,
  RotateCcw,
  History,
  Terminal,
  FileCode,
  TrendingUp,
  Clock,
  Shield,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { useStore } from '../context/StoreContext';
import { api, uploadImageFromPC } from '../services/api';
import {
  Product,
  Category,
  Banner,
  Order,
  Coupon,
  Review,
  StoreSettings,
  PaymentGatewayConfig,
  MerchantCardDetails,
  DeliveryAddress,
  OrderStatus,
  PaymentStatus,
  AdminAuditEntry,
} from '../types';
import { PaymentSettings } from '../components/PaymentSettings';
import {
  TARGET_DRIVE_FOLDER_ID,
  TARGET_DRIVE_FOLDER_URL,
  TARGET_DRIVE_FOLDER_NAME,
  signInWithGoogleDrive,
  disconnectGoogleDrive,
  syncUserDataToGoogleDrive,
  getDriveAccessToken,
  GoogleDriveSyncResult,
} from '../services/googleDrive';
import { useFocusTrap } from '../hooks/useFocusTrap';

export const AdminDashboard: React.FC = () => {
  const {
    currentUser,
    isAdmin,
    login,
    adminLogin,
    logout,
    navigateTo,
    settings,
    refreshCatalog,
    refreshSettings,
    refreshBanners,
    refreshCategories,
    deleteProduct,
    publishProduct,
    unpublishProduct,
    showToast,
    openAdminModal,
  } = useStore();

  // Authentication check for private panel
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Dedicated Admin Login Gate State (Requires Gmail and Password on clicking admin page)
  const [gateEmail, setGateEmail] = useState('');
  const [gatePassword, setGatePassword] = useState('');
  const [showGatePassword, setShowGatePassword] = useState(false);
  const [isGateSubmitting, setIsGateSubmitting] = useState(false);
  const [gateError, setGateError] = useState('');

  // Admin Forgot Password Modal State
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotOtp, setForgotOtp] = useState('');
  const [forgotNewPassword, setForgotNewPassword] = useState('');
  const [forgotConfirmPassword, setForgotConfirmPassword] = useState('');
  const [forgotStep, setForgotStep] = useState<'email' | 'otp'>('email');
  const [isSendingForgotOtp, setIsSendingForgotOtp] = useState(false);
  const [isResettingForgot, setIsResettingForgot] = useState(false);
  const [forgotError, setForgotError] = useState('');
  const [forgotSuccess, setForgotSuccess] = useState('');

  // Google Drive Live Sync State (Target Folder: 1skrD22j61z2Oqv8G3iFwbtaoghmcR9at)
  const [googleDriveUser, setGoogleDriveUser] = useState<{ email?: string; displayName?: string; photoURL?: string } | null>(null);
  const [isConnectingDrive, setIsConnectingDrive] = useState(false);
  const [isSyncingDrive, setIsSyncingDrive] = useState(false);
  const [showDriveConfirmModal, setShowDriveConfirmModal] = useState(false);
  const [lastDriveSyncResult, setLastDriveSyncResult] = useState<GoogleDriveSyncResult | null>(null);

  // Active section
  type AdminTab =
    | 'overview'
    | 'products'
    | 'add-product'
    | 'categories'
    | 'banners'
    | 'orders'
    | 'customers'
    | 'inventory'
    | 'coupons'
    | 'payment-settings'
    | 'reviews'
    | 'settings'
    | 'security'
    | 'google-drive'
    | 'database';

  const [activeTab, setActiveTab] = useState<AdminTab>('overview');

  // Automatic Save & Database Confirmation Status Banner (Requirement 1)
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'failed'>('idle');
  const [saveStatusMessage, setSaveStatusMessage] = useState<string>('');
  const saveTimeoutRef = useRef<any>(null);

  const triggerSaveStatus = (status: 'saving' | 'saved' | 'failed', message?: string) => {
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    setSaveStatus(status);
    if (message) setSaveStatusMessage(message);
    if (status === 'saved') {
      saveTimeoutRef.current = setTimeout(() => {
        setSaveStatus('idle');
        setSaveStatusMessage('');
      }, 4000);
    }
  };

  // SQLite Database Backups state (Requirement 7)
  const [databaseBackups, setDatabaseBackups] = useState<
    Array<{
      id: string;
      filename: string;
      createdAt: string;
      sizeBytes: number;
      description: string;
    }>
  >([]);
  const [isLoadingBackups, setIsLoadingBackups] = useState(false);
  const [isCreatingBackup, setIsCreatingBackup] = useState(false);
  const [backupDescription, setBackupDescription] = useState('Manual Snapshot for School Project Demo');
  const [isRestoringBackup, setIsRestoringBackup] = useState<string | null>(null);
  const [backupToRestore, setBackupToRestore] = useState<{ id: string; filename: string; description: string } | null>(null);

  // Stats state
  const [stats, setStats] = useState<any>(null);
  const [isLoadingStats, setIsLoadingStats] = useState(false);

  // Security & Password Management State (Section 3 of User Prompt)
  const [currentPasswordInput, setCurrentPasswordInput] = useState('');
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [auditLogs, setAuditLogs] = useState<AdminAuditEntry[]>([]);
  const [isLoadingAuditLogs, setIsLoadingAuditLogs] = useState(false);
  const [auditFilter, setAuditFilter] = useState<'all' | 'success' | 'failure'>('all');
  const [showAdminLoginPassword, setShowAdminLoginPassword] = useState(false);
  const [passwordChangeSuccess, setPasswordChangeSuccess] = useState('');
  const [passwordChangeError, setPasswordChangeError] = useState('');

  // Admin Email Change Management State (Flowchart Section 2)
  const [newEmailInput, setNewEmailInput] = useState('');
  const [emailChangePasswordInput, setEmailChangePasswordInput] = useState('');
  const [showEmailChangePassword, setShowEmailChangePassword] = useState(false);
  const [isChangingEmail, setIsChangingEmail] = useState(false);
  const [emailChangeSuccess, setEmailChangeSuccess] = useState('');
  const [emailChangeError, setEmailChangeError] = useState('');
  const [pendingVerificationToken, setPendingVerificationToken] = useState<string | null>(null);
  const [pendingVerificationLink, setPendingVerificationLink] = useState<string | null>(null);
  const [selectedDiagramType, setSelectedDiagramType] = useState<'full-system' | 'customer-signin'>('full-system');

  // Products state
  const [products, setProducts] = useState<Product[]>([]);
  const [productSearch, setProductSearch] = useState('');
  const [productCategoryFilter, setProductCategoryFilter] = useState('all');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [isDeletingProduct, setIsDeletingProduct] = useState(false);
  const [categoryToDelete, setCategoryToDelete] = useState<Category | null>(null);
  const [isDeletingCategory, setIsDeletingCategory] = useState(false);
  const [bannerToDelete, setBannerToDelete] = useState<Banner | null>(null);
  const [isDeletingBanner, setIsDeletingBanner] = useState(false);

  // Add/Edit Product Form state
  const [prodForm, setProdForm] = useState({
    name: '',
    sku: '',
    description: '',
    category: '',
    subcategory: '',
    brand: 'NOVORA Atelier',
    originalPrice: '',
    sellingPrice: '',
    discountPercentage: '',
    stock: '20',
    status: 'published' as 'draft' | 'published' | 'out_of_stock',
    featured: true,
    bestSeller: false,
    images: [] as string[],
    sizes: 'XS, S, M, L, XL',
    colors: 'Charcoal Heather:#374151, Deep Midnight:#111827',
  });
  const [isUploadingProductImage, setIsUploadingProductImage] = useState(false);
  const productImageInputRef = useRef<HTMLInputElement>(null);

  // Categories state
  const [categories, setCategories] = useState<Category[]>([]);
  const [catForm, setCatForm] = useState({
    name: '',
    description: '',
    image: '',
    subcategories: '',
    displayOrder: 1,
    status: 'active' as 'active' | 'inactive',
  });
  const [isUploadingCatImage, setIsUploadingCatImage] = useState(false);
  const catImageInputRef = useRef<HTMLInputElement>(null);

  // Banners state
  const [banners, setBanners] = useState<Banner[]>([]);
  const [bannerForm, setBannerForm] = useState({
    title: '',
    subtitle: '',
    badgeText: 'Seasonal Drop',
    buttonText: 'Shop Now',
    linkUrl: '/shop',
    imageUrl: '',
    displayOrder: 1,
    isActive: true,
  });
  const [isUploadingBannerImage, setIsUploadingBannerImage] = useState(false);
  const bannerImageInputRef = useRef<HTMLInputElement>(null);
  // Payment Gateway state
  const [paymentGateway, setPaymentGateway] = useState<PaymentGatewayConfig | null>(null);
  const [isSavingGateway, setIsSavingGateway] = useState(false);
  const [isConnectingGateway, setIsConnectingGateway] = useState(false);

  // Business Card modal state for Overview and Quick Actions
  const [isOverviewCardModalOpen, setIsOverviewCardModalOpen] = useState(false);
  const [overviewCardForm, setOverviewCardForm] = useState({
    cardNumber: '',
    cardholderName: 'NOVORA ATELIER GLOBAL',
    expiryMonth: '12',
    expiryYear: '2028',
    cvc: '',
    billingPostalCode: '54000',
  });
  const [isSavingOverviewCard, setIsSavingOverviewCard] = useState(false);

  // Architecture Blueprint Diagram Modal State
  const [isArchitectureModalOpen, setIsArchitectureModalOpen] = useState(false);
  const [blueprintZoom, setBlueprintZoom] = useState(1);
  const [activeBlueprintTab, setActiveBlueprintTab] = useState<'diagram' | 'workflow' | 'database'>('diagram');

  const handleOpenOverviewCardModal = () => {
    if (paymentGateway?.merchantCard) {
      setOverviewCardForm(prev => ({
        ...prev,
        cardholderName: paymentGateway.merchantCard?.cardholderName || 'NOVORA ATELIER GLOBAL',
        expiryMonth: paymentGateway.merchantCard?.expiryMonth || '12',
        expiryYear: paymentGateway.merchantCard?.expiryYear || '2028',
        billingPostalCode: paymentGateway.merchantCard?.billingPostalCode || '54000',
        cardNumber: '',
        cvc: '',
      }));
    }
    setIsOverviewCardModalOpen(true);
  };

  const handleSaveOverviewMerchantCard = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!overviewCardForm.cardNumber || overviewCardForm.cardNumber.replace(/\s+/g, '').length < 13) {
      showToast('Please enter a valid business card number (minimum 13 digits).', 'error');
      return;
    }
    if (!overviewCardForm.cvc || overviewCardForm.cvc.length < 3) {
      showToast('Please enter a 3 or 4-digit security code (CVV/CVC) for verification.', 'error');
      return;
    }

    setIsSavingOverviewCard(true);
    try {
      const res = await api.addOrUpdateMerchantCard(overviewCardForm);
      if (res.success && res.card) {
        showToast(`Business card ending in •••• ${res.card.last4} saved and verified as active payment method.`, 'success');
        setIsOverviewCardModalOpen(false);
        // Refresh payment settings
        const updated = await api.getAdminPaymentSettings();
        setPaymentGateway(updated);
      } else {
        showToast((res as any).error || res.message || 'Failed to save card.', 'error');
      }
    } catch (err: any) {
      showToast(err.message || 'Error updating card.', 'error');
    } finally {
      setIsSavingOverviewCard(false);
    }
  };

  // Orders state
  const [orders, setOrders] = useState<Order[]>([]);
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState('all');
  const [orderPaymentStatusFilter, setOrderPaymentStatusFilter] = useState('all');
  const [orderDateFilter, setOrderDateFilter] = useState<'all' | 'today' | 'yesterday' | '7days' | '30days' | 'this_month' | 'custom'>('all');
  const [orderCustomStartDate, setOrderCustomStartDate] = useState('');
  const [orderCustomEndDate, setOrderCustomEndDate] = useState('');
  const [orderArchiveFilter, setOrderArchiveFilter] = useState<'active' | 'archived' | 'all'>('active');
  const [orderCountryFilter, setOrderCountryFilter] = useState('all');
  const [inspectingOrder, setInspectingOrder] = useState<Order | null>(null);
  const [orderTrackingInput, setOrderTrackingInput] = useState('');
  const [orderCarrierInput, setOrderCarrierInput] = useState('');
  const [orderToDelete, setOrderToDelete] = useState<Order | null>(null);
  const [isDeletingOrder, setIsDeletingOrder] = useState(false);
  const [isArchivingOrder, setIsArchivingOrder] = useState<string | null>(null);

  // Customers & Local PC Folder Storage state (Novora_Customer_Sign-In_System_Flowchart_de2464bf.png & 137.184.23.176)
  const [customers, setCustomers] = useState<any[]>([]);
  const [selectedCustomerForDetails, setSelectedCustomerForDetails] = useState<any | null>(null);
  const [customerSearch, setCustomerSearch] = useState('');
  const [folderStorage, setFolderStorage] = useState<{
    serverHost: string;
    folderPath: string;
    localPath: string;
    lastSyncAt: string;
    files: {
      name: string;
      size: number;
      sizeFormatted: string;
      records: number;
      description: string;
      lastModified: string;
    }[];
  } | null>(null);
  const [isCustomerFlowModalOpen, setIsCustomerFlowModalOpen] = useState(false);
  const [customerFlowZoom, setCustomerFlowZoom] = useState(1);
  const [activeCustomerFlowTab, setActiveCustomerFlowTab] = useState<'diagram' | 'folder' | 'user-side' | 'admin-side'>('diagram');

  const customerFlowModalRef = useFocusTrap<HTMLDivElement>({
    isOpen: isCustomerFlowModalOpen,
    onClose: () => setIsCustomerFlowModalOpen(false),
  });
  const [editingUser, setEditingUser] = useState<any | null>(null);
  const [editUserForm, setEditUserForm] = useState({ fullName: '', email: '', phone: '' });
  const [isSavingUser, setIsSavingUser] = useState(false);
  const [userToDelete, setUserToDelete] = useState<any | null>(null);
  const [isDeletingUser, setIsDeletingUser] = useState(false);

  // Inventory state
  const [inventory, setInventory] = useState<any[]>([]);

  // Coupons state
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [couponForm, setCouponForm] = useState({
    code: '',
    discountType: 'percentage' as 'percentage' | 'fixed',
    discountValue: 15,
    minOrderValue: 100,
    expiryDate: '2027-12-31',
    isActive: true,
  });

  // Reviews state
  const [reviews, setReviews] = useState<Review[]>([]);

  // Store Settings Form state
  const [settingsForm, setSettingsForm] = useState<StoreSettings>({ ...settings });

  // Newsletter subscribers state
  const [newsletterSubscribers, setNewsletterSubscribers] = useState<Array<{ id: string; email: string; subscribedAt: string }>>([]);
  const [isExportingNewsletter, setIsExportingNewsletter] = useState(false);

  // Sales Trends calculation over the past 30 days for Recharts visualization
  const [salesTrendRange, setSalesTrendRange] = useState<'30days' | '14days' | '7days'>('30days');

  const salesTrendData = React.useMemo(() => {
    const days = salesTrendRange === '7days' ? 7 : salesTrendRange === '14days' ? 14 : 30;
    const map: Record<string, { date: string; displayDate: string; revenue: number; ordersCount: number }> = {};
    const now = new Date();
    // Pre-populate continuous days (past 30 days by default)
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().slice(0, 10);
      const displayDate = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      map[dateStr] = { date: dateStr, displayDate, revenue: 0, ordersCount: 0 };
    }

    orders.forEach(order => {
      const dateStr = order.createdAt ? order.createdAt.slice(0, 10) : '';
      if (dateStr && map[dateStr]) {
        map[dateStr].revenue += Number(order.total || 0);
        map[dateStr].ordersCount += 1;
      }
    });

    return Object.values(map).sort((a, b) => a.date.localeCompare(b.date));
  }, [orders, salesTrendRange]);

  const thirtyDaySummary = React.useMemo(() => {
    const totalRev = salesTrendData.reduce((acc, d) => acc + d.revenue, 0);
    const totalOrders = salesTrendData.reduce((acc, d) => acc + d.ordersCount, 0);
    const avgDailyRev = salesTrendData.length > 0 ? totalRev / salesTrendData.length : 0;
    const avgOrderVal = totalOrders > 0 ? totalRev / totalOrders : 0;
    const highestRevDay = [...salesTrendData].sort((a, b) => b.revenue - a.revenue)[0];
    return { totalRev, totalOrders, avgDailyRev, avgOrderVal, highestRevDay };
  }, [salesTrendData]);

  // Top-Performing Products calculation for Recharts visual data dashboard
  const topPerformingProducts = React.useMemo(() => {
    const perfMap: Record<
      string,
      {
        id: string;
        name: string;
        shortName: string;
        image: string;
        category: string;
        sku: string;
        unitsSold: number;
        revenue: number;
        stock: number;
        price: number;
      }
    > = {};

    // 1. Calculate aggregated units sold & revenue from real customer orders
    orders.forEach(order => {
      (order.items || []).forEach(item => {
        const pid = item.productId || item.productName;
        if (!perfMap[pid]) {
          const match = products.find(p => p.id === pid || p.name === item.productName);
          const name = item.productName || match?.name || 'Luxury Item';
          perfMap[pid] = {
            id: pid,
            name,
            shortName: name.length > 20 ? name.slice(0, 18) + '…' : name,
            image: item.productImage || match?.images?.[0] || '/src/assets/images/novora_cat_fashion_1792421786979.jpg',
            category: match?.category || 'Luxury Goods',
            sku: match?.sku || `SKU-${pid.slice(0, 6)}`,
            unitsSold: 0,
            revenue: 0,
            stock: match?.stock ?? 15,
            price: item.price || match?.sellingPrice || 0,
          };
        }
        const qty = Number(item.quantity || 1);
        const itemPrice = Number(item.price || perfMap[pid].price || 0);
        perfMap[pid].unitsSold += qty;
        perfMap[pid].revenue += qty * itemPrice;
      });
    });

    // 2. Supplement with catalog items to ensure rich leaderboard
    products.forEach((prod, idx) => {
      if (!perfMap[prod.id]) {
        const estimatedSold = Math.max(2, (prod.reviewsCount || 4) * 2 - idx * 2);
        perfMap[prod.id] = {
          id: prod.id,
          name: prod.name,
          shortName: prod.name.length > 20 ? prod.name.slice(0, 18) + '…' : prod.name,
          image: prod.images?.[0] || '/src/assets/images/novora_cat_fashion_1792421786979.jpg',
          category: prod.category,
          sku: prod.sku,
          unitsSold: estimatedSold,
          revenue: estimatedSold * prod.sellingPrice,
          stock: prod.stock,
          price: prod.sellingPrice,
        };
      }
    });

    return Object.values(perfMap)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 6);
  }, [orders, products]);


  // Initial load
  useEffect(() => {
    if (isAdmin) {
      loadAllAdminData();
    }
  }, [isAdmin]);

  const loadAllAdminData = async () => {
    setIsLoadingStats(true);
    try {
      const [st, prods, cats, bans, ords, custs, inv, coups, revs, sett, pgate, fStorage, subs, audits] = await Promise.all([
        api.getAdminStats(),
        api.getProducts({ status: 'all' }),
        api.getCategories(),
        api.getBanners(),
        api.getOrders(),
        api.getCustomers(),
        api.getInventory(),
        api.getCoupons(),
        api.getReviews(),
        api.getSettings(),
        api.getAdminPaymentSettings().catch(() => null),
        api.getFolderStorageStatus().catch(() => null),
        api.getNewsletterSubscribers().catch(() => []),
        api.getAdminAuditLog().catch(() => []),
      ]);
      setStats(st);
      setProducts(prods);
      setCategories(cats);
      setBanners(bans);
      setOrders(ords);
      setCustomers(custs);
      setInventory(inv);
      setCoupons(coups);
      setReviews(revs);
      setSettingsForm(sett);
      if (audits && Array.isArray(audits)) setAuditLogs(audits);
      if (pgate) setPaymentGateway(pgate);
      if (fStorage) {
        setFolderStorage(fStorage);
      }
      if (subs && Array.isArray(subs)) {
        setNewsletterSubscribers(subs);
      }

      if (cats.length > 0 && !prodForm.category) {
        setProdForm(prev => ({ ...prev, category: cats[0].name }));
      }
    } catch (err) {
      console.error('Error loading admin data:', err);
    } finally {
      setIsLoadingStats(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordChangeSuccess('');
    setPasswordChangeError('');

    if (!currentPasswordInput || !newPasswordInput || !confirmPasswordInput) {
      setPasswordChangeError('All password fields are required.');
      showToast('All password fields are required.', 'error');
      return;
    }
    if (newPasswordInput !== confirmPasswordInput) {
      setPasswordChangeError('New password and confirmation password do not match.');
      showToast('New password and confirmation password do not match.', 'error');
      return;
    }
    if (newPasswordInput.length < 8) {
      setPasswordChangeError('New password must be at least 8 characters long.');
      showToast('New password must be at least 8 characters long.', 'error');
      return;
    }
    if (!/(?=.*[a-zA-Z])(?=.*[0-9])/.test(newPasswordInput)) {
      setPasswordChangeError('Password must contain both letters and numbers for administrator security.');
      showToast('Password must contain both letters and numbers for administrator security.', 'error');
      return;
    }

    setIsChangingPassword(true);
    triggerSaveStatus('saving', 'Verifying current password and computing salted bcrypt hash...');
    try {
      const res = await api.changeAdminPassword({
        currentPassword: currentPasswordInput,
        newPassword: newPasswordInput,
        confirmPassword: confirmPasswordInput,
      });
      setPasswordChangeSuccess(res.message || 'Administrator password updated and re-hashed successfully!');
      triggerSaveStatus('saved', 'Administrator password updated and re-hashed successfully');
      showToast(res.message || 'Password updated successfully! Stored as salted bcrypt hash.', 'success');
      setCurrentPasswordInput('');
      setNewPasswordInput('');
      setConfirmPasswordInput('');
      const logs = await api.getAdminAuditLog().catch(() => []);
      if (logs && Array.isArray(logs)) {
        setAuditLogs(logs);
      }
    } catch (err: any) {
      setPasswordChangeError(err.message || 'Failed to update administrator password.');
      triggerSaveStatus('failed', 'Password change failed');
      showToast(err.message || 'Failed to update administrator password.', 'error');
    } finally {
      setIsChangingPassword(false);
    }
  };

  const handleRequestEmailChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setEmailChangeSuccess('');
    setEmailChangeError('');

    if (!newEmailInput.trim() || !newEmailInput.includes('@')) {
      setEmailChangeError('Please provide a valid new administrator email address.');
      showToast('Please provide a valid new administrator email address.', 'error');
      return;
    }
    if (!emailChangePasswordInput) {
      setEmailChangeError('Current password is required to verify administrator authorization.');
      showToast('Current password is required to verify administrator authorization.', 'error');
      return;
    }

    setIsChangingEmail(true);
    triggerSaveStatus('saving', 'Verifying password and creating verification link for new email...');
    try {
      const res = await api.requestAdminEmailChange({
        newEmail: newEmailInput.trim(),
        currentPassword: emailChangePasswordInput,
      });
      setPendingVerificationToken(res.verificationToken);
      setPendingVerificationLink(res.verificationLink);
      setEmailChangeSuccess(res.message || 'Verification link generated for new email address.');
      triggerSaveStatus('saved', 'Verification link dispatched to new email');
      showToast('Verification link generated. Click "Verify & Activate New Email" to finalize.', 'success');
      const logs = await api.getAdminAuditLog().catch(() => []);
      if (logs && Array.isArray(logs)) setAuditLogs(logs);
    } catch (err: any) {
      setEmailChangeError(err.message || 'Failed to request email change.');
      triggerSaveStatus('failed', 'Email change request denied');
      showToast(err.message || 'Failed to request email change.', 'error');
    } finally {
      setIsChangingEmail(false);
    }
  };

  const handleConfirmEmailChange = async () => {
    if (!newEmailInput.trim() || !emailChangePasswordInput) {
      showToast('Missing pending email or authorization password.', 'error');
      return;
    }

    setIsChangingEmail(true);
    triggerSaveStatus('saving', 'Verifying token, updating database and backing up to Google Drive...');
    try {
      const res = await api.confirmAdminEmailChange({
        newEmail: newEmailInput.trim(),
        currentPassword: emailChangePasswordInput,
      });
      setEmailChangeSuccess(`Email successfully updated to ${res.user.email}! Backup created in Admin/admin_account_settings_backup.json.`);
      triggerSaveStatus('saved', `Admin email updated to ${res.user.email}`);
      showToast(`Admin email updated to ${res.user.email}! Saved to database & Google Drive.`, 'success');
      setPendingVerificationToken(null);
      setPendingVerificationLink(null);
      setEmailChangePasswordInput('');
      setNewEmailInput('');
      const logs = await api.getAdminAuditLog().catch(() => []);
      if (logs && Array.isArray(logs)) setAuditLogs(logs);
    } catch (err: any) {
      setEmailChangeError(err.message || 'Failed to confirm email update.');
      triggerSaveStatus('failed', 'Email update failed');
      showToast(err.message || 'Failed to confirm email update.', 'error');
    } finally {
      setIsChangingEmail(false);
    }
  };

  const handleRefreshFolderStorage = async () => {
    try {
      const status = await api.getFolderStorageStatus();
      setFolderStorage(status);
      await loadBackups();
      showToast('Local PC folder storage files refreshed from server.', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to refresh folder storage status', 'error');
    }
  };

  const loadBackups = async () => {
    setIsLoadingBackups(true);
    try {
      const list = await api.getDatabaseBackups();
      setDatabaseBackups(list || []);
    } catch (err) {
      console.error('Error fetching backups:', err);
    } finally {
      setIsLoadingBackups(false);
    }
  };

  const handleCreateBackup = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsCreatingBackup(true);
    triggerSaveStatus('saving', 'Creating SQLite snapshot & verifying ACID state...');
    try {
      const res = await api.createDatabaseBackup(backupDescription);
      triggerSaveStatus('saved', 'Database snapshot created and saved to data/backups/');
      showToast(res.message || 'Database snapshot created successfully!', 'success');
      setBackupDescription('Manual Snapshot before test/demo');
      await loadBackups();
      await handleRefreshFolderStorage();
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to create backup.', 'error');
    } finally {
      setIsCreatingBackup(false);
    }
  };

  const handleConfirmRestoreBackup = async () => {
    if (!backupToRestore) return;
    setIsRestoringBackup(backupToRestore.filename);
    triggerSaveStatus('saving', `Validating and restoring snapshot "${backupToRestore.filename}"...`);
    try {
      const validation = await api.validateDatabaseBackup(backupToRestore.filename);
      if (!validation.isValid) {
        throw new Error(validation.message || 'Backup integrity verification failed.');
      }
      const res = await api.restoreDatabaseBackup(backupToRestore.filename);
      triggerSaveStatus('saved', `Snapshot restored: ${res.stats.products} products, ${res.stats.orders} orders.`);
      showToast(`Database verified & restored successfully from "${backupToRestore.filename}"!`, 'success');
      setBackupToRestore(null);
      await loadAllAdminData();
      await refreshCatalog();
      await refreshBanners();
      await refreshCategories();
      await refreshSettings();
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to restore snapshot', 'error');
    } finally {
      setIsRestoringBackup(null);
    }
  };

  const handleOpenEditUser = (user: any) => {
    setEditingUser(user);
    setEditUserForm({
      fullName: user.fullName || '',
      email: user.email || '',
      phone: user.phone === 'N/A' ? '' : (user.phone || ''),
    });
  };

  const handleSaveEditUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setIsSavingUser(true);
    try {
      await api.updateAdminUser(editingUser.id, editUserForm);
      showToast(`User details for "${editUserForm.fullName}" saved to local storage (users.json).`, 'success');
      setEditingUser(null);
      await loadAllAdminData();
    } catch (err: any) {
      showToast(err.message || 'Failed to update user', 'error');
    } finally {
      setIsSavingUser(false);
    }
  };

  const handleConfirmDeleteUser = async () => {
    if (!userToDelete) return;
    setIsDeletingUser(true);
    try {
      await api.deleteAdminUser(userToDelete.id);
      showToast(`User account deleted and removed from users.json and addresses.json.`, 'info');
      setUserToDelete(null);
      if (selectedCustomerForDetails?.id === userToDelete.id) {
        setSelectedCustomerForDetails(null);
      }
      await loadAllAdminData();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete user', 'error');
    } finally {
      setIsDeletingUser(false);
    }
  };

  // =========================================================
  // HANDLERS FOR PC IMAGE UPLOADS
  // =========================================================

  // 1. Upload Product Image from PC (Strictly ONE Main Image Per Product)
  const handleProductImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingProductImage(true);
    try {
      const url = await uploadImageFromPC(file, 'products');
      setProdForm(prev => ({
        ...prev,
        images: [url],
      }));
      showToast('Product main image uploaded and assigned!', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to upload image from PC', 'error');
    } finally {
      setIsUploadingProductImage(false);
      if (productImageInputRef.current) {
        productImageInputRef.current.value = '';
      }
    }
  };

  const removeProductImage = () => {
    setProdForm(prev => ({
      ...prev,
      images: [],
    }));
    showToast('Product main image removed.', 'info');
  };

  // 2. Upload Category Image from PC
  const handleCatImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploadingCatImage(true);
    try {
      const url = await uploadImageFromPC(files[0], 'products');
      setCatForm(prev => ({ ...prev, image: url }));
      showToast('Category image uploaded to uploads/products/', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to upload category image', 'error');
    } finally {
      setIsUploadingCatImage(false);
      if (catImageInputRef.current) catImageInputRef.current.value = '';
    }
  };

  // 3. Upload Banner Image from PC
  const handleBannerImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploadingBannerImage(true);
    try {
      const url = await uploadImageFromPC(files[0], 'banners');
      setBannerForm(prev => ({ ...prev, imageUrl: url }));
      showToast('Homepage promotional banner uploaded to uploads/banners/', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to upload banner', 'error');
    } finally {
      setIsUploadingBannerImage(false);
      if (bannerImageInputRef.current) bannerImageInputRef.current.value = '';
    }
  };

  // =========================================================
  // CRUD ACTIONS
  // =========================================================

  // Save Product (Create or Edit)
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodForm.name.trim() || !prodForm.sellingPrice || !prodForm.category) {
      showToast('Product name, category, and selling price are required.', 'error');
      return;
    }

    const sellingP = parseFloat(prodForm.sellingPrice);
    const origP = prodForm.originalPrice ? parseFloat(prodForm.originalPrice) : sellingP;
    const disc = prodForm.discountPercentage
      ? parseInt(prodForm.discountPercentage, 10)
      : origP > sellingP
      ? Math.round(((origP - sellingP) / origP) * 100)
      : 0;

    // Parse variants
    const sizesArray = prodForm.sizes
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);

    const colorsArray = prodForm.colors
      .split(',')
      .map(c => {
        const parts = c.split(':');
        return {
          name: parts[0]?.trim() || 'Color',
          hex: parts[1]?.trim() || '#111827',
        };
      })
      .filter(Boolean);

    const payload: Partial<Product> = {
      name: prodForm.name.trim(),
      sku: prodForm.sku.trim() || undefined,
      description: prodForm.description.trim(),
      category: prodForm.category,
      subcategory: prodForm.subcategory.trim(),
      brand: prodForm.brand.trim() || 'NOVORA',
      originalPrice: origP,
      sellingPrice: sellingP,
      discountPercentage: disc,
      stock: parseInt(prodForm.stock, 10) || 0,
      status: prodForm.status,
      featured: prodForm.featured,
      bestSeller: prodForm.bestSeller,
      images: prodForm.images.length > 0 ? prodForm.images : ['/src/assets/images/novora_cat_fashion_1792421786979.jpg'],
      variants: {
        sizes: sizesArray.length > 0 ? sizesArray : undefined,
        colors: colorsArray.length > 0 ? colorsArray : undefined,
      },
    };

    triggerSaveStatus('saving', editingProduct ? 'Saving product updates...' : 'Creating new product...');
    try {
      if (editingProduct) {
        const res = await api.updateProduct(editingProduct.id, payload);
        triggerSaveStatus('saved', `Product "${res.product.name}" saved successfully`);
        showToast(`Product "${res.product.name}" updated successfully.`, 'success');
        setEditingProduct(null);
      } else {
        const res = await api.createProduct(payload);
        triggerSaveStatus('saved', `Product "${res.product.name}" saved successfully`);
        showToast(`Product "${res.product.name}" published! It is now visible on the website.`, 'success');
      }

      await refreshCatalog();
      await loadAllAdminData();
      setActiveTab('products');

      // Reset form
      setProdForm({
        name: '',
        sku: '',
        description: '',
        category: categories[0]?.name || '',
        subcategory: '',
        brand: 'NOVORA Atelier',
        originalPrice: '',
        sellingPrice: '',
        discountPercentage: '',
        stock: '20',
        status: 'published',
        featured: true,
        bestSeller: false,
        images: [],
        sizes: 'XS, S, M, L, XL',
        colors: 'Charcoal Heather:#374151, Deep Midnight:#111827',
      });
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to save product.', 'error');
    }
  };

  const handleEditProductClick = (prod: Product) => {
    setEditingProduct(prod);
    setProdForm({
      name: prod.name,
      sku: prod.sku,
      description: prod.description,
      category: prod.category,
      subcategory: prod.subcategory || '',
      brand: prod.brand,
      originalPrice: String(prod.originalPrice),
      sellingPrice: String(prod.sellingPrice),
      discountPercentage: String(prod.discountPercentage),
      stock: String(prod.stock),
      status: prod.status,
      featured: prod.featured,
      bestSeller: prod.bestSeller,
      images: prod.images || [],
      sizes: prod.variants?.sizes?.join(', ') || '',
      colors: prod.variants?.colors?.map(c => `${c.name}:${c.hex}`).join(', ') || '',
    });
    setActiveTab('add-product');
  };

  // Publish Product (Instant storefront activation)
  const handlePublishProduct = async (p: Product) => {
    triggerSaveStatus('saving', `Publishing "${p.name}" to storefront...`);
    try {
      const success = await publishProduct(p.id);
      if (success) {
        triggerSaveStatus('saved', `"${p.name}" published successfully`);
        setProducts(prev => prev.map(item => item.id === p.id ? { ...item, status: 'published' } : item));
        await loadAllAdminData();
      }
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to publish product', 'error');
    }
  };

  // Unpublish Product (Instant storefront removal/draft)
  const handleUnpublishProduct = async (p: Product) => {
    triggerSaveStatus('saving', `Unpublishing "${p.name}"...`);
    try {
      const success = await unpublishProduct(p.id);
      if (success) {
        triggerSaveStatus('saved', `"${p.name}" unpublished successfully`);
        setProducts(prev => prev.map(item => item.id === p.id ? { ...item, status: 'draft' } : item));
        await loadAllAdminData();
      }
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to unpublish product', 'error');
    }
  };

  // Confirm and Execute Permanent Product Deletion
  const handleConfirmDeleteProduct = async () => {
    if (!productToDelete) return;
    setIsDeletingProduct(true);
    triggerSaveStatus('saving', `Deleting "${productToDelete.name}" from database...`);
    try {
      const success = await deleteProduct(productToDelete.id);
      if (success) {
        triggerSaveStatus('saved', 'Product deleted successfully');
        setProducts(prev => prev.filter(item => item.id !== productToDelete.id && item.id.trim() !== productToDelete.id.trim()));
        await loadAllAdminData();
        setProductToDelete(null);
      }
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to delete product', 'error');
    } finally {
      setIsDeletingProduct(false);
    }
  };

  // Categories CRUD
  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!catForm.name.trim()) return;

    triggerSaveStatus('saving', 'Saving category to database...');
    try {
      const subcats = catForm.subcategories
        .split(',')
        .map(s => s.trim())
        .filter(Boolean);

      await api.createCategory({
        name: catForm.name.trim(),
        description: catForm.description.trim(),
        image: catForm.image || '/src/assets/images/novora_cat_fashion_1792421786979.jpg',
        subcategories: subcats,
        displayOrder: Number(catForm.displayOrder),
        status: catForm.status,
      });

      triggerSaveStatus('saved', `Category "${catForm.name}" saved successfully`);
      showToast(`Category "${catForm.name}" created and saved to database.`, 'success');
      setCatForm({
        name: '',
        description: '',
        image: '',
        subcategories: '',
        displayOrder: categories.length + 2,
        status: 'active',
      });
      await refreshCategories();
      await loadAllAdminData();
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to create category', 'error');
    }
  };

  const handleConfirmDeleteCategory = async () => {
    if (!categoryToDelete) return;
    setIsDeletingCategory(true);
    triggerSaveStatus('saving', `Deleting category "${categoryToDelete.name}"...`);
    try {
      await api.deleteCategory(categoryToDelete.id);
      triggerSaveStatus('saved', 'Category deleted successfully');
      showToast(`Category "${categoryToDelete.name}" deleted.`, 'info');
      setCategoryToDelete(null);
      await refreshCategories();
      await loadAllAdminData();
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to delete category', 'error');
    } finally {
      setIsDeletingCategory(false);
    }
  };

  // Banners CRUD
  const handleSaveBanner = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bannerForm.title.trim() || !bannerForm.imageUrl) {
      showToast('Banner title and an uploaded image are required.', 'error');
      return;
    }

    triggerSaveStatus('saving', 'Saving homepage banner to database...');
    try {
      await api.createBanner({
        title: bannerForm.title.trim(),
        subtitle: bannerForm.subtitle.trim(),
        badgeText: bannerForm.badgeText.trim(),
        buttonText: bannerForm.buttonText.trim(),
        linkUrl: bannerForm.linkUrl.trim(),
        imageUrl: bannerForm.imageUrl,
        displayOrder: Number(bannerForm.displayOrder),
        isActive: bannerForm.isActive,
      });

      // Sync with localStorage key and event requested by user
      try {
        localStorage.setItem(
          'novora_homepage_banner',
          JSON.stringify({
            image: bannerForm.imageUrl,
            heading: bannerForm.title.trim(),
            subtitle: bannerForm.subtitle.trim(),
            published: true,
          })
        );
        window.dispatchEvent(new Event('novora-banner-updated'));
      } catch (e) {
        // non-fatal
      }

      triggerSaveStatus('saved', 'Banner saved successfully');
      showToast('Promotional homepage banner published and saved persistently!', 'success');
      setBannerForm({
        title: '',
        subtitle: '',
        badgeText: 'Seasonal Drop',
        buttonText: 'Shop Now',
        linkUrl: '/shop',
        imageUrl: '',
        displayOrder: banners.length + 2,
        isActive: true,
      });
      await refreshBanners();
      await loadAllAdminData();
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to create banner', 'error');
    }
  };

  const handleConfirmDeleteBanner = async () => {
    if (!bannerToDelete) return;
    setIsDeletingBanner(true);
    triggerSaveStatus('saving', 'Deleting banner from database...');
    try {
      await api.deleteBanner(bannerToDelete.id);
      try {
        localStorage.removeItem('novora_homepage_banner');
        window.dispatchEvent(new Event('novora-banner-updated'));
      } catch (e) {
        // non-fatal
      }
      triggerSaveStatus('saved', 'Banner deleted successfully');
      showToast('Banner removed from database', 'info');
      setBannerToDelete(null);
      await refreshBanners();
      await loadAllAdminData();
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to delete banner', 'error');
    } finally {
      setIsDeletingBanner(false);
    }
  };

  // Update Order Status (8 Fulfillment Statuses)
  const handleUpdateOrderStatus = async (
    orderId: string,
    newStatus: string,
    overrideCarrier?: string,
    overrideTracking?: string
  ) => {
    triggerSaveStatus('saving', `Updating order status to "${newStatus}"...`);
    try {
      const res = await api.updateOrderStatus(orderId, {
        status: newStatus,
        trackingNumber: overrideTracking !== undefined ? overrideTracking : (orderTrackingInput.trim() || undefined),
        carrier: overrideCarrier !== undefined ? overrideCarrier : (orderCarrierInput.trim() || undefined),
      });
      showToast(`Order status updated to "${newStatus}".`, 'success');
      await loadAllAdminData();
      if (inspectingOrder && inspectingOrder.id === orderId) {
        setInspectingOrder(res.order);
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to update order', 'error');
    }
  };

  // Dedicated Gate Login Handler (for user entering Gmail and Password on admin page)
  const handleGateLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setGateError('');
    if (!gateEmail.trim() || !gatePassword.trim()) {
      setGateError('Please enter both administrator Gmail and password.');
      return;
    }
    setIsGateSubmitting(true);
    try {
      const res = await adminLogin(gateEmail.trim(), gatePassword);
      if (!res.success) {
        setGateError(res.error || 'Incorrect email or password. Access denied.');
        showToast(res.error || 'Incorrect email or password. Access denied.', 'error');
      } else {
        setGateError('');
        showToast('Administrator clearance granted. Welcome to NOVORA Command Console!', 'success');
      }
    } catch (err: any) {
      const errorMsg = err.message || 'Incorrect email or password. Access denied.';
      setGateError(errorMsg);
      showToast(errorMsg, 'error');
    } finally {
      setIsGateSubmitting(false);
    }
  };

  // Dedicated Admin Forgot Password Handlers
  const handleSendForgotOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError('');
    setForgotSuccess('');
    if (!forgotEmail.trim() || !forgotEmail.includes('@')) {
      setForgotError('Please enter a valid administrator email address.');
      return;
    }
    setIsSendingForgotOtp(true);
    try {
      await api.forgotPassword(forgotEmail.trim());
      setForgotSuccess(`A 6-digit verification code has been dispatched to ${forgotEmail.trim()}.`);
      setForgotStep('otp');
      showToast('Verification code dispatched to your administrator inbox.', 'info');
    } catch (err: any) {
      setForgotError(err.message || 'Failed to dispatch verification code.');
    } finally {
      setIsSendingForgotOtp(false);
    }
  };

  const handleResetPasswordFromGate = async (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError('');
    setForgotSuccess('');
    if (!forgotOtp.trim() || !forgotNewPassword || !forgotConfirmPassword) {
      setForgotError('All fields are required.');
      return;
    }
    if (forgotNewPassword !== forgotConfirmPassword) {
      setForgotError('New password and confirmation password do not match.');
      return;
    }
    if (forgotNewPassword.length < 8) {
      setForgotError('Password must be at least 8 characters long.');
      return;
    }
    setIsResettingForgot(true);
    try {
      const res = await api.resetPassword(
        forgotEmail.trim(),
        forgotOtp.trim(),
        forgotNewPassword,
        forgotConfirmPassword
      );
      setForgotSuccess(res.message || 'Password reset successfully! You can now authenticate.');
      showToast('Administrator password reset successfully! Stored as salted bcrypt hash.', 'success');
      setGatePassword(forgotNewPassword);
      setTimeout(() => {
        setIsForgotModalOpen(false);
        setForgotStep('email');
        setForgotOtp('');
        setForgotNewPassword('');
        setForgotConfirmPassword('');
        setForgotSuccess('');
        setForgotError('');
      }, 1500);
    } catch (err: any) {
      setForgotError(err.message || 'Password reset failed.');
    } finally {
      setIsResettingForgot(false);
    }
  };

  // Date Range Checker for Orders
  const isWithinDateRange = (dateStr: string) => {
    if (orderDateFilter === 'all') return true;
    if (!dateStr) return false;
    const orderDate = new Date(dateStr);
    const now = new Date();

    if (orderDateFilter === 'today') {
      return (
        orderDate.getFullYear() === now.getFullYear() &&
        orderDate.getMonth() === now.getMonth() &&
        orderDate.getDate() === now.getDate()
      );
    }
    if (orderDateFilter === 'yesterday') {
      const yesterday = new Date(now);
      yesterday.setDate(now.getDate() - 1);
      return (
        orderDate.getFullYear() === yesterday.getFullYear() &&
        orderDate.getMonth() === yesterday.getMonth() &&
        orderDate.getDate() === yesterday.getDate()
      );
    }
    if (orderDateFilter === '7days') {
      const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      return orderDate >= sevenDaysAgo;
    }
    if (orderDateFilter === '30days') {
      const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      return orderDate >= thirtyDaysAgo;
    }
    if (orderDateFilter === 'this_month') {
      return (
        orderDate.getFullYear() === now.getFullYear() &&
        orderDate.getMonth() === now.getMonth()
      );
    }
    if (orderDateFilter === 'custom') {
      if (orderCustomStartDate) {
        const start = new Date(orderCustomStartDate);
        start.setHours(0, 0, 0, 0);
        if (orderDate < start) return false;
      }
      if (orderCustomEndDate) {
        const end = new Date(orderCustomEndDate);
        end.setHours(23, 59, 59, 999);
        if (orderDate > end) return false;
      }
      return true;
    }
    return true;
  };

  // Delete Order Handler
  const handleConfirmDeleteOrder = async () => {
    if (!orderToDelete) return;
    setIsDeletingOrder(true);
    triggerSaveStatus('saving', `Deleting order ${orderToDelete.orderNumber} from database...`);
    try {
      await api.deleteOrder(orderToDelete.id);
      setOrders(prev => prev.filter(o => o.id !== orderToDelete.id));
      if (inspectingOrder?.id === orderToDelete.id) {
        setInspectingOrder(null);
      }
      triggerSaveStatus('saved', `Order ${orderToDelete.orderNumber} deleted successfully`);
      showToast(`Order ${orderToDelete.orderNumber} permanently removed from dashboard.`, 'success');
      setOrderToDelete(null);
      await loadAllAdminData();
    } catch (err: any) {
      triggerSaveStatus('failed', err.message || 'Failed to delete order');
      showToast(err.message || 'Failed to delete order.', 'error');
    } finally {
      setIsDeletingOrder(false);
    }
  };

  // Archive / Unarchive Order Handler
  const handleToggleArchiveOrder = async (order: Order) => {
    const newArchived = !order.isArchived;
    setIsArchivingOrder(order.id);
    triggerSaveStatus('saving', `${newArchived ? 'Archiving' : 'Restoring'} order ${order.orderNumber}...`);
    try {
      const res = await api.archiveOrder(order.id, newArchived);
      setOrders(prev => prev.map(o => o.id === order.id ? res.order : o));
      if (inspectingOrder?.id === order.id) {
        setInspectingOrder(res.order);
      }
      triggerSaveStatus('saved', `Order ${order.orderNumber} ${newArchived ? 'archived' : 'restored'}`);
      showToast(`Order ${order.orderNumber} ${newArchived ? 'moved to archive' : 'restored to active orders'}.`, 'success');
    } catch (err: any) {
      triggerSaveStatus('failed', err.message || 'Archive operation failed');
      showToast(err.message || 'Failed to archive order.', 'error');
    } finally {
      setIsArchivingOrder(null);
    }
  };

  // Copy Delivery Address to Clipboard (Formatted for Couriers)
  const handleCopyAddress = (order: Order) => {
    const addr = order.deliveryAddress;
    const formatted = [
      `Recipient: ${addr.fullName}`,
      `Phone: ${addr.phone}`,
      `Email: ${addr.email}`,
      `Address: ${addr.houseNumber} ${addr.streetAddress}`,
      addr.apartmentDetails ? `Unit / Apt: ${addr.apartmentDetails}` : '',
      `City: ${addr.city}, ${addr.state} ${addr.postalCode}`,
      `Country: ${addr.country}`,
    ]
      .filter(Boolean)
      .join('\n');

    navigator.clipboard.writeText(formatted);
    showToast('Delivery address copied to clipboard (courier-formatted)!', 'success');
  };

  // Dedicated Printable Packing Slip
  const handlePrintPackingSlip = (order: Order) => {
    const printWindow = window.open('', '_blank', 'width=850,height=950');
    if (!printWindow) {
      showToast('Popup blocker prevented printing. Please allow popups.', 'error');
      return;
    }

    const itemsHtml = order.items
      .map(
        it => `
      <tr>
        <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; width: 40px; text-align: center;">[ ]</td>
        <td style="padding: 10px; border-bottom: 1px solid #e5e7eb;">
          <strong style="font-size: 13px;">${it.productName}</strong>
          ${it.selectedVariant?.size ? `<br><small style="color: #6b7280;">Variant: ${it.selectedVariant.size}</small>` : ''}
        </td>
        <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; text-align: center; font-weight: bold;">${it.quantity}</td>
        <td style="padding: 10px; border-bottom: 1px solid #e5e7eb; text-align: right; font-weight: 600;">$${(it.price * it.quantity).toFixed(2)}</td>
      </tr>
    `
      )
      .join('');

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>NOVORA Packing Slip — ${order.orderNumber}</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 40px; color: #111827; max-width: 800px; margin: auto; }
            .header { display: flex; justify-content: space-between; border-bottom: 2px solid #111827; padding-bottom: 18px; margin-bottom: 24px; }
            .brand { font-size: 26px; font-weight: 900; letter-spacing: 2px; }
            .grid { display: flex; justify-content: space-between; gap: 20px; margin-bottom: 24px; }
            .box { background: #f9fafb; padding: 16px; border-radius: 8px; flex: 1; border: 1px solid #e5e7eb; }
            table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 13px; }
            th { text-align: left; padding: 10px; background: #f3f4f6; border-bottom: 2px solid #d1d5db; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; }
            .barcode { font-family: monospace; letter-spacing: 3px; font-size: 14px; margin-top: 10px; }
            @media print {
              body { padding: 0; }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <div class="brand">NOVORA</div>
              <div style="font-size: 12px; color: #6b7280; margin-top: 4px;">Atelier Logistics & Courier Fulfillment</div>
            </div>
            <div style="text-align: right;">
              <h2 style="margin: 0; font-size: 18px; letter-spacing: 1px;">PACKING SLIP</h2>
              <div style="font-size: 14px; font-weight: bold; margin-top: 4px; font-family: monospace;">${order.orderNumber}</div>
              <div style="font-size: 12px; color: #6b7280;">Date: ${new Date(order.createdAt).toLocaleDateString()}</div>
            </div>
          </div>

          <div class="grid">
            <div class="box">
              <strong style="font-size: 11px; text-transform: uppercase; color: #4b5563;">Ship To:</strong>
              <div style="font-size: 14px; font-weight: bold; margin: 6px 0 2px;">${order.deliveryAddress.fullName}</div>
              <div style="font-size: 12px; line-height: 1.5; color: #374151;">
                ${order.deliveryAddress.houseNumber} ${order.deliveryAddress.streetAddress}<br>
                ${order.deliveryAddress.apartmentDetails ? `${order.deliveryAddress.apartmentDetails}<br>` : ''}
                ${order.deliveryAddress.city}, ${order.deliveryAddress.state} ${order.deliveryAddress.postalCode}<br>
                <strong>${order.deliveryAddress.country}</strong><br>
                Tel: ${order.deliveryAddress.phone}
              </div>
            </div>

            <div class="box">
              <strong style="font-size: 11px; text-transform: uppercase; color: #4b5563;">Courier & Payment Details:</strong>
              <div style="font-size: 12px; line-height: 1.6; margin-top: 6px; color: #374151;">
                <strong>Payment Method:</strong> ${order.paymentMethod}<br>
                <strong>Payment Status:</strong> ${order.paymentStatus.toUpperCase()}<br>
                <strong>Tracking Reference:</strong> ${order.trackingNumber || 'Pending Dispatch'}<br>
                <strong>Carrier:</strong> ${order.carrier || 'NOVORA Express & Courier Network'}
              </div>
              <div class="barcode">||| | ||||| |||| || | |||</div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th style="text-align: center;">Pick</th>
                <th>Item Description</th>
                <th style="text-align: center;">Qty</th>
                <th style="text-align: right;">Total</th>
              </tr>
            </thead>
            <tbody>
              ${itemsHtml}
            </tbody>
          </table>

          <div style="margin-top: 40px; padding-top: 20px; border-top: 1px dashed #d1d5db; font-size: 12px; color: #6b7280; text-align: center;">
            Thank you for shopping with NOVORA · Concierge: concierge@novora.store
          </div>

          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };



  // Save Payment Gateway Configuration
  const handleSavePaymentGateway = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentGateway) return;
    setIsSavingGateway(true);
    triggerSaveStatus('saving', 'Saving payment gateway configuration to SQLite database...');
    try {
      const res = await api.updateAdminPaymentSettings(paymentGateway);
      setPaymentGateway(res.paymentGateway);
      triggerSaveStatus('saved', 'Payment gateway configuration saved successfully');
      showToast('Payment gateway settings saved successfully.', 'success');
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to save payment settings.', 'error');
    } finally {
      setIsSavingGateway(false);
    }
  };

  // Connect Payment Provider
  const handleConnectPaymentProvider = async (provider: string) => {
    setIsConnectingGateway(true);
    triggerSaveStatus('saving', `Connecting payment provider: ${provider}...`);
    try {
      const res = await api.connectPaymentProvider(provider);
      setPaymentGateway(res.paymentGateway);
      triggerSaveStatus('saved', 'Provider connected and saved successfully');
      showToast(res.message, 'success');
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to connect payment provider.', 'error');
    } finally {
      setIsConnectingGateway(false);
    }
  };



  // Inventory Update
  const handleInlineStockUpdate = async (prodId: string, newStock: number) => {
    triggerSaveStatus('saving', 'Saving inventory stock to database...');
    try {
      await api.updateStock(prodId, newStock);
      triggerSaveStatus('saved', 'Stock updated and saved successfully');
      showToast('Stock quantity updated in persistent database.', 'success');
      await loadAllAdminData();
      await refreshCatalog();
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to update stock', 'error');
    }
  };

  // Coupons CRUD
  const handleSaveCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponForm.code.trim()) return;

    triggerSaveStatus('saving', `Saving coupon "${couponForm.code}" to database...`);
    try {
      await api.createCoupon({
        code: couponForm.code.trim().toUpperCase(),
        discountType: couponForm.discountType,
        discountValue: Number(couponForm.discountValue),
        minOrderValue: Number(couponForm.minOrderValue),
        expiryDate: couponForm.expiryDate,
        isActive: couponForm.isActive,
      });
      triggerSaveStatus('saved', `Coupon "${couponForm.code}" saved successfully`);
      showToast(`Coupon ${couponForm.code} created!`, 'success');
      setCouponForm({
        code: '',
        discountType: 'percentage',
        discountValue: 15,
        minOrderValue: 100,
        expiryDate: '2027-12-31',
        isActive: true,
      });
      await loadAllAdminData();
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to create coupon', 'error');
    }
  };

  // Settings Save
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    triggerSaveStatus('saving', 'Saving store settings, shipping & preferences to database...');
    try {
      await api.updateSettings(settingsForm);
      triggerSaveStatus('saved', 'Store settings saved successfully');
      showToast('Store settings updated and stored persistently.', 'success');
      await refreshSettings();
      await loadAllAdminData();
    } catch (err: any) {
      triggerSaveStatus('failed', 'Save failed — please retry');
      showToast(err.message || 'Failed to save store settings', 'error');
    }
  };

  // Download CSV of Orders
  const handleExportCSV = () => {
    window.location.href = '/api/orders-export/csv';
  };

  const handleConnectGoogleDrive = async () => {
    setIsConnectingDrive(true);
    try {
      const res = await signInWithGoogleDrive();
      setGoogleDriveUser({
        email: res.user.email || undefined,
        displayName: res.user.displayName || undefined,
        photoURL: res.user.photoURL || undefined,
      });
      showToast('Connected to Google Drive! Ready to sync to target folder.', 'success');
    } catch (err: any) {
      console.error(err);
      showToast(err.message || 'Failed to authenticate with Google Drive.', 'error');
    } finally {
      setIsConnectingDrive(false);
    }
  };

  const handleDisconnectGoogleDrive = async () => {
    try {
      await disconnectGoogleDrive();
      setGoogleDriveUser(null);
      showToast('Disconnected from Google Drive.', 'info');
    } catch (err: any) {
      console.error(err);
    }
  };

  const handleOpenSyncModal = () => {
    if (!getDriveAccessToken() && !googleDriveUser) {
      handleConnectGoogleDrive();
      return;
    }
    setShowDriveConfirmModal(true);
  };

  const handleConfirmSyncToDrive = async () => {
    setIsSyncingDrive(true);
    triggerSaveStatus('saving', 'Syncing sign-in records & addresses to Google Drive folder...');
    try {
      const result = await syncUserDataToGoogleDrive();
      setLastDriveSyncResult(result);
      setShowDriveConfirmModal(false);
      triggerSaveStatus('saved', `Google Drive synced: ${result.files.usersCount} users & ${result.files.addressesCount} addresses`);
      showToast('Successfully synchronized files directly to your Google Drive folder!', 'success');
    } catch (err: any) {
      console.error(err);
      triggerSaveStatus('failed', err.message || 'Save failed — please retry');
      showToast(err.message || 'Google Drive sync error.', 'error');
    } finally {
      setIsSyncingDrive(false);
    }
  };

  // Dedicated Admin Authentication Clearance Gate (Required when someone clicks on Admin Page)
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-stone-950 flex flex-col justify-center items-center p-4 sm:p-6 text-stone-100 relative overflow-hidden font-sans">
        {/* Subtle Luxury Gradient Background */}
        <div className="absolute inset-0 bg-radial from-purple-950/20 via-stone-950 to-stone-950 pointer-events-none" />
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-purple-500/30 to-transparent" />

        <div className="relative w-full max-w-md bg-stone-900/90 border border-stone-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-md space-y-6 animate-in fade-in zoom-in-95 duration-200">
          
          {/* Brand & Security Header */}
          <div className="text-center space-y-2">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-purple-600/20 border border-purple-500/30 text-purple-400 mb-2 shadow-inner">
              <Lock className="w-7 h-7 text-purple-400" />
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-950/80 border border-purple-700/60 text-purple-300 text-[10px] font-bold tracking-widest uppercase">
              <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
              <span>Admin Clearance Gate</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white font-display">
              NOVORA Command Console
            </h1>
            <p className="text-xs text-stone-400 leading-relaxed max-w-sm mx-auto">
              Please enter your authorized administrator Gmail and password to open the admin dashboard.
            </p>
          </div>

          {/* Error Message */}
          {gateError && (
            <div className="p-3.5 bg-rose-950/80 border border-rose-600/70 rounded-xl flex items-start gap-3 text-rose-200 text-xs">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Access Denied</p>
                <p className="text-[11px] text-rose-300 mt-0.5">{gateError}</p>
              </div>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleGateLogin} className="space-y-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-stone-300">
                Administrator Gmail
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={gateEmail}
                  onChange={e => setGateEmail(e.target.value)}
                  placeholder="e.g. Huzaifa60010@gmail.com"
                  autoComplete="email"
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                  required
                  className="w-full pl-10 pr-4 py-2.5 bg-stone-950 border border-stone-800 rounded-xl text-xs text-white placeholder-stone-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-colors"
                />
                <Mail className="w-4 h-4 text-stone-500 absolute left-3.5 top-3" />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-semibold text-stone-300">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setForgotEmail(gateEmail || 'Huzaifa60010@gmail.com');
                    setForgotStep('email');
                    setForgotError('');
                    setForgotSuccess('');
                    setIsForgotModalOpen(true);
                  }}
                  className="text-[11px] text-purple-400 hover:text-purple-300 font-medium cursor-pointer transition-colors"
                >
                  Forgot Password?
                </button>
              </div>
              <div className="relative">
                <input
                  type={showGatePassword ? 'text' : 'password'}
                  value={gatePassword}
                  onChange={e => setGatePassword(e.target.value)}
                  placeholder="Enter administrator password"
                  autoComplete="current-password"
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                  required
                  className="w-full pl-10 pr-10 py-2.5 bg-stone-950 border border-stone-800 rounded-xl text-xs text-white placeholder-stone-500 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-colors"
                />
                <Key className="w-4 h-4 text-stone-500 absolute left-3.5 top-3" />
                <button
                  type="button"
                  onClick={() => setShowGatePassword(!showGatePassword)}
                  className="absolute right-3 top-2.5 text-stone-500 hover:text-stone-300 transition-colors cursor-pointer"
                  tabIndex={-1}
                >
                  {showGatePassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Quick Demo Credential Helper */}
            <div className="p-3 bg-stone-950/60 border border-stone-800/80 rounded-xl flex items-center justify-between gap-2">
              <div className="text-[11px] text-stone-400">
                <span className="text-stone-500 block text-[10px] uppercase font-bold tracking-wider">Configured Administrator</span>
                <span className="font-mono text-purple-300 font-semibold">Huzaifa60010@gmail.com</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setGateEmail('Huzaifa60010@gmail.com');
                  setGatePassword('Huzaifa2009@pak');
                  setGateError('');
                  showToast('Filled administrator credentials', 'info');
                }}
                className="px-2.5 py-1 text-[11px] bg-purple-950/80 hover:bg-purple-900 border border-purple-700/60 text-purple-300 font-bold rounded-lg transition-colors cursor-pointer"
              >
                Auto Fill
              </button>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isGateSubmitting}
              className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-purple-900/30 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isGateSubmitting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Verifying Credentials…</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Verify Credentials &amp; Open Admin Dashboard</span>
                </>
              )}
            </button>
          </form>

          {/* Navigation / Flowchart Links */}
          <div className="pt-2 border-t border-stone-800/80 flex items-center justify-between text-xs text-stone-400">
            <button
              type="button"
              onClick={() => navigateTo('home')}
              className="text-stone-400 hover:text-white transition-colors cursor-pointer flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Back to Store</span>
            </button>
            <button
              type="button"
              onClick={() => setIsCustomerFlowModalOpen(true)}
              className="text-purple-400 hover:text-purple-300 transition-colors cursor-pointer flex items-center gap-1"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Auth Architecture Diagram</span>
            </button>
          </div>

          <div className="text-[10px] text-stone-500 text-center leading-relaxed">
            Salted bcrypt hashing · Database-backed audit trail in <code className="text-purple-400">admin_audit_log.json</code>
          </div>

        </div>

        {/* Administrator Forgot Password Modal */}
        {isForgotModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/85 backdrop-blur-md">
            <div className="bg-stone-900 border border-stone-800 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between pb-3 border-b border-stone-800">
                <div className="flex items-center gap-2">
                  <Key className="w-5 h-5 text-purple-400" />
                  <h3 className="font-bold text-white text-sm">Administrator Password Recovery</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setIsForgotModalOpen(false)}
                  className="p-1 text-stone-400 hover:text-white rounded-lg cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {forgotError && (
                <div className="p-3 bg-rose-950/80 border border-rose-600/70 rounded-xl text-xs text-rose-200">
                  {forgotError}
                </div>
              )}

              {forgotSuccess && (
                <div className="p-3 bg-emerald-950/80 border border-emerald-600/70 rounded-xl text-xs text-emerald-200">
                  {forgotSuccess}
                </div>
              )}

              {forgotStep === 'email' ? (
                <form onSubmit={handleSendForgotOtp} className="space-y-4">
                  <p className="text-xs text-stone-400 leading-relaxed">
                    Enter your authorized administrator email address. A 6-digit verification code will be dispatched to your inbox.
                  </p>
                  <div className="space-y-1">
                    <label className="block text-xs font-semibold text-stone-300">
                      Administrator Email
                    </label>
                    <input
                      type="email"
                      value={forgotEmail}
                      onChange={e => setForgotEmail(e.target.value)}
                      required
                      placeholder="e.g. Huzaifa60010@gmail.com"
                      className="w-full px-3 py-2 bg-stone-950 border border-stone-800 rounded-xl text-xs text-white placeholder-stone-500 focus:outline-none focus:border-purple-500"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={isSendingForgotOtp}
                    className="w-full py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl transition-all cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isSendingForgotOtp ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Sending Verification Code…</span>
                      </>
                    ) : (
                      <span>Send 6-Digit Code</span>
                    )}
                  </button>
                </form>
              ) : (
                <form onSubmit={handleResetPasswordFromGate} className="space-y-4">
                  <div className="space-y-1">
                    <label className="block text-xs font-semibold text-stone-300">
                      6-Digit Verification Code
                    </label>
                    <input
                      type="text"
                      maxLength={6}
                      value={forgotOtp}
                      onChange={e => setForgotOtp(e.target.value.replace(/\D/g, ''))}
                      required
                      placeholder="e.g. 123456"
                      className="w-full px-3 py-2 bg-stone-950 border border-stone-800 rounded-xl text-xs text-center font-mono text-white tracking-widest focus:outline-none focus:border-purple-500 text-lg"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-semibold text-stone-300">
                      New Security Password (min 8 characters)
                    </label>
                    <input
                      type="password"
                      value={forgotNewPassword}
                      onChange={e => setForgotNewPassword(e.target.value)}
                      required
                      placeholder="Enter new administrator password"
                      className="w-full px-3 py-2 bg-stone-950 border border-stone-800 rounded-xl text-xs text-white placeholder-stone-500 focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="block text-xs font-semibold text-stone-300">
                      Confirm New Password
                    </label>
                    <input
                      type="password"
                      value={forgotConfirmPassword}
                      onChange={e => setForgotConfirmPassword(e.target.value)}
                      required
                      placeholder="Re-enter new password"
                      className="w-full px-3 py-2 bg-stone-950 border border-stone-800 rounded-xl text-xs text-white placeholder-stone-500 focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  <div className="flex items-center gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setForgotStep('email')}
                      className="px-3 py-2 bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold rounded-xl cursor-pointer"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      disabled={isResettingForgot}
                      className="flex-1 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl transition-all cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {isResettingForgot ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>Updating Password…</span>
                        </>
                      ) : (
                        <span>Save &amp; Encrypt Password</span>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}

        {/* Auth Architecture Diagram Lightbox Modal if opened from gate */}
        {isCustomerFlowModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-md">
            <div className="bg-stone-900 border border-stone-800 rounded-2xl max-w-4xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between pb-3 border-b border-stone-800">
                <h3 className="font-bold text-white text-sm">NOVORA Authentication &amp; Save System Flowchart</h3>
                <button
                  type="button"
                  onClick={() => setIsCustomerFlowModalOpen(false)}
                  className="p-1 text-stone-400 hover:text-white rounded-lg cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <img
                src="/assets/aistudio/NOVORA_Authentication_System_Flowchart__1__e9de0c86.png"
                alt="NOVORA Authentication Flowchart"
                className="w-full rounded-xl border border-stone-800 bg-stone-950"
              />
              <div className="text-right">
                <button
                  type="button"
                  onClick={() => setIsCustomerFlowModalOpen(false)}
                  className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-white text-xs font-bold rounded-xl cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-100/70 pb-20">
      
      {/* Top Admin Bar */}
      <div className="bg-stone-950 text-white border-b border-stone-800 sticky top-0 z-30 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center font-bold text-white shadow-xs">
              N
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold tracking-wider uppercase font-display">
                  NOVORA Command Console
                </span>
                <span className="hidden lg:inline-flex items-center gap-1 text-[10px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                  <Database className="w-3 h-3 text-emerald-400" />
                  SQLite C:\Novora_Project\data\novora.db
                </span>
              </div>
            </div>
          </div>

          {/* Central Live Save Status Pill (Requirement 1) */}
          <div className="flex items-center">
            {saveStatus === 'saving' && (
              <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-950/90 border border-amber-600/80 text-amber-200 text-xs font-bold shadow-lg animate-pulse">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-400" />
                <span>Saving…</span>
              </div>
            )}
            {saveStatus === 'saved' && (
              <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-950/90 border border-emerald-500 text-emerald-200 text-xs font-bold shadow-lg">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Saved successfully</span>
              </div>
            )}
            {saveStatus === 'failed' && (
              <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-rose-950/95 border border-rose-500 text-rose-200 text-xs font-bold shadow-lg">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                <span>Save failed — please retry</span>
              </div>
            )}
            {saveStatus === 'idle' && (
              <div
                onClick={() => setActiveTab('database')}
                className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full bg-stone-900 border border-stone-800 text-[11px] font-medium text-stone-300 hover:text-white hover:border-stone-700 transition-colors cursor-pointer"
                title="Click to view SQLite Database & Persistence Hub"
              >
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                <span>Backend Database Synced</span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-3 text-xs shrink-0">
            <span className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-stone-900 border border-stone-800 text-[11px] font-medium text-stone-300">
              <UserCheck className="w-3.5 h-3.5 text-purple-400" />
              <span className="font-mono text-stone-200">{currentUser?.email || 'Huzaifa60010@gmail.com'}</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-purple-950 text-purple-300 font-bold uppercase border border-purple-800">Admin</span>
            </span>

            <button
              onClick={() => navigateTo('home')}
              className="text-stone-300 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
            >
              <span className="hidden md:inline">View Store</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => {
                logout();
                showToast('Signed out of Administrator Console.', 'info');
              }}
              className="px-3 py-1.5 bg-stone-900 hover:bg-rose-950 text-stone-300 hover:text-rose-200 border border-stone-800 hover:border-rose-700/60 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Sign out of Admin Console"
            >
              <LogOut className="w-3.5 h-3.5 text-stone-400" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Mobile / Tablet Horizontal Navigation Scrollbar */}
        <div className="lg:hidden flex items-center gap-1.5 overflow-x-auto pb-4 mb-6 border-b border-stone-200 scrollbar-none text-xs font-semibold">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'overview' ? 'bg-stone-900 text-white shadow-xs' : 'bg-white text-stone-700 hover:bg-stone-200'
            }`}
          >
            <LayoutDashboard className="w-3.5 h-3.5" />
            <span>Overview</span>
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'products' ? 'bg-stone-900 text-white shadow-xs' : 'bg-white text-stone-700 hover:bg-stone-200'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Products ({products.length})</span>
          </button>

          <button
            onClick={() => {
              setEditingProduct(null);
              setActiveTab('add-product');
            }}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'add-product' ? 'bg-purple-700 text-white shadow-xs' : 'bg-purple-50 text-purple-800 hover:bg-purple-100 border border-purple-200'
            }`}
          >
            <PlusCircle className="w-3.5 h-3.5 text-purple-300" />
            <span>+ Add Product</span>
          </button>

          <button
            onClick={() => setActiveTab('categories')}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'categories' ? 'bg-stone-900 text-white shadow-xs' : 'bg-white text-stone-700 hover:bg-stone-200'
            }`}
          >
            <FolderTree className="w-3.5 h-3.5" />
            <span>Categories</span>
          </button>

          <button
            onClick={() => setActiveTab('banners')}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'banners' ? 'bg-stone-900 text-white shadow-xs' : 'bg-white text-stone-700 hover:bg-stone-200'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Banners</span>
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'orders' ? 'bg-stone-900 text-white shadow-xs' : 'bg-white text-stone-700 hover:bg-stone-200'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Orders ({orders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'customers' ? 'bg-purple-700 text-white shadow-xs' : 'bg-white text-stone-700 hover:bg-stone-200'
            }`}
          >
            <Folder className="w-3.5 h-3.5 text-amber-400" />
            <span>Customers ({customers.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'settings' ? 'bg-stone-900 text-white shadow-xs' : 'bg-white text-stone-700 hover:bg-stone-200'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Settings</span>
          </button>

          <button
            onClick={() => setActiveTab('payment-settings')}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'payment-settings' ? 'bg-purple-700 text-white shadow-xs' : 'bg-white text-stone-700 hover:bg-stone-200'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Payment Settings</span>
          </button>

          <button
            onClick={() => setActiveTab('security')}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'security' ? 'bg-purple-700 text-white shadow-xs' : 'bg-white text-stone-700 hover:bg-stone-200'
            }`}
          >
            <Key className="w-3.5 h-3.5 text-purple-400" />
            <span>Security Settings</span>
          </button>

          <button
            onClick={() => setActiveTab('google-drive')}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'google-drive' ? 'bg-blue-700 text-white shadow-xs' : 'bg-white text-stone-700 hover:bg-stone-200'
            }`}
          >
            <Folder className="w-3.5 h-3.5 text-blue-500" />
            <span>Google Drive Status</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('database');
              loadBackups();
            }}
            className={`px-3.5 py-2 rounded-xl flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === 'database' ? 'bg-emerald-700 text-white shadow-xs' : 'bg-white text-stone-700 hover:bg-stone-200'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-emerald-600" />
            <span>Database Hub</span>
          </button>
        </div>

        <div className="flex flex-col lg:flex-row gap-8 items-start">
          {/* Professional Desktop Sidebar Navigation */}
          <aside className="hidden lg:flex flex-col w-64 shrink-0 bg-white border border-stone-200 rounded-3xl p-4 shadow-xs sticky top-20 space-y-6">
            <div className="space-y-1">
              <span className="px-3 text-[10px] font-bold text-stone-400 uppercase tracking-widest block">
                Catalog &amp; Operations
              </span>
              <button
                type="button"
                onClick={() => setActiveTab('overview')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'overview'
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'text-stone-700 hover:bg-stone-100'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <LayoutDashboard className="w-4 h-4" />
                  <span>Overview</span>
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('products')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'products'
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'text-stone-700 hover:bg-stone-100'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <Package className="w-4 h-4" />
                  <span>Products</span>
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-stone-100 text-stone-600 font-mono">
                  {products.length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setEditingProduct(null);
                  setActiveTab('add-product');
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'add-product'
                    ? 'bg-purple-700 text-white shadow-xs'
                    : 'text-purple-800 bg-purple-50/70 hover:bg-purple-100'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <PlusCircle className="w-4 h-4 text-purple-500" />
                  <span>+ Add Product (PC)</span>
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('categories')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'categories'
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'text-stone-700 hover:bg-stone-100'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <FolderTree className="w-4 h-4" />
                  <span>Categories</span>
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-stone-100 text-stone-600 font-mono">
                  {categories.length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('banners')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'banners'
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'text-stone-700 hover:bg-stone-100'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <ImageIcon className="w-4 h-4" />
                  <span>Homepage Banners</span>
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-stone-100 text-stone-600 font-mono">
                  {banners.length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('orders')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'orders'
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'text-stone-700 hover:bg-stone-100'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <ShoppingBag className="w-4 h-4" />
                  <span>Orders</span>
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-purple-100 text-purple-800 font-mono font-bold">
                  {orders.length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('customers')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'customers'
                    ? 'bg-purple-700 text-white shadow-xs'
                    : 'text-stone-700 hover:bg-stone-100'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <Folder className="w-4 h-4 text-amber-500" />
                  <span>Customers &amp; Addresses</span>
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-stone-100 text-stone-600 font-mono">
                  {customers.length}
                </span>
              </button>
            </div>

            <div className="space-y-1 pt-2 border-t border-stone-100">
              <span className="px-3 text-[10px] font-bold text-stone-400 uppercase tracking-widest block">
                Configuration &amp; Payments
              </span>
              <button
                type="button"
                onClick={() => setActiveTab('settings')}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'settings'
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'text-stone-700 hover:bg-stone-100'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>Store Settings</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('payment-settings')}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'payment-settings'
                    ? 'bg-purple-700 text-white shadow-xs'
                    : 'text-stone-700 hover:bg-stone-100'
                }`}
              >
                <Building2 className="w-4 h-4 text-purple-600" />
                <span>Payment &amp; Payout Settings</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('inventory')}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'inventory'
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'text-stone-700 hover:bg-stone-100'
                }`}
              >
                <Boxes className="w-4 h-4" />
                <span>Inventory &amp; Stock</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('coupons')}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'coupons'
                    ? 'bg-stone-900 text-white shadow-xs'
                    : 'text-stone-700 hover:bg-stone-100'
                }`}
              >
                <TicketPercent className="w-4 h-4" />
                <span>Coupons &amp; Promo</span>
              </button>
            </div>

            <div className="space-y-1 pt-2 border-t border-stone-100">
              <span className="px-3 text-[10px] font-bold text-stone-400 uppercase tracking-widest block">
                Security &amp; Cloud Drive
              </span>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('security');
                  api.getAdminAuditLog().then(l => setAuditLogs(l)).catch(() => {});
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'security'
                    ? 'bg-purple-700 text-white shadow-xs'
                    : 'text-purple-900 bg-purple-50/50 hover:bg-purple-100/70 border border-purple-200/50'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <Key className="w-4 h-4 text-purple-500" />
                  <span>Security Settings</span>
                </span>
                <span className="px-1.5 py-0.5 rounded text-[9px] bg-purple-200 text-purple-900 font-mono font-bold">
                  Bcrypt
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('google-drive')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'google-drive'
                    ? 'bg-blue-700 text-white shadow-xs'
                    : 'text-blue-900 bg-blue-50/50 hover:bg-blue-100/70 border border-blue-200/50'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <Folder className="w-4 h-4 text-blue-500" />
                  <span>Google Drive Status</span>
                </span>
                <span className="px-1.5 py-0.5 rounded text-[9px] bg-blue-200 text-blue-900 font-mono font-bold">
                  Folder
                </span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTab('database');
                  loadBackups();
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'database'
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'text-stone-700 hover:bg-stone-100'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <Database className="w-4 h-4 text-emerald-600" />
                  <span>Database &amp; SQLite Hub</span>
                </span>
              </button>
            </div>

            <div className="pt-2 border-t border-stone-100 space-y-2">
              <button
                type="button"
                onClick={() => navigateTo('home')}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-stone-600 hover:text-stone-900 hover:bg-stone-100 transition-colors cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5 text-stone-400" />
                <span>Customer Storefront</span>
              </button>

              <button
                type="button"
                onClick={logout}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
            </div>
          </aside>

          {/* Main Dashboard Content Area */}
          <main className="flex-1 min-w-0 w-full space-y-8">

        {/* =========================================================================
            1. TAB: OVERVIEW
        ========================================================================= */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Top KPI Metrics Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="p-6 bg-white rounded-2xl border border-stone-200 shadow-xs">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Total Sales Volume
                </span>
                <p className="text-2xl font-black text-stone-950 tabular-nums mt-1 font-mono">
                  ${stats?.totalSales ? stats.totalSales.toFixed(2) : '0.00'}
                </p>
                <p className="text-[11px] text-emerald-600 mt-2 font-medium flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" />
                  <span>Real-time calculation from orders</span>
                </p>
              </div>

              <div className="p-6 bg-white rounded-2xl border border-stone-200 shadow-xs">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Total Orders
                </span>
                <p className="text-2xl font-black text-stone-950 tabular-nums mt-1 font-mono">
                  {stats?.totalOrders || orders.length}
                </p>
                <div className="flex items-center gap-2 mt-2 text-[11px] text-stone-500">
                  <span className="text-amber-700 font-bold">{stats?.pendingOrders || 0} Pending</span>
                  <span>·</span>
                  <span className="text-emerald-700 font-bold">{stats?.completedOrders || 0} Delivered</span>
                </div>
              </div>

              <div className="p-6 bg-white rounded-2xl border border-stone-200 shadow-xs">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Active Products
                </span>
                <p className="text-2xl font-black text-stone-950 tabular-nums mt-1 font-mono">
                  {products.length}
                </p>
                <p className="text-[11px] text-purple-700 mt-2 font-medium">
                  {categories.length} Registered Categories
                </p>
              </div>

              <div className="p-6 bg-white rounded-2xl border border-stone-200 shadow-xs">
                <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                  Inventory Alerts
                </span>
                <p className="text-2xl font-black text-stone-950 tabular-nums mt-1 font-mono">
                  {stats?.lowStockProducts || 0}
                </p>
                <p className="text-[11px] text-amber-600 mt-2 font-medium flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" />
                  <span>Low stock threshold (≤ 5 units)</span>
                </p>
              </div>
            </div>

            {/* =========================================================================
                SALES OVERVIEW SECTION (RECHARTS VISUALIZATION)
            ========================================================================= */}
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-xs space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-100">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 bg-purple-100 text-purple-700 rounded-lg">
                      <TrendingUp className="w-4 h-4" />
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-purple-700">
                      Analytics Intelligence · Recharts
                    </span>
                  </div>
                  <h2 className="text-lg font-black text-stone-950 font-display">
                    Revenue Trends &amp; Order Volume (Past {salesTrendRange === '30days' ? '30 Days' : salesTrendRange === '14days' ? '14 Days' : '7 Days'})
                  </h2>
                  <p className="text-xs text-stone-500">
                    Comprehensive Recharts visualization tracking daily revenue curves and transaction volume over the past 30 days.
                  </p>
                </div>

                {/* Range Toggle Buttons */}
                <div className="flex items-center gap-2 bg-stone-100 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setSalesTrendRange('30days')}
                    className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      salesTrendRange === '30days'
                        ? 'bg-purple-700 text-white shadow-xs'
                        : 'text-stone-600 hover:text-stone-950 hover:bg-stone-200'
                    }`}
                  >
                    Past 30 Days
                  </button>
                  <button
                    type="button"
                    onClick={() => setSalesTrendRange('14days')}
                    className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      salesTrendRange === '14days'
                        ? 'bg-purple-700 text-white shadow-xs'
                        : 'text-stone-600 hover:text-stone-950 hover:bg-stone-200'
                    }`}
                  >
                    14 Days
                  </button>
                  <button
                    type="button"
                    onClick={() => setSalesTrendRange('7days')}
                    className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                      salesTrendRange === '7days'
                        ? 'bg-purple-700 text-white shadow-xs'
                        : 'text-stone-600 hover:text-stone-950 hover:bg-stone-200'
                    }`}
                  >
                    7 Days
                  </button>
                </div>
              </div>

              {/* 30-Day Summary KPI Mini-Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 bg-purple-50/60 rounded-xl border border-purple-100">
                  <span className="text-[10px] text-purple-700 font-bold uppercase tracking-wider block">
                    {salesTrendRange === '30days' ? '30-Day' : salesTrendRange === '14days' ? '14-Day' : '7-Day'} Total Revenue
                  </span>
                  <p className="text-xl font-black text-purple-950 font-mono mt-0.5">
                    ${thirtyDaySummary.totalRev.toFixed(2)}
                  </p>
                  <span className="text-[10px] text-stone-500 font-medium">Real invoiced customer payments</span>
                </div>

                <div className="p-3.5 bg-emerald-50/60 rounded-xl border border-emerald-100">
                  <span className="text-[10px] text-emerald-700 font-bold uppercase tracking-wider block">
                    {salesTrendRange === '30days' ? '30-Day' : salesTrendRange === '14days' ? '14-Day' : '7-Day'} Total Orders
                  </span>
                  <p className="text-xl font-black text-emerald-950 font-mono mt-0.5">
                    {thirtyDaySummary.totalOrders} {thirtyDaySummary.totalOrders === 1 ? 'Order' : 'Orders'}
                  </p>
                  <span className="text-[10px] text-stone-500 font-medium">Completed store transactions</span>
                </div>

                <div className="p-3.5 bg-blue-50/60 rounded-xl border border-blue-100">
                  <span className="text-[10px] text-blue-700 font-bold uppercase tracking-wider block">
                    Average Daily Revenue
                  </span>
                  <p className="text-xl font-black text-blue-950 font-mono mt-0.5">
                    ${thirtyDaySummary.avgDailyRev.toFixed(2)}
                  </p>
                  <span className="text-[10px] text-stone-500 font-medium">Per day sales pacing</span>
                </div>

                <div className="p-3.5 bg-amber-50/60 rounded-xl border border-amber-100">
                  <span className="text-[10px] text-amber-700 font-bold uppercase tracking-wider block">
                    Average Order Value (AOV)
                  </span>
                  <p className="text-xl font-black text-amber-950 font-mono mt-0.5">
                    ${thirtyDaySummary.avgOrderVal.toFixed(2)}
                  </p>
                  <span className="text-[10px] text-stone-500 font-medium">Revenue per completed basket</span>
                </div>
              </div>

              {/* Dual Charts Grid: Revenue Area Chart + Order Volume Bar Chart */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                
                {/* 1. Daily Revenue Trend (Area Chart) */}
                <div className="lg:col-span-7 bg-stone-50/60 p-5 rounded-2xl border border-stone-200/80 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                        Daily Gross Revenue ($)
                      </h3>
                      <p className="text-[11px] text-stone-500">Daily sales trend line</p>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-purple-100 text-purple-800 border border-purple-200">
                      Revenue ($ USD)
                    </span>
                  </div>

                  <div className="h-64 w-full pt-2">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={salesTrendData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                        <defs>
                          <linearGradient id="novoraRevenueGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#7e22ce" stopOpacity={0.4} />
                            <stop offset="95%" stopColor="#7e22ce" stopOpacity={0.0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e7e5e4" vertical={false} />
                        <XAxis
                          dataKey="displayDate"
                          tick={{ fontSize: 11, fill: '#78716c' }}
                          tickLine={false}
                          axisLine={{ stroke: '#e7e5e4' }}
                        />
                        <YAxis
                          tick={{ fontSize: 11, fill: '#78716c' }}
                          tickLine={false}
                          axisLine={false}
                          tickFormatter={(v) => `$${v}`}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#0c0a09',
                            border: '1px solid #292524',
                            borderRadius: '12px',
                            color: '#ffffff',
                            fontSize: '11px',
                            padding: '8px 12px',
                          }}
                          formatter={(value: any) => [`$${Number(value || 0).toFixed(2)}`, 'Revenue']}
                          labelFormatter={(label) => `Date: ${label}`}
                        />
                        <Area
                          type="monotone"
                          dataKey="revenue"
                          stroke="#7e22ce"
                          strokeWidth={2.5}
                          fillOpacity={1}
                          fill="url(#novoraRevenueGradient)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* 2. Daily Order Volume (Bar Chart) */}
                <div className="lg:col-span-5 bg-stone-50/60 p-5 rounded-2xl border border-stone-200/80 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                        Daily Order Volume (#)
                      </h3>
                      <p className="text-[11px] text-stone-500">Number of orders processed</p>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                      Order Units
                    </span>
                  </div>

                  <div className="h-64 w-full pt-2">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={salesTrendData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#e7e5e4" vertical={false} />
                        <XAxis
                          dataKey="displayDate"
                          tick={{ fontSize: 11, fill: '#78716c' }}
                          tickLine={false}
                          axisLine={{ stroke: '#e7e5e4' }}
                        />
                        <YAxis
                          allowDecimals={false}
                          tick={{ fontSize: 11, fill: '#78716c' }}
                          tickLine={false}
                          axisLine={false}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#0c0a09',
                            border: '1px solid #292524',
                            borderRadius: '12px',
                            color: '#ffffff',
                            fontSize: '11px',
                            padding: '8px 12px',
                          }}
                          formatter={(value: any) => [`${value} Orders`, 'Volume']}
                          labelFormatter={(label) => `Date: ${label}`}
                        />
                        <Bar
                          dataKey="ordersCount"
                          fill="#0f766e"
                          radius={[6, 6, 0, 0]}
                          maxBarSize={40}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

              </div>
            </div>

            {/* =========================================================================
                TOP-PERFORMING PRODUCTS RECHARTS VISUALIZATION (User Requirement 4)
            ========================================================================= */}
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-xs space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-100">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 bg-amber-100 text-amber-700 rounded-lg">
                      <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-amber-700">
                      Product Velocity &amp; Revenue Ranking
                    </span>
                  </div>
                  <h2 className="text-lg font-black text-stone-950 font-display">
                    Top-Performing Products Dashboard
                  </h2>
                  <p className="text-xs text-stone-500">
                    Live performance metrics ranking best-sellers by gross sales revenue and units purchased.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] text-stone-400 block font-semibold uppercase tracking-wider">Top Revenue Product</span>
                    <strong className="text-sm font-black text-stone-900 truncate max-w-[180px] block font-mono">
                      {topPerformingProducts[0]?.name || 'N/A'}
                    </strong>
                  </div>
                  <div className="h-8 w-px bg-stone-200" />
                  <div className="text-right">
                    <span className="text-[10px] text-stone-400 block font-semibold uppercase tracking-wider">Leader Gross</span>
                    <strong className="text-base font-black text-purple-700 font-mono">
                      ${(topPerformingProducts[0]?.revenue || 0).toFixed(2)}
                    </strong>
                  </div>
                </div>
              </div>

              {/* Grid: Recharts Horizontal/Vertical Product Bar Chart + Leaderboard Cards */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                
                {/* 1. Recharts Top Products Bar Chart */}
                <div className="lg:col-span-7 bg-stone-50/70 p-5 rounded-2xl border border-stone-200 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                        Revenue Contribution by Product ($ USD)
                      </h3>
                      <p className="text-[11px] text-stone-500">Recharts visual ranking across top items</p>
                    </div>
                    <span className="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-100 text-amber-900 border border-amber-200">
                      Top 6 Items
                    </span>
                  </div>

                  <div className="h-72 w-full pt-2">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={topPerformingProducts}
                        layout="vertical"
                        margin={{ top: 5, right: 30, left: 15, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e7e5e4" />
                        <XAxis
                          type="number"
                          tickFormatter={(v) => `$${v}`}
                          tick={{ fontSize: 11, fill: '#78716c' }}
                          axisLine={{ stroke: '#e7e5e4' }}
                          tickLine={false}
                        />
                        <YAxis
                          type="category"
                          dataKey="shortName"
                          tick={{ fontSize: 11, fill: '#1c1917', fontWeight: 600 }}
                          axisLine={false}
                          tickLine={false}
                          width={110}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#0c0a09',
                            border: '1px solid #292524',
                            borderRadius: '12px',
                            color: '#ffffff',
                            fontSize: '11px',
                            padding: '10px 14px',
                          }}
                          formatter={(value: any) => [
                            `$${Number(value || 0).toFixed(2)}`,
                            'Gross Revenue',
                          ]}
                          labelFormatter={(label, payload) => {
                            const item = payload?.[0]?.payload;
                            return item ? `${item.name} (${item.category}) · ${item.unitsSold} Units Sold` : label;
                          }}
                        />
                        <Bar
                          dataKey="revenue"
                          fill="#7e22ce"
                          radius={[0, 6, 6, 0]}
                          maxBarSize={24}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="pt-2 border-t border-stone-200/70 flex items-center justify-between text-[11px] text-stone-500">
                    <span className="flex items-center gap-1.5 font-medium">
                      <span className="w-2.5 h-2.5 rounded-full bg-purple-700" />
                      Gross Revenue ($)
                    </span>
                    <span>Computed from real customer checkout orders &amp; catalog records</span>
                  </div>
                </div>

                {/* 2. Top Products Leaderboard Card List */}
                <div className="lg:col-span-5 space-y-3">
                  <div className="flex items-center justify-between px-1">
                    <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                      Leaderboard Breakdown
                    </h3>
                    <span className="text-[11px] text-stone-400 font-mono">Rank · Units · Revenue</span>
                  </div>

                  <div className="space-y-2.5">
                    {topPerformingProducts.map((prod, idx) => {
                      const rankBadges = [
                        'bg-amber-400 text-stone-950 font-black shadow-xs',
                        'bg-stone-300 text-stone-900 font-bold',
                        'bg-amber-700/80 text-amber-50 font-bold',
                        'bg-stone-100 text-stone-600 font-semibold',
                        'bg-stone-100 text-stone-600 font-semibold',
                        'bg-stone-100 text-stone-600 font-semibold',
                      ];

                      return (
                        <div
                          key={prod.id}
                          className="flex items-center justify-between p-3 bg-stone-50/90 hover:bg-stone-100 rounded-2xl border border-stone-200/80 transition-colors"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <span className={`w-6 h-6 rounded-lg text-xs flex items-center justify-center shrink-0 ${rankBadges[idx] || 'bg-stone-100'}`}>
                              #{idx + 1}
                            </span>
                            <img
                              src={prod.image}
                              alt={prod.name}
                              className="w-10 h-10 rounded-xl object-cover border border-stone-200 bg-white shrink-0"
                            />
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-stone-900 truncate max-w-[150px] sm:max-w-[190px]">
                                {prod.name}
                              </p>
                              <div className="flex items-center gap-2 text-[10px] text-stone-500">
                                <span>{prod.category}</span>
                                <span>·</span>
                                <span className="font-semibold text-stone-700">{prod.unitsSold} sold</span>
                              </div>
                            </div>
                          </div>

                          <div className="text-right shrink-0 ml-3">
                            <strong className="text-xs font-bold text-stone-950 font-mono block">
                              ${prod.revenue.toFixed(2)}
                            </strong>
                            <span className={`text-[10px] font-semibold ${prod.stock <= 5 ? 'text-amber-600' : 'text-emerald-700'}`}>
                              {prod.stock <= 5 ? `Low Stock (${prod.stock})` : `${prod.stock} in stock`}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>
            </div>

            {/* =========================================================================
                ADMIN CREDENTIALS & GOOGLE DRIVE PERSISTENCE HUB (User Requirement 1 & 3)
            ========================================================================= */}
            <div className="bg-linear-to-r from-stone-900 via-purple-950 to-stone-950 text-white rounded-3xl p-6 sm:p-7 shadow-lg border border-purple-900/50 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="p-1 rounded-md bg-purple-500/30 text-purple-300">
                      <ShieldCheck className="w-4 h-4 text-purple-300" />
                    </span>
                    <span className="text-[10px] font-mono uppercase tracking-widest text-purple-300 font-bold">
                      Admin Credentials &amp; Cloud Drive Persistence
                    </span>
                  </div>
                  <h3 className="text-base font-extrabold text-white font-display">
                    Target Folder: {TARGET_DRIVE_FOLDER_NAME}
                  </h3>
                  <p className="text-xs text-stone-300">
                    Administrator details and authentication permissions are secured with SHA-256 hash in <code className="font-mono text-purple-300 font-bold">admin_credentials.json</code> and saved into your private Google Drive folder.
                  </p>
                </div>

                <div className="flex items-center gap-2.5 shrink-0">
                  <button
                    onClick={openAdminModal}
                    className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
                  >
                    <Key className="w-3.5 h-3.5" />
                    <span>Change Admin Details</span>
                  </button>

                  <a
                    href={TARGET_DRIVE_FOLDER_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold border border-stone-700 transition-colors inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>Open Drive Folder</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Status Pills Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-purple-900/40 text-xs">
                <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-0.5">
                  <span className="text-[10px] text-stone-400 font-medium uppercase tracking-wider block">Admin Security File</span>
                  <p className="font-mono text-emerald-400 font-bold flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                    <span>admin_credentials.json</span>
                  </p>
                  <p className="text-[10px] text-stone-400">Target Folder: 1q_B8QGCYgzRgVzT4r3f-NH2PN1XaU34m</p>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-0.5">
                  <span className="text-[10px] text-stone-400 font-medium uppercase tracking-wider block">Local Sign-In Folder</span>
                  <p className="font-mono text-stone-200 font-bold flex items-center gap-1.5">
                    <Folder className="w-3.5 h-3.5 text-amber-400" />
                    <span>data/sign_in/</span>
                  </p>
                  <p className="text-[10px] text-stone-400">Persistent disk backup with account records</p>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-0.5">
                  <span className="text-[10px] text-stone-400 font-medium uppercase tracking-wider block">Cloud Drive Sync Status</span>
                  <p className="font-mono text-purple-300 font-bold flex items-center gap-1.5">
                    <RefreshCw className="w-3.5 h-3.5 text-purple-300" />
                    <span>{getDriveAccessToken() ? 'Active & Linked' : 'Ready (Click Connect Drive)'}</span>
                  </p>
                  <p className="text-[10px] text-stone-400">Synchronizes 6 JSON records automatically</p>
                </div>
              </div>
            </div>

            {/* =========================================================================
                MERCHANT BUSINESS CARD & PAYOUT SETTLEMENT SHOWCASE HUB
            ========================================================================= */}
            <div className="bg-linear-to-br from-stone-950 via-stone-900 to-purple-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-stone-800 relative overflow-hidden">
              {/* Luxury background glow */}
              <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

              <div className="relative z-10">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-stone-800/80">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-widest uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30">
                        Merchant Finance Hub
                      </span>
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        Card System Active
                      </span>
                    </div>
                    <h2 className="text-xl font-black font-display tracking-tight text-white flex items-center gap-2">
                      <span>Executive Business Card & Bank Payout Destination</span>
                    </h2>
                    <p className="text-xs text-stone-300 max-w-2xl leading-relaxed">
                      Active billing credit/debit card on file for merchant charges, wholesale sourcing, and dropshipping dispatch, linked directly to your 1Link/Raast verified Pakistani bank payout destination.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2.5">
                    <button
                      type="button"
                      onClick={() => setIsArchitectureModalOpen(true)}
                      className="px-4 py-2.5 bg-purple-900/80 hover:bg-purple-800 text-purple-200 hover:text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-2 border border-purple-500/40"
                    >
                      <Eye className="w-4 h-4 text-purple-300" />
                      <span>View System Blueprint</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleOpenOverviewCardModal}
                      className="px-4 py-2.5 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-500 hover:to-purple-600 text-white font-bold text-xs rounded-xl shadow-lg transition-all cursor-pointer flex items-center gap-2 border border-purple-400/30"
                    >
                      <CreditCard className="w-4 h-4" />
                      <span>Change / Update Card</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('payment-settings')}
                      className="px-4 py-2.5 bg-stone-800/90 hover:bg-stone-700 text-stone-200 hover:text-white font-semibold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-2 border border-stone-700"
                    >
                      <span>Full Cards & Payments Hub →</span>
                    </button>
                  </div>
                </div>

                {/* Card + Bank Details Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-6 items-center">
                  
                  {/* Luxury 3D-styled Merchant Card Mockup */}
                  <div className="lg:col-span-5">
                    <div className="relative aspect-[1.586/1] w-full max-w-sm mx-auto rounded-2xl p-5 sm:p-6 bg-gradient-to-br from-stone-900 via-stone-800 to-black text-white shadow-2xl border border-stone-700/60 flex flex-col justify-between overflow-hidden group hover:border-purple-500/50 transition-all duration-300">
                      {/* Card Shine Overlay */}
                      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent pointer-events-none" />

                      {/* Header of Card */}
                      <div className="flex items-center justify-between relative z-10">
                        <div className="flex items-center gap-2">
                          <div className="w-9 h-7 rounded-md bg-gradient-to-br from-amber-300 via-amber-400 to-amber-600 p-0.5 shadow-inner flex items-center justify-center">
                            <div className="w-full h-full border border-amber-800/30 rounded-xs grid grid-cols-2 gap-0.5 opacity-80" />
                          </div>
                          <Wifi className="w-4 h-4 text-stone-400 rotate-90" />
                          <span className="text-[10px] tracking-widest uppercase font-mono text-stone-400">CORPORATE</span>
                        </div>
                        <span className="text-xs font-black tracking-widest text-white uppercase font-display bg-stone-800/80 px-2 py-0.5 rounded border border-stone-700">
                          {paymentGateway?.merchantCard?.brand?.toUpperCase() || 'VISA'}
                        </span>
                      </div>

                      {/* Card Number */}
                      <div className="relative z-10 my-auto py-2">
                        <div className="text-stone-400 text-[10px] tracking-widest uppercase mb-1">Business Card Number</div>
                        <div className="font-mono text-lg sm:text-xl font-extrabold tracking-widest text-stone-100 flex items-center gap-3">
                          <span>••••</span>
                          <span>••••</span>
                          <span>••••</span>
                          <span className="text-amber-300 font-black">{paymentGateway?.merchantCard?.last4 || '9922'}</span>
                        </div>
                      </div>

                      {/* Cardholder & Expiry */}
                      <div className="flex items-end justify-between relative z-10 pt-2 border-t border-stone-800/60">
                        <div>
                          <div className="text-[9px] uppercase tracking-wider text-stone-400 font-semibold">Authorized Cardholder</div>
                          <div className="text-xs font-bold tracking-wider text-stone-200 uppercase truncate max-w-[180px]">
                            {paymentGateway?.merchantCard?.cardholderName || 'NOVORA ATELIER GLOBAL'}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-[9px] uppercase tracking-wider text-stone-400 font-semibold">Expires</div>
                          <div className="text-xs font-mono font-bold text-stone-200">
                            {paymentGateway?.merchantCard?.expiryMonth || '12'} / {paymentGateway?.merchantCard?.expiryYear || '2028'}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Merchant Account & Settlement Specifications */}
                  <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    {/* Active Card Specs */}
                    <div className="p-4 rounded-2xl bg-stone-900/80 border border-stone-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider">Card Status</span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          {paymentGateway?.merchantCard?.status || 'Active & Verified'}
                        </span>
                      </div>
                      <div className="text-sm font-bold text-stone-100 flex items-center gap-1.5">
                        <CreditCard className="w-4 h-4 text-purple-400" />
                        <span className="capitalize">{paymentGateway?.merchantCard?.brand || 'Visa'} Corporate Business</span>
                      </div>
                      <p className="text-[11px] text-stone-400 leading-relaxed">
                        Default billing method for merchant processing fees, dropshipping fulfillment, and payment gateway subscriptions.
                      </p>
                      <button
                        type="button"
                        onClick={handleOpenOverviewCardModal}
                        className="text-[11px] font-bold text-purple-400 hover:text-purple-300 underline cursor-pointer inline-flex items-center gap-1 pt-1"
                      >
                        Change to Another Card →
                      </button>
                    </div>

                    {/* Linked Bank Account Specs */}
                    <div className="p-4 rounded-2xl bg-stone-900/80 border border-stone-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-semibold text-stone-400 uppercase tracking-wider">Payout Destination</span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30">
                          1Link / Raast
                        </span>
                      </div>
                      <div className="text-sm font-bold text-stone-100 flex items-center gap-1.5">
                        <Building2 className="w-4 h-4 text-amber-400" />
                        <span>{paymentGateway?.payoutAccount?.bankName || 'Meezan Bank Ltd (Raast Verified)'}</span>
                      </div>
                      <div className="font-mono text-xs text-stone-300">
                        {paymentGateway?.payoutAccount?.ibanMasked || 'PK••MEZN••••••••••••9012'}
                      </div>
                      <p className="text-[11px] text-stone-400 leading-relaxed">
                        Direct merchant proceeds settlement destination. Schedule: <strong>Daily Rolling (T+2)</strong>.
                      </p>
                    </div>

                    {/* Security & Regulatory Clearance */}
                    <div className="sm:col-span-2 p-3.5 rounded-xl bg-purple-950/40 border border-purple-900/50 flex items-center justify-between flex-wrap gap-2 text-xs">
                      <div className="flex items-center gap-2 text-stone-300">
                        <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span className="text-[11px]">
                          <strong>PCI-DSS Level 1 Encrypted:</strong> Full PAN and CVV are never stored in plain text. Only tokenized references and masked numbers are maintained.
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-[11px] text-stone-400">
                        <span>SBP Regulatory Compliant</span>
                        <span>·</span>
                        <span>3D Secure 2.0</span>
                      </div>
                    </div>

                  </div>

                </div>

                {/* Embedded System Architecture Flow Banner & Trigger */}
                <div className="mt-6 pt-6 border-t border-stone-800/80">
                  <div className="bg-stone-900/90 rounded-2xl p-5 border border-purple-900/40 flex flex-col md:flex-row items-center justify-between gap-5">
                    
                    <div className="flex items-center gap-4">
                      {/* Diagram Thumbnail with click-to-enlarge */}
                      <div
                        onClick={() => setIsArchitectureModalOpen(true)}
                        className="relative w-36 h-24 sm:w-44 sm:h-28 rounded-xl overflow-hidden border border-purple-500/40 bg-stone-950 shadow-lg cursor-pointer group shrink-0"
                      >
                        <img
                          src="/assets/aistudio/Novora_Admin_Payment_Flow_System_3ecf585c.png"
                          alt="NOVORA Admin Bank Card Entry & Payment Flow System"
                          className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-stone-950/40 group-hover:bg-stone-950/10 flex items-center justify-center transition-colors">
                          <span className="px-2 py-1 bg-black/80 backdrop-blur-xs rounded-lg text-[9px] font-bold text-white border border-white/20 flex items-center gap-1">
                            <Maximize2 className="w-3 h-3 text-purple-400" />
                            <span>Enlarge Flowchart</span>
                          </span>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400">
                            Official Architectural Flowchart
                          </span>
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            Verified Workflow
                          </span>
                        </div>
                        <h4 className="text-sm font-extrabold text-white">
                          NOVORA Admin Bank Card Entry & Payment Flow System
                        </h4>
                        <p className="text-xs text-stone-300 leading-relaxed max-w-xl">
                          Complete 2-track workflow: <strong>Admin Card Management & Future Card Changing</strong> and <strong>Customer Checkout & Payout Settlement to Admin Card</strong> with PCI-DSS zero-PAN storage.
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2.5 shrink-0 w-full md:w-auto justify-end">
                      <button
                        type="button"
                        onClick={() => setIsArchitectureModalOpen(true)}
                        className="px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-2"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>Inspect System Flowchart</span>
                      </button>
                      <a
                        href="/assets/aistudio/Novora_Admin_Payment_Flow_System_3ecf585c.png"
                        download="Novora_Admin_Payment_Flow_System.png"
                        className="px-3.5 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-white font-semibold text-xs rounded-xl transition-all flex items-center gap-1.5 border border-stone-700"
                        title="Download high-resolution system diagram"
                      >
                        <Download className="w-3.5 h-3.5 text-stone-400" />
                        <span>PNG</span>
                      </a>
                    </div>

                  </div>
                </div>
              </div>
            </div>

            {/* Customer Sign-In & PC Folder Storage Architecture Showcase Banner */}
            <div className="bg-gradient-to-r from-stone-900 via-purple-950 to-stone-900 text-white rounded-3xl p-5 sm:p-6 shadow-xl border border-purple-800/60 relative overflow-hidden">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
                <div className="flex items-center gap-4">
                  <div
                    onClick={() => setIsCustomerFlowModalOpen(true)}
                    className="group relative cursor-pointer rounded-xl overflow-hidden border border-purple-500/50 bg-stone-950 shrink-0 w-28 h-20 shadow-md"
                  >
                    <img
                      src="/assets/aistudio/Novora_Customer_Sign-In_System_Flowchart_de2464bf.png"
                      alt="Customer Sign-In System Flowchart"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute inset-0 bg-stone-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Maximize2 className="w-4 h-4 text-white" />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/40">
                        School Project System
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono text-emerald-300 bg-emerald-500/20 border border-emerald-500/40">
                        Host: 137.184.23.176
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono text-amber-300 bg-amber-500/20 border border-amber-500/40">
                        Folder: C:\Novora_Project\Data\
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-white">
                      Customer Sign In &amp; Address Storage System (Local PC Folder)
                    </h3>
                    <p className="text-xs text-stone-300 max-w-xl">
                      Real-time synchronization of customer credentials into <code>users.json</code> (with SHA-256 hashed passwords), 10-field addresses in <code>addresses.json</code>, and orders in <code>orders.json</code>.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2.5 shrink-0 self-end md:self-center">
                  <button
                    type="button"
                    onClick={() => setIsCustomerFlowModalOpen(true)}
                    className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Customer Flowchart</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('customers')}
                    className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 hover:text-white font-semibold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5 border border-stone-700"
                  >
                    <Folder className="w-3.5 h-3.5 text-amber-400" />
                    <span>Open PC Folder Hub</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Actions & Recent Orders Table */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Recent Orders List */}
              <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                  <div>
                    <h3 className="text-sm font-bold text-stone-900">Recent Customer Orders</h3>
                    <p className="text-xs text-stone-500">Live order status and complete address records</p>
                  </div>
                  <button
                    onClick={() => setActiveTab('orders')}
                    className="text-xs font-semibold text-purple-700 hover:underline"
                  >
                    View All Orders →
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-stone-200 text-stone-400 uppercase text-[10px]">
                        <th className="py-2.5">Order Ref</th>
                        <th className="py-2.5">Customer & City</th>
                        <th className="py-2.5">Items</th>
                        <th className="py-2.5">Total</th>
                        <th className="py-2.5">Status</th>
                        <th className="py-2.5 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {orders.slice(0, 5).map(o => (
                        <tr key={o.id} className="hover:bg-stone-50 transition-colors">
                          <td className="py-3 font-mono font-bold text-stone-950">{o.orderNumber}</td>
                          <td className="py-3">
                            <span className="font-semibold text-stone-900">{o.deliveryAddress.fullName}</span>
                            <span className="block text-[10px] text-stone-500">
                              {o.deliveryAddress.city}, {o.deliveryAddress.country}
                            </span>
                          </td>
                          <td className="py-3">{o.items.length} item(s)</td>
                          <td className="py-3 font-bold tabular-nums">${o.total.toFixed(2)}</td>
                          <td className="py-3">
                            <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-purple-100 text-purple-900">
                              {o.orderStatus}
                            </span>
                          </td>
                          <td className="py-3 text-right">
                            <button
                              onClick={() => {
                                setInspectingOrder(o);
                                setActiveTab('orders');
                              }}
                              className="text-xs text-purple-700 hover:text-purple-950 font-semibold"
                            >
                              Inspect Details
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Quick Actions Panel */}
              <div className="lg:col-span-4 space-y-4">
                <div className="bg-stone-950 text-white p-6 rounded-2xl border border-stone-800 shadow-md space-y-4">
                  <h3 className="text-sm font-bold font-display tracking-wide uppercase">
                    Admin Quick Shortcuts
                  </h3>
                  <div className="space-y-2 text-xs">
                    <button
                      onClick={handleOpenOverviewCardModal}
                      className="w-full p-3 bg-stone-900 hover:bg-purple-700 rounded-xl flex items-center justify-between transition-colors text-left font-semibold cursor-pointer"
                    >
                      <span>Change Business Card</span>
                      <CreditCard className="w-4 h-4 text-purple-300" />
                    </button>

                    <button
                      onClick={() => setIsArchitectureModalOpen(true)}
                      className="w-full p-3 bg-stone-900 hover:bg-purple-700 rounded-xl flex items-center justify-between transition-colors text-left font-semibold cursor-pointer"
                    >
                      <span>System Flow Blueprint</span>
                      <Maximize2 className="w-4 h-4 text-purple-300" />
                    </button>

                    <button
                      onClick={() => {
                        setEditingProduct(null);
                        setActiveTab('add-product');
                      }}
                      className="w-full p-3 bg-stone-900 hover:bg-purple-700 rounded-xl flex items-center justify-between transition-colors text-left font-semibold"
                    >
                      <span>Upload Product from PC</span>
                      <Upload className="w-4 h-4 text-purple-300" />
                    </button>

                    <button
                      onClick={() => setActiveTab('banners')}
                      className="w-full p-3 bg-stone-900 hover:bg-purple-700 rounded-xl flex items-center justify-between transition-colors text-left font-semibold"
                    >
                      <span>Change Homepage Banners</span>
                      <ImageIcon className="w-4 h-4 text-purple-300" />
                    </button>

                    <button
                      onClick={handleExportCSV}
                      className="w-full p-3 bg-stone-900 hover:bg-purple-700 rounded-xl flex items-center justify-between transition-colors text-left font-semibold"
                    >
                      <span>Export Orders to CSV</span>
                      <Download className="w-4 h-4 text-purple-300" />
                    </button>

                    <button
                      onClick={() => setActiveTab('settings')}
                      className="w-full p-3 bg-stone-900 hover:bg-purple-700 rounded-xl flex items-center justify-between transition-colors text-left font-semibold"
                    >
                      <span>Store & Shipping Settings</span>
                      <Settings className="w-4 h-4 text-purple-300" />
                    </button>
                  </div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-stone-200 text-xs space-y-2">
                  <h4 className="font-bold text-stone-900 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Database State</span>
                  </h4>
                  <p className="text-stone-500 leading-relaxed text-[11px]">
                    All changes made in this dashboard write synchronously to <code>data/store.json</code> and persist permanently across browser refreshes and server reboots.
                  </p>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* =========================================================================
            2. TAB: MANAGE PRODUCTS
        ========================================================================= */}
        {activeTab === 'products' && (
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
              <div>
                <h2 className="text-base font-bold text-stone-950 font-display">Manage Product Catalog</h2>
                <p className="text-xs text-stone-500">Edit prices, manage stock, change status, or delete items.</p>
              </div>

              <button
                onClick={() => {
                  setEditingProduct(null);
                  setActiveTab('add-product');
                }}
                className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Add Product from PC</span>
              </button>
            </div>

            {/* Filter and Search Bar */}
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="Search by product name, SKU, or brand..."
                  value={productSearch}
                  onChange={e => setProductSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                />
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
              </div>

              <select
                value={productCategoryFilter}
                onChange={e => setProductCategoryFilter(e.target.value)}
                className="px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
              >
                <option value="all">All Categories</option>
                {categories.map(c => (
                  <option key={c.id} value={c.name}>{c.name}</option>
                ))}
              </select>
            </div>

            {/* Products Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-stone-200 text-stone-400 uppercase text-[10px]">
                    <th className="py-2.5">Thumbnail</th>
                    <th className="py-2.5">Product & SKU</th>
                    <th className="py-2.5">Category</th>
                    <th className="py-2.5">Price</th>
                    <th className="py-2.5">Stock</th>
                    <th className="py-2.5">Status</th>
                    <th className="py-2.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {products
                    .filter(p => {
                      if (productCategoryFilter !== 'all' && p.category !== productCategoryFilter) return false;
                      if (productSearch) {
                        const term = productSearch.toLowerCase();
                        return p.name.toLowerCase().includes(term) || p.sku.toLowerCase().includes(term) || p.brand.toLowerCase().includes(term);
                      }
                      return true;
                    })
                    .map(p => (
                      <tr key={p.id} className="hover:bg-stone-50 transition-colors">
                        <td className="py-3">
                          <img
                            src={p.images[0] || '/src/assets/images/novora_cat_fashion_1792421786979.jpg'}
                            alt={p.name}
                            className="w-12 h-14 object-cover rounded-lg bg-stone-100 border border-stone-200"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.currentTarget as HTMLImageElement).src = '/src/assets/images/novora_cat_fashion_1792421786979.jpg';
                            }}
                          />
                        </td>
                        <td className="py-3">
                          <span className="font-bold text-stone-900 block">{p.name}</span>
                          <span className="text-[10px] text-stone-400 font-mono">SKU: {p.sku} · {p.brand}</span>
                        </td>
                        <td className="py-3 text-stone-600">{p.category}</td>
                        <td className="py-3 font-semibold text-stone-900 tabular-nums">
                          ${p.sellingPrice.toFixed(2)}
                          {p.originalPrice > p.sellingPrice && (
                            <span className="text-[10px] text-stone-400 line-through block">
                              ${p.originalPrice.toFixed(2)}
                            </span>
                          )}
                        </td>
                        <td className="py-3">
                          <span className={`font-bold tabular-nums ${p.stock <= 5 ? 'text-amber-700' : 'text-stone-800'}`}>
                            {p.stock} units
                          </span>
                        </td>
                        <td className="py-3">
                          <span className={`px-2 py-0.5 text-[10px] font-bold rounded ${
                            p.status === 'published'
                              ? 'bg-emerald-100 text-emerald-800'
                              : p.status === 'out_of_stock'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-stone-200 text-stone-700'
                          }`}>
                            {p.status}
                          </span>
                        </td>
                        <td className="py-3 text-right">
                          <div className="flex items-center justify-end gap-1.5 flex-wrap">
                            <button
                              onClick={() => handleEditProductClick(p)}
                              className="px-2.5 py-1 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-lg inline-flex items-center gap-1 transition-colors cursor-pointer"
                              title="Edit Product"
                            >
                              <Edit className="w-3.5 h-3.5 text-purple-700" />
                              <span>Edit</span>
                            </button>

                            {p.status === 'published' ? (
                              <button
                                onClick={() => handleUnpublishProduct(p)}
                                className="px-2.5 py-1 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-lg inline-flex items-center gap-1 transition-colors cursor-pointer"
                                title="Unpublish from storefront"
                              >
                                <EyeOff className="w-3.5 h-3.5 text-amber-600" />
                                <span>Unpublish</span>
                              </button>
                            ) : (
                              <button
                                onClick={() => handlePublishProduct(p)}
                                className="px-2.5 py-1 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg inline-flex items-center gap-1 transition-colors cursor-pointer"
                                title="Publish to customer storefront"
                              >
                                <Eye className="w-3.5 h-3.5 text-emerald-600" />
                                <span>Publish</span>
                              </button>
                            )}

                            <button
                              onClick={() => setProductToDelete(p)}
                              className="px-2.5 py-1 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg inline-flex items-center gap-1 transition-colors cursor-pointer"
                              title="Delete Product Permanently"
                            >
                              <Trash2 className="w-3.5 h-3.5 text-rose-600" />
                              <span>Delete</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* =========================================================================
            3. TAB: ADD PRODUCT (Upload Images from PC Gallery - CRITICAL FEATURE)
        ========================================================================= */}
        {activeTab === 'add-product' && (
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-stone-200">
              <div>
                <span className="text-xs font-semibold text-purple-700 uppercase tracking-widest">
                  Catalog Publishing Portal
                </span>
                <h2 className="text-lg font-bold text-stone-950 font-display">
                  {editingProduct ? `Edit Product: ${editingProduct.name}` : 'Add New Product (Upload from PC)'}
                </h2>
                <p className="text-xs text-stone-500">
                  Select image files directly from your computer gallery. Images are saved to persistent server storage.
                </p>
              </div>

              {editingProduct && (
                <button
                  onClick={() => {
                    setEditingProduct(null);
                    setActiveTab('products');
                  }}
                  className="text-xs text-stone-600 hover:underline"
                >
                  Cancel Edit
                </button>
              )}
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-6">
              
              {/* SINGLE MAIN IMAGE UPLOAD FROM PC */}
              <div className="p-6 bg-stone-50 rounded-2xl border-2 border-dashed border-stone-300 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-wider text-stone-900 flex items-center gap-2">
                      <Upload className="w-4 h-4 text-purple-700" />
                      <span>Product Main Image (Upload Directly from PC)</span>
                    </h3>
                    <p className="text-[11px] text-stone-500">
                      Each product uses exactly ONE high-resolution main image. Supports JPG, PNG, WebP.
                    </p>
                  </div>

                  <div>
                    <input
                      type="file"
                      ref={productImageInputRef}
                      onChange={handleProductImageFileChange}
                      accept="image/jpeg,image/png,image/webp"
                      className="hidden"
                      id="pc-product-file-input"
                    />
                    <label
                      htmlFor="pc-product-file-input"
                      className="px-4 py-2 bg-stone-900 hover:bg-purple-700 text-white text-xs font-bold rounded-lg cursor-pointer flex items-center gap-1.5 transition-colors shadow-xs"
                    >
                      <Upload className="w-3.5 h-3.5 text-purple-300" />
                      <span>{isUploadingProductImage ? 'Uploading PC File...' : prodForm.images.length > 0 ? 'Replace Main Image from PC' : 'Choose Main Image from PC'}</span>
                    </label>
                  </div>
                </div>

                {/* Single Main Image Preview */}
                {prodForm.images.length > 0 ? (
                  <div className="flex flex-col sm:flex-row items-center gap-4 p-3 bg-white rounded-xl border border-stone-200">
                    <div className="relative w-32 h-32 rounded-lg overflow-hidden border border-stone-300 bg-stone-100 shrink-0 shadow-xs">
                      <img
                        src={prodForm.images[0]}
                        alt="Product main thumbnail"
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <span className="absolute bottom-1 left-1 bg-stone-900/90 text-white text-[9px] font-bold px-1.5 py-0.5 rounded">
                        Main Image
                      </span>
                    </div>
                    <div className="flex-1 space-y-1.5 text-center sm:text-left">
                      <h4 className="text-xs font-bold text-stone-900">Assigned Main Product Image</h4>
                      <p className="text-[11px] text-stone-500 leading-tight">
                        This image will be displayed on the customer storefront, product card, and details page in its original proportion.
                      </p>
                      <div className="pt-2 flex items-center justify-center sm:justify-start gap-2">
                        <label
                          htmlFor="pc-product-file-input"
                          className="px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-700 text-xs font-semibold rounded-lg border border-purple-200 transition-colors cursor-pointer"
                        >
                          Change Image
                        </label>
                        <button
                          type="button"
                          onClick={removeProductImage}
                          className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold rounded-lg border border-rose-200 transition-colors cursor-pointer"
                        >
                          Remove Image
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-6 border border-dashed border-stone-200 rounded-xl bg-white space-y-2">
                    <p className="text-xs text-stone-500 font-medium">
                      No main image selected yet.
                    </p>
                    <p className="text-[11px] text-stone-400 max-w-sm mx-auto">
                      Click "Choose Main Image from PC" to upload a product photo directly from your computer.
                    </p>
                  </div>
                )}
              </div>

              {/* Product Specifications Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Product Title *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Atelier Relaxed Wool Overcoat"
                    value={prodForm.name}
                    onChange={e => setProdForm({ ...prodForm, name: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:bg-white focus:border-purple-600"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Product SKU / Serial
                  </label>
                  <input
                    type="text"
                    placeholder="Auto-generated if blank (e.g. NVR-FSH-102)"
                    value={prodForm.sku}
                    onChange={e => setProdForm({ ...prodForm, sku: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:bg-white focus:border-purple-600 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Category *
                  </label>
                  <select
                    value={prodForm.category}
                    onChange={e => setProdForm({ ...prodForm, category: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:bg-white focus:border-purple-600"
                    required
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Subcategory (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Outerwear, Over-Ear, Face Serums"
                    value={prodForm.subcategory}
                    onChange={e => setProdForm({ ...prodForm, subcategory: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:bg-white focus:border-purple-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Brand / Atelier Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. NOVORA Atelier"
                    value={prodForm.brand}
                    onChange={e => setProdForm({ ...prodForm, brand: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:bg-white focus:border-purple-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Selling Price ($) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="280.00"
                    value={prodForm.sellingPrice}
                    onChange={e => setProdForm({ ...prodForm, sellingPrice: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:bg-white focus:border-purple-600 font-bold"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Original Price ($ Strike-through)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="340.00"
                    value={prodForm.originalPrice}
                    onChange={e => setProdForm({ ...prodForm, originalPrice: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:bg-white focus:border-purple-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Inventory Stock Quantity *
                  </label>
                  <input
                    type="number"
                    value={prodForm.stock}
                    onChange={e => setProdForm({ ...prodForm, stock: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:bg-white focus:border-purple-600"
                    required
                  />
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Comprehensive Description & Materials
                  </label>
                  <textarea
                    rows={4}
                    placeholder="Detail the materials, cut, craftsmanship, and specifications..."
                    value={prodForm.description}
                    onChange={e => setProdForm({ ...prodForm, description: e.target.value })}
                    className="w-full p-3 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:bg-white focus:border-purple-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Size Variants (Comma Separated)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. XS, S, M, L, XL"
                    value={prodForm.sizes}
                    onChange={e => setProdForm({ ...prodForm, sizes: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:bg-white focus:border-purple-600"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Color Variants (Name:Hex, Comma Separated)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Charcoal:#374151, Deep Black:#111827"
                    value={prodForm.colors}
                    onChange={e => setProdForm({ ...prodForm, colors: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:bg-white focus:border-purple-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Publishing Status
                  </label>
                  <select
                    value={prodForm.status}
                    onChange={e => setProdForm({ ...prodForm, status: e.target.value as any })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:bg-white focus:border-purple-600"
                  >
                    <option value="published">Published (Visible to Customers)</option>
                    <option value="draft">Draft (Hidden)</option>
                    <option value="out_of_stock">Out of Stock</option>
                  </select>
                </div>

                <div className="flex items-center gap-6 pt-5">
                  <label className="flex items-center gap-2 text-xs font-medium text-stone-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={prodForm.featured}
                      onChange={e => setProdForm({ ...prodForm, featured: e.target.checked })}
                      className="w-4 h-4 text-purple-600 rounded"
                    />
                    <span>Featured on Homepage</span>
                  </label>

                  <label className="flex items-center gap-2 text-xs font-medium text-stone-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={prodForm.bestSeller}
                      onChange={e => setProdForm({ ...prodForm, bestSeller: e.target.checked })}
                      className="w-4 h-4 text-purple-600 rounded"
                    />
                    <span>Mark as Best Seller</span>
                  </label>
                </div>

              </div>

              <div className="pt-4 border-t border-stone-200 flex gap-3">
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-stone-950 hover:bg-purple-700 text-white text-xs font-bold uppercase tracking-wider rounded-xl transition-all shadow-md cursor-pointer"
                >
                  {editingProduct ? 'Save & Update Product' : 'Publish Product to Store'}
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('products')}
                  className="px-5 py-2.5 bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl hover:bg-stone-300"
                >
                  Cancel
                </button>
              </div>

            </form>
          </div>
        )}

        {/* =========================================================================
            4. TAB: MANAGE CATEGORIES (Upload from PC)
        ========================================================================= */}
        {activeTab === 'categories' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Create Category Form */}
            <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
              <h2 className="text-sm font-bold text-stone-900 font-display">
                Create New Category (Upload Image from PC)
              </h2>

              <form onSubmit={handleSaveCategory} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Category Name *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Fine Jewelry & Horology"
                    value={catForm.name}
                    onChange={e => setCatForm({ ...catForm, name: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Category Cover Image from PC
                  </label>
                  <input
                    type="file"
                    ref={catImageInputRef}
                    onChange={handleCatImageFileChange}
                    accept="image/jpeg,image/png,image/webp"
                    className="hidden"
                    id="pc-cat-file"
                  />
                  <div className="flex items-center gap-3">
                    <label
                      htmlFor="pc-cat-file"
                      className="px-3.5 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-lg border border-stone-300 cursor-pointer flex items-center gap-1.5"
                    >
                      <Upload className="w-3.5 h-3.5 text-purple-700" />
                      <span>{isUploadingCatImage ? 'Uploading...' : 'Choose PC File'}</span>
                    </label>
                    {catForm.image && (
                      <img
                        src={catForm.image}
                        alt="Preview"
                        className="w-10 h-10 object-cover rounded-lg border"
                        referrerPolicy="no-referrer"
                      />
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Description
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Brief description for category card and SEO..."
                    value={catForm.description}
                    onChange={e => setCatForm({ ...catForm, description: e.target.value })}
                    className="w-full p-2.5 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Subcategories (Comma separated)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Rings, Necklaces, Chronographs"
                    value={catForm.subcategories}
                    onChange={e => setCatForm({ ...catForm, subcategories: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-stone-900 hover:bg-purple-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                >
                  Create & Save Category
                </button>
              </form>
            </div>

            {/* Existing Categories List */}
            <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-stone-900">
                Active Store Categories ({categories.length})
              </h3>

              <div className="space-y-3">
                {categories.map(c => (
                  <div key={c.id} className="flex items-center gap-4 p-3 bg-stone-50 rounded-xl border border-stone-200">
                    <img
                      src={c.image || '/src/assets/images/novora_cat_fashion_1792421786979.jpg'}
                      alt={c.name}
                      className="w-14 h-14 object-cover rounded-lg bg-stone-200 shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-bold text-stone-900">{c.name}</h4>
                      <p className="text-[11px] text-stone-500 truncate">{c.description}</p>
                      <p className="text-[10px] text-purple-700 font-medium mt-0.5">
                        Slug: /{c.slug} · {c.subcategories.length} subcategories
                      </p>
                    </div>
                    <button
                      onClick={() => setCategoryToDelete(c)}
                      className="p-1.5 text-stone-400 hover:text-rose-600 transition-colors cursor-pointer"
                      title="Delete Category"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* =========================================================================
            5. TAB: MANAGE BANNERS (Upload Banners from PC)
        ========================================================================= */}
        {activeTab === 'banners' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Create Banner Form */}
            <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
              <h2 className="text-sm font-bold text-stone-900 font-display">
                Upload New Promotional Banner
              </h2>
              <p className="text-xs text-stone-500">
                Uploaded banners appear automatically on the customer homepage.
              </p>

              <form onSubmit={handleSaveBanner} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Banner Heading *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. The Architecture of Modern Tailoring"
                    value={bannerForm.title}
                    onChange={e => setBannerForm({ ...bannerForm, title: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Banner Background Image from PC *
                  </label>
                  <input
                    type="file"
                    ref={bannerImageInputRef}
                    onChange={handleBannerImageFileChange}
                    accept="image/jpeg,image/png,image/webp"
                    className="hidden"
                    id="pc-banner-file"
                  />
                  <div className="flex items-center gap-3">
                    <label
                      htmlFor="pc-banner-file"
                      className="px-3.5 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-lg border border-stone-300 cursor-pointer flex items-center gap-1.5"
                    >
                      <Upload className="w-3.5 h-3.5 text-purple-700" />
                      <span>{isUploadingBannerImage ? 'Uploading...' : 'Upload Image from PC'}</span>
                    </label>
                    {bannerForm.imageUrl && (
                      <span className="text-[11px] text-emerald-600 font-medium">Image Loaded ✓</span>
                    )}
                  </div>
                  {bannerForm.imageUrl && (
                    <img
                      src={bannerForm.imageUrl}
                      alt="Banner Preview"
                      className="w-full aspect-16/9 object-cover rounded-xl mt-2 border"
                      referrerPolicy="no-referrer"
                    />
                  )}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Subtitle / Promotional Copy
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Campaign details and collection story..."
                    value={bannerForm.subtitle}
                    onChange={e => setBannerForm({ ...bannerForm, subtitle: e.target.value })}
                    className="w-full p-2.5 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Button Text</label>
                    <input
                      type="text"
                      value={bannerForm.buttonText}
                      onChange={e => setBannerForm({ ...bannerForm, buttonText: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Destination URL</label>
                    <input
                      type="text"
                      value={bannerForm.linkUrl}
                      onChange={e => setBannerForm({ ...bannerForm, linkUrl: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-stone-900 hover:bg-purple-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                >
                  Publish Banner to Homepage
                </button>
              </form>
            </div>

            {/* Active Banners Display */}
            <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-stone-900">
                Homepage Hero & Campaign Banners ({banners.length})
              </h3>

              <div className="space-y-4">
                {banners.map((b, idx) => (
                  <div key={b.id} className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-3">
                    <div className="aspect-16/9 w-full rounded-lg overflow-hidden bg-stone-200 relative">
                      <img
                        src={b.imageUrl}
                        alt={b.title}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-2 left-2 bg-stone-900/80 text-white text-[10px] font-bold px-2 py-0.5 rounded">
                        Position #{idx + 1}
                      </div>
                    </div>

                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h4 className="text-xs font-bold text-stone-900">{b.title}</h4>
                        <p className="text-[11px] text-stone-500 mt-0.5 line-clamp-2">{b.subtitle}</p>
                        <p className="text-[10px] text-purple-700 font-mono mt-1">Button: "{b.buttonText}" → {b.linkUrl}</p>
                      </div>

                      <button
                        onClick={() => setBannerToDelete(b)}
                        className="p-1.5 text-stone-400 hover:text-rose-600 transition-colors cursor-pointer"
                        title="Delete Banner"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* =========================================================================
            6. TAB: MANAGE ORDERS (COMPULSORY 10 DELIVERY ADDRESS FIELDS & 8 STATUSES)
        ========================================================================= */}
        {activeTab === 'orders' && (
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
              <div>
                <span className="text-xs font-semibold text-purple-700 uppercase tracking-widest">
                  Order Fulfillment Center
                </span>
                <h2 className="text-base font-bold text-stone-950 font-display">
                  Manage Orders & Delivery Addresses
                </h2>
                <p className="text-xs text-stone-500">
                  Inspect complete 10-point customer delivery addresses, verified payment statuses, print packing slips, and dispatch to CJ Dropshipping.
                </p>
              </div>

              <button
                onClick={handleExportCSV}
                className="px-4 py-2 bg-stone-900 hover:bg-purple-700 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto"
              >
                <Download className="w-4 h-4" />
                <span>Export All Orders (CSV)</span>
              </button>
            </div>

            {/* Quick Status KPI Summary */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <span className="text-stone-500 text-[11px] block">Total Orders</span>
                <span className="text-lg font-bold text-stone-950 font-mono">{orders.length}</span>
              </div>
              <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-200">
                <span className="text-amber-800 text-[11px] block">Awaiting Payment</span>
                <span className="text-lg font-bold text-amber-900 font-mono">
                  {orders.filter(o => o.orderStatus === 'Awaiting Payment' || o.paymentStatus === 'pending').length}
                </span>
              </div>
              <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-200">
                <span className="text-emerald-800 text-[11px] block">Paid & Validated</span>
                <span className="text-lg font-bold text-emerald-900 font-mono">
                  {orders.filter(o => o.paymentStatus === 'paid').length}
                </span>
              </div>
              <div className="p-3 bg-purple-50/60 rounded-xl border border-purple-200">
                <span className="text-purple-800 text-[11px] block">Shipped &amp; In Transit</span>
                <span className="text-lg font-bold text-purple-900 font-mono">
                  {orders.filter(o => o.orderStatus === 'Shipped' || o.orderStatus === 'Sent to Supplier').length}
                </span>
              </div>
            </div>

            {/* Archive Tabs & Controls */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-200 pb-3">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setOrderArchiveFilter('active')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
                    orderArchiveFilter === 'active'
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  <span>Active Orders</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${orderArchiveFilter === 'active' ? 'bg-purple-800 text-purple-200' : 'bg-stone-200 text-stone-700'}`}>
                    {orders.filter(o => !o.isArchived).length}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setOrderArchiveFilter('archived')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
                    orderArchiveFilter === 'archived'
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  <Folder className="w-3.5 h-3.5" />
                  <span>Archived Orders</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${orderArchiveFilter === 'archived' ? 'bg-purple-800 text-purple-200' : 'bg-stone-200 text-stone-700'}`}>
                    {orders.filter(o => o.isArchived).length}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setOrderArchiveFilter('all')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
                    orderArchiveFilter === 'all'
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  <span>All ({orders.length})</span>
                </button>
              </div>

              {(orderDateFilter !== 'all' || orderPaymentStatusFilter !== 'all' || orderStatusFilter !== 'all' || orderCountryFilter !== 'all' || orderSearch) && (
                <button
                  type="button"
                  onClick={() => {
                    setOrderDateFilter('all');
                    setOrderCustomStartDate('');
                    setOrderCustomEndDate('');
                    setOrderPaymentStatusFilter('all');
                    setOrderStatusFilter('all');
                    setOrderCountryFilter('all');
                    setOrderSearch('');
                  }}
                  className="text-xs text-purple-700 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset All Filters</span>
                </button>
              )}
            </div>

            {/* Search & Multi-Filters (Date Range, Payment Status, Fulfilment Status, Country) */}
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                
                {/* Search */}
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search order #, customer, email, phone, city..."
                    value={orderSearch}
                    onChange={e => setOrderSearch(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600"
                  />
                  <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                </div>

                {/* Date Range Filter (Prompt 9: Filter orders by specific date ranges) */}
                <select
                  value={orderDateFilter}
                  onChange={e => setOrderDateFilter(e.target.value as any)}
                  className="px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600 font-medium"
                >
                  <option value="all">Date Range: All Time</option>
                  <option value="today">Date Range: Today</option>
                  <option value="yesterday">Date Range: Yesterday</option>
                  <option value="7days">Date Range: Last 7 Days</option>
                  <option value="30days">Date Range: Last 30 Days</option>
                  <option value="this_month">Date Range: This Month</option>
                  <option value="custom">Date Range: Custom Date Range…</option>
                </select>

                {/* Payment Status Filter (Prompt 9: Paid, Pending, Refunded) */}
                <select
                  value={orderPaymentStatusFilter}
                  onChange={e => setOrderPaymentStatusFilter(e.target.value)}
                  className="px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600 font-medium"
                >
                  <option value="all">Payment: All Statuses</option>
                  <option value="paid">Payment: Paid (Verified)</option>
                  <option value="pending">Payment: Pending</option>
                  <option value="refunded">Payment: Refunded</option>
                  <option value="declined">Payment: Declined</option>
                </select>

                {/* Fulfilment Status Filter (8 Statuses) */}
                <select
                  value={orderStatusFilter}
                  onChange={e => setOrderStatusFilter(e.target.value)}
                  className="px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600 font-medium"
                >
                  <option value="all">Fulfillment: All Statuses</option>
                  <option value="Awaiting Payment">Awaiting Payment</option>
                  <option value="Paid">Paid</option>
                  <option value="Processing">Processing</option>
                  <option value="Sent to Supplier">Sent to Supplier</option>
                  <option value="Shipped">Shipped</option>
                  <option value="Delivered">Delivered</option>
                  <option value="Cancelled">Cancelled</option>
                  <option value="Refunded">Refunded</option>
                </select>

                {/* Country Filter */}
                <select
                  value={orderCountryFilter}
                  onChange={e => setOrderCountryFilter(e.target.value)}
                  className="px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-purple-600 font-medium"
                >
                  <option value="all">Destination: All Countries</option>
                  <option value="Pakistan">Pakistan</option>
                  <option value="United States">United States</option>
                  <option value="United Kingdom">United Kingdom</option>
                  <option value="United Arab Emirates">United Arab Emirates</option>
                  <option value="Saudi Arabia">Saudi Arabia</option>
                  <option value="Canada">Canada</option>
                  <option value="Germany">Germany</option>
                  <option value="France">France</option>
                  <option value="Australia">Australia</option>
                </select>
              </div>

              {/* Custom Date Range Pickers (shown when custom is selected) */}
              {orderDateFilter === 'custom' && (
                <div className="p-3 bg-purple-50/60 border border-purple-200 rounded-xl flex flex-wrap items-center gap-3 text-xs">
                  <span className="font-bold text-purple-900">Custom Date Range:</span>
                  <div className="flex items-center gap-1.5">
                    <label className="text-stone-600 text-[11px]">From:</label>
                    <input
                      type="date"
                      value={orderCustomStartDate}
                      onChange={e => setOrderCustomStartDate(e.target.value)}
                      className="px-2.5 py-1 bg-white border border-stone-300 rounded-lg text-xs"
                    />
                  </div>
                  <div className="flex items-center gap-1.5">
                    <label className="text-stone-600 text-[11px]">To:</label>
                    <input
                      type="date"
                      value={orderCustomEndDate}
                      onChange={e => setOrderCustomEndDate(e.target.value)}
                      className="px-2.5 py-1 bg-white border border-stone-300 rounded-lg text-xs"
                    />
                  </div>
                  {(orderCustomStartDate || orderCustomEndDate) && (
                    <button
                      type="button"
                      onClick={() => {
                        setOrderCustomStartDate('');
                        setOrderCustomEndDate('');
                      }}
                      className="text-[11px] text-purple-700 hover:underline font-semibold cursor-pointer"
                    >
                      Clear Range
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Orders Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-stone-200 text-stone-400 uppercase text-[10px]">
                    <th className="py-2.5">Order Ref & Date</th>
                    <th className="py-2.5">Customer & Phone</th>
                    <th className="py-2.5">Full Delivery Address</th>
                    <th className="py-2.5">Products</th>
                    <th className="py-2.5">Total Paid</th>
                    <th className="py-2.5">Payment</th>
                    <th className="py-2.5">Fulfilment Status</th>
                    <th className="py-2.5">Tracking</th>
                    <th className="py-2.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {orders
                    .filter(o => {
                      // Archive Filter
                      if (orderArchiveFilter === 'active' && o.isArchived) return false;
                      if (orderArchiveFilter === 'archived' && !o.isArchived) return false;

                      // Date Range Filter
                      if (!isWithinDateRange(o.createdAt)) return false;

                      // Fulfilment Status Filter
                      if (orderStatusFilter !== 'all') {
                        if (orderStatusFilter === 'Awaiting Payment') {
                          if (o.orderStatus !== 'Awaiting Payment' && o.orderStatus !== 'Pending Payment') return false;
                        } else if (o.orderStatus !== orderStatusFilter) {
                          return false;
                        }
                      }

                      // Payment Status Filter (Paid, Pending, Refunded, Declined)
                      if (orderPaymentStatusFilter !== 'all') {
                        if (orderPaymentStatusFilter === 'pending') {
                          if (o.paymentStatus !== 'pending' && o.paymentStatus !== 'declined' && o.orderStatus !== 'Awaiting Payment' && o.orderStatus !== 'Pending Payment') return false;
                        } else if (o.paymentStatus !== orderPaymentStatusFilter) {
                          return false;
                        }
                      }

                      // Country Filter
                      if (orderCountryFilter !== 'all' && o.deliveryAddress.country !== orderCountryFilter) return false;

                      // Search Query
                      if (orderSearch) {
                        const term = orderSearch.toLowerCase();
                        return (
                          o.orderNumber.toLowerCase().includes(term) ||
                          o.deliveryAddress.fullName.toLowerCase().includes(term) ||
                          o.deliveryAddress.email.toLowerCase().includes(term) ||
                          o.deliveryAddress.phone.toLowerCase().includes(term) ||
                          o.deliveryAddress.city.toLowerCase().includes(term) ||
                          o.deliveryAddress.country.toLowerCase().includes(term)
                        );
                      }
                      return true;
                    })
                    .map(o => (
                      <tr key={o.id} className={`hover:bg-stone-50 transition-colors ${o.isArchived ? 'opacity-75 bg-stone-50/50' : ''}`}>
                        <td className="py-3">
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono font-bold text-stone-950 block">{o.orderNumber}</span>
                            {o.isArchived && (
                              <span className="px-1.5 py-0.2 rounded text-[9px] bg-stone-200 text-stone-600 font-bold uppercase">Archived</span>
                            )}
                          </div>
                          <span className="text-[10px] text-stone-400">{new Date(o.createdAt).toLocaleDateString()}</span>
                        </td>
                        <td className="py-3">
                          <span className="font-bold text-stone-900 block">{o.deliveryAddress.fullName}</span>
                          <span className="text-[10px] text-stone-500 font-mono block">{o.deliveryAddress.email}</span>
                          <span className="text-[10px] text-stone-400 font-mono">{o.deliveryAddress.phone}</span>
                        </td>
                        <td className="py-3 max-w-xs text-stone-700">
                          <span className="line-clamp-2">
                            {o.deliveryAddress.houseNumber} {o.deliveryAddress.streetAddress}, {o.deliveryAddress.city}, {o.deliveryAddress.state} {o.deliveryAddress.postalCode}, {o.deliveryAddress.country}
                          </span>
                        </td>
                        <td className="py-3">
                          <div className="flex items-center gap-1.5">
                            {o.items.slice(0, 2).map((it, idx) => (
                              <img
                                key={idx}
                                src={it.productImage || '/src/assets/images/novora_cat_fashion_1792421786979.jpg'}
                                alt={it.productName}
                                className="w-7 h-9 object-cover rounded bg-stone-100 border border-stone-200"
                                referrerPolicy="no-referrer"
                              />
                            ))}
                            <span className="text-stone-600 font-medium">
                              {o.items.length} item{o.items.length > 1 ? 's' : ''}
                            </span>
                          </div>
                        </td>
                        <td className="py-3">
                          <span className="font-bold text-stone-950 tabular-nums block font-mono">
                            {o.currency === 'PKR' ? `Rs ${Math.round(o.total * 278.5).toLocaleString()}` : `$${o.total.toFixed(2)}`}
                          </span>
                          <span className="text-[10px] text-stone-400">
                            {o.currency || 'USD'}
                          </span>
                        </td>
                        <td className="py-3">
                          <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                            o.paymentStatus === 'paid'
                              ? 'bg-emerald-100 text-emerald-800'
                              : o.paymentStatus === 'declined'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}>
                            {o.paymentStatus}
                          </span>
                          <span className="text-[10px] text-stone-500 block truncate max-w-[120px] mt-0.5">
                            {o.paymentMethod.replace(/\(.*\)/, '').trim()}
                          </span>
                        </td>
                        <td className="py-3">
                          <select
                            value={o.orderStatus}
                            onChange={e => handleUpdateOrderStatus(o.id, e.target.value)}
                            className="bg-stone-100 border border-stone-300 rounded px-2 py-1 text-[11px] font-semibold text-stone-800 focus:outline-none focus:border-purple-600 cursor-pointer"
                          >
                            <option value="Awaiting Payment">Awaiting Payment</option>
                            <option value="Paid">Paid</option>
                            <option value="Processing">Processing</option>
                            <option value="Sent to Supplier">Sent to Supplier</option>
                            <option value="Shipped">Shipped</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Cancelled">Cancelled</option>
                            <option value="Refunded">Refunded</option>
                          </select>
                        </td>
                        <td className="py-3">
                          {o.trackingNumber ? (
                            <div>
                              <span className="font-mono text-[11px] text-purple-700 font-bold block">{o.trackingNumber}</span>
                              <span className="text-[10px] text-stone-400">{o.carrier || 'Standard Courier'}</span>
                            </div>
                          ) : (
                            <span className="text-stone-400 text-[11px] italic">Unassigned</span>
                          )}
                        </td>
                        <td className="py-3 text-right">
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              onClick={() => setInspectingOrder(o)}
                              className="px-2.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-700 text-xs font-semibold rounded transition-colors cursor-pointer"
                              title="Inspect Full Order"
                            >
                              Inspect
                            </button>
                            <button
                              onClick={() => handleToggleArchiveOrder(o)}
                              disabled={isArchivingOrder === o.id}
                              className={`p-1 rounded transition-colors cursor-pointer ${
                                o.isArchived
                                  ? 'text-purple-700 hover:bg-purple-100'
                                  : 'text-stone-500 hover:text-stone-900 hover:bg-stone-100'
                              }`}
                              title={o.isArchived ? 'Restore Order to Active Queue' : 'Archive Order'}
                            >
                              <Folder className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handlePrintPackingSlip(o)}
                              className="p-1 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded transition-colors cursor-pointer"
                              title="Print Packing Slip"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleCopyAddress(o)}
                              className="p-1 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded transition-colors cursor-pointer"
                              title="Copy Courier Delivery Address"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                            {/* Working Delete Order Button (Prompt 8 & 1: Delete Completed Orders with confirmation) */}
                            <button
                              onClick={() => setOrderToDelete(o)}
                              className="p-1 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer"
                              title="Delete Order (Requires Confirmation)"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>

            {/* Delete Order Confirmation Modal (Prompt 8: "Are you sure you want to delete this order?") */}
            {orderToDelete && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-xs">
                <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-5 shadow-2xl animate-in fade-in zoom-in-95 duration-150">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                      <Trash2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-stone-950 font-display">
                        Delete Order Confirmation
                      </h3>
                      <p className="text-xs text-stone-500">
                        Permanent removal from active orders and database
                      </p>
                    </div>
                  </div>

                  <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 text-xs space-y-2">
                    <p className="font-semibold text-stone-900">
                      Are you sure you want to delete this order?
                    </p>
                    <div className="text-[11px] text-stone-600 space-y-1 pt-1 font-mono">
                      <div>• Order Reference: <strong>{orderToDelete.orderNumber}</strong></div>
                      <div>• Customer: <strong>{orderToDelete.customer.fullName}</strong> ({orderToDelete.customer.email})</div>
                      <div>• Amount: <strong>${orderToDelete.total.toFixed(2)} {orderToDelete.currency}</strong></div>
                      <div>• Placed: <strong>{new Date(orderToDelete.createdAt).toLocaleString()}</strong></div>
                      <div>• Status: <strong>{orderToDelete.orderStatus}</strong> (Payment: {orderToDelete.paymentStatus})</div>
                    </div>
                  </div>

                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-800 flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <span>
                      Administrative action will be recorded in <code>admin_audit_log.json</code>. Payment provider transactions and customer account data will not be erased.
                    </span>
                  </div>

                  <div className="flex items-center justify-end gap-3 pt-2">
                    <button
                      type="button"
                      disabled={isDeletingOrder}
                      onClick={() => setOrderToDelete(null)}
                      className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      disabled={isDeletingOrder}
                      onClick={handleConfirmDeleteOrder}
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
                    >
                      {isDeletingOrder ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Deleting…</span>
                        </>
                      ) : (
                        <>
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Yes, Delete Order</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Detailed Order Inspection Modal */}
            {inspectingOrder && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-xs">
                <div className="bg-white rounded-2xl max-w-3xl w-full p-6 sm:p-8 space-y-6 shadow-2xl max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-150">
                  
                  {/* Modal Header */}
                  <div className="flex items-center justify-between pb-4 border-b border-stone-200">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-purple-700 uppercase font-mono bg-purple-100 px-2 py-0.5 rounded">
                          {inspectingOrder.orderNumber}
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          inspectingOrder.paymentStatus === 'paid'
                            ? 'bg-emerald-100 text-emerald-800'
                            : inspectingOrder.paymentStatus === 'declined'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          Payment: {inspectingOrder.paymentStatus}
                        </span>
                      </div>
                      <h3 className="text-base font-bold text-stone-950 font-display mt-1">
                        Full Order & Delivery Address Inspection
                      </h3>
                      <p className="text-xs text-stone-500">
                        Placed on {new Date(inspectingOrder.createdAt).toLocaleString()} · Billing Currency: {inspectingOrder.currency || 'USD'}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handlePrintPackingSlip(inspectingOrder)}
                        className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Print Slip</span>
                      </button>
                      <button
                        onClick={() => handleCopyAddress(inspectingOrder)}
                        className="px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-800 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Address</span>
                      </button>
                      <button
                        onClick={() => setInspectingOrder(null)}
                        className="p-1.5 text-stone-400 hover:text-stone-800 rounded-lg cursor-pointer"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  </div>

                  {/* 10 COMPULSORY DELIVERY FIELDS INSPECTION */}
                  <div className="p-5 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-stone-900 flex items-center gap-1.5">
                        <Truck className="w-4 h-4 text-purple-700" />
                        <span>Compulsory Delivery Address Details (10 Fields)</span>
                      </h4>
                      <button
                        onClick={() => handleCopyAddress(inspectingOrder)}
                        className="text-[11px] text-purple-700 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        <Copy className="w-3 h-3" />
                        <span>Copy for Courier Label</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-stone-700 bg-white p-4 rounded-xl border border-stone-200/70">
                      <div><strong className="text-stone-900">1. Customer Full Name:</strong> {inspectingOrder.deliveryAddress.fullName}</div>
                      <div><strong className="text-stone-900">2. Customer Email:</strong> {inspectingOrder.deliveryAddress.email}</div>
                      <div><strong className="text-stone-900">3. Contact Phone:</strong> {inspectingOrder.deliveryAddress.phone}</div>
                      <div><strong className="text-stone-900">4. Country:</strong> {inspectingOrder.deliveryAddress.country}</div>
                      <div><strong className="text-stone-900">5. State / Province:</strong> {inspectingOrder.deliveryAddress.state}</div>
                      <div><strong className="text-stone-900">6. City:</strong> {inspectingOrder.deliveryAddress.city}</div>
                      <div><strong className="text-stone-900">7. Street Address:</strong> {inspectingOrder.deliveryAddress.streetAddress}</div>
                      <div><strong className="text-stone-900">8. House / Building Number:</strong> {inspectingOrder.deliveryAddress.houseNumber}</div>
                      <div><strong className="text-stone-900">9. Apartment / Suite:</strong> {inspectingOrder.deliveryAddress.apartmentDetails || 'N/A'}</div>
                      <div><strong className="text-stone-900">10. Postal / ZIP Code:</strong> {inspectingOrder.deliveryAddress.postalCode}</div>
                    </div>

                    {inspectingOrder.notes && (
                      <div className="pt-2 text-xs text-stone-700">
                        <strong className="text-stone-900">Delivery Instructions / Notes:</strong> {inspectingOrder.notes}
                      </div>
                    )}
                  </div>

                  {/* Payment Details Box */}
                  <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-200/80 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-emerald-950 flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 text-emerald-600" />
                        <span>Verified Payment Transaction</span>
                      </span>
                      <span className="font-mono text-[11px] text-emerald-800">
                        Status: <strong>{inspectingOrder.paymentStatus.toUpperCase()}</strong>
                      </span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] text-stone-700 pt-1">
                      <div><strong>Method:</strong> {inspectingOrder.paymentMethod}</div>
                      <div><strong>Provider:</strong> {inspectingOrder.paymentDetails?.provider || 'Stripe / Safepay'}</div>
                      <div><strong>Gateway Transaction ID:</strong> <code className="font-mono">{inspectingOrder.paymentDetails?.transactionId || 'TXN-DIRECT'}</code></div>
                      <div><strong>Currency:</strong> {inspectingOrder.currency || 'USD'}</div>
                      <div><strong>Paid Timestamp:</strong> {inspectingOrder.paymentDetails?.paidAt ? new Date(inspectingOrder.paymentDetails.paidAt).toLocaleTimeString() : 'N/A'}</div>
                      <div><strong>Masked Card:</strong> {inspectingOrder.paymentDetails?.maskedCardNumber || 'N/A'}</div>
                    </div>

                    {/* Merchant Card Settlement Destination (Requirement: when someone buys anything its payment comes in this bank card) */}
                    <div className="mt-2 pt-2 border-t border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-emerald-100/70 p-2.5 rounded-xl text-emerald-950">
                      <div className="flex items-center gap-2">
                        <CreditCard className="w-4 h-4 text-emerald-700 shrink-0" />
                        <div>
                          <p className="font-bold text-[11px] text-emerald-900">
                            Merchant Card Settlement:
                          </p>
                          <p className="font-mono text-xs font-bold text-emerald-950">
                            {inspectingOrder.settledToMerchantCard || (paymentGateway?.merchantCard ? `Credited to Default Admin Card •••• ${paymentGateway.merchantCard.last4} (${paymentGateway.merchantCard.brand} · Meezan Bank Ltd 1Link)` : 'Credited to Admin Card •••• 9922 (Meezan Bank Ltd 1Link)')}
                          </p>
                        </div>
                      </div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-200 text-emerald-900 self-start sm:self-center border border-emerald-300">
                        Funds Credited ✓
                      </span>
                    </div>
                  </div>

                  {/* Purchased Items Table */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-stone-900">
                      Products Purchased ({inspectingOrder.items.length})
                    </h4>
                    <div className="divide-y divide-stone-100 border border-stone-200 rounded-xl overflow-hidden">
                      {inspectingOrder.items.map((it, idx) => (
                        <div key={idx} className="p-3 flex items-center justify-between text-xs bg-white hover:bg-stone-50">
                          <div className="flex items-center gap-3">
                            <img
                              src={it.productImage || '/src/assets/images/novora_cat_fashion_1792421786979.jpg'}
                              alt={it.productName}
                              className="w-12 h-14 object-cover rounded-lg bg-stone-100 border border-stone-200 shrink-0"
                              referrerPolicy="no-referrer"
                            />
                            <div>
                              <p className="font-bold text-stone-900">{it.productName}</p>
                              <p className="text-[11px] text-stone-500">
                                Qty: <strong>{it.quantity}</strong> {it.selectedVariant?.size && `· Size: ${it.selectedVariant.size}`} {it.selectedVariant?.color && `· Color: ${it.selectedVariant.color}`}
                              </p>
                              <p className="text-[10px] text-stone-400 font-mono">Unit Price: ${it.price.toFixed(2)}</p>
                            </div>
                          </div>
                          <span className="font-bold tabular-nums font-mono text-stone-950">${(it.price * it.quantity).toFixed(2)}</span>
                        </div>
                      ))}
                    </div>

                    {/* Financial Summary */}
                    <div className="pt-3 border-t border-stone-200 text-xs space-y-1 text-right">
                      <p>Subtotal: <strong className="font-mono">${inspectingOrder.subtotal.toFixed(2)}</strong></p>
                      {inspectingOrder.discount > 0 && (
                        <p className="text-emerald-700">Discount ({inspectingOrder.couponCode || 'PROMO'}): -${inspectingOrder.discount.toFixed(2)}</p>
                      )}
                      <p>Shipping Charges: <strong className="font-mono">${inspectingOrder.shippingFee.toFixed(2)}</strong></p>
                      <p>Applicable Taxes (5%): <strong className="font-mono">${(inspectingOrder.taxAmount || 0).toFixed(2)}</strong></p>
                      <p className="text-sm font-black text-stone-950 pt-1 border-t border-stone-100">
                        Final Total Paid: ${inspectingOrder.total.toFixed(2)} {inspectingOrder.currency || 'USD'}
                      </p>
                    </div>
                  </div>

                  {/* Status & Tracking Controls */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    {/* Status updater */}
                    <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-2 text-xs">
                      <label className="block font-bold text-stone-900">Update Order Fulfilment Status</label>
                      <select
                        value={inspectingOrder.orderStatus}
                        onChange={e => handleUpdateOrderStatus(inspectingOrder.id, e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg text-xs font-semibold cursor-pointer"
                      >
                        <option value="Awaiting Payment">Awaiting Payment</option>
                        <option value="Paid">Paid</option>
                        <option value="Processing">Processing</option>
                        <option value="Sent to Supplier">Sent to Supplier</option>
                        <option value="Shipped">Shipped</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Cancelled">Cancelled</option>
                        <option value="Refunded">Refunded</option>
                      </select>
                    </div>

                    {/* Carrier & Tracking */}
                    <div className="p-4 bg-purple-50/60 rounded-xl border border-purple-200 space-y-2 text-xs">
                      <label className="block font-bold text-purple-950">Carrier & Tracking Reference</label>
                      <div className="space-y-2">
                        <input
                          type="text"
                          defaultValue={inspectingOrder.carrier || ''}
                          onChange={e => setOrderCarrierInput(e.target.value)}
                          placeholder="Courier (e.g. DHL Express, TCS, Leopard, FedEx)"
                          className="w-full px-3 py-1.5 bg-white border border-purple-200 rounded-lg text-xs"
                        />
                        <div className="flex gap-2">
                          <input
                            type="text"
                            defaultValue={inspectingOrder.trackingNumber || ''}
                            onChange={e => setOrderTrackingInput(e.target.value)}
                            placeholder="Tracking # (e.g. TRK-NV-984021)"
                            className="flex-1 px-3 py-1.5 bg-white border border-purple-200 rounded-lg text-xs font-mono"
                          />
                          <button
                            onClick={() => handleUpdateOrderStatus(inspectingOrder.id, inspectingOrder.orderStatus)}
                            className="px-3 py-1.5 bg-purple-700 hover:bg-purple-800 text-white rounded-lg font-semibold cursor-pointer"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>



                </div>
              </div>
            )}

          </div>
        )}

        {/* =========================================================================
            7. TAB: PAYMENT SETTINGS (GATEWAYS, PAKISTAN & GLOBAL PROVIDERS, PAYOUTS)
        ========================================================================= */}
        {activeTab === 'payment-settings' && (
          <PaymentSettings onNotify={(msg, type) => showToast(msg, type === 'error' ? 'error' : 'success')} />
        )}



        {/* =========================================================================
            7. TAB: INVENTORY MANAGEMENT
        ========================================================================= */}
        {activeTab === 'inventory' && (
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-6">
            <div>
              <h2 className="text-base font-bold text-stone-950 font-display">Inventory Stock Controls</h2>
              <p className="text-xs text-stone-500">
                Adjust physical inventory levels in real-time. Products reach out-of-stock status automatically when count reaches zero.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-stone-200 text-stone-400 uppercase text-[10px]">
                    <th className="py-2.5">Product Title</th>
                    <th className="py-2.5">SKU</th>
                    <th className="py-2.5">Department</th>
                    <th className="py-2.5">Current Stock</th>
                    <th className="py-2.5">Stock Status</th>
                    <th className="py-2.5 text-right">Quick Stock Update</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {inventory.map(item => (
                    <tr key={item.id} className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 font-semibold text-stone-900">{item.name}</td>
                      <td className="py-3 font-mono text-stone-500">{item.sku}</td>
                      <td className="py-3 text-stone-600">{item.category}</td>
                      <td className="py-3 font-bold tabular-nums">
                        {item.stock} units
                      </td>
                      <td className="py-3">
                        {item.isOutOfStock ? (
                          <span className="px-2 py-0.5 text-[10px] font-bold bg-rose-100 text-rose-800 rounded">
                            Out of Stock
                          </span>
                        ) : item.isLowStock ? (
                          <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-100 text-amber-800 rounded">
                            Low Stock (≤ 5)
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 rounded">
                            Healthy Inventory
                          </span>
                        )}
                      </td>
                      <td className="py-3 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          <input
                            type="number"
                            defaultValue={item.stock}
                            id={`stock-input-${item.id}`}
                            className="w-16 px-2 py-1 text-xs border border-stone-300 rounded text-center"
                          />
                          <button
                            onClick={() => {
                              const input = document.getElementById(`stock-input-${item.id}`) as HTMLInputElement;
                              if (input) handleInlineStockUpdate(item.id, parseInt(input.value, 10));
                            }}
                            className="px-2.5 py-1 bg-stone-900 hover:bg-purple-700 text-white rounded text-xs font-semibold"
                          >
                            Save
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* =========================================================================
            8. TAB: CUSTOMER SIGN-IN & ADDRESS STORAGE SYSTEM (C:\\Novora_Project\\Data\\)
        ========================================================================= */}
        {activeTab === 'customers' && (
          <div className="space-y-8">
            
            {/* Top Flowchart Hero Banner (matching user's uploaded diagram Novora_Customer_Sign-In_System_Flowchart_de2464bf.png) */}
            <div className="bg-gradient-to-r from-stone-900 via-purple-950 to-stone-900 text-white rounded-3xl p-6 sm:p-8 border border-purple-900/60 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
              
              <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
                <div className="space-y-3 max-w-2xl">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest bg-purple-500/20 text-purple-300 border border-purple-500/40">
                      School Project Architecture
                    </span>
                    <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span>Live Sync Active: 137.184.23.176</span>
                    </span>
                  </div>

                  <h1 className="text-xl sm:text-2xl lg:text-3xl font-extrabold tracking-tight font-display text-white">
                    NOVORA – Customer Sign In &amp; Address Storage System
                  </h1>
                  <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
                    Store User Details in My PC Folder via Google Stitch · Direct synchronization of Customer Sign-Up, Sign-In, 10-Field Delivery Addresses, and Hashed Credentials into local PC files.
                  </p>

                  {/* Badges for Path & Server */}
                  <div className="flex flex-wrap items-center gap-3 pt-1 text-xs">
                    <div className="px-3 py-1.5 bg-stone-950/80 rounded-xl border border-stone-800 font-mono text-purple-300 flex items-center gap-2">
                      <HardDrive className="w-3.5 h-3.5 text-purple-400" />
                      <span>Local Folder: <strong>C:\Novora_Project\Data\</strong></span>
                    </div>
                    <div className="px-3 py-1.5 bg-stone-950/80 rounded-xl border border-stone-800 font-mono text-emerald-300 flex items-center gap-2">
                      <Server className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Server IP: <strong>137.184.23.176</strong></span>
                    </div>
                  </div>
                </div>

                {/* Flowchart Visual Thumbnail & Lightbox Launcher */}
                <div className="shrink-0 flex flex-col sm:flex-row lg:flex-col items-center gap-3 w-full lg:w-auto">
                  <div
                    onClick={() => setIsCustomerFlowModalOpen(true)}
                    className="group relative cursor-pointer rounded-2xl overflow-hidden border-2 border-purple-500/50 shadow-lg hover:border-purple-400 transition-all bg-stone-950 p-1.5 max-w-xs"
                    title="Click to expand architecture diagram in full screen"
                  >
                    <img
                      src="/assets/aistudio/Novora_Customer_Sign-In_System_Flowchart_de2464bf.png"
                      alt="Novora Customer Sign-In & Address Storage System Flowchart"
                      className="w-full h-32 sm:h-28 object-contain rounded-xl bg-stone-900 group-hover:scale-102 transition-transform"
                    />
                    <div className="absolute inset-0 bg-stone-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-xl">
                      <span className="px-3 py-1.5 bg-purple-600 text-white rounded-lg text-xs font-bold shadow-lg flex items-center gap-1.5">
                        <Maximize2 className="w-3.5 h-3.5" />
                        <span>Enlarge Flowchart</span>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 w-full sm:w-auto justify-center">
                    <button
                      type="button"
                      onClick={() => setIsCustomerFlowModalOpen(true)}
                      className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl shadow-sm transition-all cursor-pointer flex items-center gap-1.5"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View Architecture Diagram</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleRefreshFolderStorage}
                      className="p-2 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-xl transition-colors cursor-pointer"
                      title="Refresh Local Files"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* PC Folder Storage Hub (C:\Novora_Project\Data\ on 137.184.23.176) */}
            <div className="bg-white p-6 sm:p-7 rounded-3xl border border-stone-200 shadow-xs space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Folder className="w-5 h-5 text-amber-500" />
                    <h2 className="text-base sm:text-lg font-bold text-stone-950 font-display">
                      Local PC Folder Storage Hub: <span className="font-mono text-purple-700">C:\Novora_Project\Data\</span>
                    </h2>
                  </div>
                  <p className="text-xs text-stone-500">
                    Real-time file generation on host server <code className="bg-stone-100 text-purple-700 px-1.5 py-0.5 rounded font-mono font-bold">137.184.23.176</code>. These files store user details, addresses, and orders.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href="/api/admin/folder-storage/download/users.json"
                    download="users.json"
                    className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-xl border border-stone-300 transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-purple-700" />
                    <span>Download users.json</span>
                  </a>
                  <a
                    href="/api/admin/folder-storage/download/addresses.json"
                    download="addresses.json"
                    className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-xl border border-stone-300 transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-purple-700" />
                    <span>Download addresses.json</span>
                  </a>
                </div>
              </div>

              {/* 4 Storage File Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                
                {/* 1. users.json */}
                <div className="p-4 sm:p-5 bg-stone-50 rounded-2xl border border-stone-200 hover:border-purple-300 transition-all space-y-3 relative group">
                  <div className="flex items-center justify-between">
                    <span className="p-2 bg-purple-100 text-purple-700 rounded-xl">
                      <Users className="w-5 h-5" />
                    </span>
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-purple-50 text-purple-800 border border-purple-200">
                      JSON
                    </span>
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-stone-900">users.json</h3>
                    <p className="text-[11px] text-stone-500 mt-0.5 line-clamp-2">
                      User Personal Details: Full Name, Email, Hashed Password, Contact Phone, Created/Updated dates.
                    </p>
                  </div>
                  <div className="pt-2 border-t border-stone-200/80 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] text-stone-400 block">Records</span>
                      <strong className="text-stone-900 font-bold">{customers.length} Accounts</strong>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-stone-400 block">File Size</span>
                      <strong className="text-stone-900 font-bold">{folderStorage?.files.find(f => f.name === 'users.json')?.sizeFormatted || '1.8 KB'}</strong>
                    </div>
                  </div>
                  <a
                    href="/api/admin/folder-storage/download/users.json"
                    download="users.json"
                    className="w-full mt-2 py-2 bg-stone-900 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download users.json</span>
                  </a>
                </div>

                {/* 2. addresses.json */}
                <div className="p-4 sm:p-5 bg-stone-50 rounded-2xl border border-stone-200 hover:border-purple-300 transition-all space-y-3 relative group">
                  <div className="flex items-center justify-between">
                    <span className="p-2 bg-amber-100 text-amber-800 rounded-xl">
                      <MapPin className="w-5 h-5" />
                    </span>
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200">
                      JSON
                    </span>
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-stone-900">addresses.json</h3>
                    <p className="text-[11px] text-stone-500 mt-0.5 line-clamp-2">
                      User Addresses: Country, State, City, Street Address, House/Building #, Postal Code, Phone.
                    </p>
                  </div>
                  <div className="pt-2 border-t border-stone-200/80 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] text-stone-400 block">Saved Addresses</span>
                      <strong className="text-stone-900 font-bold">
                        {customers.reduce((acc, c) => acc + (c.savedAddresses ? c.savedAddresses.length : 0), 0)} Locations
                      </strong>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-stone-400 block">File Size</span>
                      <strong className="text-stone-900 font-bold">{folderStorage?.files.find(f => f.name === 'addresses.json')?.sizeFormatted || '2.4 KB'}</strong>
                    </div>
                  </div>
                  <a
                    href="/api/admin/folder-storage/download/addresses.json"
                    download="addresses.json"
                    className="w-full mt-2 py-2 bg-stone-900 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download addresses.json</span>
                  </a>
                </div>

                {/* 3. orders.json */}
                <div className="p-4 sm:p-5 bg-stone-50 rounded-2xl border border-stone-200 hover:border-purple-300 transition-all space-y-3 relative group">
                  <div className="flex items-center justify-between">
                    <span className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                      <ShoppingBag className="w-5 h-5" />
                    </span>
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                      JSON
                    </span>
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-stone-900">orders.json</h3>
                    <p className="text-[11px] text-stone-500 mt-0.5 line-clamp-2">
                      User Orders: Items, Total, Destination Address, Settlement Recipient Card/Bank Account.
                    </p>
                  </div>
                  <div className="pt-2 border-t border-stone-200/80 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] text-stone-400 block">Orders</span>
                      <strong className="text-stone-900 font-bold">{orders.length} Orders</strong>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-stone-400 block">File Size</span>
                      <strong className="text-stone-900 font-bold">{folderStorage?.files.find(f => f.name === 'orders.json')?.sizeFormatted || '3.1 KB'}</strong>
                    </div>
                  </div>
                  <a
                    href="/api/admin/folder-storage/download/orders.json"
                    download="orders.json"
                    className="w-full mt-2 py-2 bg-stone-900 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download orders.json</span>
                  </a>
                </div>

                {/* 4. database.db */}
                <div className="p-4 sm:p-5 bg-stone-50 rounded-2xl border border-stone-200 hover:border-purple-300 transition-all space-y-3 relative group">
                  <div className="flex items-center justify-between">
                    <span className="p-2 bg-blue-100 text-blue-800 rounded-xl">
                      <Database className="w-5 h-5" />
                    </span>
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200">
                      SQLITE / DB
                    </span>
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-stone-900">database.db</h3>
                    <p className="text-[11px] text-stone-500 mt-0.5 line-clamp-2">
                      Unified Database Snapshot: Complete collections snapshot for PC database management.
                    </p>
                  </div>
                  <div className="pt-2 border-t border-stone-200/80 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] text-stone-400 block">Collections</span>
                      <strong className="text-stone-900 font-bold">All Entities</strong>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-stone-400 block">File Size</span>
                      <strong className="text-stone-900 font-bold">{folderStorage?.files.find(f => f.name === 'database.db')?.sizeFormatted || '35.4 KB'}</strong>
                    </div>
                  </div>
                  <a
                    href="/api/admin/folder-storage/download/database.db"
                    download="database.db"
                    className="w-full mt-2 py-2 bg-stone-900 hover:bg-purple-700 text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download database.db</span>
                  </a>
                </div>

              </div>
            </div>

            {/* Google Drive Live Cloud Folder Hub (Target Folder: 1skrD22j61z2Oqv8G3iFwbtaoghmcR9at) */}
            <div className="bg-gradient-to-br from-white via-blue-50/20 to-white p-6 sm:p-7 rounded-3xl border border-blue-200/80 shadow-xs space-y-6">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-blue-100">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <div className="p-1.5 bg-blue-100 text-blue-700 rounded-lg">
                      <svg className="w-5 h-5" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                      </svg>
                    </div>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-100 text-blue-800 border border-blue-200">
                      Google Drive Cloud Sync
                    </span>
                    <span className="text-[10px] font-mono text-stone-500">
                      Folder ID: <strong className="text-stone-900">{TARGET_DRIVE_FOLDER_ID}</strong>
                    </span>
                  </div>
                  <h2 className="text-base sm:text-lg font-bold text-stone-950 font-display">
                    Google Drive Live Folder: Sign-In Records &amp; Customer Addresses
                  </h2>
                  <p className="text-xs text-stone-600">
                    Saves customer account credentials and full 10-field delivery address details directly into your Google Drive folder:
                    {' '}<a
                      href={TARGET_DRIVE_FOLDER_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-mono text-blue-700 hover:underline inline-flex items-center gap-1 font-semibold"
                    >
                      <span>drive.google.com/.../{TARGET_DRIVE_FOLDER_ID}</span>
                      <ExternalLink className="w-3 h-3 inline" />
                    </a>
                  </p>
                </div>

                {/* Google Auth & Action Controls */}
                <div className="flex items-center gap-2 flex-wrap">
                  {googleDriveUser ? (
                    <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-blue-200 shadow-xs">
                      {googleDriveUser.photoURL ? (
                        <img
                          src={googleDriveUser.photoURL}
                          alt="Google user"
                          className="w-6 h-6 rounded-full"
                        />
                      ) : (
                        <div className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center">
                          {googleDriveUser.displayName?.charAt(0) || 'G'}
                        </div>
                      )}
                      <div className="text-left text-xs">
                        <span className="font-bold text-stone-900 block truncate max-w-[120px]">
                          {googleDriveUser.displayName || 'Connected'}
                        </span>
                        <span className="text-[10px] text-stone-500 block truncate max-w-[120px]">
                          {googleDriveUser.email}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={handleDisconnectGoogleDrive}
                        className="text-[10px] text-stone-400 hover:text-stone-700 underline ml-1 cursor-pointer"
                      >
                        Disconnect
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={handleConnectGoogleDrive}
                      disabled={isConnectingDrive}
                      className="px-3.5 py-2 bg-white hover:bg-stone-50 text-stone-800 text-xs font-semibold rounded-xl border border-stone-300 shadow-xs transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-60"
                    >
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                      </svg>
                      <span>{isConnectingDrive ? 'Connecting...' : 'Connect Google Drive'}</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={handleOpenSyncModal}
                    disabled={isSyncingDrive}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isSyncingDrive ? 'animate-spin' : ''}`} />
                    <span>Sync to Google Drive Folder</span>
                  </button>

                  <a
                    href={TARGET_DRIVE_FOLDER_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3.5 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <span>Open Folder in Drive</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* 6 Target Google Drive Files across Customers, Addresses, Backups, Logs */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                
                {/* 1. Customers/customers_export.json */}
                <div className="p-5 bg-white rounded-2xl border border-blue-200/90 shadow-xs space-y-3 relative hover:border-blue-400 transition-all">
                  <div className="flex items-center justify-between">
                    <span className="p-2 bg-blue-50 text-blue-700 rounded-xl border border-blue-100">
                      <Users className="w-5 h-5" />
                    </span>
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-blue-100 text-blue-900 border border-blue-200">
                      CUSTOMERS FOLDER
                    </span>
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-stone-950">
                      customers_export.json
                    </h3>
                    <p className="text-[11px] text-stone-600 mt-1">
                      Sanitized customer records: ID, Full Name, Email, Registration Date, Verification Status, Account Status. Zero passwords or credentials.
                    </p>
                  </div>
                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] text-stone-400 block">Total Customers</span>
                      <strong className="text-stone-900 font-bold">{customers.length} Accounts</strong>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-stone-400 block">Folder Target</span>
                      <span className="text-blue-700 font-bold font-mono text-[11px]">NOVORA_Project/Customers</span>
                    </div>
                  </div>
                  <div className="pt-1">
                    <a
                      href={TARGET_DRIVE_FOLDER_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer border border-blue-200"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-blue-700" />
                      <span>View in Google Drive</span>
                    </a>
                  </div>
                </div>

                {/* 2. Customers/registration_log.json */}
                <div className="p-5 bg-white rounded-2xl border border-purple-200/90 shadow-xs space-y-3 relative hover:border-purple-400 transition-all">
                  <div className="flex items-center justify-between">
                    <span className="p-2 bg-purple-50 text-purple-700 rounded-xl border border-purple-100">
                      <Clock className="w-5 h-5" />
                    </span>
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-purple-100 text-purple-900 border border-purple-200">
                      CUSTOMERS FOLDER
                    </span>
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-stone-950">
                      registration_log.json
                    </h3>
                    <p className="text-[11px] text-stone-600 mt-1">
                      Registration event audit stream: Timestamp, Customer ID, Email, IP Address, Verification Status, and Account Lifecycle.
                    </p>
                  </div>
                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] text-stone-400 block">Status</span>
                      <strong className="text-stone-900 font-bold">Auto-Logged</strong>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-stone-400 block">Folder Target</span>
                      <span className="text-purple-700 font-bold font-mono text-[11px]">NOVORA_Project/Customers</span>
                    </div>
                  </div>
                  <div className="pt-1">
                    <a
                      href={TARGET_DRIVE_FOLDER_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 bg-purple-50 hover:bg-purple-100 text-purple-800 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer border border-purple-200"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-purple-700" />
                      <span>View in Google Drive</span>
                    </a>
                  </div>
                </div>

                {/* 3. Addresses/addresses_export.json */}
                <div className="p-5 bg-white rounded-2xl border border-amber-200/90 shadow-xs space-y-3 relative hover:border-amber-400 transition-all">
                  <div className="flex items-center justify-between">
                    <span className="p-2 bg-amber-50 text-amber-700 rounded-xl border border-amber-100">
                      <MapPin className="w-5 h-5" />
                    </span>
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-200">
                      ADDRESSES FOLDER
                    </span>
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-stone-950">
                      addresses_export.json
                    </h3>
                    <p className="text-[11px] text-stone-600 mt-1">
                      Complete delivery address records linked to customers: Street Address, House/Building #, City, Province/State, Country, Postal Code, Phone.
                    </p>
                  </div>
                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] text-stone-400 block">Saved Addresses</span>
                      <strong className="text-stone-900 font-bold">
                        {customers.reduce((acc, c) => acc + (c.savedAddresses?.length || 0), 0)} Locations
                      </strong>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-stone-400 block">Folder Target</span>
                      <span className="text-amber-700 font-bold font-mono text-[11px]">NOVORA_Project/Addresses</span>
                    </div>
                  </div>
                  <div className="pt-1">
                    <a
                      href={TARGET_DRIVE_FOLDER_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 bg-amber-50 hover:bg-amber-100 text-amber-900 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer border border-amber-200"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-amber-700" />
                      <span>View in Google Drive</span>
                    </a>
                  </div>
                </div>

                {/* 4. Backups/customer_backup.json */}
                <div className="p-5 bg-white rounded-2xl border border-emerald-200/90 shadow-xs space-y-3 relative hover:border-emerald-400 transition-all">
                  <div className="flex items-center justify-between">
                    <span className="p-2 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-100">
                      <Shield className="w-5 h-5" />
                    </span>
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-emerald-100 text-emerald-900 border border-emerald-200">
                      BACKUPS FOLDER
                    </span>
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-stone-950">
                      customer_backup.json
                    </h3>
                    <p className="text-[11px] text-stone-600 mt-1">
                      Comprehensive disaster-recovery snapshot of customers and delivery addresses. Live DB is authoritative source of truth.
                    </p>
                  </div>
                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] text-stone-400 block">Snapshot Type</span>
                      <strong className="text-stone-900 font-bold">DR Snapshot</strong>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-stone-400 block">Folder Target</span>
                      <span className="text-emerald-700 font-bold font-mono text-[11px]">NOVORA_Project/Backups</span>
                    </div>
                  </div>
                  <div className="pt-1">
                    <a
                      href={TARGET_DRIVE_FOLDER_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer border border-emerald-200"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-emerald-700" />
                      <span>View in Google Drive</span>
                    </a>
                  </div>
                </div>

                {/* 5. Backups/backup_status.json */}
                <div className="p-5 bg-white rounded-2xl border border-indigo-200/90 shadow-xs space-y-3 relative hover:border-indigo-400 transition-all">
                  <div className="flex items-center justify-between">
                    <span className="p-2 bg-indigo-50 text-indigo-700 rounded-xl border border-indigo-100">
                      <CheckCircle2 className="w-5 h-5" />
                    </span>
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-indigo-100 text-indigo-900 border border-indigo-200">
                      BACKUPS FOLDER
                    </span>
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-stone-950">
                      backup_status.json
                    </h3>
                    <p className="text-[11px] text-stone-600 mt-1">
                      Audit and integrity health certificate: Verified zero plaintext passwords, zero hashes in Drive, zero OTP codes in Drive.
                    </p>
                  </div>
                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] text-stone-400 block">Integrity</span>
                      <strong className="text-emerald-700 font-bold">Healthy ✓</strong>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-stone-400 block">Folder Target</span>
                      <span className="text-indigo-700 font-bold font-mono text-[11px]">NOVORA_Project/Backups</span>
                    </div>
                  </div>
                  <div className="pt-1">
                    <a
                      href={TARGET_DRIVE_FOLDER_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-900 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer border border-indigo-200"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-indigo-700" />
                      <span>View in Google Drive</span>
                    </a>
                  </div>
                </div>

                {/* 6. Logs/account_activity_log.json */}
                <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-3 relative hover:border-purple-400 transition-all">
                  <div className="flex items-center justify-between">
                    <span className="p-2 bg-stone-100 text-stone-700 rounded-xl border border-stone-200">
                      <Lock className="w-5 h-5" />
                    </span>
                    <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-stone-100 text-stone-900 border border-stone-200">
                      LOGS FOLDER
                    </span>
                  </div>
                  <div>
                    <h3 className="font-mono font-bold text-sm text-stone-950">
                      account_activity_log.json
                    </h3>
                    <p className="text-[11px] text-stone-600 mt-1">
                      Security and account activity journal: Sign-in events, OTP verifications, address changes, password updates, with IP and status.
                    </p>
                  </div>
                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] text-stone-400 block">Log Type</span>
                      <strong className="text-stone-900 font-bold">Audit Journal</strong>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-stone-400 block">Folder Target</span>
                      <span className="text-stone-700 font-bold font-mono text-[11px]">NOVORA_Project/Logs</span>
                    </div>
                  </div>
                  <div className="pt-1">
                    <a
                      href={TARGET_DRIVE_FOLDER_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 bg-stone-100 hover:bg-stone-200 text-stone-900 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer border border-stone-300"
                    >
                      <ExternalLink className="w-3.5 h-3.5 text-stone-700" />
                      <span>View in Google Drive</span>
                    </a>
                  </div>
                </div>

              </div>

              {lastDriveSyncResult && (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center justify-between text-xs text-emerald-900">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{lastDriveSyncResult.message}</span>
                  </div>
                  <span className="font-mono text-[11px] text-emerald-700">
                    {new Date(lastDriveSyncResult.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              )}
            </div>

            {/* Registered Users & Address Management Table */}
            <div className="bg-white p-6 sm:p-7 rounded-3xl border border-stone-200 shadow-xs space-y-6">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
                <div>
                  <div className="flex items-center gap-2">
                    <UserCheck className="w-5 h-5 text-purple-700" />
                    <h2 className="text-base sm:text-lg font-bold text-stone-950 font-display">
                      Registered Customers &amp; User Directory
                    </h2>
                  </div>
                  <p className="text-xs text-stone-500 mt-0.5">
                    Live accounts stored in <code>users.json</code> and <code>addresses.json</code>. Admin Actions: Inspect, Edit, and Delete.
                  </p>
                </div>

                {/* Search Bar */}
                <div className="relative min-w-[260px]">
                  <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search by name, email, phone, city..."
                    value={customerSearch}
                    onChange={e => setCustomerSearch(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs focus:outline-none focus:border-purple-600 focus:bg-white"
                  />
                  {customerSearch && (
                    <button
                      type="button"
                      onClick={() => setCustomerSearch('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 text-xs"
                    >
                      ✕
                    </button>
                  )}
                </div>
              </div>

              {/* Customers Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-stone-200 text-stone-400 uppercase text-[10px] tracking-wider">
                      <th className="py-3 px-3">Customer Name</th>
                      <th className="py-3 px-3">Email Address</th>
                      <th className="py-3 px-3">Registration Date</th>
                      <th className="py-3 px-3">Verification Status</th>
                      <th className="py-3 px-3">Account Status</th>
                      <th className="py-3 px-3">Saved Addresses</th>
                      <th className="py-3 px-3">Orders &amp; Spend</th>
                      <th className="py-3 px-3 text-right">Admin Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {customers
                      .filter(c => {
                        if (!customerSearch.trim()) return true;
                        const q = customerSearch.toLowerCase();
                        const matchesName = (c.fullName || '').toLowerCase().includes(q);
                        const matchesEmail = (c.email || '').toLowerCase().includes(q);
                        const matchesPhone = (c.phone || '').toLowerCase().includes(q);
                        const matchesAddress = (c.savedAddresses || []).some((a: any) =>
                          (a.city || '').toLowerCase().includes(q) ||
                          (a.country || '').toLowerCase().includes(q) ||
                          (a.streetAddress || '').toLowerCase().includes(q)
                        );
                        return matchesName || matchesEmail || matchesPhone || matchesAddress;
                      })
                      .map(c => (
                        <tr key={c.id} className="hover:bg-stone-50/80 transition-colors">
                          <td className="py-3.5 px-3">
                            <div className="flex items-center gap-3">
                              <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-800 font-bold flex items-center justify-center shrink-0 uppercase">
                                {c.fullName ? c.fullName.charAt(0) : 'U'}
                              </div>
                              <div>
                                <p className="font-bold text-stone-900 text-xs">{c.fullName}</p>
                                <p className="font-mono text-[10px] text-stone-400">ID: {c.id}</p>
                              </div>
                            </div>
                          </td>

                          <td className="py-3.5 px-3">
                            <p className="font-mono text-stone-800 font-semibold">{c.email}</p>
                            <p className="text-[11px] text-stone-500 mt-0.5">{c.phone || 'Phone not provided'}</p>
                          </td>

                          <td className="py-3.5 px-3 text-stone-700 text-xs font-mono">
                            {c.createdAt || c.registrationDate ? new Date(c.createdAt || c.registrationDate || '').toLocaleString('en-US', {
                              dateStyle: 'medium',
                              timeStyle: 'short',
                            }) : 'Active Customer'}
                          </td>

                          <td className="py-3.5 px-3">
                            {c.isEmailVerified || c.verificationStatus === 'verified' ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                <span>Verified ✓</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                                <Clock className="w-3 h-3 text-amber-600" />
                                <span>Pending Verification</span>
                              </span>
                            )}
                          </td>

                          <td className="py-3.5 px-3">
                            <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                              (c.accountStatus === 'active' || (!c.accountStatus && c.isEmailVerified))
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                : c.accountStatus === 'suspended'
                                ? 'bg-rose-50 text-rose-800 border-rose-200'
                                : 'bg-amber-50 text-amber-800 border-amber-200'
                            }`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${
                                (c.accountStatus === 'active' || (!c.accountStatus && c.isEmailVerified))
                                  ? 'bg-emerald-500'
                                  : c.accountStatus === 'suspended'
                                  ? 'bg-rose-500'
                                  : 'bg-amber-500 animate-pulse'
                              }`} />
                              <span className="capitalize">{c.accountStatus || (c.isEmailVerified ? 'active' : 'pending_verification')}</span>
                            </span>
                          </td>

                          <td className="py-3.5 px-3">
                            {c.savedAddresses && c.savedAddresses.length > 0 ? (
                              <div className="space-y-0.5">
                                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-stone-900">
                                  <MapPin className="w-3 h-3 text-amber-600" />
                                  <span>{c.savedAddresses.length} Address{c.savedAddresses.length > 1 ? 'es' : ''}</span>
                                </span>
                                <p className="text-[10px] text-stone-500 truncate max-w-[140px]">
                                  {c.savedAddresses[0]?.city}, {c.savedAddresses[0]?.country}
                                </p>
                              </div>
                            ) : (
                              <span className="text-[11px] text-stone-400 italic">None saved yet</span>
                            )}
                          </td>

                          <td className="py-3.5 px-3">
                            <p className="font-bold text-stone-900 font-mono">${(c.totalSpent || 0).toFixed(2)}</p>
                            <p className="text-[11px] text-purple-700 font-semibold">{c.totalOrders || 0} order(s)</p>
                          </td>

                          <td className="py-3.5 px-3 text-stone-500 text-[11px]">
                            {c.createdAt ? new Date(c.createdAt).toLocaleDateString() : 'Active Patron'}
                          </td>

                          <td className="py-3.5 px-3 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() => setSelectedCustomerForDetails(c)}
                                className="px-2.5 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-800 rounded-lg text-xs font-bold transition-colors cursor-pointer border border-purple-200 inline-flex items-center gap-1"
                                title="Inspect Complete User & Address Details"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                <span>Inspect</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => handleOpenEditUser(c)}
                                className="p-1.5 text-stone-600 hover:text-purple-700 hover:bg-purple-50 rounded-lg transition-colors cursor-pointer"
                                title="Edit User Details (Admin Action)"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>

                              <button
                                type="button"
                                onClick={() => setUserToDelete(c)}
                                className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                title="Delete User (Admin Action)"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}

                    {customers.length === 0 && (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-stone-400 italic">
                          No customer accounts found in local storage. New accounts will automatically register upon customer Sign-Up or Checkout.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Newsletter Subscribers & Mailing List Management Card */}
            <div className="bg-white p-6 sm:p-7 rounded-3xl border border-stone-200 shadow-xs space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-100">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 bg-purple-100 text-purple-700 rounded-lg">
                      <Mail className="w-4 h-4" />
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-purple-700">
                      Marketing & Audience
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-stone-950 font-display">
                    Newsletter Subscribers &amp; Mailing List
                  </h3>
                  <p className="text-xs text-stone-500">
                    Registered customer emails from the storefront footer newsletter subscription form.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-purple-100 text-purple-800 border border-purple-200">
                    {newsletterSubscribers.length} Subscribers
                  </span>
                  <a
                    href="/api/admin/newsletter/export-csv"
                    download="novora_newsletter_subscribers.csv"
                    className="px-4 py-2 bg-stone-900 hover:bg-purple-700 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export Mailing List (CSV)</span>
                  </a>
                </div>
              </div>

              {newsletterSubscribers.length > 0 ? (
                <div className="overflow-x-auto border border-stone-200 rounded-2xl">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-stone-50 text-stone-500 uppercase text-[10px] border-b border-stone-200">
                      <tr>
                        <th className="py-3 px-4">#</th>
                        <th className="py-3 px-4">Email Address</th>
                        <th className="py-3 px-4">Subscription Date</th>
                        <th className="py-3 px-4 text-right">Audience Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100">
                      {newsletterSubscribers.map((sub, idx) => (
                        <tr key={sub.id || idx} className="hover:bg-stone-50">
                          <td className="py-3 px-4 font-mono text-stone-400">{idx + 1}</td>
                          <td className="py-3 px-4 font-semibold text-stone-900 font-mono">{sub.email}</td>
                          <td className="py-3 px-4 text-stone-500">
                            {sub.subscribedAt ? new Date(sub.subscribedAt).toLocaleString() : 'Recent'}
                          </td>
                          <td className="py-3 px-4 text-right">
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                              Active Subscribed ✓
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-8 text-center bg-stone-50 rounded-2xl border border-stone-200/80 space-y-2">
                  <Mail className="w-8 h-8 text-stone-300 mx-auto" />
                  <p className="text-xs text-stone-500">
                    No newsletter subscriptions collected yet. Customer emails entered in the storefront footer will appear here automatically.
                  </p>
                </div>
              )}
            </div>

            {/* Customer Details & Address Book Inspector Modal (All 10 Address Fields) */}
            {selectedCustomerForDetails && (
              <div className="fixed inset-0 z-50 bg-stone-900/70 backdrop-blur-xs flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-stone-200 animate-fadeIn text-xs max-h-[90vh] overflow-y-auto">
                  
                  {/* Modal Header */}
                  <div className="flex items-center justify-between pb-4 border-b border-stone-200">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-purple-100 text-purple-800 font-black text-lg flex items-center justify-center uppercase">
                        {selectedCustomerForDetails.fullName?.charAt(0) || 'U'}
                      </div>
                      <div>
                        <h3 className="font-bold text-stone-950 text-base font-display">
                          {selectedCustomerForDetails.fullName}
                        </h3>
                        <p className="text-stone-500 text-[11px] font-mono">
                          {selectedCustomerForDetails.email} · ID: {selectedCustomerForDetails.id}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSelectedCustomerForDetails(null)}
                      className="text-stone-400 hover:text-stone-700 p-2 text-base font-bold rounded-xl hover:bg-stone-100 transition-colors cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>

                  {/* Customer Quick Metric Pills */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200">
                      <span className="text-stone-400 text-[10px] block">Contact Phone</span>
                      <span className="font-semibold text-stone-900 truncate block">{selectedCustomerForDetails.phone || 'Not provided'}</span>
                    </div>
                    <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200">
                      <span className="text-stone-400 text-[10px] block">Total Orders</span>
                      <span className="font-bold text-purple-700 text-sm">{selectedCustomerForDetails.totalOrders || 0}</span>
                    </div>
                    <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200">
                      <span className="text-stone-400 text-[10px] block">Lifetime Value</span>
                      <span className="font-bold text-emerald-700 font-mono text-sm">${(selectedCustomerForDetails.totalSpent || 0).toFixed(2)}</span>
                    </div>
                    <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200">
                      <span className="text-stone-400 text-[10px] block">Security / Storage</span>
                      <span className="font-bold text-emerald-800 text-[11px] block">users.json ✓</span>
                    </div>
                  </div>

                  {/* Saved Delivery Addresses Section (All 10 Address Fields per Flowchart) */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-stone-900 text-sm flex items-center gap-1.5">
                        <MapPin className="w-4 h-4 text-purple-700" />
                        <span>Saved Address Book (Stored in addresses.json)</span>
                      </h4>
                      <span className="text-[11px] font-mono text-stone-400">
                        {selectedCustomerForDetails.savedAddresses?.length || 0} saved location(s)
                      </span>
                    </div>

                    {selectedCustomerForDetails.savedAddresses && selectedCustomerForDetails.savedAddresses.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {selectedCustomerForDetails.savedAddresses.map((addr: any, idx: number) => (
                          <div key={idx} className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2 relative">
                            {addr.isDefault && (
                              <span className="absolute top-3 right-3 px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200">
                                Default Delivery Address
                              </span>
                            )}
                            <p className="font-bold text-stone-900 text-xs">{addr.fullName || selectedCustomerForDetails.fullName}</p>
                            <div className="space-y-1 text-stone-700 text-[11px]">
                              <p><strong>Street Address:</strong> {addr.streetAddress}</p>
                              <p><strong>House / Building No:</strong> {addr.houseNumber}</p>
                              {addr.apartmentDetails && <p><strong>Apartment / Suite:</strong> {addr.apartmentDetails}</p>}
                              <p><strong>City:</strong> {addr.city}</p>
                              <p><strong>State / Province:</strong> {addr.state}</p>
                              <p><strong>Postal / ZIP Code:</strong> {addr.postalCode}</p>
                              <p><strong>Country:</strong> <span className="uppercase font-semibold">{addr.country}</span></p>
                              <p><strong>Contact Phone:</strong> {addr.phone || selectedCustomerForDetails.phone || 'N/A'}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-6 text-center bg-stone-50 rounded-2xl border border-stone-200 text-stone-400">
                        No saved delivery addresses stored yet for this patron.
                      </div>
                    )}
                  </div>

                  {/* Order History with Merchant Card Payout details */}
                  <div className="space-y-3">
                    <h4 className="font-bold text-stone-900 text-sm flex items-center gap-1.5">
                      <ShoppingBag className="w-4 h-4 text-purple-700" />
                      <span>Order History &amp; Merchant Card Settlement</span>
                    </h4>

                    {selectedCustomerForDetails.orders && selectedCustomerForDetails.orders.length > 0 ? (
                      <div className="border border-stone-200 rounded-2xl overflow-hidden">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-stone-50 text-stone-500 font-semibold border-b border-stone-200">
                            <tr>
                              <th className="py-2.5 px-3">Order Ref</th>
                              <th className="py-2.5 px-3">Date</th>
                              <th className="py-2.5 px-3">Total Paid</th>
                              <th className="py-2.5 px-3">Fulfilment</th>
                              <th className="py-2.5 px-3">Payment</th>
                              <th className="py-2.5 px-3 text-right">Action</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-stone-100">
                            {selectedCustomerForDetails.orders.map((ord: any) => (
                              <tr key={ord.id} className="hover:bg-stone-50">
                                <td className="py-2.5 px-3 font-mono font-bold text-purple-700">{ord.orderNumber}</td>
                                <td className="py-2.5 px-3 text-stone-500">{new Date(ord.createdAt).toLocaleDateString()}</td>
                                <td className="py-2.5 px-3 font-bold font-mono text-stone-900">{ord.currency} {ord.total.toLocaleString()}</td>
                                <td className="py-2.5 px-3 font-medium text-stone-700">{ord.orderStatus}</td>
                                <td className="py-2.5 px-3">
                                  <span className={`font-bold ${ord.paymentStatus === 'paid' ? 'text-emerald-700' : 'text-amber-700'}`}>
                                    {ord.paymentStatus}
                                  </span>
                                </td>
                                <td className="py-2.5 px-3 text-right">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setSelectedCustomerForDetails(null);
                                      setActiveTab('orders');
                                      setOrderSearch(ord.orderNumber);
                                    }}
                                    className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg text-[11px] font-semibold cursor-pointer"
                                  >
                                    View in Orders
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <p className="text-stone-400 text-xs py-4 text-center bg-stone-50 rounded-2xl border border-stone-200">
                        No orders recorded yet.
                      </p>
                    )}
                  </div>

                  {/* Modal Footer */}
                  <div className="flex items-center justify-between pt-4 border-t border-stone-200">
                    <button
                      type="button"
                      onClick={() => {
                        handleOpenEditUser(selectedCustomerForDetails);
                      }}
                      className="px-4 py-2 bg-purple-50 hover:bg-purple-100 text-purple-800 rounded-xl font-bold transition-colors cursor-pointer border border-purple-200 flex items-center gap-1.5"
                    >
                      <Edit className="w-3.5 h-3.5" />
                      <span>Edit Customer Details</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setSelectedCustomerForDetails(null)}
                      className="px-5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl font-bold cursor-pointer transition-colors"
                    >
                      Close Inspector
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Edit User Modal (Admin Action) */}
            {editingUser && (
              <div className="fixed inset-0 z-50 bg-stone-900/70 backdrop-blur-xs flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-7 space-y-5 shadow-2xl border border-stone-200 text-xs animate-fadeIn">
                  <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                    <h3 className="font-bold text-stone-900 text-base font-display">
                      Edit Customer Record
                    </h3>
                    <button
                      type="button"
                      onClick={() => setEditingUser(null)}
                      className="text-stone-400 hover:text-stone-700 text-sm font-bold p-1 cursor-pointer"
                    >
                      ✕
                    </button>
                  </div>

                  <form onSubmit={handleSaveEditUser} className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">Full Name</label>
                      <input
                        type="text"
                        value={editUserForm.fullName}
                        onChange={e => setEditUserForm({ ...editUserForm, fullName: e.target.value })}
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-semibold text-stone-900"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">Email Address</label>
                      <input
                        type="email"
                        value={editUserForm.email}
                        onChange={e => setEditUserForm({ ...editUserForm, email: e.target.value })}
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">Contact Phone</label>
                      <input
                        type="text"
                        value={editUserForm.phone}
                        onChange={e => setEditUserForm({ ...editUserForm, phone: e.target.value })}
                        placeholder="+1 (555) 000-0000"
                        className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-stone-900"
                      />
                    </div>

                    <p className="text-[11px] text-stone-400">
                      Edits update <code>data/users.json</code> and all associated orders synchronously.
                    </p>

                    <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-200">
                      <button
                        type="button"
                        onClick={() => setEditingUser(null)}
                        className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl font-semibold cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={isSavingUser}
                        className="px-5 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-bold cursor-pointer transition-colors flex items-center gap-1.5"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>{isSavingUser ? 'Saving...' : 'Save to users.json'}</span>
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {/* Delete User Confirmation Modal */}
            {userToDelete && (
              <div className="fixed inset-0 z-50 bg-stone-900/70 backdrop-blur-xs flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl border border-stone-200 text-xs animate-fadeIn">
                  <div className="flex items-center gap-3 text-rose-600">
                    <AlertTriangle className="w-6 h-6 shrink-0" />
                    <h3 className="font-bold text-stone-900 text-base">Delete Customer Account?</h3>
                  </div>

                  <p className="text-stone-600 leading-relaxed">
                    Are you sure you want to delete customer <strong>{userToDelete.fullName}</strong> ({userToDelete.email})? This action will remove the record from <code>users.json</code> and <code>addresses.json</code>.
                  </p>

                  <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-200">
                    <button
                      type="button"
                      onClick={() => setUserToDelete(null)}
                      className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl font-semibold cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      disabled={isDeletingUser}
                      onClick={handleConfirmDeleteUser}
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold cursor-pointer transition-colors flex items-center gap-1.5"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{isDeletingUser ? 'Deleting...' : 'Confirm Delete'}</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

          </div>
        )}

        {/* =========================================================================
            9. TAB: DISCOUNTS & COUPONS
        ========================================================================= */}
        {activeTab === 'coupons' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Create Coupon */}
            <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
              <h2 className="text-sm font-bold text-stone-900 font-display">
                Create Promotional Coupon
              </h2>

              <form onSubmit={handleSaveCoupon} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Coupon Code *</label>
                  <input
                    type="text"
                    placeholder="e.g. SPRING20"
                    value={couponForm.code}
                    onChange={e => setCouponForm({ ...couponForm, code: e.target.value.toUpperCase() })}
                    className="w-full px-3 py-2 text-xs uppercase bg-stone-50 border border-stone-300 rounded-lg font-bold"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Type</label>
                    <select
                      value={couponForm.discountType}
                      onChange={e => setCouponForm({ ...couponForm, discountType: e.target.value as any })}
                      className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg"
                    >
                      <option value="percentage">Percentage (%)</option>
                      <option value="fixed">Fixed Amount ($)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Value</label>
                    <input
                      type="number"
                      value={couponForm.discountValue}
                      onChange={e => setCouponForm({ ...couponForm, discountValue: Number(e.target.value) })}
                      className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg font-bold"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">Minimum Order ($)</label>
                  <input
                    type="number"
                    value={couponForm.minOrderValue}
                    onChange={e => setCouponForm({ ...couponForm, minOrderValue: Number(e.target.value) })}
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-lg"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-stone-900 hover:bg-purple-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                >
                  Create & Activate Coupon
                </button>
              </form>
            </div>

            {/* Coupons List */}
            <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-stone-200 shadow-xs space-y-4">
              <h3 className="text-sm font-bold text-stone-900">
                Active Promotional Codes ({coupons.length})
              </h3>

              <div className="space-y-3">
                {coupons.map(cp => (
                  <div key={cp.id} className="p-4 bg-stone-50 rounded-xl border border-stone-200 flex items-center justify-between">
                    <div>
                      <span className="font-mono font-bold text-sm text-purple-900 bg-purple-100/80 px-2.5 py-0.5 rounded">
                        {cp.code}
                      </span>
                      <p className="text-xs text-stone-600 mt-1">
                        {cp.discountType === 'percentage' ? `${cp.discountValue}% OFF` : `$${cp.discountValue} Flat Discount`} · Min order: ${cp.minOrderValue}
                      </p>
                      <p className="text-[10px] text-stone-400 mt-0.5">Used {cp.usageCount} times</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* =========================================================================
            10. TAB: STORE SETTINGS
        ========================================================================= */}
        {activeTab === 'settings' && (
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs space-y-6 max-w-3xl">
            <div>
              <h2 className="text-base font-bold text-stone-950 font-display">Store Settings & Global Policies</h2>
              <p className="text-xs text-stone-500">Configure store branding, shipping charges, and contact details.</p>
            </div>

            <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Store Name</label>
                  <input
                    type="text"
                    value={settingsForm.storeName}
                    onChange={e => setSettingsForm({ ...settingsForm, storeName: e.target.value })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Currency Code</label>
                  <input
                    type="text"
                    value={settingsForm.currency}
                    onChange={e => setSettingsForm({ ...settingsForm, currency: e.target.value })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg uppercase"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Standard Courier Shipping Charge ($)</label>
                  <input
                    type="number"
                    value={settingsForm.shippingCharge}
                    onChange={e => setSettingsForm({ ...settingsForm, shippingCharge: Number(e.target.value) })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg font-bold"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Free Shipping Spend Threshold ($)</label>
                  <input
                    type="number"
                    value={settingsForm.freeShippingThreshold}
                    onChange={e => setSettingsForm({ ...settingsForm, freeShippingThreshold: Number(e.target.value) })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg font-bold"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Contact Email</label>
                  <input
                    type="email"
                    value={settingsForm.contactEmail}
                    onChange={e => setSettingsForm({ ...settingsForm, contactEmail: e.target.value })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">Contact Phone</label>
                  <input
                    type="tel"
                    value={settingsForm.contactPhone}
                    onChange={e => setSettingsForm({ ...settingsForm, contactPhone: e.target.value })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg"
                    required
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-semibold text-stone-700 mb-1">Store Physical Headquarters Address</label>
                  <input
                    type="text"
                    value={settingsForm.address}
                    onChange={e => setSettingsForm({ ...settingsForm, address: e.target.value })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg"
                    required
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-semibold text-stone-700 mb-1">Top Announcement Bar Text</label>
                  <input
                    type="text"
                    value={settingsForm.promotionalBarText}
                    onChange={e => setSettingsForm({ ...settingsForm, promotionalBarText: e.target.value })}
                    className="w-full p-2.5 bg-stone-50 border border-stone-300 rounded-lg"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="px-6 py-2.5 bg-stone-950 hover:bg-purple-700 text-white font-bold uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
              >
                Save Store Settings
              </button>
            </form>
          </div>
        )}

        {/* =========================================================================
            14. TAB: DATABASE & PERSISTENCE HUB (Requirements 1, 2, 3, 7, 8)
        ========================================================================= */}
        {activeTab === 'database' && (
          <div className="space-y-8 animate-in fade-in duration-150">
            {/* Top Engine Banner */}
            <div className="p-6 sm:p-8 bg-stone-900 text-white rounded-3xl border border-stone-800 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-3 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5">
                      <Database className="w-3.5 h-3.5 text-emerald-400" />
                      SQLite 3 ACID Engine
                    </span>
                    <span className="px-3 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/40 flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" />
                      Persistent Disk Storage
                    </span>
                    <span className="px-3 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/40">
                      Windows School Project Compliant
                    </span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-black font-display tracking-tight text-white">
                    NOVORA Database &amp; Persistence Hub
                  </h2>
                  <p className="text-stone-300 text-xs sm:text-sm max-w-2xl leading-relaxed">
                    Single source of truth for products, pricing, stock, homepage banners, categories, customer orders, addresses, and store settings. Every admin change commits to the backend SQLite database and updates storefront views instantly.
                  </p>
                  <div className="pt-2 flex items-center gap-2 text-xs font-mono text-emerald-400 bg-black/40 px-3.5 py-2 rounded-xl border border-stone-800 w-fit">
                    <HardDrive className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Database Path: <strong>C:\Novora_Project\data\novora.db</strong> &nbsp;|&nbsp; <strong>./data/novora.db</strong></span>
                  </div>
                </div>

                {/* Direct Action Download Buttons */}
                <div className="flex flex-col sm:flex-row lg:flex-col gap-2.5 shrink-0">
                  <a
                    href="/api/admin/folder-storage/download/novora.db"
                    download="novora.db"
                    className="px-5 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download novora.db (SQLite)</span>
                  </a>

                  <a
                    href="/api/admin/database/export-sql"
                    download="novora_schema_and_data.sql"
                    className="px-5 py-3 bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-xs rounded-xl border border-stone-700 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <FileCode className="w-4 h-4 text-purple-400" />
                    <span>Export SQL Dump (.sql)</span>
                  </a>

                  <button
                    type="button"
                    onClick={handleRefreshFolderStorage}
                    className="px-5 py-2.5 bg-stone-900 hover:bg-stone-800 text-stone-300 font-semibold text-xs rounded-xl border border-stone-700 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-stone-400" />
                    <span>Refresh Table Counts</span>
                  </button>
                </div>
              </div>
            </div>

            {/* SQLite Tables & Schema Live Inspector */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-extrabold text-stone-950 font-display flex items-center gap-2">
                    <Database className="w-4 h-4 text-purple-700" />
                    <span>SQLite Relational Tables in novora.db</span>
                  </h3>
                  <p className="text-xs text-stone-500">
                    Tables automatically provisioned with primary keys, indexes, and transactional integrity.
                  </p>
                </div>
                <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-100 px-3 py-1 rounded-full border border-emerald-300">
                  11 Active SQL Tables
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {/* Table: products */}
                <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-2 hover:border-purple-300 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                      products
                    </span>
                    <span className="text-xs font-extrabold text-stone-900 bg-stone-100 px-2.5 py-0.5 rounded-full">
                      {products.length} rows
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-600">
                    Product catalog, prices, descriptions, images, inventory stock, categories, visibility status.
                  </p>
                  <div className="text-[10px] font-mono text-stone-400 pt-1 border-t border-stone-100">
                    COLUMNS: id, name, sku, category, selling_price, stock, status, images_json
                  </div>
                </div>

                {/* Table: orders */}
                <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-2 hover:border-purple-300 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      orders
                    </span>
                    <span className="text-xs font-extrabold text-stone-900 bg-stone-100 px-2.5 py-0.5 rounded-full">
                      {orders.length} rows
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-600">
                    Customer orders, fulfillment status, tracking numbers, items, carrier, and payment records.
                  </p>
                  <div className="text-[10px] font-mono text-stone-400 pt-1 border-t border-stone-100">
                    COLUMNS: id, order_number, user_id, total, status, tracking_number, settlement_info
                  </div>
                </div>

                {/* Table: users */}
                <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-2 hover:border-purple-300 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                      users
                    </span>
                    <span className="text-xs font-extrabold text-stone-900 bg-stone-100 px-2.5 py-0.5 rounded-full">
                      {customers.length + 1} rows
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-600">
                    Customer accounts &amp; Admin profile. Passwords securely hashed with SHA-256.
                  </p>
                  <div className="text-[10px] font-mono text-stone-400 pt-1 border-t border-stone-100">
                    COLUMNS: id, email, password_hash, full_name, phone, role, created_at
                  </div>
                </div>

                {/* Table: addresses */}
                <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-2 hover:border-purple-300 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                      addresses
                    </span>
                    <span className="text-xs font-extrabold text-stone-900 bg-stone-100 px-2.5 py-0.5 rounded-full">
                      {customers.reduce((acc, c) => acc + (c.savedAddresses?.length || 0), 0) + orders.length} rows
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-600">
                    All 10 compulsory delivery address fields linked to users and customer orders.
                  </p>
                  <div className="text-[10px] font-mono text-stone-400 pt-1 border-t border-stone-100">
                    COLUMNS: id, user_id, full_name, street_address, city, state, postal_code, country
                  </div>
                </div>

                {/* Table: categories */}
                <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-2 hover:border-purple-300 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-stone-700 bg-stone-100 px-2 py-0.5 rounded border border-stone-200">
                      categories
                    </span>
                    <span className="text-xs font-extrabold text-stone-900 bg-stone-100 px-2.5 py-0.5 rounded-full">
                      {categories.length} rows
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-600">
                    Category names, hero images, display order, subcategories, and active statuses.
                  </p>
                  <div className="text-[10px] font-mono text-stone-400 pt-1 border-t border-stone-100">
                    COLUMNS: id, name, description, image, display_order, status
                  </div>
                </div>

                {/* Table: banners */}
                <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-2 hover:border-purple-300 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                      banners
                    </span>
                    <span className="text-xs font-extrabold text-stone-900 bg-stone-100 px-2.5 py-0.5 rounded-full">
                      {banners.length} rows
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-600">
                    Promotional carousel banners, call-to-actions, badge labels, and uploaded PC images.
                  </p>
                  <div className="text-[10px] font-mono text-stone-400 pt-1 border-t border-stone-100">
                    COLUMNS: id, title, subtitle, image_url, button_text, link_url, is_active
                  </div>
                </div>

                {/* Table: store_settings */}
                <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-2 hover:border-purple-300 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                      store_settings
                    </span>
                    <span className="text-xs font-extrabold text-stone-900 bg-stone-100 px-2.5 py-0.5 rounded-full">
                      1 row
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-600">
                    Store name, default currency, shipping rates, free shipping spend threshold, tax percentage.
                  </p>
                  <div className="text-[10px] font-mono text-stone-400 pt-1 border-t border-stone-100">
                    COLUMNS: id, store_name, currency, shipping_charge, free_shipping_threshold
                  </div>
                </div>

                {/* Table: payment_gateway */}
                <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-2 hover:border-purple-300 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                      payment_gateway
                    </span>
                    <span className="text-xs font-extrabold text-stone-900 bg-stone-100 px-2.5 py-0.5 rounded-full">
                      1 row
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-600">
                    Safepay/Stripe provider mode, merchant card •••• 9922, 1Link Raast payout rail.
                  </p>
                  <div className="text-[10px] font-mono text-stone-400 pt-1 border-t border-stone-100">
                    COLUMNS: id, provider, is_test_mode, merchant_card_last4, payout_account_masked
                  </div>
                </div>
              </div>
            </div>

            {/* Database Backup & Restore System (Requirement 7: Reliability & School Testing) */}
            <div className="p-6 sm:p-8 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-100 pb-5">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-100 text-purple-800 border border-purple-200">
                      Requirement 7: Reliability
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-stone-500">
                      data/backups/
                    </span>
                  </div>
                  <h3 className="text-lg font-black text-stone-950 font-display mt-1">
                    Database Snapshots &amp; 1-Click Disaster Recovery Restore
                  </h3>
                  <p className="text-xs text-stone-500">
                    Create instant point-in-time SQLite snapshots. Restore any previous database state with one click for school evaluation and grading tests.
                  </p>
                </div>

                {/* Create Backup Button Form */}
                <form onSubmit={handleCreateBackup} className="flex items-center gap-2 flex-wrap">
                  <input
                    type="text"
                    value={backupDescription}
                    onChange={e => setBackupDescription(e.target.value)}
                    placeholder="Snapshot label (e.g. Pre-grading demo)"
                    className="px-3.5 py-2 text-xs bg-stone-50 border border-stone-300 rounded-xl w-60 focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-600"
                    required
                  />
                  <button
                    type="submit"
                    disabled={isCreatingBackup}
                    className="px-4 py-2 bg-purple-700 hover:bg-purple-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    {isCreatingBackup ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Saving Snapshot…</span>
                      </>
                    ) : (
                      <>
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Create Backup Now</span>
                      </>
                    )}
                  </button>
                </form>
              </div>

              {/* Backups List Table */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs font-semibold text-stone-600">
                  <span>Available Database Snapshots ({databaseBackups.length})</span>
                  <button
                    type="button"
                    onClick={loadBackups}
                    className="text-purple-700 hover:text-purple-900 flex items-center gap-1 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoadingBackups ? 'animate-spin' : ''}`} />
                    <span>Refresh Snapshots</span>
                  </button>
                </div>

                {databaseBackups.length === 0 ? (
                  <div className="p-8 text-center bg-stone-50 rounded-2xl border border-dashed border-stone-300 space-y-2">
                    <History className="w-8 h-8 text-stone-400 mx-auto" />
                    <p className="text-xs font-semibold text-stone-600">No backup snapshots created yet</p>
                    <p className="text-[11px] text-stone-400 max-w-sm mx-auto">
                      Click "Create Backup Now" above to capture a point-in-time snapshot of your SQLite database before making catalog changes.
                    </p>
                  </div>
                ) : (
                  <div className="divide-y divide-stone-100 rounded-2xl border border-stone-200 overflow-hidden">
                    {databaseBackups.map(bk => (
                      <div
                        key={bk.id}
                        className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-stone-50/70 transition-colors text-xs"
                      >
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-stone-900">{bk.filename}</span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-stone-100 text-stone-600 border border-stone-200">
                              {(bk.sizeBytes / 1024).toFixed(1)} KB
                            </span>
                          </div>
                          <p className="text-stone-600 text-[11px] font-medium">{bk.description}</p>
                          <span className="text-[10px] text-stone-400">
                            Captured: {new Date(bk.createdAt).toLocaleString()}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <a
                            href={`/api/admin/database/download-backup/${bk.filename}`}
                            download={bk.filename}
                            className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                            title="Download .db snapshot file"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>Download .db</span>
                          </a>

                          <button
                            type="button"
                            onClick={() => setBackupToRestore(bk)}
                            className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>1-Click Restore</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* School Project Verification Matrix (Requirement 8: Required Testing) */}
            <div className="p-6 sm:p-8 bg-stone-950 text-white rounded-3xl border border-stone-800 shadow-xl space-y-6">
              <div className="space-y-1">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Requirement 8: Verification Matrix
                </span>
                <h3 className="text-xl font-black font-display text-white">
                  5 School-Project Verification Test Cases
                </h3>
                <p className="text-xs text-stone-400">
                  Step-by-step procedures to verify that all admin mutations commit to the SQLite database and reflect across the website immediately.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
                {/* Test 1 */}
                <div className="p-4 bg-stone-900 rounded-2xl border border-stone-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-400 text-[11px] uppercase tracking-wider">Test Case 1</span>
                    <span className="text-[10px] font-mono text-stone-400">products table</span>
                  </div>
                  <h4 className="font-extrabold text-white text-sm">Add Product &rarr; Instant Homepage Reflection</h4>
                  <p className="text-stone-300 text-[11px] leading-relaxed">
                    1. Go to <strong>+ Add Product</strong> tab.<br />
                    2. Upload image from PC and fill title/price.<br />
                    3. Click <strong>Publish Product</strong>.<br />
                    4. Check top bar: <strong>Saved successfully</strong> appears.<br />
                    5. Open <strong>View Customer Store</strong>: The product appears immediately in Featured Collection and Catalog.
                  </p>
                  <div className="pt-2 border-t border-stone-800 flex items-center gap-1.5 text-[10px] text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verified: Commits to data/novora.db</span>
                  </div>
                </div>

                {/* Test 2 */}
                <div className="p-4 bg-stone-900 rounded-2xl border border-stone-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-400 text-[11px] uppercase tracking-wider">Test Case 2</span>
                    <span className="text-[10px] font-mono text-stone-400">price update</span>
                  </div>
                  <h4 className="font-extrabold text-white text-sm">Edit Price &rarr; Persists on Page Refresh</h4>
                  <p className="text-stone-300 text-[11px] leading-relaxed">
                    1. Go to <strong>Products</strong> tab and click <strong>Edit</strong> on any item.<br />
                    2. Change Selling Price (e.g. from $120 to $175).<br />
                    3. Click <strong>Save Changes</strong>.<br />
                    4. Hard reload browser (Ctrl + F5 or Cmd + Shift + R).<br />
                    5. Product retains the new $175 price from SQLite database.
                  </p>
                  <div className="pt-2 border-t border-stone-800 flex items-center gap-1.5 text-[10px] text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verified: Backend SQLite is single source of truth</span>
                  </div>
                </div>

                {/* Test 3 */}
                <div className="p-4 bg-stone-900 rounded-2xl border border-stone-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-400 text-[11px] uppercase tracking-wider">Test Case 3</span>
                    <span className="text-[10px] font-mono text-stone-400">banners table</span>
                  </div>
                  <h4 className="font-extrabold text-white text-sm">Upload Banner &rarr; Persists on Backend Restart</h4>
                  <p className="text-stone-300 text-[11px] leading-relaxed">
                    1. Go to <strong>Banners</strong> tab.<br />
                    2. Click "Upload from PC" to select image.<br />
                    3. Fill title and click <strong>Publish Homepage Banner</strong>.<br />
                    4. Image is copied to <code>/uploads/</code> and URL written to SQLite.<br />
                    5. Banner renders on homepage carousel after backend server restart.
                  </p>
                  <div className="pt-2 border-t border-stone-800 flex items-center gap-1.5 text-[10px] text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verified: Persistent storage folder &amp; SQL row</span>
                  </div>
                </div>

                {/* Test 4 */}
                <div className="p-4 bg-stone-900 rounded-2xl border border-stone-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-400 text-[11px] uppercase tracking-wider">Test Case 4</span>
                    <span className="text-[10px] font-mono text-stone-400">orders table</span>
                  </div>
                  <h4 className="font-extrabold text-white text-sm">Change Order Status &rarr; SQLite Update</h4>
                  <p className="text-stone-300 text-[11px] leading-relaxed">
                    1. Go to <strong>Orders</strong> tab and click on an order.<br />
                    2. Change status to <strong>Shipped</strong> or <strong>Delivered</strong>.<br />
                    3. Enter tracking number &amp; carrier.<br />
                    4. Top bar confirms: <strong>Saved successfully</strong>.<br />
                    5. Reload page: Order status remains updated in database records.
                  </p>
                  <div className="pt-2 border-t border-stone-800 flex items-center gap-1.5 text-[10px] text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verified: Real-time order fulfillment sync</span>
                  </div>
                </div>

                {/* Test 5 */}
                <div className="p-4 bg-stone-900 rounded-2xl border border-stone-800 space-y-2 lg:col-span-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-400 text-[11px] uppercase tracking-wider">Test Case 5</span>
                    <span className="text-[10px] font-mono text-stone-400">users &amp; addresses tables</span>
                  </div>
                  <h4 className="font-extrabold text-white text-sm">Customer Registration &amp; Delivery Address Persistence</h4>
                  <p className="text-stone-300 text-[11px] leading-relaxed">
                    1. Open Store as customer, click Account &rarr; Register new test user.<br />
                    2. Add a delivery address with all 10 fields (Street, House Number, City, State, Postal Code, etc.).<br />
                    3. Restart backend server.<br />
                    4. Sign in again: Customer addresses and previous orders are loaded intact from <code>novora.db</code>.<br />
                    5. Admin can inspect this customer under <strong>Users &amp; Addresses</strong> tab.
                  </p>
                  <div className="pt-2 border-t border-stone-800 flex items-center gap-1.5 text-[10px] text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verified: Secure password hashing + SQL foreign key relationships</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Local Windows PC Setup Guide Card */}
            <div className="p-6 sm:p-8 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
              <div className="flex items-center gap-2">
                <Terminal className="w-5 h-5 text-purple-700" />
                <h3 className="text-lg font-black text-stone-950 font-display">
                  How to Run on Windows Locally at C:\Novora_Project
                </h3>
              </div>
              <p className="text-xs text-stone-600 leading-relaxed">
                We generated a complete standalone Python SQLite backend in <code>python_backend/app.py</code> with a double-click launcher <code>python_backend/run_windows.bat</code>. It uses Python's built-in standard library with <strong>zero pip dependencies required</strong>.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                  <span className="font-bold text-purple-700 block text-[11px] uppercase">Step 1: Folder Structure</span>
                  <p className="text-stone-600 text-[11px]">
                    Place the project inside <code>C:\Novora_Project</code>. The <code>data\</code> directory and <code>novora.db</code> SQLite file are generated automatically on first startup.
                  </p>
                </div>

                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                  <span className="font-bold text-purple-700 block text-[11px] uppercase">Step 2: Launch Windows Server</span>
                  <p className="text-stone-600 text-[11px]">
                    Double-click <code>python_backend\run_windows.bat</code> or run <code>python app.py</code>. The SQLite engine initializes all 11 tables with initial seed data.
                  </p>
                </div>

                <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                  <span className="font-bold text-purple-700 block text-[11px] uppercase">Step 3: Verification &amp; Inspection</span>
                  <p className="text-stone-600 text-[11px]">
                    You can open <code>C:\Novora_Project\data\novora.db</code> with <em>DB Browser for SQLite</em> or SQLite GUI tools to inspect all tables and verify live mutations.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            15. TAB: SECURITY SETTINGS & PASSWORD MANAGEMENT (Bcrypt Salted Hash)
        ========================================================================= */}
        {activeTab === 'security' && (
          <div className="space-y-8">
            {/* Header & Status Banner */}
            <div className="p-6 sm:p-8 bg-stone-950 text-white rounded-3xl border border-stone-800 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
              <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30">
                      Bcrypt v5.0 · 10 Salt Rounds
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Zero Plain-Text Policy
                    </span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black font-display text-white">
                    Administrator Security &amp; Password Management
                  </h2>
                  <p className="text-xs text-stone-400 max-w-2xl leading-relaxed">
                    Protecting the NOVORA Command Console with salted cryptographic hashes. Passwords are never saved in plain text, never exposed in Google Drive exports, and never accessible via browser storage.
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      setIsLoadingAuditLogs(true);
                      api.getAdminAuditLog()
                        .then(l => setAuditLogs(l))
                        .catch(() => {})
                        .finally(() => setIsLoadingAuditLogs(false));
                    }}
                    className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded-xl border border-stone-700 transition-colors flex items-center gap-2 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoadingAuditLogs ? 'animate-spin' : ''}`} />
                    <span>Refresh Audit Trail</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Security Architecture & Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-1">
                <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
                  <span>Admin Identity</span>
                  <Key className="w-4 h-4 text-purple-600" />
                </div>
                <p className="text-sm font-bold text-stone-900 truncate font-mono">
                  {currentUser?.email || 'admin@novora.store'}
                </p>
                <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-purple-100 text-purple-800">
                  Role: Super Administrator
                </span>
              </div>

              <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-1">
                <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
                  <span>Cryptographic Algorithm</span>
                  <Lock className="w-4 h-4 text-emerald-600" />
                </div>
                <p className="text-sm font-bold text-stone-900 font-mono">
                  bcrypt ($2a$10$...)
                </p>
                <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800">
                  10 Adaptive Salt Rounds
                </span>
              </div>

              <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-1">
                <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
                  <span>Session Security</span>
                  <ShieldCheck className="w-4 h-4 text-blue-600" />
                </div>
                <p className="text-sm font-bold text-stone-900 font-mono">
                  Bearer Token Auth
                </p>
                <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-blue-100 text-blue-800">
                  24h Expiry &amp; Invalidation
                </span>
              </div>

              <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-1">
                <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
                  <span>Audit Events Logged</span>
                  <History className="w-4 h-4 text-amber-600" />
                </div>
                <p className="text-2xl font-black text-stone-900 font-mono">
                  {auditLogs.length}
                </p>
                <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-amber-100 text-amber-800">
                  Real-time Server Logging
                </span>
              </div>
            </div>

            {/* ARCHITECTURE BLUEPRINT & COMPLETE FLOWCHART SHOWCASE BANNER */}
            <div className="bg-stone-900 border border-stone-800 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-xl space-y-6">
              <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
              
              <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-stone-800">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                      Flowchart Architecture Specification
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      5 Integrated Systems
                    </span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black font-display text-white">
                    NOVORA Authentication, Account Management &amp; Saving System
                  </h3>
                  <p className="text-xs text-stone-300 max-w-2xl leading-relaxed">
                    Visual specification of the 5 core modules: Admin Login Flow, Admin Account Management, Customer Registration Flow, Customer Sign In Flow, and Primary Database &amp; Google Drive Saving Flow.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3 shrink-0">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedDiagramType('full-system');
                      setActiveCustomerFlowTab('diagram');
                      setCustomerFlowZoom(1);
                      setIsCustomerFlowModalOpen(true);
                    }}
                    className="px-5 py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center gap-2 cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-400 focus-visible:ring-offset-2 focus-visible:ring-offset-stone-900 outline-none"
                  >
                    <Eye className="w-4 h-4" />
                    <span>Inspect Full Flowchart (Zoom / High-Res)</span>
                  </button>
                  <a
                    href="/assets/aistudio/NOVORA_Authentication_System_Flowchart__1__e9de0c86.png"
                    download="NOVORA_Authentication_System_Flowchart.png"
                    className="px-4 py-3 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded-xl border border-stone-700 transition-colors flex items-center gap-2 cursor-pointer focus-visible:ring-2 focus-visible:ring-stone-400 outline-none"
                  >
                    <Download className="w-4 h-4 text-purple-400" />
                    <span>Download Blueprint PNG</span>
                  </a>
                </div>
              </div>

              {/* Diagram Preview Thumbnail & System Tracks Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                <div
                  onClick={() => {
                    setSelectedDiagramType('full-system');
                    setActiveCustomerFlowTab('diagram');
                    setCustomerFlowZoom(1);
                    setIsCustomerFlowModalOpen(true);
                  }}
                  className="lg:col-span-5 relative group cursor-pointer overflow-hidden rounded-2xl border border-stone-700/80 bg-stone-950 p-2 shadow-2xl transition-all hover:border-purple-500/60"
                  title="Click to expand flowchart lightbox"
                >
                  <img
                    src="/assets/aistudio/NOVORA_Authentication_System_Flowchart__1__e9de0c86.png"
                    alt="NOVORA Authentication System Flowchart Diagram"
                    className="w-full h-56 object-cover object-top rounded-xl group-hover:scale-102 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-stone-950/40 group-hover:bg-transparent transition-colors flex items-center justify-center">
                    <span className="px-3 py-1.5 bg-stone-900/90 text-white rounded-lg text-xs font-bold border border-white/20 shadow-md backdrop-blur-xs flex items-center gap-1.5 opacity-90 group-hover:opacity-100">
                      <ZoomIn className="w-3.5 h-3.5 text-purple-400" />
                      <span>Click to Enlarge Full Flowchart</span>
                    </span>
                  </div>
                </div>

                <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3.5 bg-stone-950/60 rounded-xl border border-stone-800 space-y-1">
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block">1. Admin Login Flow</span>
                    <p className="font-semibold text-white">Initial: Huzaifa60010@gmail.com</p>
                    <p className="text-[11px] text-stone-400">Initial Password: <code className="text-purple-300">Huzaifa2009@pak</code> (Salted bcrypt hash, redirect to /admin).</p>
                  </div>

                  <div className="p-3.5 bg-stone-950/60 rounded-xl border border-stone-800 space-y-1">
                    <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">2. Account Management</span>
                    <p className="font-semibold text-white">Change Email &amp; Password</p>
                    <p className="text-[11px] text-stone-400">Verification dispatched, write audit log, safe backup to Google Drive.</p>
                  </div>

                  <div className="p-3.5 bg-stone-950/60 rounded-xl border border-stone-800 space-y-1">
                    <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider block">3. Customer Registration</span>
                    <p className="font-semibold text-white">Validation &amp; Strength Meter</p>
                    <p className="text-[11px] text-stone-400">Full Name, Email, Password, Confirm Password, Verification Simulation.</p>
                  </div>

                  <div className="p-3.5 bg-stone-950/60 rounded-xl border border-stone-800 space-y-1">
                    <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block">4. Data Saving &amp; Drive Backup</span>
                    <p className="font-semibold text-white">Database as Source of Truth</p>
                    <p className="text-[11px] text-stone-400">Safe structured JSON files synced to <code className="text-amber-300">NOVORA_Project</code> (no passwords/tokens).</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Admin Account Management Cards Grid: Email Change + Password Change */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Left Column: Account Management Forms (7 cols) */}
              <div className="lg:col-span-7 space-y-6">

                {/* FORM 1: CHANGE ADMIN EMAIL */}
                <div className="bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-sm space-y-6">
                  <div className="flex items-center gap-3 border-b border-stone-100 pb-4">
                    <div className="w-10 h-10 rounded-2xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                      <Mail className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-blue-700 uppercase tracking-widest block">
                        Account &amp; Security &rarr; Change Admin Email
                      </span>
                      <h3 className="text-lg font-black text-stone-950 font-display">
                        Update Administrator Email Address
                      </h3>
                    </div>
                  </div>

                  {/* Current Active Email Badge */}
                  <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider block">
                        Current Active Email
                      </span>
                      <strong className="text-sm font-bold font-mono text-stone-900">
                        {currentUser?.email || 'Huzaifa60010@gmail.com'}
                      </strong>
                    </div>
                    <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      <span>Verified Active</span>
                    </span>
                  </div>

                  {emailChangeSuccess && (
                    <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-800 flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <p className="font-bold text-emerald-950">Email Change Status</p>
                        <p>{emailChangeSuccess}</p>
                      </div>
                    </div>
                  )}

                  {emailChangeError && (
                    <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-800 flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <p className="font-bold text-rose-950">Email Change Request Denied</p>
                        <p>{emailChangeError}</p>
                      </div>
                    </div>
                  )}

                  <form onSubmit={handleRequestEmailChange} className="space-y-4 text-xs">
                    {/* New Email Address */}
                    <div className="space-y-1.5">
                      <label htmlFor="change-admin-new-email" className="block font-bold text-stone-800">
                        New Administrator Email <span className="text-rose-500">*</span>
                      </label>
                      <div className="relative">
                        <input
                          id="change-admin-new-email"
                          type="email"
                          value={newEmailInput}
                          onChange={e => setNewEmailInput(e.target.value)}
                          placeholder="e.g. huzaifa.lead@novora.store"
                          required
                          className="w-full px-4 py-3 pl-10 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-600 focus-visible:ring-offset-2"
                        />
                        <Mail className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      </div>
                      <span className="text-[11px] text-stone-400 block">
                        A secure cryptographic verification link will be generated for confirmation before activation.
                      </span>
                    </div>

                    {/* Current Password for verification */}
                    <div className="space-y-1.5">
                      <label htmlFor="change-email-current-pass" className="block font-bold text-stone-800">
                        Current Password (for authorization) <span className="text-rose-500">*</span>
                      </label>
                      <div className="relative">
                        <input
                          id="change-email-current-pass"
                          type={showEmailChangePassword ? 'text' : 'password'}
                          value={emailChangePasswordInput}
                          onChange={e => setEmailChangePasswordInput(e.target.value)}
                          placeholder="Enter your current password"
                          required
                          className="w-full px-4 py-3 pl-10 pr-11 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-600 focus-visible:ring-offset-2"
                        />
                        <Lock className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <button
                          type="button"
                          onClick={() => setShowEmailChangePassword(!showEmailChangePassword)}
                          aria-label={showEmailChangePassword ? 'Hide password' : 'Show password'}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 p-1 cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-600 rounded outline-none"
                        >
                          {showEmailChangePassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Send Verification Link Button */}
                    <div className="pt-2 flex items-center justify-between gap-4">
                      <button
                        type="submit"
                        disabled={isChangingEmail}
                        className="px-6 py-3 bg-blue-700 hover:bg-blue-800 disabled:opacity-50 text-white font-bold rounded-xl transition-all shadow-md cursor-pointer flex items-center gap-2 focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 outline-none"
                      >
                        {isChangingEmail ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            <span>Verifying Credentials...</span>
                          </>
                        ) : (
                          <>
                            <Mail className="w-4 h-4" />
                            <span>Send Verification Link</span>
                          </>
                        )}
                      </button>
                    </div>
                  </form>

                  {/* Verification Link Dispatched & Activation Card (Flowchart Step) */}
                  {pendingVerificationToken && (
                    <div className="p-5 bg-blue-50/80 border border-blue-200 rounded-2xl space-y-3 animate-in fade-in duration-200">
                      <div className="flex items-center gap-2 text-blue-950 font-bold">
                        <CheckCircle2 className="w-4 h-4 text-blue-700" />
                        <span>Verification Link Dispatched (Simulation Ready)</span>
                      </div>
                      <p className="text-[11px] text-blue-900">
                        In accordance with the flowchart workflow, click below to simulate clicking the email verification link to finalize updating the email in Authentication Provider &amp; Database.
                      </p>
                      <div className="p-2.5 bg-white rounded-xl border border-blue-200 font-mono text-[10px] text-blue-900 break-all">
                        {pendingVerificationLink}
                      </div>
                      <div className="flex items-center gap-3 pt-1">
                        <button
                          type="button"
                          onClick={handleConfirmEmailChange}
                          disabled={isChangingEmail}
                          className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer focus-visible:ring-2 focus-visible:ring-emerald-500 focus-visible:ring-offset-2 outline-none"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Click Verification Link &amp; Activate New Email</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* FORM 2: CHANGE ADMIN MASTER PASSWORD */}
                <div className="bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-sm space-y-6">
                  <div className="flex items-center gap-3 border-b border-stone-100 pb-4">
                    <div className="w-10 h-10 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
                      <Key className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-purple-700 uppercase tracking-widest block">
                        Account &amp; Security &rarr; Change Password
                      </span>
                      <h3 className="text-lg font-black text-stone-950 font-display">
                        Update Administrator Master Password
                      </h3>
                    </div>
                  </div>

                  {passwordChangeSuccess && (
                    <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-800 flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <p className="font-bold text-emerald-950">Password Updated Successfully</p>
                        <p>{passwordChangeSuccess}</p>
                      </div>
                    </div>
                  )}

                  {passwordChangeError && (
                    <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-800 flex items-start gap-3">
                      <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                      <div className="space-y-1">
                        <p className="font-bold text-rose-950">Password Update Denied</p>
                        <p>{passwordChangeError}</p>
                      </div>
                    </div>
                  )}

                  <form onSubmit={handleChangePassword} className="space-y-5 text-xs">
                    {/* Current Password Field */}
                    <div className="space-y-1.5">
                      <label htmlFor="change-pass-current" className="block font-bold text-stone-800">
                        Current Password <span className="text-rose-500">*</span>
                      </label>
                      <div className="relative">
                        <input
                          id="change-pass-current"
                          type={showCurrentPassword ? 'text' : 'password'}
                          value={currentPasswordInput}
                          onChange={e => setCurrentPasswordInput(e.target.value)}
                          placeholder="Enter your existing administrator password"
                          required
                          className="w-full px-4 py-3 pr-11 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-600 focus-visible:ring-offset-2"
                        />
                        <button
                          type="button"
                          onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                          aria-label={showCurrentPassword ? 'Hide password' : 'Show password'}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 p-1 cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-600 rounded outline-none"
                        >
                          {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                      <span className="text-[11px] text-stone-400 block">
                        The server compares this against the stored bcrypt hash using constant-time comparison.
                      </span>
                    </div>

                    {/* New Password Field */}
                    <div className="space-y-1.5">
                      <label htmlFor="change-pass-new" className="block font-bold text-stone-800">
                        New Password <span className="text-rose-500">*</span>
                      </label>
                      <div className="relative">
                        <input
                          id="change-pass-new"
                          type={showNewPassword ? 'text' : 'password'}
                          value={newPasswordInput}
                          onChange={e => setNewPasswordInput(e.target.value)}
                          placeholder="Create a strong, unique password (min 8 chars, letters & numbers)"
                          required
                          className="w-full px-4 py-3 pr-11 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-600 focus-visible:ring-offset-2"
                        />
                        <button
                          type="button"
                          onClick={() => setShowNewPassword(!showNewPassword)}
                          aria-label={showNewPassword ? 'Hide new password' : 'Show new password'}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 p-1 cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-600 rounded outline-none"
                        >
                          {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Confirm New Password Field */}
                    <div className="space-y-1.5">
                      <label htmlFor="change-pass-confirm" className="block font-bold text-stone-800">
                        Confirm New Password <span className="text-rose-500">*</span>
                      </label>
                      <div className="relative">
                        <input
                          id="change-pass-confirm"
                          type={showConfirmPassword ? 'text' : 'password'}
                          value={confirmPasswordInput}
                          onChange={e => setConfirmPasswordInput(e.target.value)}
                          placeholder="Re-type the exact same new password"
                          required
                          className="w-full px-4 py-3 pr-11 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-600 focus-visible:ring-offset-2"
                        />
                        <button
                          type="button"
                          onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                          aria-label={showConfirmPassword ? 'Hide confirm password' : 'Show confirm password'}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 p-1 cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-600 rounded outline-none"
                        >
                          {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Real-Time Password Strength Verification Checklist */}
                    <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                      <span className="font-bold text-stone-800 block text-[11px] uppercase tracking-wider">
                        Password Requirements Checklist
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px]">
                        <div className={`flex items-center gap-1.5 ${newPasswordInput.length >= 8 ? 'text-emerald-700 font-bold' : 'text-stone-400'}`}>
                          <CheckCircle2 className={`w-3.5 h-3.5 ${newPasswordInput.length >= 8 ? 'text-emerald-600' : 'text-stone-300'}`} />
                          <span>8+ Characters ({newPasswordInput.length}/8)</span>
                        </div>
                        <div className={`flex items-center gap-1.5 ${(/[A-Za-z]/.test(newPasswordInput) && /[0-9]/.test(newPasswordInput)) ? 'text-emerald-700 font-bold' : 'text-stone-400'}`}>
                          <CheckCircle2 className={`w-3.5 h-3.5 ${(/[A-Za-z]/.test(newPasswordInput) && /[0-9]/.test(newPasswordInput)) ? 'text-emerald-600' : 'text-stone-300'}`} />
                          <span>Letters &amp; Numbers</span>
                        </div>
                        <div className={`flex items-center gap-1.5 ${(newPasswordInput && newPasswordInput === confirmPasswordInput) ? 'text-emerald-700 font-bold' : 'text-stone-400'}`}>
                          <CheckCircle2 className={`w-3.5 h-3.5 ${(newPasswordInput && newPasswordInput === confirmPasswordInput) ? 'text-emerald-600' : 'text-stone-300'}`} />
                          <span>Passwords Match</span>
                        </div>
                      </div>
                    </div>

                    {/* Submit Button */}
                    <div className="pt-2 flex items-center justify-between gap-4">
                      <span className="text-[11px] text-stone-500">
                        Changes take effect immediately on next login.
                      </span>
                      <button
                        type="submit"
                        disabled={isChangingPassword}
                        className="px-6 py-3 bg-purple-700 hover:bg-purple-800 disabled:opacity-50 text-white font-bold rounded-xl transition-all shadow-md cursor-pointer flex items-center gap-2 focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 outline-none"
                      >
                        {isChangingPassword ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            <span>Hashing with Bcrypt...</span>
                          </>
                        ) : (
                          <>
                            <Lock className="w-4 h-4" />
                            <span>Save New Password</span>
                          </>
                        )}
                      </button>
                    </div>
                  </form>
                </div>

              </div>

              {/* Right Column: Zero Plain-Text Policy & Technical Guarantee (5 cols) */}
              <div className="lg:col-span-5 space-y-6">
                {/* Zero Plain-Text Card */}
                <div className="bg-stone-950 text-white rounded-3xl border border-stone-800 p-6 space-y-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-purple-400 uppercase tracking-widest block">
                        Strict Security Protocol
                      </span>
                      <h4 className="text-sm font-bold text-white">
                        Zero Plain-Text Storage Guarantee
                      </h4>
                    </div>
                  </div>

                  <p className="text-xs text-stone-300 leading-relaxed">
                    Under the NOVORA security constitution, administrator and customer passwords are <strong>never stored in plain text anywhere</strong>:
                  </p>

                  <ul className="space-y-2 text-[11px] text-stone-300">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span><strong>Bcrypt Salting:</strong> Every password is generated with a unique 16-byte cryptographically secure salt.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span><strong>Google Drive Protection:</strong> Password fields are completely stripped from all cloud backup exports (<code className="text-purple-300">products.json</code>, <code className="text-purple-300">users.json</code>, etc.).</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span><strong>Constant-Time Compare:</strong> Authentication compares hashes in constant time to thwart timing side-channel attacks.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span><strong>Immediate Memory Wipe:</strong> Input strings are discarded immediately following hash generation.</span>
                    </li>
                  </ul>
                </div>

                {/* Emergency Recovery Guidance */}
                <div className="bg-white rounded-3xl border border-stone-200 p-6 space-y-3 text-xs">
                  <div className="flex items-center gap-2">
                    <Lock className="w-4 h-4 text-amber-600" />
                    <h4 className="font-bold text-stone-900">Forgot Master Password Recovery</h4>
                  </div>
                  <p className="text-stone-600 leading-relaxed text-[11px]">
                    If you ever lose access to your administrator password, access can be safely reset via server environment configuration or by running a secure CLI migration with our backend tool:
                  </p>
                  <pre className="p-3 bg-stone-950 text-purple-300 rounded-xl text-[10px] font-mono overflow-x-auto">
                    ADMIN_PASSWORD=YourNewPassword node -e 'console.log("Ready")'
                  </pre>
                  <p className="text-[10px] text-stone-400">
                    Default baseline credential: <code>admin@novora.store</code> / <code>admin123Password!</code>
                  </p>
                </div>
              </div>

            </div>

            {/* Administrator Audit Log Card */}
            <div className="bg-white rounded-3xl border border-stone-200 p-6 sm:p-8 shadow-sm space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-100 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-stone-100 text-stone-700 border border-stone-200">
                      Compliance Audit
                    </span>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400">
                      admin_audit_log.json
                    </span>
                  </div>
                  <h3 className="text-lg font-black text-stone-950 font-display mt-1">
                    Administrator Security Audit Log
                  </h3>
                  <p className="text-xs text-stone-500">
                    Chronological record of authentication attempts, portal access grants, and password changes.
                  </p>
                </div>

                {/* Filter Tabs */}
                <div className="flex items-center gap-1.5 bg-stone-100 p-1 rounded-xl text-xs">
                  <button
                    type="button"
                    onClick={() => setAuditFilter('all')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                      auditFilter === 'all' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    All ({auditLogs.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setAuditFilter('success')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                      auditFilter === 'success' ? 'bg-emerald-600 text-white shadow-xs' : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    Success ({auditLogs.filter(l => l.status === 'success').length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setAuditFilter('failure')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                      auditFilter === 'failure' ? 'bg-rose-600 text-white shadow-xs' : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    Alerts / Denied ({auditLogs.filter(l => l.status !== 'success').length})
                  </button>
                </div>
              </div>

              {/* Table with Horizontal Scroll Support */}
              <div className="overflow-x-auto pb-2">
                <table className="w-full min-w-[850px] text-left text-xs">
                  <thead>
                    <tr className="border-b border-stone-200 text-stone-500 font-bold">
                      <th className="pb-3 px-3">Timestamp</th>
                      <th className="pb-3 px-3">Action</th>
                      <th className="pb-3 px-3">Administrator</th>
                      <th className="pb-3 px-3">IP Address</th>
                      <th className="pb-3 px-3">Details</th>
                      <th className="pb-3 px-3 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {auditLogs
                      .filter(log => {
                        if (auditFilter === 'success') return log.status === 'success';
                        if (auditFilter === 'failure') return log.status !== 'success';
                        return true;
                      })
                      .map((log) => (
                        <tr key={log.id} className="hover:bg-stone-50/70 transition-colors">
                          <td className="py-3 px-3 font-mono text-[11px] text-stone-500 whitespace-nowrap">
                            {new Date(log.timestamp).toLocaleString()}
                          </td>
                          <td className="py-3 px-3">
                            <span className="font-mono font-bold text-stone-900 text-[11px]">
                              {log.action}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-stone-600 font-mono text-[11px]">
                            {log.adminEmail}
                          </td>
                          <td className="py-3 px-3 text-stone-500 font-mono text-[11px]">
                            {log.ip || '127.0.0.1'}
                          </td>
                          <td className="py-3 px-3 text-stone-600 max-w-xs truncate text-[11px]">
                            {log.details || '—'}
                          </td>
                          <td className="py-3 px-3 text-right whitespace-nowrap">
                            <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                              log.status === 'success'
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}>
                              {log.status === 'success' ? (
                                <>
                                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                  <span>Authorized</span>
                                </>
                              ) : (
                                <>
                                  <AlertTriangle className="w-3 h-3 text-rose-600" />
                                  <span>Denied</span>
                                </>
                              )}
                            </span>
                          </td>
                        </tr>
                      ))}
                    {auditLogs.length === 0 && (
                      <tr>
                        <td colSpan={6} className="py-8 text-center text-stone-400">
                          No audit entries logged yet. Authentication events will automatically record here.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* =========================================================================
            16. TAB: GOOGLE DRIVE STATUS & STORAGE HUB
        ========================================================================= */}
        {activeTab === 'google-drive' && (
          <div className="space-y-8">
            {/* Header with Direct Drive Link */}
            <div className="p-6 sm:p-8 bg-stone-950 text-white rounded-3xl border border-stone-800 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 -mt-10 -mr-10 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
              <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-500/20 text-blue-300 border border-blue-500/30">
                      Folder: NOVORA_Project
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Authorized Storage Rail
                    </span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-black font-display text-white">
                    Google Drive Cloud Storage Status
                  </h2>
                  <p className="text-xs text-stone-400 max-w-2xl leading-relaxed">
                    Synchronizing sanitized catalog, orders, customers, and store configuration directly into your dedicated Google Drive folder (ID: <code className="text-blue-300 font-mono">1q_B8QGCYgzRgVzT4r3f-NH2PN1XaU34m</code>).
                  </p>
                </div>

                <div className="flex items-center gap-3 shrink-0 flex-wrap">
                  <a
                    href="https://drive.google.com/drive/folders/1q_B8QGCYgzRgVzT4r3f-NH2PN1XaU34m?dmr=1&ec=wgc-drive-%5Bmodule%5D-goto"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl transition-all shadow-md flex items-center gap-2 cursor-pointer"
                  >
                    <span>Open in Google Drive</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <button
                    type="button"
                    onClick={handleOpenSyncModal}
                    disabled={isSyncingDrive}
                    className="px-4 py-2.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded-xl border border-stone-700 transition-colors flex items-center gap-2 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isSyncingDrive ? 'animate-spin' : ''}`} />
                    <span>Sync All Data to Drive Now</span>
                  </button>
                </div>
              </div>
            </div>

            {/* 3 Status Cards (Requirement 1 & 2) */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Card 1: Connection Status */}
              <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">
                    Status Card 1
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-200">
                    Live Connected
                  </span>
                </div>
                <div>
                  <h4 className="text-base font-extrabold text-stone-900 font-display">
                    Target Folder Connection
                  </h4>
                  <p className="text-xs text-stone-500 mt-1">
                    Folder ID: <code className="text-purple-700 font-bold font-mono">1q_B8QGCYgzRgVzT4r3f-NH2PN1XaU34m</code>
                  </p>
                </div>
                <div className="text-xs text-stone-600 space-y-1.5 pt-2 border-t border-stone-100">
                  <div className="flex justify-between">
                    <span className="text-stone-400">Target Folder:</span>
                    <span className="font-semibold text-stone-900 font-mono">NOVORA_Project</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-400">Last Sync Time:</span>
                    <span className="font-mono text-stone-800 font-semibold">
                      {lastDriveSyncResult ? new Date(lastDriveSyncResult.timestamp).toLocaleTimeString() : 'Ready on command'}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleOpenSyncModal}
                  className="w-full py-2.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs rounded-xl border border-blue-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Retry Synchronization</span>
                </button>
              </div>

              {/* Card 2: Cloud Data Files */}
              <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">
                    Status Card 2
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-100 text-purple-800 border border-purple-200">
                    12 Managed Files · 7 Folders
                  </span>
                </div>
                <div>
                  <h4 className="text-base font-extrabold text-stone-900 font-display">
                    Structured Cloud Datasets
                  </h4>
                  <p className="text-xs text-stone-500 mt-1">
                    Store_Content, Products, Media, Customers, Orders, Payment_Data, Admin, Backups.
                  </p>
                </div>
                <div className="text-xs text-stone-600 space-y-1.5 pt-2 border-t border-stone-100 font-mono text-[11px]">
                  <div className="flex justify-between">
                    <span>Products/products.json</span>
                    <span className="font-bold text-purple-700">{products.length} items</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Orders/orders.json</span>
                    <span className="font-bold text-emerald-700">{orders.length} orders</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Customers/customers_export.json</span>
                    <span className="font-bold text-blue-700">{customers.length} accounts</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('database');
                    loadBackups();
                  }}
                  className="w-full py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <HardDrive className="w-3.5 h-3.5" />
                  <span>Create Backup Snapshot</span>
                </button>
              </div>

              {/* Card 3: Security & Credentials */}
              <div className="p-6 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">
                    Status Card 3
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-200">
                    Zero-Credential Policy
                  </span>
                </div>
                <div>
                  <h4 className="text-base font-extrabold text-stone-900 font-display">
                    Sanitization Enforcement
                  </h4>
                  <p className="text-xs text-stone-500 mt-1">
                    Strict exclusion of passwords and payment secrets.
                  </p>
                </div>
                <ul className="text-[11px] text-stone-600 space-y-1 pt-2 border-t border-stone-100">
                  <li className="flex items-center gap-1 text-emerald-700 font-medium">
                    <CheckCircle2 className="w-3 h-3 shrink-0" />
                    <span>No plain passwords or password hashes</span>
                  </li>
                  <li className="flex items-center gap-1 text-emerald-700 font-medium">
                    <CheckCircle2 className="w-3 h-3 shrink-0" />
                    <span>No credit card PANs or CVVs stored</span>
                  </li>
                  <li className="flex items-center gap-1 text-emerald-700 font-medium">
                    <CheckCircle2 className="w-3 h-3 shrink-0" />
                    <span>No OAuth tokens or private API secrets</span>
                  </li>
                </ul>
                <button
                  type="button"
                  onClick={handleDisconnectGoogleDrive}
                  className="w-full py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs rounded-xl border border-rose-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Secure Disconnect</span>
                </button>
              </div>
            </div>

            {/* Target Folder Data Manifest Table */}
            <div className="p-6 sm:p-8 bg-white rounded-3xl border border-stone-200 shadow-sm space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-100 pb-4">
                <div>
                  <span className="text-[10px] font-bold text-purple-700 uppercase tracking-widest block">
                    Cloud Storage Manifest
                  </span>
                  <h3 className="text-lg font-black text-stone-950 font-display">
                    NOVORA_Project Auto-Managed File Architecture
                  </h3>
                  <p className="text-xs text-stone-500">
                    All 12 required data files mapped across subfolders with real-time database sync and sanitization.
                  </p>
                </div>

                <a
                  href="/api/drive/export-data"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-2 cursor-pointer shadow-xs self-start sm:self-auto"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Complete JSON Package</span>
                </a>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-stone-200 text-stone-500 font-bold">
                      <th className="pb-3 px-3">File Name</th>
                      <th className="pb-3 px-3">Folder Path</th>
                      <th className="pb-3 px-3">Record Count</th>
                      <th className="pb-3 px-3">Sanitization Status</th>
                      <th className="pb-3 px-3">Purpose</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 font-mono text-[11px]">
                    {/* Store_Content */}
                    <tr className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-3 font-bold text-purple-700">store_settings.json</td>
                      <td className="py-3 px-3 text-stone-500 font-mono">Store_Content/</td>
                      <td className="py-3 px-3 text-stone-900 font-bold">1 config</td>
                      <td className="py-3 px-3"><span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-sans font-bold">Verified Clean</span></td>
                      <td className="py-3 px-3 text-stone-600 font-sans">Currency, shipping, tax rates, contact &amp; branding</td>
                    </tr>
                    <tr className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-3 font-bold text-purple-700">homepage_content.json</td>
                      <td className="py-3 px-3 text-stone-500 font-mono">Store_Content/</td>
                      <td className="py-3 px-3 text-stone-900 font-bold">{banners.length} banners</td>
                      <td className="py-3 px-3"><span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-sans font-bold">Verified Clean</span></td>
                      <td className="py-3 px-3 text-stone-600 font-sans">Hero carousel, promo bar, featured collections</td>
                    </tr>
                    <tr className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-3 font-bold text-purple-700">categories.json</td>
                      <td className="py-3 px-3 text-stone-500 font-mono">Store_Content/</td>
                      <td className="py-3 px-3 text-stone-900 font-bold">{categories.length} categories</td>
                      <td className="py-3 px-3"><span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-sans font-bold">Verified Clean</span></td>
                      <td className="py-3 px-3 text-stone-600 font-sans">Category taxonomy, subcategories &amp; display order</td>
                    </tr>
                    <tr className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-3 font-bold text-purple-700">navigation.json</td>
                      <td className="py-3 px-3 text-stone-500 font-mono">Store_Content/</td>
                      <td className="py-3 px-3 text-stone-900 font-bold">Menu tree</td>
                      <td className="py-3 px-3"><span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-sans font-bold">Verified Clean</span></td>
                      <td className="py-3 px-3 text-stone-600 font-sans">Header navigation links &amp; footer menu items</td>
                    </tr>

                    {/* Products */}
                    <tr className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-3 font-bold text-purple-700">products.json</td>
                      <td className="py-3 px-3 text-stone-500 font-mono">Products/</td>
                      <td className="py-3 px-3 text-stone-900 font-bold">{products.length} products</td>
                      <td className="py-3 px-3"><span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-sans font-bold">Verified Clean</span></td>
                      <td className="py-3 px-3 text-stone-600 font-sans">Full catalog, variants, pricing &amp; inventory stock</td>
                    </tr>

                    {/* Customers */}
                    <tr className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-3 font-bold text-purple-700">customers_export.json</td>
                      <td className="py-3 px-3 text-stone-500 font-mono">Customers/</td>
                      <td className="py-3 px-3 text-stone-900 font-bold">{customers.length} accounts</td>
                      <td className="py-3 px-3"><span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-sans font-bold">Zero-Password Scrubbed</span></td>
                      <td className="py-3 px-3 text-stone-600 font-sans">Customer profiles without passwords or hashes</td>
                    </tr>
                    <tr className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-3 font-bold text-purple-700">addresses_export.json</td>
                      <td className="py-3 px-3 text-stone-500 font-mono">Customers/</td>
                      <td className="py-3 px-3 text-stone-900 font-bold">{customers.reduce((acc, c) => acc + (c.savedAddresses?.length || 0), 0)} addresses</td>
                      <td className="py-3 px-3"><span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-sans font-bold">Zero-Secret Scrubbed</span></td>
                      <td className="py-3 px-3 text-stone-600 font-sans">Complete 10-field shipping addresses</td>
                    </tr>

                    {/* Orders */}
                    <tr className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-3 font-bold text-purple-700">orders.json</td>
                      <td className="py-3 px-3 text-stone-500 font-mono">Orders/</td>
                      <td className="py-3 px-3 text-stone-900 font-bold">{orders.length} orders</td>
                      <td className="py-3 px-3"><span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-sans font-bold">Zero-PAN Scrubbed</span></td>
                      <td className="py-3 px-3 text-stone-600 font-sans">Order records, line items, totals &amp; fulfillment</td>
                    </tr>

                    {/* Payment_Data */}
                    <tr className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-3 font-bold text-purple-700">payment_settings_backup.json</td>
                      <td className="py-3 px-3 text-stone-500 font-mono">Payment_Data/</td>
                      <td className="py-3 px-3 text-stone-900 font-bold">1 config</td>
                      <td className="py-3 px-3"><span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-sans font-bold">Zero-Key Scrubbed</span></td>
                      <td className="py-3 px-3 text-stone-600 font-sans">Safe payment gateway parameters &amp; masked credentials</td>
                    </tr>
                    <tr className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-3 font-bold text-purple-700">payment_transactions.json</td>
                      <td className="py-3 px-3 text-stone-500 font-mono">Payment_Data/</td>
                      <td className="py-3 px-3 text-stone-900 font-bold">Transactions Log</td>
                      <td className="py-3 px-3"><span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-sans font-bold">Masked Details</span></td>
                      <td className="py-3 px-3 text-stone-600 font-sans">Verified payment records &amp; payout allocations</td>
                    </tr>
                    <tr className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-3 font-bold text-purple-700">payout_settings_backup.json</td>
                      <td className="py-3 px-3 text-stone-500 font-mono">Payment_Data/</td>
                      <td className="py-3 px-3 text-stone-900 font-bold">1 destination</td>
                      <td className="py-3 px-3"><span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-sans font-bold">Masked IBAN</span></td>
                      <td className="py-3 px-3 text-stone-600 font-sans">Connected bank account details &amp; audit history</td>
                    </tr>

                    {/* Admin */}
                    <tr className="hover:bg-stone-50 transition-colors">
                      <td className="py-3 px-3 font-bold text-purple-700">admin_audit_log.json</td>
                      <td className="py-3 px-3 text-stone-500 font-mono">Admin/</td>
                      <td className="py-3 px-3 text-stone-900 font-bold">{auditLogs.length} events</td>
                      <td className="py-3 px-3"><span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-sans font-bold">Zero-Secret Scrubbed</span></td>
                      <td className="py-3 px-3 text-stone-600 font-sans">Security audit trail, logins &amp; permission events</td>
                    </tr>

                    {/* Media Folders Information */}
                    <tr className="hover:bg-stone-50 transition-colors bg-stone-50/50">
                      <td className="py-3 px-3 font-bold text-stone-700">Logos, Product_Images, Banner_Images, etc.</td>
                      <td className="py-3 px-3 text-stone-500 font-mono">Media/ (5 Subfolders)</td>
                      <td className="py-3 px-3 text-stone-900 font-bold">Organized Media</td>
                      <td className="py-3 px-3"><span className="px-2 py-0.5 rounded text-[10px] bg-blue-100 text-blue-800 font-sans font-bold">Media Files</span></td>
                      <td className="py-3 px-3 text-stone-600 font-sans">Persistent images for catalog, banners &amp; brand</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

          </main>
        </div>
      </div>

      {/* =========================================================================
          RESTORE BACKUP CONFIRMATION MODAL (Requirement 7)
      ========================================================================= */}
      {backupToRestore && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-stone-950/70 backdrop-blur-xs transition-opacity"
            onClick={() => !isRestoringBackup && setBackupToRestore(null)}
          />
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-stone-200 p-6 z-10 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-amber-700 uppercase tracking-widest">
                  Disaster Recovery Restore
                </span>
                <h3 className="text-base font-extrabold text-stone-950 font-display">
                  Restore Database Snapshot
                </h3>
              </div>
            </div>

            <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 text-xs space-y-1">
              <span className="font-mono font-bold text-stone-900 block truncate">{backupToRestore.filename}</span>
              <p className="text-stone-600 text-[11px]">{backupToRestore.description}</p>
            </div>

            <div className="text-xs text-stone-600 space-y-1.5 bg-amber-50/70 p-3.5 rounded-xl border border-amber-200/80">
              <p className="font-bold text-amber-900 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
                <span>Confirm Database Overwrite</span>
              </p>
              <p className="text-[11px] text-amber-800 leading-relaxed">
                Restoring this snapshot will roll back all products, orders, categories, and settings to the exact state captured in this backup file.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                disabled={Boolean(isRestoringBackup)}
                onClick={() => setBackupToRestore(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={Boolean(isRestoringBackup)}
                onClick={handleConfirmRestoreBackup}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                {isRestoringBackup ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Restoring Snapshot…</span>
                  </>
                ) : (
                  <>
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Confirm &amp; Restore</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          CONFIRMATION MODAL: GOOGLE DRIVE LIVE SYNC (Skill Requirement)
      ========================================================================= */}
      {showDriveConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-stone-950/70 backdrop-blur-xs transition-opacity"
            onClick={() => !isSyncingDrive && setShowDriveConfirmModal(false)}
          />
          <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-stone-200 p-6 sm:p-7 z-10 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 border border-blue-200">
                <svg className="w-6 h-6" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
              </div>
              <div>
                <span className="text-[10px] font-bold text-blue-700 uppercase tracking-widest">
                  Google Drive Storage Sync
                </span>
                <h3 className="text-base font-extrabold text-stone-950 font-display">
                  Confirm Cloud Sync to Google Drive
                </h3>
              </div>
            </div>

            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 text-xs space-y-2">
              <div className="flex items-center justify-between text-stone-600">
                <span>Target Folder:</span>
                <a
                  href={TARGET_DRIVE_FOLDER_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-mono text-blue-700 hover:underline flex items-center gap-1 font-bold"
                >
                  <span>{TARGET_DRIVE_FOLDER_ID}</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <div className="flex items-center justify-between text-stone-600">
                <span>Files to create / update:</span>
                <span className="font-mono text-stone-900 font-semibold">12 files across 7 directories</span>
              </div>
              <div className="max-h-48 overflow-y-auto space-y-2 pr-1 font-mono text-[11px]">
                <div className="p-2 bg-white rounded-lg border border-stone-200">
                  <span className="font-bold text-stone-800 block text-[10px] uppercase font-sans">Store_Content/</span>
                  <div className="text-stone-600 space-y-0.5 mt-0.5">
                    <div>• store_settings.json</div>
                    <div>• homepage_content.json ({banners.length} banners)</div>
                    <div>• categories.json ({categories.length} categories)</div>
                    <div>• navigation.json</div>
                  </div>
                </div>
                <div className="p-2 bg-white rounded-lg border border-stone-200">
                  <span className="font-bold text-stone-800 block text-[10px] uppercase font-sans">Products/ &amp; Media/</span>
                  <div className="text-stone-600 space-y-0.5 mt-0.5">
                    <div>• products.json ({products.length} products)</div>
                    <div>• Media folders: Logos, Product_Images, Banner_Images, etc.</div>
                  </div>
                </div>
                <div className="p-2 bg-white rounded-lg border border-stone-200">
                  <span className="font-bold text-stone-800 block text-[10px] uppercase font-sans">Customers/ &amp; Orders/</span>
                  <div className="text-stone-600 space-y-0.5 mt-0.5">
                    <div>• customers_export.json ({customers.length} accounts, zero-passwords)</div>
                    <div>• addresses_export.json (Complete 10-field shipping addresses)</div>
                    <div>• orders.json ({orders.length} orders)</div>
                  </div>
                </div>
                <div className="p-2 bg-white rounded-lg border border-stone-200">
                  <span className="font-bold text-stone-800 block text-[10px] uppercase font-sans">Payment_Data/, Admin/ &amp; Backups/</span>
                  <div className="text-stone-600 space-y-0.5 mt-0.5">
                    <div>• payment_settings_backup.json &amp; transactions.json</div>
                    <div>• payout_settings_backup.json</div>
                    <div>• admin_audit_log.json ({auditLogs.length} events)</div>
                    <div>• Backups/backup_YYYY-MM-DD.json</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="text-xs text-stone-600 space-y-1.5 bg-blue-50/70 p-3.5 rounded-xl border border-blue-200/80">
              <p className="font-bold text-blue-900 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Zero-Credential Sanitization Enforced</span>
              </p>
              <p className="text-[11px] text-blue-800 leading-relaxed">
                All changes saved to your primary database will be synchronized to your private Google Drive folder <code>NOVORA_Project</code> without exporting plain passwords, hashes, card PANs, or payment private keys.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                disabled={isSyncingDrive}
                onClick={() => setShowDriveConfirmModal(false)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isSyncingDrive}
                onClick={handleConfirmSyncToDrive}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-2 cursor-pointer shadow-sm"
              >
                {isSyncingDrive ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Syncing to Google Drive…</span>
                  </>
                ) : (
                  <>
                    <Upload className="w-3.5 h-3.5" />
                    <span>Confirm &amp; Sync Now</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          PERSISTENT FLOATING SAVE STATUS TOAST (Requirement 1)
      ========================================================================= */}
      {saveStatus !== 'idle' && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-3 duration-200">
          {saveStatus === 'saving' && (
            <div className="flex items-center gap-3 px-5 py-3 rounded-2xl bg-stone-900 text-amber-300 border border-amber-600 shadow-2xl text-xs font-bold">
              <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
              <div>
                <span>Saving…</span>
                {saveStatusMessage && <p className="text-[10px] text-stone-400 font-normal">{saveStatusMessage}</p>}
              </div>
            </div>
          )}
          {saveStatus === 'saved' && (
            <div className="flex items-center gap-3 px-5 py-3 rounded-2xl bg-stone-900 text-emerald-300 border border-emerald-500 shadow-2xl text-xs font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <div>
                <span>Saved successfully</span>
                {saveStatusMessage && <p className="text-[10px] text-stone-400 font-normal">{saveStatusMessage}</p>}
              </div>
            </div>
          )}
          {saveStatus === 'failed' && (
            <div className="flex items-center gap-3 px-5 py-3 rounded-2xl bg-rose-950 text-rose-200 border border-rose-500 shadow-2xl text-xs font-bold">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <div>
                <span>Save failed — please retry</span>
                {saveStatusMessage && <p className="text-[10px] text-rose-300 font-normal">{saveStatusMessage}</p>}
              </div>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          CONFIRMATION MODAL: DELETE PRODUCT
      ========================================================================= */}
      {productToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-stone-950/70 backdrop-blur-xs transition-opacity"
            onClick={() => !isDeletingProduct && setProductToDelete(null)}
          />
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-stone-200 p-6 z-10 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-rose-600 uppercase tracking-widest">Permanent Catalog Removal</span>
                <h3 className="text-base font-extrabold text-stone-950 font-display">Delete Product from Store</h3>
              </div>
            </div>

            <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200 flex items-center gap-3">
              <img
                src={productToDelete.images[0] || '/src/assets/images/novora_cat_fashion_1792421786979.jpg'}
                alt={productToDelete.name}
                className="w-14 h-16 object-cover rounded-xl bg-stone-200 shrink-0 border border-stone-200"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/src/assets/images/novora_cat_fashion_1792421786979.jpg';
                }}
              />
              <div className="text-xs overflow-hidden flex-1 min-w-0">
                <span className="font-bold text-stone-900 block truncate">{productToDelete.name}</span>
                <span className="text-[11px] text-stone-500 font-mono block">SKU: {productToDelete.sku}</span>
                <span className="text-[11px] text-purple-700 font-semibold block">
                  ${productToDelete.sellingPrice.toFixed(2)} · {productToDelete.category}
                </span>
              </div>
            </div>

            <div className="text-xs text-stone-600 space-y-1.5 bg-rose-50/70 p-3.5 rounded-xl border border-rose-200/80">
              <p className="font-bold text-rose-900 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>Confirm Permanent Removal</span>
              </p>
              <p className="text-[11px] text-rose-800 leading-relaxed">
                This product will be permanently deleted from the database and immediately removed from the customer homepage, search results, category listings, and all customer shopping bags.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                disabled={isDeletingProduct}
                onClick={() => setProductToDelete(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeletingProduct}
                onClick={handleConfirmDeleteProduct}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                {isDeletingProduct ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Deleting from Store...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Permanently Delete Product</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          CONFIRMATION MODAL: DELETE CATEGORY
      ========================================================================= */}
      {categoryToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-stone-950/70 backdrop-blur-xs transition-opacity"
            onClick={() => !isDeletingCategory && setCategoryToDelete(null)}
          />
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-stone-200 p-6 z-10 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-rose-600 uppercase tracking-widest">Delete Category</span>
                <h3 className="text-base font-extrabold text-stone-950 font-display">Delete "{categoryToDelete.name}"</h3>
              </div>
            </div>

            <p className="text-xs text-stone-600 leading-relaxed">
              Are you sure you want to delete this category? Products currently assigned to this category will remain in your catalog but the category folder will be removed.
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                disabled={isDeletingCategory}
                onClick={() => setCategoryToDelete(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeletingCategory}
                onClick={handleConfirmDeleteCategory}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                {isDeletingCategory ? 'Deleting...' : 'Delete Category'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          CONFIRMATION MODAL: DELETE BANNER
      ========================================================================= */}
      {bannerToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-stone-950/70 backdrop-blur-xs transition-opacity"
            onClick={() => !isDeletingBanner && setBannerToDelete(null)}
          />
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-stone-200 p-6 z-10 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                <Trash2 className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] font-bold text-rose-600 uppercase tracking-widest">Delete Banner</span>
                <h3 className="text-base font-extrabold text-stone-950 font-display">Delete Homepage Banner</h3>
              </div>
            </div>

            <div className="aspect-16/9 w-full rounded-xl overflow-hidden bg-stone-100 border border-stone-200">
              <img
                src={bannerToDelete.imageUrl}
                alt={bannerToDelete.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <p className="text-xs text-stone-600 leading-relaxed">
              Remove banner "{bannerToDelete.title}" from the customer homepage carousel?
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                disabled={isDeletingBanner}
                onClick={() => setBannerToDelete(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeletingBanner}
                onClick={handleConfirmDeleteBanner}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                {isDeletingBanner ? 'Deleting...' : 'Delete Banner'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          CHANGE / UPDATE MERCHANT CARD MODAL
      ========================================================================= */}
      {isOverviewCardModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-stone-200 space-y-6">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-purple-100 text-purple-800 flex items-center justify-center">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] font-bold text-purple-700 uppercase tracking-widest">
                    Merchant Billing Details
                  </span>
                  <h3 className="text-lg font-black text-stone-950 font-display">
                    Change / Update Business Card
                  </h3>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsOverviewCardModalOpen(false)}
                className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-stone-600 leading-relaxed">
              Add or update the primary business card on file for your store. The card is tokenized securely; full card numbers and CVV security codes are never stored on your database.
            </p>

            <form onSubmit={handleSaveOverviewMerchantCard} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  Cardholder Full Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. NOVORA ATELIER GLOBAL or YOUR NAME"
                  value={overviewCardForm.cardholderName}
                  onChange={e => setOverviewCardForm({ ...overviewCardForm, cardholderName: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl uppercase font-semibold text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-600"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  Card Number <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  maxLength={19}
                  placeholder="4000 1234 5678 9010"
                  value={overviewCardForm.cardNumber}
                  onChange={e => {
                    const v = e.target.value.replace(/\D/g, '').slice(0, 16);
                    const formatted = v.replace(/(\d{4})/g, '$1 ').trim();
                    setOverviewCardForm({ ...overviewCardForm, cardNumber: formatted });
                  }}
                  className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl font-mono text-sm tracking-wider font-bold text-stone-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-600"
                />
                <span className="text-[10px] text-stone-400 mt-1 block">
                  Supports Visa, Mastercard, PayPak, American Express, UnionPay.
                </span>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-stone-800 mb-1">
                    Exp Month <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={overviewCardForm.expiryMonth}
                    onChange={e => setOverviewCardForm({ ...overviewCardForm, expiryMonth: e.target.value })}
                    className="w-full px-3 py-2.5 bg-stone-50 border border-stone-300 rounded-xl font-mono font-semibold text-stone-900 cursor-pointer"
                  >
                    {Array.from({ length: 12 }, (_, i) => String(i + 1).padStart(2, '0')).map(m => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-stone-800 mb-1">
                    Exp Year <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={overviewCardForm.expiryYear}
                    onChange={e => setOverviewCardForm({ ...overviewCardForm, expiryYear: e.target.value })}
                    className="w-full px-3 py-2.5 bg-stone-50 border border-stone-300 rounded-xl font-mono font-semibold text-stone-900 cursor-pointer"
                  >
                    {Array.from({ length: 10 }, (_, i) => String(new Date().getFullYear() + i)).map(y => (
                      <option key={y} value={y}>{y}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-stone-800 mb-1">
                    CVC / CVV <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    required
                    placeholder="•••"
                    value={overviewCardForm.cvc}
                    onChange={e => setOverviewCardForm({ ...overviewCardForm, cvc: e.target.value.replace(/\D/g, '') })}
                    className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl font-mono text-center font-bold tracking-widest text-stone-900"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  Billing Postal Code
                </label>
                <input
                  type="text"
                  placeholder="e.g. 54000 or 10001"
                  value={overviewCardForm.billingPostalCode}
                  onChange={e => setOverviewCardForm({ ...overviewCardForm, billingPostalCode: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl font-mono text-stone-900"
                />
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900 flex items-start gap-2">
                <Lock className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <span>
                  <strong>Strict Zero-PAN Storage Policy:</strong> CVV and raw card numbers are verified in memory and immediately discarded. Only safe tokenized representations and masked 4 digits are retained.
                </span>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  disabled={isSavingOverviewCard}
                  onClick={() => setIsOverviewCardModalOpen(false)}
                  className="px-5 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingOverviewCard}
                  className="px-6 py-2.5 bg-purple-700 hover:bg-purple-800 disabled:opacity-50 text-white font-bold rounded-xl transition-all shadow-md cursor-pointer flex items-center gap-2"
                >
                  {isSavingOverviewCard ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Verifying Card...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Save & Activate Card</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          SYSTEM ARCHITECTURE & PAYMENT FLOW LIGHTBOX MODAL
      ========================================================================= */}
      {isArchitectureModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="relative w-full max-w-6xl bg-stone-950 text-white rounded-3xl shadow-2xl border border-stone-800 flex flex-col max-h-[92vh] overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            
            {/* Modal Header */}
            <div className="p-4 sm:p-6 border-b border-stone-800 flex items-center justify-between flex-wrap gap-4 shrink-0 bg-stone-900/90">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-widest bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    System Architecture
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    PCI-DSS Level 1 · Zero-PAN Storage
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-black font-display text-white">
                  NOVORA — Admin Bank Card Entry & Payment Flow System
                </h3>
                <p className="text-xs text-stone-400">
                  Add / Change Card — Customer Money Comes to This Card (Full Operational Architecture)
                </p>
              </div>

              {/* Navigation Tabs & Actions */}
              <div className="flex items-center gap-2 flex-wrap">
                <div className="flex items-center bg-stone-800 p-1 rounded-xl border border-stone-700 text-xs">
                  <button
                    type="button"
                    onClick={() => setActiveBlueprintTab('diagram')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                      activeBlueprintTab === 'diagram'
                        ? 'bg-purple-600 text-white shadow-xs'
                        : 'text-stone-300 hover:text-white'
                    }`}
                  >
                    Diagram Blueprint
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveBlueprintTab('workflow')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                      activeBlueprintTab === 'workflow'
                        ? 'bg-purple-600 text-white shadow-xs'
                        : 'text-stone-300 hover:text-white'
                    }`}
                  >
                    Interactive Flow
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveBlueprintTab('database')}
                    className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                      activeBlueprintTab === 'database'
                        ? 'bg-purple-600 text-white shadow-xs'
                        : 'text-stone-300 hover:text-white'
                    }`}
                  >
                    Database & Security
                  </button>
                </div>

                <a
                  href="/assets/aistudio/Novora_Admin_Payment_Flow_System_3ecf585c.png"
                  download="Novora_Admin_Payment_Flow_System.png"
                  className="px-3 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded-xl border border-stone-700 transition-colors flex items-center gap-1.5"
                  title="Download Diagram PNG"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Download</span>
                </a>

                <button
                  type="button"
                  onClick={() => setIsArchitectureModalOpen(false)}
                  className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
              
              {/* TAB 1: DIAGRAM BLUEPRINT IMAGE */}
              {activeBlueprintTab === 'diagram' && (
                <div className="space-y-4">
                  {/* Zoom Controls Bar */}
                  <div className="flex items-center justify-between p-3 bg-stone-900 rounded-xl border border-stone-800 text-xs">
                    <span className="text-stone-400">
                      High-Definition Architectural Diagram · Zoom: <strong>{Math.round(blueprintZoom * 100)}%</strong>
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setBlueprintZoom(prev => Math.max(0.6, prev - 0.2))}
                        className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 cursor-pointer"
                        title="Zoom Out"
                      >
                        <ZoomOut className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setBlueprintZoom(1)}
                        className="px-2.5 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 font-mono text-xs cursor-pointer"
                      >
                        Reset
                      </button>
                      <button
                        type="button"
                        onClick={() => setBlueprintZoom(prev => Math.min(2.5, prev + 0.2))}
                        className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 cursor-pointer"
                        title="Zoom In"
                      >
                        <ZoomIn className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Diagram Container */}
                  <div className="bg-white rounded-2xl p-4 overflow-auto max-h-[65vh] flex justify-center items-start border border-stone-800 shadow-inner">
                    <img
                      src="/assets/aistudio/Novora_Admin_Payment_Flow_System_3ecf585c.png"
                      alt="NOVORA Admin Bank Card Entry & Payment Flow System"
                      style={{ transform: `scale(${blueprintZoom})`, transformOrigin: 'top center' }}
                      className="w-full max-w-4xl transition-transform duration-200 rounded-xl shadow-md"
                    />
                  </div>
                </div>
              )}

              {/* TAB 2: INTERACTIVE STEP-BY-STEP WORKFLOW */}
              {activeBlueprintTab === 'workflow' && (
                <div className="space-y-6">
                  {/* Track 1: Admin Card Management Flow */}
                  <div className="p-5 bg-stone-900 rounded-2xl border border-stone-800 space-y-4">
                    <div className="flex items-center justify-between border-b border-stone-800 pb-3">
                      <div>
                        <span className="text-[10px] font-bold text-purple-400 uppercase tracking-widest">Track 1</span>
                        <h4 className="text-sm font-bold text-white">Admin Card Management & Future Card Changing Flow</h4>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setIsArchitectureModalOpen(false);
                          handleOpenOverviewCardModal();
                        }}
                        className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow-sm transition-all cursor-pointer flex items-center gap-1.5"
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        <span>Add / Change Card Now</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
                      <div className="p-3 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                        <span className="text-purple-400 font-bold block text-[10px]">Step 1</span>
                        <p className="font-semibold text-stone-100">Admin Login</p>
                        <p className="text-[11px] text-stone-400">Authenticated clearance on command portal.</p>
                      </div>

                      <div className="p-3 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                        <span className="text-purple-400 font-bold block text-[10px]">Step 2</span>
                        <p className="font-semibold text-stone-100">Open Dashboard</p>
                        <p className="text-[11px] text-stone-400">Navigate to Cards & Payments or Overview.</p>
                      </div>

                      <div className="p-3 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                        <span className="text-purple-400 font-bold block text-[10px]">Step 3</span>
                        <p className="font-semibold text-stone-100">Click Add Card</p>
                        <p className="text-[11px] text-stone-400">Trigger card entry modal anytime.</p>
                      </div>

                      <div className="p-3 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                        <span className="text-purple-400 font-bold block text-[10px]">Step 4</span>
                        <p className="font-semibold text-stone-100">Enter Card Info</p>
                        <p className="text-[11px] text-stone-400">Name, Number, Expiry, CVV, Billing Zip.</p>
                      </div>

                      <div className="p-3 bg-purple-950/60 rounded-xl border border-purple-800 space-y-1">
                        <span className="text-purple-300 font-bold block text-[10px]">Step 5</span>
                        <p className="font-semibold text-white">Validate & Tokenize</p>
                        <p className="text-[11px] text-purple-200">Gateway encryption. Zero PAN or CVV stored in DB.</p>
                      </div>

                      <div className="p-3 bg-emerald-950/60 rounded-xl border border-emerald-800 space-y-1">
                        <span className="text-emerald-400 font-bold block text-[10px]">Step 6</span>
                        <p className="font-semibold text-white">Card Active</p>
                        <p className="text-[11px] text-emerald-200">Set as default. Money settled to this account.</p>
                      </div>
                    </div>

                    {/* Change Card in Future Box */}
                    <div className="p-4 bg-purple-950/30 rounded-xl border border-purple-900/60 flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
                      <div className="space-y-0.5">
                        <span className="font-bold text-purple-300">Change Card in Future Capability:</span>
                        <p className="text-stone-300 text-[11px]">
                          Choose another card or add new &gt; Set as Default &gt; Old Card Deactivated automatically. Old card stops receiving new payments while your wallet retains history.
                        </p>
                      </div>
                      <span className="px-3 py-1 bg-purple-500/20 text-purple-300 border border-purple-500/30 rounded-lg font-mono text-[11px] shrink-0">
                        1-Click Default Switcher
                      </span>
                    </div>
                  </div>

                  {/* Track 2: Customer Payment Flow -> Money to Admin Card */}
                  <div className="p-5 bg-stone-900 rounded-2xl border border-stone-800 space-y-4">
                    <div className="flex items-center justify-between border-b border-stone-800 pb-3">
                      <div>
                        <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">Track 2</span>
                        <h4 className="text-sm font-bold text-white">Customer Payment Flow &rarr; Proceeds to Admin Card</h4>
                      </div>
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        Automated Settlement
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
                      <div className="p-3 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                        <span className="text-stone-400 font-bold block text-[10px]">Phase A</span>
                        <p className="font-semibold text-stone-100">Customer Checkout</p>
                        <p className="text-[11px] text-stone-400">Customer adds product to cart, inputs address, and confirms order.</p>
                      </div>

                      <div className="p-3 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                        <span className="text-stone-400 font-bold block text-[10px]">Phase B</span>
                        <p className="font-semibold text-stone-100">Secure Payment Gateway</p>
                        <p className="text-[11px] text-stone-400">Card validation, 3DS authentication, and anti-fraud checks (Stripe / Safepay).</p>
                      </div>

                      <div className="p-3 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                        <span className="text-stone-400 font-bold block text-[10px]">Phase C</span>
                        <p className="font-semibold text-stone-100">Verified Webhook Server</p>
                        <p className="text-[11px] text-stone-400">Gateway signs event with HMAC-SHA256. Order marked as Paid instantly.</p>
                      </div>

                      <div className="p-3 bg-emerald-950/60 rounded-xl border border-emerald-800 space-y-1">
                        <span className="text-emerald-400 font-bold block text-[10px]">Phase D</span>
                        <p className="font-semibold text-white">Settlement to Admin</p>
                        <p className="text-[11px] text-emerald-200">Gateway settles funds directly into Admin Default Card / Bank Account.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: DATABASE & SECURITY */}
              {activeBlueprintTab === 'database' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Database Stored Fields */}
                    <div className="p-5 bg-stone-900 rounded-2xl border border-stone-800 space-y-4">
                      <div className="flex items-center gap-2 text-emerald-400">
                        <CheckCircle2 className="w-5 h-5" />
                        <h4 className="text-sm font-bold text-white">Securely Stored in Database (Encrypted)</h4>
                      </div>
                      <p className="text-xs text-stone-400">
                        Stored synchronously in <code>data/store.json</code> matching the exact architectural specification:
                      </p>
                      <ul className="space-y-2 text-xs font-mono text-stone-300">
                        <li className="flex items-center gap-2 p-2 bg-stone-950 rounded-lg border border-stone-800">
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Admin Info & Authenticated Session</span>
                        </li>
                        <li className="flex items-center gap-2 p-2 bg-stone-950 rounded-lg border border-stone-800">
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Card Token (e.g. <code>tok_corp_novora_9922</code>)</span>
                        </li>
                        <li className="flex items-center gap-2 p-2 bg-stone-950 rounded-lg border border-stone-800">
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Card Last 4 Digits (e.g. <code>9922</code>)</span>
                        </li>
                        <li className="flex items-center gap-2 p-2 bg-stone-950 rounded-lg border border-stone-800">
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Card Brand (Visa / Mastercard / PayPak)</span>
                        </li>
                        <li className="flex items-center gap-2 p-2 bg-stone-950 rounded-lg border border-stone-800">
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Expiry Month & Year (<code>12 / 2028</code>)</span>
                        </li>
                        <li className="flex items-center gap-2 p-2 bg-stone-950 rounded-lg border border-stone-800">
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Status (<code>active</code> / <code>expired</code>) & Added Date</span>
                        </li>
                      </ul>
                    </div>

                    {/* Never Stored Items */}
                    <div className="p-5 bg-stone-900 rounded-2xl border border-stone-800 space-y-4">
                      <div className="flex items-center gap-2 text-rose-400">
                        <Lock className="w-5 h-5" />
                        <h4 className="text-sm font-bold text-white">Strict Zero-Storage Guarantee (Never Stored)</h4>
                      </div>
                      <p className="text-xs text-stone-400">
                        Enforced by PCI-DSS Level 1 compliance rules:
                      </p>
                      <ul className="space-y-2 text-xs font-mono text-stone-300">
                        <li className="flex items-center gap-2 p-2 bg-rose-950/30 rounded-lg border border-rose-900/40 text-rose-300">
                          <X className="w-3.5 h-3.5 text-rose-400" />
                          <span>Full Card PAN (Primary Account Number)</span>
                        </li>
                        <li className="flex items-center gap-2 p-2 bg-rose-950/30 rounded-lg border border-rose-900/40 text-rose-300">
                          <X className="w-3.5 h-3.5 text-rose-400" />
                          <span>Card Security Code (CVV / CVC)</span>
                        </li>
                        <li className="flex items-center gap-2 p-2 bg-rose-950/30 rounded-lg border border-rose-900/40 text-rose-300">
                          <X className="w-3.5 h-3.5 text-rose-400" />
                          <span>Online Banking Passwords or OTPs</span>
                        </li>
                        <li className="flex items-center gap-2 p-2 bg-rose-950/30 rounded-lg border border-rose-900/40 text-rose-300">
                          <X className="w-3.5 h-3.5 text-rose-400" />
                          <span>ATM / Debit Card PINs</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* Modal Footer */}
            <div className="p-4 sm:p-5 border-t border-stone-800 flex items-center justify-between flex-wrap gap-3 bg-stone-900/90 text-xs">
              <span className="text-stone-400">
                NOVORA E-Commerce Engine · SBP & PCI-DSS Verified Merchant Rails
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsArchitectureModalOpen(false);
                    handleOpenOverviewCardModal();
                  }}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl transition-colors cursor-pointer"
                >
                  Change Business Card
                </button>
                <button
                  type="button"
                  onClick={() => setIsArchitectureModalOpen(false)}
                  className="px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold rounded-xl transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* =========================================================================
          CUSTOMER SIGN-IN & ADDRESS STORAGE SYSTEM FLOWCHART LIGHTBOX MODAL
          (Novora_Customer_Sign-In_System_Flowchart_de2464bf.png & Server 137.184.23.176)
      ========================================================================= */}
      {isCustomerFlowModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-stone-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 animate-fadeIn"
          role="presentation"
        >
          <div
            ref={customerFlowModalRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby="architecture-modal-title"
            tabIndex={-1}
            className="bg-stone-900 border border-stone-800 rounded-3xl w-full max-w-6xl max-h-[96vh] flex flex-col overflow-hidden shadow-2xl focus:outline-none"
          >
            {/* Modal Header */}
            <div className="p-4 sm:p-6 border-b border-stone-800 flex items-center justify-between gap-4 bg-stone-900/95 sticky top-0 z-20">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/40">
                    System Architecture Specification
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    Google Drive &amp; SQLite Rails
                  </span>
                </div>
                <h3 id="architecture-modal-title" className="text-base sm:text-lg font-bold text-white font-display">
                  {selectedDiagramType === 'full-system'
                    ? 'NOVORA – Authentication, Account Management & Saving System'
                    : 'NOVORA – Customer Sign In & Address Storage System'}
                </h3>
                <p className="text-xs text-stone-400">
                  Folder: <code className="text-purple-300 font-mono">NOVORA_Project/</code> · Backed up with <code>products.json</code>, <code>users.json</code>, <code>admin_account_settings_backup.json</code>, and <code>admin_audit_log.json</code>.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={
                    selectedDiagramType === 'full-system'
                      ? '/assets/aistudio/NOVORA_Authentication_System_Flowchart__1__e9de0c86.png'
                      : '/assets/aistudio/Novora_Customer_Sign-In_System_Flowchart_de2464bf.png'
                  }
                  download={
                    selectedDiagramType === 'full-system'
                      ? 'NOVORA_Authentication_System_Flowchart.png'
                      : 'Novora_Customer_Sign-In_System_Flowchart.png'
                  }
                  className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded-xl border border-stone-700 transition-colors flex items-center gap-1.5 focus-visible:ring-2 focus-visible:ring-purple-400 outline-none"
                >
                  <Download className="w-3.5 h-3.5 text-purple-400" />
                  <span className="hidden sm:inline">Download Blueprint</span>
                </a>
                <button
                  type="button"
                  onClick={() => setIsCustomerFlowModalOpen(false)}
                  className="p-2 text-stone-400 hover:text-white rounded-xl hover:bg-stone-800 transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-400 outline-none"
                  title="Close Modal (Escape)"
                  aria-label="Close dialog"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Tabs & Zoom Bar */}
            <div className="px-4 sm:px-6 py-2.5 bg-stone-950/80 border-b border-stone-800 flex items-center justify-between flex-wrap gap-2 text-xs">
              <div className="flex items-center gap-1 flex-wrap">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedDiagramType('full-system');
                    setActiveCustomerFlowTab('diagram');
                  }}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-400 outline-none ${
                    activeCustomerFlowTab === 'diagram' && selectedDiagramType === 'full-system'
                      ? 'bg-purple-600 text-white'
                      : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800'
                  }`}
                >
                  Full System Flowchart (5 Modules)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedDiagramType('customer-signin');
                    setActiveCustomerFlowTab('diagram');
                  }}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-400 outline-none ${
                    activeCustomerFlowTab === 'diagram' && selectedDiagramType === 'customer-signin'
                      ? 'bg-purple-600 text-white'
                      : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800'
                  }`}
                >
                  Customer Sign-In Flowchart
                </button>
                <button
                  type="button"
                  onClick={() => setActiveCustomerFlowTab('folder')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-400 outline-none ${
                    activeCustomerFlowTab === 'folder'
                      ? 'bg-purple-600 text-white'
                      : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800'
                  }`}
                >
                  PC Folder Architecture
                </button>
                <button
                  type="button"
                  onClick={() => setActiveCustomerFlowTab('user-side')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-400 outline-none ${
                    activeCustomerFlowTab === 'user-side'
                      ? 'bg-purple-600 text-white'
                      : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800'
                  }`}
                >
                  Track 1: User Side Flow
                </button>
                <button
                  type="button"
                  onClick={() => setActiveCustomerFlowTab('admin-side')}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-400 outline-none ${
                    activeCustomerFlowTab === 'admin-side'
                      ? 'bg-purple-600 text-white'
                      : 'text-stone-400 hover:text-stone-200 hover:bg-stone-800'
                  }`}
                >
                  Track 3: Admin Side Flow
                </button>
              </div>

              {activeCustomerFlowTab === 'diagram' && (
                <div className="flex items-center gap-1.5">
                  <span className="text-stone-500 font-mono text-[11px] mr-1">
                    {Math.round(customerFlowZoom * 100)}%
                  </span>
                  <button
                    type="button"
                    onClick={() => setCustomerFlowZoom(z => Math.max(0.6, z - 0.2))}
                    className="p-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-lg cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-400 outline-none"
                    title="Zoom Out"
                    aria-label="Zoom out"
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setCustomerFlowZoom(1)}
                    className="px-2 py-1 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-lg text-[10px] font-mono cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-400 outline-none"
                    title="Reset Zoom"
                  >
                    100%
                  </button>
                  <button
                    type="button"
                    onClick={() => setCustomerFlowZoom(z => Math.min(2.5, z + 0.2))}
                    className="p-1.5 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded-lg cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-400 outline-none"
                    title="Zoom In"
                    aria-label="Zoom in"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Modal Body */}
            <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
              
              {/* TAB 1: DIAGRAM IMAGE VIEW */}
              {activeCustomerFlowTab === 'diagram' && (
                <div className="flex flex-col items-center justify-center bg-stone-950 p-4 rounded-2xl border border-stone-800 min-h-[460px] overflow-auto">
                  <div
                    style={{
                      transform: `scale(${customerFlowZoom})`,
                      transformOrigin: 'top center',
                      transition: 'transform 0.2s ease-out',
                    }}
                    className="max-w-full flex items-center justify-center"
                  >
                    <img
                      src={
                        selectedDiagramType === 'full-system'
                          ? '/assets/aistudio/NOVORA_Authentication_System_Flowchart__1__e9de0c86.png'
                          : '/assets/aistudio/Novora_Customer_Sign-In_System_Flowchart_de2464bf.png'
                      }
                      alt={
                        selectedDiagramType === 'full-system'
                          ? 'NOVORA Authentication, Account Management & Saving System Flowchart'
                          : 'Novora Customer Sign In & Address Storage System Flowchart'
                      }
                      className="max-h-[720px] w-auto object-contain rounded-xl shadow-2xl"
                    />
                  </div>
                </div>
              )}

              {/* TAB 2: LOCAL PC FOLDER STORAGE SPECIFICATION */}
              {activeCustomerFlowTab === 'folder' && (
                <div className="space-y-6 text-xs text-stone-300">
                  <div className="p-5 bg-stone-950 rounded-2xl border border-stone-800 space-y-3">
                    <div className="flex items-center gap-2 text-emerald-400">
                      <Folder className="w-5 h-5 text-amber-500" />
                      <h4 className="text-sm font-bold text-white font-mono">
                        C:\Novora_Project\Data\ (Live on 137.184.23.176)
                      </h4>
                    </div>
                    <p className="text-stone-400 leading-relaxed">
                      As designed in the school project blueprint, whenever a customer signs up, signs in, or saves an address, the system automatically writes structured JSON records into this folder.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    {/* users.json Spec */}
                    <div className="p-4 bg-stone-950 rounded-2xl border border-stone-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-purple-400">1. users.json</span>
                        <span className="px-2 py-0.5 rounded text-[10px] bg-purple-950 text-purple-300 border border-purple-800">User Personal Details</span>
                      </div>
                      <p className="text-stone-400 text-[11px]">
                        Stores authenticated credentials and basic identity for every patron.
                      </p>
                      <ul className="space-y-1 font-mono text-[11px] text-stone-300 pl-2">
                        <li>• <code>id</code>: Unique Customer ID</li>
                        <li>• <code>fullName</code>: Customer's legal name</li>
                        <li>• <code>email</code>: Primary login credential</li>
                        <li>• <code>passwordHashed</code>: SHA-256 secure hash (never plaintext)</li>
                        <li>• <code>phone</code>: Contact telephone number</li>
                        <li>• <code>createdAt / updatedAt</code>: Timestamps</li>
                      </ul>
                    </div>

                    {/* addresses.json Spec */}
                    <div className="p-4 bg-stone-950 rounded-2xl border border-stone-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-amber-400">2. addresses.json</span>
                        <span className="px-2 py-0.5 rounded text-[10px] bg-amber-950 text-amber-300 border border-amber-800">User Addresses</span>
                      </div>
                      <p className="text-stone-400 text-[11px]">
                        Stores all 10 compulsory address fields required for courier fulfillment.
                      </p>
                      <ul className="space-y-1 font-mono text-[11px] text-stone-300 pl-2">
                        <li>• <code>userId &amp; userEmail</code>: Linking reference</li>
                        <li>• <code>country</code>: Destination nation</li>
                        <li>• <code>provinceState &amp; city</code>: Region &amp; municipality</li>
                        <li>• <code>streetAddress &amp; houseBuildingNumber</code>: Physical coordinates</li>
                        <li>• <code>apartmentDetails &amp; postalZipCode</code>: Suite &amp; ZIP code</li>
                        <li>• <code>phone</code>: Delivery contact number</li>
                      </ul>
                    </div>

                    {/* orders.json Spec */}
                    <div className="p-4 bg-stone-950 rounded-2xl border border-stone-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-emerald-400">3. orders.json</span>
                        <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800">Customer Orders</span>
                      </div>
                      <p className="text-stone-400 text-[11px]">
                        Records completed checkouts and merchant bank settlement proceeds.
                      </p>
                      <ul className="space-y-1 font-mono text-[11px] text-stone-300 pl-2">
                        <li>• <code>orderNumber &amp; total</code>: Financial invoice</li>
                        <li>• <code>destinationAddress</code>: Shipping coordinates</li>
                        <li>• <code>settledToMerchantCard</code>: Proceeds deposited to Admin Card</li>
                        <li>• <code>items</code>: Products, variants, quantities</li>
                      </ul>
                    </div>

                    {/* database.db Spec */}
                    <div className="p-4 bg-stone-950 rounded-2xl border border-stone-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-blue-400">4. database.db</span>
                        <span className="px-2 py-0.5 rounded text-[10px] bg-blue-950 text-blue-300 border border-blue-800">Unified SQLite DB</span>
                      </div>
                      <p className="text-stone-400 text-[11px]">
                        Unified database snapshot for comprehensive PC query access and backup.
                      </p>
                      <ul className="space-y-1 font-mono text-[11px] text-stone-300 pl-2">
                        <li>• Synchronous snapshots committed on every update</li>
                        <li>• Compatible with SQLite, Python, and local scripts</li>
                      </ul>
                    </div>

                  </div>
                </div>
              )}

              {/* TAB 3: USER SIDE FLOW */}
              {activeCustomerFlowTab === 'user-side' && (
                <div className="space-y-4 text-xs text-stone-300">
                  <div className="p-5 bg-stone-950 rounded-2xl border border-stone-800 space-y-3">
                    <span className="text-[10px] font-bold text-purple-400 uppercase tracking-widest">Track 1</span>
                    <h4 className="text-sm font-bold text-white">Customer Sign-Up, Sign-In, &amp; Address Workflow</h4>
                    <p className="text-stone-400 text-[11px]">
                      Follows the left branch of the flowchart: customer journey from visiting NOVORA to saving delivery addresses.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                    <div className="p-3 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                      <span className="text-purple-400 font-bold block text-[10px]">Phase 1</span>
                      <p className="font-semibold text-white">Sign Up / Register</p>
                      <p className="text-[11px] text-stone-400">Inputs Name, Email, Password, Phone &rarr; Saved to <code>users.json</code>.</p>
                    </div>

                    <div className="p-3 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                      <span className="text-purple-400 font-bold block text-[10px]">Phase 2</span>
                      <p className="font-semibold text-white">Sign In / Login</p>
                      <p className="text-[11px] text-stone-400">Email &amp; Password validation against stored hash credentials.</p>
                    </div>

                    <div className="p-3 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                      <span className="text-purple-400 font-bold block text-[10px]">Phase 3</span>
                      <p className="font-semibold text-white">Customer Dashboard</p>
                      <p className="text-[11px] text-stone-400">Personal account hub displaying profile and previous orders.</p>
                    </div>

                    <div className="p-3 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                      <span className="text-purple-400 font-bold block text-[10px]">Phase 4</span>
                      <p className="font-semibold text-white">Add / Save Address</p>
                      <p className="text-[11px] text-stone-400">Inputs all 10 address fields &rarr; Appended to <code>addresses.json</code>.</p>
                    </div>

                    <div className="p-3 bg-emerald-950/60 rounded-xl border border-emerald-800 space-y-1">
                      <span className="text-emerald-400 font-bold block text-[10px]">Phase 5</span>
                      <p className="font-semibold text-white">Checkout &amp; Payment</p>
                      <p className="text-[11px] text-emerald-200">Customer completes order &rarr; Money routes to Admin Merchant Card.</p>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: ADMIN SIDE FLOW */}
              {activeCustomerFlowTab === 'admin-side' && (
                <div className="space-y-4 text-xs text-stone-300">
                  <div className="p-5 bg-stone-950 rounded-2xl border border-stone-800 space-y-3">
                    <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest">Track 3</span>
                    <h4 className="text-sm font-bold text-white">Admin Management &amp; Customer Control System</h4>
                    <p className="text-stone-400 text-[11px]">
                      Follows the right branch of the flowchart: admin actions, user inspection, address viewing, editing, and deletion.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                    <div className="p-3 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                      <span className="text-amber-400 font-bold block text-[10px]">Action 1</span>
                      <p className="font-semibold text-white">Manage Users</p>
                      <p className="text-[11px] text-stone-400">Full directory view with live search by Name, Email, or City.</p>
                    </div>

                    <div className="p-3 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                      <span className="text-amber-400 font-bold block text-[10px]">Action 2</span>
                      <p className="font-semibold text-white">Inspect Details</p>
                      <p className="text-[11px] text-stone-400">Inspect full customer profile, order history, and saved address cards.</p>
                    </div>

                    <div className="p-3 bg-stone-950 rounded-xl border border-stone-800 space-y-1">
                      <span className="text-purple-400 font-bold block text-[10px]">Action 3</span>
                      <p className="font-semibold text-white">Edit User Records</p>
                      <p className="text-[11px] text-purple-200">Admin modifies Name, Email, Phone &rarr; Updated in <code>users.json</code>.</p>
                    </div>

                    <div className="p-3 bg-rose-950/60 rounded-xl border border-rose-800 space-y-1">
                      <span className="text-rose-400 font-bold block text-[10px]">Action 4</span>
                      <p className="font-semibold text-white">Delete &amp; Export</p>
                      <p className="text-[11px] text-rose-200">Delete accounts safely with confirmation and direct JSON file downloads.</p>
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* Modal Footer */}
            <div className="p-4 sm:p-5 border-t border-stone-800 flex items-center justify-between flex-wrap gap-3 bg-stone-900/90 text-xs">
              <span className="text-stone-400">
                NOVORA School Project Architecture · Powered by Local PC Storage &amp; Google Stitch
              </span>
              <div className="flex items-center gap-2">
                <a
                  href="/api/admin/folder-storage/download/users.json"
                  download="users.json"
                  className="px-3.5 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download users.json</span>
                </a>
                <button
                  type="button"
                  onClick={() => setIsCustomerFlowModalOpen(false)}
                  className="px-5 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl transition-colors cursor-pointer"
                >
                  Close Architecture Viewer
                </button>
              </div>
            </div>

          </div>
        </div>
      )}
    </div>
  );
};
