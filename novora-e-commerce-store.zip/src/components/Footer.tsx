import React, { useState } from 'react';
import { ArrowRight, Mail, MapPin, Phone, ShieldCheck, Check } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { api } from '../services/api';

export const Footer: React.FC = () => {
  const { navigateTo, settings, showToast } = useStore();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail || !newsletterEmail.includes('@')) {
      showToast('Please enter a valid email address.', 'error');
      return;
    }
    setIsSubmitting(true);
    try {
      const res = await api.subscribeNewsletter(newsletterEmail.trim());
      setIsSubscribed(true);
      showToast(res.message || 'Thank you for subscribing to the NOVORA register!', 'success');
      setNewsletterEmail('');
    } catch (err: any) {
      showToast(err.message || 'Failed to subscribe. Please retry.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <footer className="bg-stone-950 text-stone-300 pt-16 pb-12 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Newsletter & Brand Hero Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pb-14 border-b border-stone-800">
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-black tracking-widest text-white font-display">
                NOVORA
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-purple-500"></span>
            </div>
            <p className="text-sm text-stone-400 max-w-md leading-relaxed">
              Curated everyday luxury. Engineered apparel, precision audio hardware, and restorative botanical beauty formulated without compromise.
            </p>
            <div className="pt-2 text-xs text-stone-400 space-y-1">
              <p className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span>{settings.address}</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span>{settings.contactPhone}</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span>{settings.contactEmail}</span>
              </p>
            </div>
          </div>

          <div className="lg:col-span-7 flex flex-col justify-center">
            <div className="bg-stone-900/80 p-6 rounded-2xl border border-stone-800">
              <h4 className="text-sm font-semibold text-white tracking-wide uppercase">
                The NOVORA Gazette
              </h4>
              <p className="text-xs text-stone-400 mt-1 mb-4">
                Receive private invitations to seasonal drops, archival private sales, and design essays.
              </p>

              {isSubscribed ? (
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-medium py-2">
                  <Check className="w-4 h-4" />
                  <span>You are subscribed. Welcome to the NOVORA register.</span>
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="email"
                    placeholder="Enter your email address..."
                    value={newsletterEmail}
                    onChange={e => setNewsletterEmail(e.target.value)}
                    className="flex-1 px-4 py-2.5 text-xs bg-stone-950 border border-stone-700 text-white placeholder-stone-500 rounded-lg focus:outline-none focus:border-purple-500"
                    required
                  />
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shrink-0"
                  >
                    <span>{isSubmitting ? 'Saving...' : 'Subscribe'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Links Navigation Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-12 border-b border-stone-800 text-xs">
          {/* Shop */}
          <div className="space-y-3">
            <h5 className="font-semibold text-white tracking-wider uppercase text-[11px]">Shop Collections</h5>
            <ul className="space-y-2">
              <li>
                <button onClick={() => navigateTo('shop')} className="text-stone-400 hover:text-white transition-colors cursor-pointer">
                  All Products
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('shop', { categorySlug: 'fashion' })} className="text-stone-400 hover:text-white transition-colors cursor-pointer">
                  Fashion & Tailoring
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('shop', { categorySlug: 'electronics' })} className="text-stone-400 hover:text-white transition-colors cursor-pointer">
                  Precision Audio & Tech
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('shop', { categorySlug: 'beauty' })} className="text-stone-400 hover:text-white transition-colors cursor-pointer">
                  Beauty & Skincare
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('shop', { categorySlug: 'accessories' })} className="text-stone-400 hover:text-white transition-colors cursor-pointer">
                  Accessories & Bags
                </button>
              </li>
            </ul>
          </div>

          {/* Client Concierge */}
          <div className="space-y-3">
            <h5 className="font-semibold text-white tracking-wider uppercase text-[11px]">Client Concierge</h5>
            <ul className="space-y-2">
              <li>
                <button onClick={() => navigateTo('contact')} className="text-stone-400 hover:text-white transition-colors cursor-pointer">
                  Contact Us
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('account')} className="text-stone-400 hover:text-white transition-colors cursor-pointer">
                  Track Your Order
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('faq')} className="text-stone-400 hover:text-white transition-colors cursor-pointer">
                  Frequently Asked Questions
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('shipping-policy')} className="text-stone-400 hover:text-white transition-colors cursor-pointer">
                  Shipping & Dispatch Policy
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('returns-policy')} className="text-stone-400 hover:text-white transition-colors cursor-pointer">
                  Returns & Exchanges Policy
                </button>
              </li>
            </ul>
          </div>

          {/* Corporate & Legal */}
          <div className="space-y-3">
            <h5 className="font-semibold text-white tracking-wider uppercase text-[11px]">House & Legal</h5>
            <ul className="space-y-2">
              <li>
                <button onClick={() => navigateTo('about')} className="text-stone-400 hover:text-white transition-colors cursor-pointer">
                  About NOVORA
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('privacy-policy')} className="text-stone-400 hover:text-white transition-colors cursor-pointer">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => navigateTo('terms')} className="text-stone-400 hover:text-white transition-colors cursor-pointer">
                  Terms and Conditions
                </button>
              </li>
            </ul>
          </div>

          {/* Payment & Security */}
          <div className="space-y-3">
            <h5 className="font-semibold text-white tracking-wider uppercase text-[11px]">Secure Fulfillment</h5>
            <p className="text-stone-400 leading-relaxed text-[11px]">
              Cash on Delivery (COD) supported with direct telephone courier verification. Safe, contact-free options available.
            </p>
            <div className="pt-2 flex flex-wrap gap-2 text-[10px] text-stone-400 font-mono">
              <span className="px-2 py-1 bg-stone-900 border border-stone-800 rounded">CASH ON DELIVERY</span>
              <span className="px-2 py-1 bg-stone-900 border border-stone-800 rounded">ENCRYPTED SSL</span>
              <span className="px-2 py-1 bg-stone-900 border border-stone-800 rounded">AUTHENTICITY 100%</span>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <p>
            © {new Date().getFullYear()} NOVORA Global Inc. All rights reserved. Built for College Degree Project.
          </p>
          <div className="flex items-center gap-4 text-stone-400">
            <span className="text-[11px]">Curated in New York · Worldwide Dispatch</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
