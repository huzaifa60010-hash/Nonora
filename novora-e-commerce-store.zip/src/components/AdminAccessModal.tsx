import React, { useState } from 'react';
import {
  Shield,
  X,
  Lock,
  Mail,
  User,
  Key,
  FolderCheck,
  ExternalLink,
  Eye,
  EyeOff,
  CheckCircle2,
  HardDrive,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import {
  TARGET_DRIVE_FOLDER_ID,
  TARGET_DRIVE_FOLDER_NAME,
  TARGET_DRIVE_FOLDER_URL,
} from '../services/googleDrive';
import { useFocusTrap } from '../hooks/useFocusTrap';

export const AdminAccessModal: React.FC = () => {
  const { isAdminModalOpen, closeAdminModal, enableAdminPortal } = useStore();

  const [adminName, setAdminName] = useState('System Administrator (Huzaifa)');
  const [adminEmail, setAdminEmail] = useState('Huzaifa60010@gmail.com');
  const [adminPassword, setAdminPassword] = useState('Huzaifa2009@pak');
  const [securityKey, setSecurityKey] = useState('NOVORA-SEC-ADMIN-2026');
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [saveToDriveAndFolder, setSaveToDriveAndFolder] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');

  const modalContainerRef = useFocusTrap<HTMLDivElement>({
    isOpen: isAdminModalOpen,
    onClose: closeAdminModal,
  });

  if (!isAdminModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!adminEmail.trim() || !adminEmail.includes('@')) {
      setErrorMessage('Please enter a valid administrator email address.');
      return;
    }
    if (!adminPassword || adminPassword.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await enableAdminPortal({
        email: adminEmail.trim(),
        password: adminPassword,
        fullName: adminName.trim(),
        securityKey: securityKey.trim(),
      });

      if (!res.success) {
        setErrorMessage(res.error || 'Failed to enable Admin Portal with provided details.');
      } else {
        closeAdminModal();
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'An unexpected error occurred during admin authorization.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const fillInitialAdmin = () => {
    setAdminName('Master Admin (Huzaifa)');
    setAdminEmail('Huzaifa60010@gmail.com');
    setAdminPassword('Huzaifa2009@pak');
    setSecurityKey('NOVORA-SEC-ADMIN-2026');
    setErrorMessage('');
  };

  const fillLegacyAdmin = () => {
    setAdminName('System Administrator');
    setAdminEmail('admin@novora.store');
    setAdminPassword('admin123Password!');
    setSecurityKey('NOVORA-SEC-ADMIN-2026');
    setErrorMessage('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm animate-in fade-in duration-200 overflow-y-auto"
      role="presentation"
    >
      <div
        ref={modalContainerRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="admin-access-title"
        aria-describedby="admin-access-desc"
        tabIndex={-1}
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden my-8 focus:outline-none"
        onClick={e => e.stopPropagation()}
      >
        {/* Header Ribbon */}
        <div className="bg-linear-to-r from-stone-950 via-stone-900 to-purple-950 text-white p-6 sm:p-7 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex items-start justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-purple-600/30 border border-purple-400/40 text-purple-300 flex items-center justify-center shadow-inner">
                <Shield className="w-6 h-6 text-purple-200" />
              </div>
              <div>
                <span className="text-[10px] font-mono uppercase tracking-widest text-purple-300 font-bold block">
                  Security Gateway · Clearance L-10
                </span>
                <h2 id="admin-access-title" className="text-xl font-extrabold text-white font-display">
                  Admin Portal Option
                </h2>
              </div>
            </div>

            <button
              onClick={closeAdminModal}
              className="p-1.5 rounded-full text-stone-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-400 focus-visible:ring-offset-2 focus-visible:ring-offset-stone-900 outline-none"
              aria-label="Close dialog (Escape)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <p id="admin-access-desc" className="mt-3 text-xs text-stone-300 leading-relaxed relative z-10">
            Enter administrator credentials to unlock the Command Console. Details will be preserved in the sign-in folder and synchronized to your authorized Google Drive folder.
          </p>

          {/* Quick preset credentials bar */}
          <div className="mt-3 flex items-center gap-2 relative z-10">
            <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider">Presets:</span>
            <button
              type="button"
              onClick={fillInitialAdmin}
              className="px-2 py-1 bg-purple-800/60 hover:bg-purple-700/80 text-white rounded text-[11px] font-mono font-bold transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-400 outline-none"
            >
              Huzaifa60010@gmail.com
            </button>
            <button
              type="button"
              onClick={fillLegacyAdmin}
              className="px-2 py-1 bg-stone-800/70 hover:bg-stone-700/80 text-stone-300 rounded text-[11px] font-mono transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-stone-400 outline-none"
            >
              admin@novora.store
            </button>
          </div>

          {/* Google Drive target badge */}
          <div className="mt-4 p-2.5 rounded-xl bg-purple-900/40 border border-purple-500/30 flex items-center justify-between text-xs text-purple-200">
            <div className="flex items-center gap-2 truncate">
              <FolderCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="truncate">
                Target Folder: <strong className="text-white font-mono">{TARGET_DRIVE_FOLDER_NAME}</strong>
              </span>
            </div>
            <a
              href={TARGET_DRIVE_FOLDER_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-[11px] font-bold text-purple-300 hover:text-white underline shrink-0 ml-2 focus-visible:ring-2 focus-visible:ring-purple-400 rounded outline-none"
            >
              <span>Folder ID: {TARGET_DRIVE_FOLDER_ID.slice(0, 8)}...</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 sm:p-7 space-y-4">
          {errorMessage && (
            <div role="alert" className="p-3 text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-xl">
              {errorMessage}
            </div>
          )}

          {/* Admin Full Name */}
          <div>
            <label htmlFor="admin-name-input" className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
              Admin Full Name / Clearance Title
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                id="admin-name-input"
                type="text"
                value={adminName}
                onChange={e => setAdminName(e.target.value)}
                placeholder="e.g. System Administrator"
                autoComplete="name"
                autoCapitalize="words"
                autoCorrect="off"
                spellCheck={false}
                className="w-full pl-9 pr-3 py-2.5 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 outline-none transition-colors"
                required
              />
            </div>
          </div>

          {/* Admin Email */}
          <div>
            <label htmlFor="admin-email-input" className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
              Admin Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                id="admin-email-input"
                type="email"
                value={adminEmail}
                onChange={e => setAdminEmail(e.target.value)}
                placeholder="Huzaifa60010@gmail.com"
                autoComplete="email"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                className="w-full pl-9 pr-3 py-2.5 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 font-mono outline-none transition-colors"
                required
              />
            </div>
          </div>

          {/* Admin Password */}
          <div>
            <label htmlFor="admin-pass-input" className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
              Admin Security Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                id="admin-pass-input"
                type={showPassword ? 'text' : 'password'}
                value={adminPassword}
                onChange={e => setAdminPassword(e.target.value)}
                placeholder="Enter admin password"
                autoComplete="current-password"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                className="w-full pl-9 pr-10 py-2.5 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 font-mono outline-none transition-colors"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
                className="p-1.5 text-stone-400 hover:text-stone-700 absolute right-2.5 top-1/2 -translate-y-1/2 cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-600 rounded outline-none"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="mt-1 text-[11px] text-stone-400">
              Saved as secure salted bcrypt hash in <code className="font-mono text-purple-700">admin_credentials.json</code>.
            </p>
          </div>

          {/* Security Clearance Key */}
          <div>
            <label htmlFor="admin-key-input" className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1.5">
              Security Clearance Key / Passphrase
            </label>
            <div className="relative">
              <Key className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                id="admin-key-input"
                type="text"
                value={securityKey}
                onChange={e => setSecurityKey(e.target.value)}
                placeholder="NOVORA-SEC-ADMIN-2026"
                autoComplete="off"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                className="w-full pl-9 pr-3 py-2.5 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 font-mono outline-none transition-colors"
              />
            </div>
          </div>

          {/* Persistence Checkbox */}
          <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200 space-y-1.5">
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={saveToDriveAndFolder}
                onChange={e => setSaveToDriveAndFolder(e.target.checked)}
                className="mt-0.5 rounded text-purple-600 focus-visible:ring-2 focus-visible:ring-purple-500"
              />
              <div className="text-xs text-stone-700">
                <span className="font-bold text-stone-900 block">
                  Persist in Sign-In Folder &amp; Google Drive
                </span>
                <span className="text-[11px] text-stone-500 leading-tight block">
                  Write to <code className="text-stone-700 font-mono">data/sign_in/admin_credentials.json</code> and upload directly to Google Drive folder <code className="text-purple-700 font-mono">1q_B8QGCYgzRgVzT4r3f-NH2PN1XaU34m</code>.
                </span>
              </div>
            </label>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full sm:w-2/3 py-3 px-4 bg-stone-950 hover:bg-purple-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 outline-none"
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-purple-300" />
                  <span>Enabling &amp; Syncing...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Enable Admin Page &amp; Sign In</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={closeAdminModal}
              className="w-full sm:w-1/3 py-3 px-4 bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold text-xs rounded-xl transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-stone-600 focus-visible:ring-offset-2 outline-none"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
