import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { useStore, ViewType } from '../context/StoreContext';

interface BackButtonProps {
  fallbackView?: ViewType;
  label?: string;
  confirmMessage?: string;
  className?: string;
  variant?: 'default' | 'minimal' | 'pill' | 'dark' | 'outline';
  showIcon?: boolean;
  onClick?: () => boolean | void;
}

export const BackButton: React.FC<BackButtonProps> = ({
  fallbackView = 'home',
  label = 'Back',
  confirmMessage,
  className = '',
  variant = 'default',
  showIcon = true,
  onClick,
}) => {
  const { goBack } = useStore();

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (confirmMessage) {
      const proceed = window.confirm(confirmMessage);
      if (!proceed) return;
    }
    if (onClick) {
      const result = onClick();
      if (result === false) return;
    }
    goBack(fallbackView);
  };

  const getVariantStyles = () => {
    switch (variant) {
      case 'pill':
        return 'px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-full border border-stone-200/80 shadow-xs hover:shadow-sm';
      case 'dark':
        return 'px-3.5 py-1.5 bg-stone-900/90 hover:bg-stone-800 text-stone-200 hover:text-white rounded-xl border border-stone-700/80 shadow-xs';
      case 'outline':
        return 'px-3.5 py-1.5 bg-white hover:bg-stone-50 text-stone-700 hover:text-stone-950 rounded-xl border border-stone-300 shadow-xs';
      case 'minimal':
        return 'text-stone-500 hover:text-stone-950 p-0 hover:underline underline-offset-4';
      case 'default':
      default:
        return 'inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-stone-700 hover:text-stone-950 bg-stone-100/80 hover:bg-stone-200/90 rounded-lg transition-all border border-stone-200/60 shadow-2xs hover:-translate-x-0.5';
    }
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-label={label}
      className={`group inline-flex items-center gap-1.5 text-xs font-semibold cursor-pointer transition-all duration-150 select-none focus:outline-none focus:ring-2 focus:ring-purple-500/40 ${getVariantStyles()} ${className}`}
    >
      {showIcon && (
        <ArrowLeft className="w-3.5 h-3.5 text-stone-600 group-hover:text-stone-950 group-hover:-translate-x-0.5 transition-transform" />
      )}
      <span>{label}</span>
    </button>
  );
};
