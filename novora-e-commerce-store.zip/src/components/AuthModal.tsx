import React, { useState, useMemo, useCallback } from 'react';
import {
  X,
  Shield,
  User,
  Lock,
  Mail,
  Phone,
  Eye,
  EyeOff,
  ArrowRight,
  KeyRound,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  CloudCheck,
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { api } from '../services/api';
import { signInWithGoogleDrive, syncUserDataToGoogleDrive, TARGET_DRIVE_FOLDER_URL } from '../services/googleDrive';
import { useFocusTrap } from '../hooks/useFocusTrap';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    closeAuthModal,
    authModalMode,
    openAuthModal,
    login,
    loginWithGoogle,
    register,
    verifyEmailOtp,
    resendEmailOtp,
    pendingVerificationEmail,
    setPendingVerificationEmail,
    hasSeenWelcome,
    dismissWelcome,
    currentUser,
    showToast,
    openAdminModal,
  } = useStore();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);

  // OTP state
  const [otpCode, setOtpCode] = useState('');
  const [otpCooldown, setOtpCooldown] = useState(60);
  const [isResendingOtp, setIsResendingOtp] = useState(false);

  // Cooldown interval
  React.useEffect(() => {
    if (otpCooldown <= 0) return;
    const interval = setInterval(() => {
      setOtpCooldown(c => Math.max(0, c - 1));
    }, 1000);
    return () => clearInterval(interval);
  }, [otpCooldown]);

  // Forgot password flow state
  const [forgotStep, setForgotStep] = useState<'request' | 'reset'>('request');
  const [resetCode, setResetCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [dispatchedCodeHint, setDispatchedCodeHint] = useState<string | null>(null);

  const isModalActive = isAuthModalOpen || (!hasSeenWelcome && !currentUser);

  const handleContinueBrowsing = useCallback(() => {
    dismissWelcome();
    closeAuthModal();
  }, [dismissWelcome, closeAuthModal]);

  // WCAG Focus Trap Hook
  const modalContainerRef = useFocusTrap<HTMLDivElement>({
    isOpen: isModalActive,
    onClose: handleContinueBrowsing,
  });

  // Calculate password strength for registration
  const passwordStrength = useMemo(() => {
    if (!password) return { score: 0, label: '', color: 'bg-stone-200' };
    let score = 0;
    if (password.length >= 8) score += 1;
    if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score += 1;
    if (/[0-9]/.test(password)) score += 1;
    if (/[^A-Za-z0-9]/.test(password)) score += 1;

    if (score <= 1) return { score: 1, label: 'Weak (needs letter + number, 8+ chars)', color: 'bg-rose-500', text: 'text-rose-600' };
    if (score <= 2) return { score: 2, label: 'Medium', color: 'bg-amber-500', text: 'text-amber-600' };
    return { score: 3, label: 'Strong', color: 'bg-emerald-500', text: 'text-emerald-600' };
  }, [password]);

  // If already authenticated and not explicitly requested, don't show
  if (!isModalActive) {
    return null;
  }

  const handleModalResendOtp = async () => {
    if (otpCooldown > 0) return;
    setIsResendingOtp(true);
    setErrorMessage('');
    try {
      const res = await resendEmailOtp('registration');
      if (res.success) {
        setOtpCooldown(60);
        showToast('Fresh 6-digit verification code sent to your email.', 'info');
      } else {
        setErrorMessage(res.error || 'Failed to resend code.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error resending code.');
    } finally {
      setIsResendingOtp(false);
    }
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');
    setIsLoading(true);

    try {
      if (authModalMode === 'login') {
        const res = await login(email, password);
        if (!res.success) {
          if (!res.requiresVerification) {
            setErrorMessage(res.error || 'Authentication failed. Please verify your credentials.');
          }
        } else {
          showToast('Welcome back! Signed in successfully.', 'success');
          dismissWelcome();
          closeAuthModal();
        }
      } else if (authModalMode === 'register') {
        if (!fullName.trim()) {
          setErrorMessage('Full Legal Name is required for courier dispatch.');
          setIsLoading(false);
          return;
        }
        if (!email.trim() || !email.includes('@')) {
          setErrorMessage('Please enter a valid email address.');
          setIsLoading(false);
          return;
        }
        if (password.length < 8) {
          setErrorMessage('Password must be at least 8 characters long.');
          setIsLoading(false);
          return;
        }
        if (!/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
          setErrorMessage('Password must contain at least one letter and one number.');
          setIsLoading(false);
          return;
        }
        if (password !== confirmPassword) {
          setErrorMessage('Passwords do not match. Please re-enter your password to confirm.');
          setIsLoading(false);
          return;
        }
        if (!agreedToTerms) {
          setErrorMessage('You must agree to the Privacy Policy and Terms of Service to create an account.');
          setIsLoading(false);
          return;
        }

        const res = await register({ email, password, confirmPassword, fullName, phone, agreedToTerms: true });
        if (!res.success) {
          setErrorMessage(res.error || 'Registration failed. Email might already be registered.');
        } else {
          setOtpCooldown(60);
          setSuccessMessage('Account registered! Enter the 6-digit verification code dispatched to your email.');
          openAuthModal('verify-otp');
        }
      } else if (authModalMode === 'verify-otp') {
        if (otpCode.trim().length !== 6) {
          setErrorMessage('Please enter the full 6-digit verification code.');
          setIsLoading(false);
          return;
        }
        const res = await verifyEmailOtp(otpCode.trim(), 'registration');
        if (!res.success) {
          setErrorMessage(res.error || 'Invalid or expired verification code.');
        } else {
          showToast('Email verified! Welcome to NOVORA.', 'success');
          dismissWelcome();
          closeAuthModal();
        }
      } else if (authModalMode === 'forgot') {
        if (forgotStep === 'request') {
          if (!email.trim() || !email.includes('@')) {
            setErrorMessage('Please enter a valid email address.');
            setIsLoading(false);
            return;
          }
          const res = await api.forgotPassword(email);
          if (res.success) {
            setSuccessMessage(res.message);
            if (res.verificationCode) {
              setDispatchedCodeHint(res.verificationCode);
              setResetCode(res.verificationCode);
            }
            setForgotStep('reset');
          } else {
            setErrorMessage(res.message || 'Unable to process reset request.');
          }
        } else {
          // Reset step
          if (!resetCode.trim()) {
            setErrorMessage('Please enter the 6-digit verification code.');
            setIsLoading(false);
            return;
          }
          if (newPassword.length < 6) {
            setErrorMessage('New password must be at least 6 characters long.');
            setIsLoading(false);
            return;
          }
          const res = await api.resetPassword(email, resetCode, newPassword);
          if (res.success) {
            showToast('Password reset successfully! Please sign in with your new password.', 'success');
            setSuccessMessage('Password reset successfully. You can now sign in.');
            setForgotStep('request');
            setDispatchedCodeHint(null);
            setPassword(newPassword);
            openAuthModal('login');
          } else {
            setErrorMessage(res.message || 'Failed to reset password.');
          }
        }
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setErrorMessage('');
    setSuccessMessage('');
    setIsGoogleLoading(true);
    try {
      const { user, accessToken } = await signInWithGoogleDrive();
      if (!user.email) {
        throw new Error('Google account did not return an email address.');
      }
      const authRes = await loginWithGoogle(user.email, user.displayName || undefined, user.photoURL || undefined);
      if (!authRes.success) {
        throw new Error(authRes.error || 'Failed to authenticate Google user with backend.');
      }

      // Synchronize sign-in record to designated Google Drive folder
      try {
        await syncUserDataToGoogleDrive(accessToken);
        showToast('Signed in with Google! Credentials & folder sync updated.', 'success');
      } catch (syncErr: any) {
        console.warn('Google Drive background sync notice:', syncErr);
        showToast('Signed in successfully with Google account.', 'success');
      }

      dismissWelcome();
      closeAuthModal();
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Google sign-in was cancelled or failed.');
    } finally {
      setIsGoogleLoading(false);
    }
  };

  // Quick Credentials Fillers per flowchart
  const fillInitialAdminCredentials = () => {
    setEmail('Huzaifa60010@gmail.com');
    setPassword('Huzaifa2009@pak');
    setErrorMessage('');
    setSuccessMessage('Loaded initial administrator credentials from security blueprint.');
  };

  const fillLegacyAdminCredentials = () => {
    setEmail('admin@novora.store');
    setPassword('admin123Password!');
    setErrorMessage('');
  };

  const fillCustomerCredentials = () => {
    setEmail('customer@novora.store');
    setPassword('customer123Password!');
    setErrorMessage('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto"
      role="presentation"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-stone-950/80 backdrop-blur-xs transition-opacity"
        onClick={handleContinueBrowsing}
        aria-hidden="true"
      />

      {/* Modal Dialog with WCAG Trap */}
      <div
        ref={modalContainerRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="auth-modal-title"
        aria-describedby="auth-modal-subtitle"
        tabIndex={-1}
        className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden z-10 my-8 focus:outline-none animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="p-6 border-b border-stone-100 flex items-center justify-between bg-stone-950 text-white">
          <div>
            <span
              id="auth-modal-title"
              className="text-xl font-extrabold tracking-widest font-display text-white"
            >
              NOVORA
            </span>
            <p id="auth-modal-subtitle" className="text-[11px] text-stone-400 tracking-wide mt-0.5">
              Refined Everyday Luxury &amp; Contemporary Essentials
            </p>
          </div>
          <button
            onClick={handleContinueBrowsing}
            className="p-1.5 text-stone-400 hover:text-white hover:bg-stone-800 rounded-full transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-400 focus-visible:ring-offset-2 focus-visible:ring-offset-stone-900 outline-none"
            title="Close dialog (Escape)"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-stone-200 bg-stone-50" role="tablist" aria-label="Authentication Options">
          <button
            type="button"
            role="tab"
            aria-selected={authModalMode === 'login'}
            onClick={() => {
              openAuthModal('login');
              setErrorMessage('');
              setSuccessMessage('');
            }}
            className={`flex-1 py-3 text-xs font-semibold text-center transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 outline-none ${
              authModalMode === 'login'
                ? 'bg-white text-purple-700 border-b-2 border-purple-700 shadow-xs'
                : 'text-stone-500 hover:text-stone-900'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={authModalMode === 'register'}
            onClick={() => {
              openAuthModal('register');
              setErrorMessage('');
              setSuccessMessage('');
            }}
            className={`flex-1 py-3 text-xs font-semibold text-center transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 outline-none ${
              authModalMode === 'register'
                ? 'bg-white text-purple-700 border-b-2 border-purple-700 shadow-xs'
                : 'text-stone-500 hover:text-stone-900'
            }`}
          >
            Create Account
          </button>
          {authModalMode === 'verify-otp' ? (
            <button
              type="button"
              role="tab"
              aria-selected={true}
              className="flex-1 py-3 text-xs font-semibold text-center transition-colors cursor-pointer bg-white text-purple-700 border-b-2 border-purple-700 shadow-xs outline-none"
            >
              Verify OTP
            </button>
          ) : (
            <button
              type="button"
              role="tab"
              aria-selected={authModalMode === 'forgot'}
              onClick={() => {
                openAuthModal('forgot');
                setErrorMessage('');
                setSuccessMessage('');
                setForgotStep('request');
              }}
              className={`flex-1 py-3 text-xs font-semibold text-center transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 outline-none ${
                authModalMode === 'forgot'
                  ? 'bg-white text-purple-700 border-b-2 border-purple-700 shadow-xs'
                  : 'text-stone-500 hover:text-stone-900'
              }`}
            >
              Forgot Password
            </button>
          )}
        </div>

        {/* Form Body */}
        <form onSubmit={handleAuthSubmit} className="p-6 space-y-4">
          {errorMessage && (
            <div
              role="alert"
              className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-xs leading-relaxed flex items-start gap-2"
            >
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div
              role="status"
              className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs leading-relaxed flex items-start gap-2"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Google Sign In option */}
          {(authModalMode === 'login' || authModalMode === 'register') && (
            <div>
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isGoogleLoading || isLoading}
                className="w-full py-2.5 px-4 bg-white hover:bg-stone-50 text-stone-700 text-xs font-semibold rounded-lg border border-stone-300 shadow-xs flex items-center justify-center gap-2.5 transition-colors cursor-pointer disabled:opacity-60 focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 outline-none"
              >
                <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>
                  {isGoogleLoading
                    ? 'Connecting Google Account...'
                    : authModalMode === 'login'
                    ? 'Sign in with Google (OAuth)'
                    : 'Sign up with Google (OAuth)'}
                </span>
              </button>
              <div className="relative my-3" aria-hidden="true">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-stone-200" />
                </div>
                <div className="relative flex justify-center text-[10px] uppercase tracking-wider">
                  <span className="bg-white px-2 text-stone-400 font-medium">or continue with email</span>
                </div>
              </div>
            </div>
          )}

          {/* VERIFY OTP MODE */}
          {authModalMode === 'verify-otp' && (
            <div className="space-y-4">
              <div className="p-3 bg-purple-50 border border-purple-200 text-purple-900 rounded-lg text-xs leading-relaxed space-y-1">
                <div className="flex items-center gap-2 font-bold text-purple-950">
                  <Mail className="w-4 h-4 text-purple-700" />
                  <span>Verification Code Dispatched</span>
                </div>
                <p className="text-[11px] text-purple-800">
                  A 6-digit verification code has been dispatched to <strong>{pendingVerificationEmail || email}</strong>. The code expires in 10 minutes.
                </p>
              </div>

              <div>
                <label htmlFor="modal-otp-code" className="block text-xs font-semibold text-stone-700 mb-1">
                  6-Digit Verification Code <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    id="modal-otp-code"
                    type="text"
                    maxLength={6}
                    inputMode="numeric"
                    placeholder="••••••"
                    value={otpCode}
                    onChange={e => setOtpCode(e.target.value.replace(/\D/g, ''))}
                    className="w-full pl-9 pr-3 py-2.5 text-center text-lg font-mono tracking-[0.3em] font-bold bg-stone-50 border border-stone-300 rounded-lg focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 focus:bg-white outline-none"
                    required
                    autoFocus
                  />
                  <KeyRound className="w-4 h-4 text-stone-400 absolute left-3 top-3.5" />
                </div>
              </div>

              <div className="flex items-center justify-between text-xs pt-1">
                <span className="text-stone-500">Didn't receive code?</span>
                <button
                  type="button"
                  disabled={otpCooldown > 0 || isResendingOtp}
                  onClick={handleModalResendOtp}
                  className="text-purple-700 hover:text-purple-900 font-semibold disabled:text-stone-400 disabled:cursor-not-allowed cursor-pointer outline-none"
                >
                  {isResendingOtp ? 'Sending...' : otpCooldown > 0 ? `Resend in ${otpCooldown}s` : 'Resend Code'}
                </button>
              </div>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => openAuthModal('register')}
                  className="text-[11px] text-stone-500 hover:text-stone-800 underline cursor-pointer"
                >
                  Change email address or return to registration
                </button>
              </div>
            </div>
          )}

          {authModalMode !== 'verify-otp' && (
            <>
              {/* REGISTER: Full Name */}
              {authModalMode === 'register' && (
                <div>
                  <label htmlFor="register-fullname" className="block text-xs font-semibold text-stone-700 mb-1">
                    Full Legal Name <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      id="register-fullname"
                      type="text"
                      placeholder="e.g. Julian Montgomery"
                      value={fullName}
                      onChange={e => setFullName(e.target.value)}
                      autoComplete="name"
                      autoCapitalize="words"
                      autoCorrect="off"
                      spellCheck={false}
                      className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 focus:bg-white outline-none transition-colors"
                      required
                    />
                    <User className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                  </div>
                </div>
              )}

              {/* EMAIL (All non-OTP modes) */}
              <div>
                <label htmlFor="auth-email-input" className="block text-xs font-semibold text-stone-700 mb-1">
                  Email Address <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    id="auth-email-input"
                    type="email"
                    placeholder="name@example.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    autoComplete="email"
                    autoCapitalize="none"
                    autoCorrect="off"
                    spellCheck={false}
                    className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 focus:bg-white outline-none transition-colors"
                    required
                  />
                  <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                </div>
              </div>

              {/* REGISTER: Phone */}
              {authModalMode === 'register' && (
                <div>
                  <label htmlFor="register-phone" className="block text-xs font-semibold text-stone-700 mb-1">
                    Phone Number (for courier contact)
                  </label>
                  <div className="relative">
                    <input
                      id="register-phone"
                      type="tel"
                      placeholder="+1 (555) 000-0000"
                      value={phone}
                      onChange={e => setPhone(e.target.value)}
                      autoComplete="tel"
                      autoCapitalize="none"
                      autoCorrect="off"
                      spellCheck={false}
                      className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 focus:bg-white outline-none transition-colors"
                    />
                    <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                  </div>
                </div>
              )}

              {/* LOGIN / REGISTER: Password */}
              {(authModalMode === 'login' || authModalMode === 'register') && (
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label htmlFor="auth-password-input" className="block text-xs font-semibold text-stone-700">
                      Password <span className="text-rose-500">*</span>
                    </label>
                    {authModalMode === 'login' && (
                      <button
                        type="button"
                        onClick={() => {
                          openAuthModal('forgot');
                          setErrorMessage('');
                          setSuccessMessage('');
                        }}
                        className="text-[11px] text-purple-700 hover:text-purple-900 font-semibold cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-1 rounded outline-none"
                      >
                        Forgot password?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <input
                      id="auth-password-input"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      autoComplete={authModalMode === 'register' ? 'new-password' : 'current-password'}
                      autoCapitalize="none"
                      autoCorrect="off"
                      spellCheck={false}
                      className="w-full pl-9 pr-10 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 focus:bg-white outline-none transition-colors"
                      required
                    />
                    <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                      className="absolute right-3 top-2.5 text-stone-400 hover:text-stone-700 focus-visible:ring-2 focus-visible:ring-purple-600 rounded p-0.5 outline-none cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>

                  {/* Password strength meter for registration */}
                  {authModalMode === 'register' && password && (
                    <div className="mt-2 space-y-1">
                      <div className="flex items-center justify-between text-[10px]">
                        <span className="text-stone-500">Password Strength:</span>
                        <span className={`font-bold ${passwordStrength.text}`}>{passwordStrength.label}</span>
                      </div>
                      <div className="w-full h-1.5 bg-stone-100 rounded-full overflow-hidden flex gap-1">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${
                            passwordStrength.score >= 1 ? passwordStrength.color : 'bg-transparent'
                          }`}
                          style={{ width: '33.3%' }}
                        />
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${
                            passwordStrength.score >= 2 ? passwordStrength.color : 'bg-transparent'
                          }`}
                          style={{ width: '33.3%' }}
                        />
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${
                            passwordStrength.score >= 3 ? passwordStrength.color : 'bg-transparent'
                          }`}
                          style={{ width: '33.3%' }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* REGISTER: Confirm Password */}
              {authModalMode === 'register' && (
                <div>
                  <label htmlFor="register-confirm-password" className="block text-xs font-semibold text-stone-700 mb-1">
                    Confirm Password <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      id="register-confirm-password"
                      type={showConfirmPassword ? 'text' : 'password'}
                      placeholder="Re-type password"
                      value={confirmPassword}
                      onChange={e => setConfirmPassword(e.target.value)}
                      autoComplete="new-password"
                      autoCapitalize="none"
                      autoCorrect="off"
                      spellCheck={false}
                      className="w-full pl-9 pr-10 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 focus:bg-white outline-none transition-colors"
                      required
                    />
                    <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      aria-label={showConfirmPassword ? 'Hide confirm password' : 'Show confirm password'}
                      className="absolute right-3 top-2.5 text-stone-400 hover:text-stone-700 focus-visible:ring-2 focus-visible:ring-purple-600 rounded p-0.5 outline-none cursor-pointer"
                    >
                      {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {confirmPassword && password !== confirmPassword && (
                    <p className="text-[10px] text-rose-500 mt-1 font-medium">
                      Passwords do not match yet.
                    </p>
                  )}
                  {confirmPassword && password === confirmPassword && (
                    <p className="text-[10px] text-emerald-600 mt-1 font-medium flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Passwords match</span>
                    </p>
                  )}
                </div>
              )}

              {/* REGISTER: Agreement Checkbox */}
              {authModalMode === 'register' && (
                <div className="pt-1">
                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={agreedToTerms}
                      onChange={e => setAgreedToTerms(e.target.checked)}
                      className="mt-0.5 rounded border-stone-300 text-purple-700 focus:ring-purple-600"
                      required
                    />
                    <span className="text-[11px] text-stone-600 leading-tight">
                      I agree to the NOVORA <span className="font-semibold text-stone-900 underline">Privacy Policy</span> and <span className="font-semibold text-stone-900 underline">Terms of Service</span>.
                    </span>
                  </label>
                </div>
              )}

              {/* FORGOT PASSWORD: Reset step fields */}
              {authModalMode === 'forgot' && forgotStep === 'reset' && (
                <>
                  {dispatchedCodeHint && (
                    <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-900">
                      <span className="font-bold">Test Mode Verification Code: </span>
                      <code className="font-mono bg-white px-1.5 py-0.5 rounded border border-amber-300 font-bold">
                        {dispatchedCodeHint}
                      </code>
                    </div>
                  )}

                  <div>
                    <label htmlFor="forgot-reset-code" className="block text-xs font-semibold text-stone-700 mb-1">
                      6-Digit Verification Code <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <input
                        id="forgot-reset-code"
                        type="text"
                        maxLength={6}
                        placeholder="e.g. 839201"
                        value={resetCode}
                        onChange={e => setResetCode(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 text-xs font-mono tracking-widest bg-stone-50 border border-stone-200 rounded-lg focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 focus:bg-white outline-none"
                        required
                      />
                      <KeyRound className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="forgot-new-password" className="block text-xs font-semibold text-stone-700 mb-1">
                      Set New Password <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <input
                        id="forgot-new-password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="At least 6 characters"
                        value={newPassword}
                        onChange={e => setNewPassword(e.target.value)}
                        className="w-full pl-9 pr-10 py-2 text-xs bg-stone-50 border border-stone-200 rounded-lg focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 focus:bg-white outline-none"
                        required
                      />
                      <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        aria-label={showPassword ? 'Hide password' : 'Show password'}
                        className="absolute right-3 top-2.5 text-stone-400 hover:text-stone-700 focus-visible:ring-2 focus-visible:ring-purple-600 rounded p-0.5 outline-none cursor-pointer"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </>
              )}
            </>
          )}

          {/* Action Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2.5 bg-stone-900 hover:bg-purple-700 text-white text-xs font-bold uppercase tracking-wider rounded-lg transition-colors cursor-pointer mt-2 disabled:opacity-50 focus-visible:ring-2 focus-visible:ring-purple-600 focus-visible:ring-offset-2 outline-none"
          >
            {isLoading
              ? 'Processing...'
              : authModalMode === 'verify-otp'
              ? 'Verify Email & Activate Account'
              : authModalMode === 'login'
              ? 'Sign In to NOVORA'
              : authModalMode === 'register'
              ? 'Create Customer Account'
              : forgotStep === 'request'
              ? 'Send Verification Code'
              : 'Set New Password & Sign In'}
          </button>

          {/* Continue button as specified in Requirement 1 */}
          <button
            type="button"
            onClick={handleContinueBrowsing}
            className="w-full py-2 border border-stone-300 hover:bg-stone-50 text-stone-700 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer focus-visible:ring-2 focus-visible:ring-stone-600 focus-visible:ring-offset-2 outline-none"
          >
            <span>Continue to Store (Browse Collections)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          {/* Admin Page Option Button */}
          <button
            type="button"
            onClick={() => {
              closeAuthModal();
              openAdminModal();
            }}
            className="w-full py-2 px-3 bg-linear-to-r from-stone-900 via-purple-950 to-stone-900 text-purple-200 hover:text-white hover:border-purple-500 border border-purple-800/80 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-500 focus-visible:ring-offset-2 outline-none"
          >
            <Shield className="w-3.5 h-3.5 text-purple-400" />
            <span>Admin Page Option — Unlock Admin Portal &amp; Save Details</span>
          </button>
        </form>
      </div>
    </div>
  );
};
