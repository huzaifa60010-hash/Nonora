import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Building2,
  CreditCard,
  Banknote,
  Check,
  AlertTriangle,
  RefreshCw,
  ExternalLink,
  Lock,
  ArrowRight,
  Search,
  RotateCcw,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Clock,
  DollarSign,
  AlertCircle,
  Info,
  ChevronDown,
  ChevronUp,
  Edit,
  Plus,
  Trash2,
  Wifi,
  Download,
  Eye,
  Maximize2,
  ZoomIn,
  ZoomOut,
  X,
  History,
  KeyRound,
  Landmark,
} from 'lucide-react';
import { api } from '../services/api';
import { PaymentGatewayConfig, PaymentTransaction, BankPayoutAccount, PayoutAuditRecord, Order, MerchantCardDetails } from '../types';

interface PaymentSettingsProps {
  onNotify?: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const POPULAR_PAKISTAN_BANKS = [
  'Meezan Bank Ltd (Islamic)',
  'Habib Bank Limited (HBL)',
  'Bank Alfalah Limited',
  'Standard Chartered Bank Pakistan',
  'MCB Bank Limited',
  'United Bank Limited (UBL)',
  'Allied Bank Limited (ABL)',
  'Faysal Bank Limited',
  'Askari Bank Limited',
  'Dubai Islamic Bank Pakistan',
  'Soneri Bank Limited',
  'JS Bank Limited',
  'Bank of Punjab (BOP)',
  'Bank Al Habib Limited',
  'Other / International Commercial Bank',
];

export const PaymentSettings: React.FC<PaymentSettingsProps> = ({ onNotify }) => {
  // Main settings state
  const [config, setConfig] = useState<PaymentGatewayConfig | null>(null);
  const [transactions, setTransactions] = useState<PaymentTransaction[]>([]);
  const [credentialsStatus, setCredentialsStatus] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isVerifyingBank, setIsVerifyingBank] = useState(false);
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [connectionTestResult, setConnectionTestResult] = useState<any>(null);

  // Bank Form State
  const [bankName, setBankName] = useState('Meezan Bank Ltd (Islamic)');
  const [customBankName, setCustomBankName] = useState('');
  const [accountHolderName, setAccountHolderName] = useState('NOVORA Atelier & Retail (Pvt) Ltd');
  const [country, setCountry] = useState('Pakistan');
  const [currency, setCurrency] = useState('PKR');
  const [accountNumberOrIban, setAccountNumberOrIban] = useState('PK92 MEZN 0000 0001 2345 6701');
  const [branchCode, setBranchCode] = useState('0102');
  const [bankFormError, setBankFormError] = useState<string | null>(null);

  // Change Payout Account Modal & Confirmation State
  const [isChangePayoutModalOpen, setIsChangePayoutModalOpen] = useState(false);
  const [changeBankName, setChangeBankName] = useState('Meezan Bank Ltd (Islamic)');
  const [changeCustomBankName, setChangeCustomBankName] = useState('');
  const [changeAccountHolderName, setChangeAccountHolderName] = useState('NOVORA Atelier & Retail (Pvt) Ltd');
  const [changeCountry, setChangeCountry] = useState('Pakistan');
  const [changeCurrency, setChangeCurrency] = useState('PKR');
  const [changeIban, setChangeIban] = useState('');
  const [changeBranchCode, setChangeBranchCode] = useState('');
  const [changeReason, setChangeReason] = useState('Corporate Banking Migration / Account Restructuring');
  const [changeAdminPassword, setChangeAdminPassword] = useState('');
  const [changeAgreed, setChangeAgreed] = useState(false);
  const [isSubmittingPayoutChange, setIsSubmittingPayoutChange] = useState(false);
  const [changePayoutError, setChangePayoutError] = useState<string | null>(null);
  const [changeSuccessRecord, setChangeSuccessRecord] = useState<any | null>(null);
  const [saveStatusMessage, setSaveStatusMessage] = useState<{ text: string; type: 'success' | 'error' | 'saving' } | null>(null);

  // Connect Provider Modal State
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);
  const [selectedProviderToConnect, setSelectedProviderToConnect] = useState<'safepay' | 'stripe' | 'paymob'>('safepay');

  // Credentials Config Modal State
  const [isCredsModalOpen, setIsCredsModalOpen] = useState(false);
  const [isLiveBlockedModalOpen, setIsLiveBlockedModalOpen] = useState(false);
  const [apiKeyInput, setApiKeyInput] = useState('');
  const [secretKeyInput, setSecretKeyInput] = useState('');
  const [webhookSecretInput, setWebhookSecretInput] = useState('');
  const [kycStatusInput, setKycStatusInput] = useState<'verified' | 'pending_approval' | 'unregistered'>('verified');
  const [showSecretKey, setShowSecretKey] = useState(false);
  const [isSavingCreds, setIsSavingCreds] = useState(false);
  const [credsModalError, setCredsModalError] = useState<string | null>(null);

  // Merchant Card Modal State
  const [isCardModalOpen, setIsCardModalOpen] = useState(false);
  const [cardHolderNameInput, setCardHolderNameInput] = useState('NOVORA Atelier & Retail (Pvt) Ltd');
  const [cardNumberInput, setCardNumberInput] = useState('');
  const [cardExpiryMonthInput, setCardExpiryMonthInput] = useState('09');
  const [cardExpiryYearInput, setCardExpiryYearInput] = useState('28');
  const [cardCvcInput, setCardCvcInput] = useState('');
  const [cardZipInput, setCardZipInput] = useState('54660');
  const [isDefaultCardInput, setIsDefaultCardInput] = useState(true);
  const [isSavingCard, setIsSavingCard] = useState(false);
  const [cardModalError, setCardModalError] = useState<string | null>(null);
  const [isDeletingCardId, setIsDeletingCardId] = useState<string | null>(null);

  // System Architecture Flowchart Lightbox State
  const [isDiagramOpen, setIsDiagramOpen] = useState(false);
  const [diagramZoom, setDiagramZoom] = useState(1);
  const [showDiagramSection, setShowDiagramSection] = useState(true);

  // Format card number with spaces every 4 digits
  const handleCardNumberChange = (val: string) => {
    const raw = val.replace(/\D/g, '').slice(0, 16);
    const formatted = raw.replace(/(\d{4})/g, '$1 ').trim();
    setCardNumberInput(formatted);
  };

  // Detect card brand dynamically
  const detectBrand = (num: string) => {
    const clean = num.replace(/\D/g, '');
    if (clean.startsWith('4')) return 'Visa';
    if (/^(5[1-5]|2[2-7])/.test(clean)) return 'Mastercard';
    if (/^(34|37)/.test(clean)) return 'American Express';
    if (/^(5081|6032|60)/.test(clean)) return 'PayPak';
    if (/^62/.test(clean)) return 'UnionPay';
    return 'Visa';
  };

  // Open card modal for adding/updating
  const handleOpenCardModal = () => {
    setCardHolderNameInput(config?.payoutAccount?.accountHolderName || 'NOVORA Atelier & Retail (Pvt) Ltd');
    setCardNumberInput('');
    setCardExpiryMonthInput('09');
    setCardExpiryYearInput('28');
    setCardCvcInput('');
    setCardZipInput('54660');
    setIsDefaultCardInput(true);
    setCardModalError(null);
    setIsCardModalOpen(true);
  };

  // Save / Update Merchant Card
  const handleSaveMerchantCard = async (e: React.FormEvent) => {
    e.preventDefault();
    setCardModalError(null);

    const cleanNumber = cardNumberInput.replace(/\s+/g, '');
    if (cleanNumber.length < 13) {
      setCardModalError('Please enter a valid 13-16 digit card number.');
      return;
    }

    if (!cardCvcInput || cardCvcInput.length < 3) {
      setCardModalError('Please enter a valid 3 or 4 digit CVC security code.');
      return;
    }

    setIsSavingCard(true);
    try {
      const res = await api.addOrUpdateMerchantCard({
        cardholderName: cardHolderNameInput.trim(),
        cardNumber: cleanNumber,
        expiryMonth: cardExpiryMonthInput,
        expiryYear: cardExpiryYearInput,
        cvc: cardCvcInput.trim(),
        billingPostalCode: cardZipInput.trim(),
        isDefault: isDefaultCardInput,
      });

      setConfig(res.paymentGateway);
      setIsCardModalOpen(false);
      notify(res.message || 'Business card successfully updated and saved to your dashboard!');
    } catch (err: any) {
      setCardModalError(err.message || 'Failed to update card.');
      notify(err.message || 'Card verification failed', 'error');
    } finally {
      setIsSavingCard(false);
    }
  };

  // Set default card
  const handleSetDefaultCard = async (cardId: string) => {
    try {
      const res = await api.setDefaultMerchantCard(cardId);
      setConfig(res.paymentGateway);
      notify(res.message || 'Primary merchant card updated.');
    } catch (err: any) {
      notify(err.message || 'Failed to update default card', 'error');
    }
  };

  // Delete card
  const handleDeleteCard = async (cardId: string) => {
    if (!window.confirm('Are you sure you want to remove this card from your dashboard?')) {
      return;
    }
    setIsDeletingCardId(cardId);
    try {
      const res = await api.deleteMerchantCard(cardId);
      setConfig(res.paymentGateway);
      notify(res.message || 'Card removed successfully.');
    } catch (err: any) {
      notify(err.message || 'Failed to remove card', 'error');
    } finally {
      setIsDeletingCardId(null);
    }
  };

  // Refund Modal State
  const [selectedTxForRefund, setSelectedTxForRefund] = useState<PaymentTransaction | null>(null);
  const [refundAmount, setRefundAmount] = useState<string>('');
  const [refundReason, setRefundReason] = useState<string>('');
  const [isProcessingRefund, setIsProcessingRefund] = useState(false);
  const [refundError, setRefundError] = useState<string | null>(null);

  // Filters for Transactions Table
  const [txFilter, setTxFilter] = useState<'all' | 'paid' | 'refunded' | 'pending'>('all');
  const [txSearch, setTxSearch] = useState('');
  const [showDocsGuide, setShowDocsGuide] = useState(true);

  // Notification helper
  const notify = (msg: string, type: 'success' | 'error' | 'info' = 'success') => {
    if (onNotify) {
      onNotify(msg, type);
    }
  };

  // Load configuration and transaction history
  const loadData = async () => {
    setIsLoading(true);
    try {
      const [settingsRes, txRes, credsRes] = await Promise.all([
        api.getAdminPaymentSettings(),
        api.getPaymentTransactions(),
        api.getPaymentCredentialsStatus().catch(err => {
          console.warn('Credentials status fetch warning:', err);
          return null;
        }),
      ]);
      setConfig(settingsRes);
      setTransactions(txRes);
      if (credsRes) {
        setCredentialsStatus(credsRes);
      }

      // Pre-populate bank form if existing payout account is found
      if (settingsRes.payoutAccount) {
        setBankName(settingsRes.payoutAccount.bankName);
        setAccountHolderName(settingsRes.payoutAccount.accountHolderName);
        setCountry(settingsRes.payoutAccount.country);
        setCurrency(settingsRes.payoutAccount.currency);
        setBranchCode(settingsRes.payoutAccount.branchCode || '');
      }
    } catch (err: any) {
      console.error('Failed to load payment settings:', err);
      notify(err.message || 'Failed to load payment settings', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Open credentials configuration modal
  const handleOpenCredsModal = () => {
    setApiKeyInput(config?.apiKeyMasked || '');
    setSecretKeyInput('');
    setWebhookSecretInput(config?.webhookSecret || '');
    setKycStatusInput(config?.merchantKycStatus || 'verified');
    setCredsModalError(null);
    setIsCredsModalOpen(true);
  };

  // Save server-side credentials
  const handleSaveCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingCreds(true);
    setCredsModalError(null);

    try {
      const res = await api.updatePaymentCredentials({
        apiKey: apiKeyInput.trim() || undefined,
        secretKey: secretKeyInput.trim() || undefined,
        webhookSecret: webhookSecretInput.trim() || undefined,
        merchantKycStatus: kycStatusInput,
      });

      setConfig(res.paymentGateway);
      notify(res.message || 'Provider credentials and webhook secret updated!');
      setIsCredsModalOpen(false);

      // Refresh checklist status
      const updatedCreds = await api.getPaymentCredentialsStatus();
      setCredentialsStatus(updatedCreds);
    } catch (err: any) {
      setCredsModalError(err.message || 'Failed to update credentials');
      notify(err.message || 'Failed to update credentials', 'error');
    } finally {
      setIsSavingCreds(false);
    }
  };

  // Safe mode toggle with checklist validation
  const handleToggleMode = async (targetMode: 'test' | 'live') => {
    if (targetMode === 'live') {
      if (credentialsStatus && !credentialsStatus.isLiveEligible) {
        setIsLiveBlockedModalOpen(true);
        return;
      }
    }

    if (!config) return;
    try {
      const updated = { ...config, mode: targetMode, isTestMode: targetMode === 'test' };
      setConfig(updated);
      await api.updateAdminPaymentSettings(updated);
      notify(
        targetMode === 'live'
          ? 'Switched to Live Production Mode — Real customer payments active'
          : 'Switched to Sandbox Test Mode — Ready for simulated testing',
        targetMode === 'live' ? 'success' : 'info'
      );
    } catch (err: any) {
      notify(err.message || 'Failed to switch mode', 'error');
    }
  };

  // Handle Save Settings
  const handleSaveSettings = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!config) return;

    if (config.mode === 'live' && credentialsStatus && !credentialsStatus.isLiveEligible) {
      setIsLiveBlockedModalOpen(true);
      return;
    }

    setIsSaving(true);
    setSaveStatusMessage({ text: 'Saving settings to backend database...', type: 'saving' });
    try {
      const res = await api.updateAdminPaymentSettings(config);
      setConfig(res.paymentGateway);
      setSaveStatusMessage({ text: 'Settings saved successfully to persistent database.', type: 'success' });
      notify('Payment gateway & bank payout settings successfully saved to persistent storage!');
      setTimeout(() => setSaveStatusMessage(null), 5000);
    } catch (err: any) {
      setSaveStatusMessage({ text: err.message || 'Failed to save settings.', type: 'error' });
      notify(err.message || 'Failed to save settings', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  // Open Change Payout Account Modal
  const handleOpenChangePayoutModal = () => {
    if (config?.payoutAccount) {
      setChangeBankName(config.payoutAccount.bankName || 'Meezan Bank Ltd (Islamic)');
      setChangeAccountHolderName(config.payoutAccount.accountHolderName || 'NOVORA Atelier & Retail (Pvt) Ltd');
      setChangeCountry(config.payoutAccount.country || 'Pakistan');
      setChangeCurrency(config.payoutAccount.currency || 'PKR');
      setChangeBranchCode(config.payoutAccount.branchCode || '');
    }
    setChangeIban('');
    setChangeAdminPassword('');
    setChangeAgreed(false);
    setChangePayoutError(null);
    setChangeSuccessRecord(null);
    setIsChangePayoutModalOpen(true);
  };

  // Submit Change Payout Account
  const handleSubmitChangePayout = async (e: React.FormEvent) => {
    e.preventDefault();
    setChangePayoutError(null);

    if (!changeAgreed) {
      setChangePayoutError('You must confirm that you authorize redirecting merchant customer payout settlements to this account.');
      return;
    }

    const effectiveBank = changeBankName === 'Other / International Commercial Bank' ? changeCustomBankName.trim() : changeBankName;
    if (!effectiveBank) {
      setChangePayoutError('Please select or specify a valid commercial bank name.');
      return;
    }

    if (!changeAccountHolderName.trim()) {
      setChangePayoutError('Account holder name is required and must match your registered corporate/tax identity.');
      return;
    }

    const cleanIban = changeIban.replace(/\s+/g, '');
    if (cleanIban.length < 8) {
      setChangePayoutError('Please enter a valid 24-character IBAN or bank account number.');
      return;
    }

    setIsSubmittingPayoutChange(true);
    try {
      const res = await api.changePayoutAccount({
        bankName: effectiveBank,
        accountHolderName: changeAccountHolderName.trim(),
        country: changeCountry,
        currency: changeCurrency,
        accountNumberOrIban: cleanIban,
        branchCode: changeBranchCode.trim() || undefined,
        reasonForChange: changeReason.trim(),
        adminConfirmationPassword: changeAdminPassword.trim() || undefined,
      });

      setConfig(res.paymentGateway);
      setChangeSuccessRecord({
        confirmationReference: res.confirmationReference,
        payoutAccount: res.payoutAccount,
        message: res.message,
      });
      notify(res.message || 'Payout bank destination successfully updated and verified on 1Link rails!', 'success');
    } catch (err: any) {
      setChangePayoutError(err.message || 'Failed to update payout destination. Please check the IBAN.');
      notify(err.message || 'Payout destination change failed', 'error');
    } finally {
      setIsSubmittingPayoutChange(false);
    }
  };

  // Handle Connect Payment Provider
  const handleConnectProvider = async (provider: 'safepay' | 'stripe' | 'paymob') => {
    setIsConnecting(true);
    try {
      const res = await api.connectPaymentProvider(provider);
      setConfig(res.paymentGateway);
      setIsConnectModalOpen(false);
      notify(res.message || `Successfully linked with ${provider.toUpperCase()} Gateway!`);
    } catch (err: any) {
      notify(err.message || 'Failed to connect payment provider', 'error');
    } finally {
      setIsConnecting(false);
    }
  };

  // Handle Save and Verify Bank Account
  const handleSaveAndVerifyBankAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setBankFormError(null);

    const effectiveBankName = bankName === 'Other / International Commercial Bank' ? customBankName.trim() : bankName;

    if (!effectiveBankName) {
      setBankFormError('Please select or specify your bank name.');
      return;
    }

    if (!accountHolderName.trim()) {
      setBankFormError('Account holder name is required and must match your registered tax/merchant identity.');
      return;
    }

    const cleanIban = accountNumberOrIban.replace(/\s+/g, '');
    if (cleanIban.length < 8) {
      setBankFormError('Please enter a valid Bank Account Number or 24-character IBAN.');
      return;
    }

    setIsVerifyingBank(true);
    try {
      const res = await api.saveAndVerifyBankAccount({
        bankName: effectiveBankName,
        accountHolderName: accountHolderName.trim(),
        country,
        currency,
        accountNumberOrIban: cleanIban,
        branchCode: branchCode.trim() || undefined,
      });

      setConfig(res.paymentGateway);
      notify(res.message || 'Bank account successfully verified and linked for payouts!');
    } catch (err: any) {
      setBankFormError(err.message || 'Bank verification failed. Please check your IBAN.');
      notify(err.message || 'Failed to verify bank account', 'error');
    } finally {
      setIsVerifyingBank(false);
    }
  };

  // Handle Disconnect Gateway and Bank Account
  const handleDisconnect = async () => {
    if (!window.confirm('Are you sure you want to disconnect this payment provider and payout account? Online card checkout will be disabled until reconnected.')) {
      return;
    }

    try {
      const res = await api.disconnectPaymentGateway();
      setConfig(res.paymentGateway);
      notify('Payment provider and payout account disconnected.', 'info');
    } catch (err: any) {
      notify(err.message || 'Failed to disconnect account', 'error');
    }
  };

  // Handle Test Connection
  const handleTestConnection = async () => {
    setIsTestingConnection(true);
    setConnectionTestResult(null);
    try {
      const res = await api.testPaymentConnection();
      setConnectionTestResult(res);
      notify(`Connection handshake successful: ${res.latencyMs}ms latency · Webhook Active`, 'success');
    } catch (err: any) {
      notify(err.message || 'Connection test failed', 'error');
    } finally {
      setIsTestingConnection(false);
    }
  };

  // Handle Order Refund
  const handleProcessRefund = async () => {
    if (!selectedTxForRefund) return;
    setRefundError(null);

    const amt = parseFloat(refundAmount);
    if (isNaN(amt) || amt <= 0 || amt > selectedTxForRefund.amount) {
      setRefundError(`Refund amount must be between 1 and ${selectedTxForRefund.currency} ${selectedTxForRefund.amount.toLocaleString()}.`);
      return;
    }

    setIsProcessingRefund(true);
    try {
      const res = await api.refundOrder(selectedTxForRefund.orderId, {
        amount: amt,
        reason: refundReason.trim() || 'Merchant issued refund via Admin Payout Settings',
      });

      notify(res.message || 'Refund successfully processed!');
      setSelectedTxForRefund(null);
      setRefundAmount('');
      setRefundReason('');

      // Refresh transactions
      const updatedTx = await api.getPaymentTransactions();
      setTransactions(updatedTx);
    } catch (err: any) {
      setRefundError(err.message || 'Failed to process refund');
      notify(err.message || 'Refund processing failed', 'error');
    } finally {
      setIsProcessingRefund(false);
    }
  };

  // Filter transactions
  const filteredTransactions = transactions.filter(t => {
    const matchesFilter =
      txFilter === 'all'
        ? true
        : txFilter === 'paid'
        ? t.paymentStatus === 'paid'
        : txFilter === 'refunded'
        ? t.paymentStatus === 'refunded' || t.paymentStatus === 'partially_refunded'
        : t.paymentStatus === 'pending';

    const q = txSearch.toLowerCase().trim();
    const matchesSearch =
      !q ||
      t.transactionReference.toLowerCase().includes(q) ||
      t.orderNumber.toLowerCase().includes(q) ||
      t.customerName.toLowerCase().includes(q) ||
      t.customerEmail.toLowerCase().includes(q);

    return matchesFilter && matchesSearch;
  });

  // Calculate transaction metrics
  const totalProcessed = transactions
    .filter(t => t.paymentStatus === 'paid')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalFees = transactions
    .filter(t => t.paymentStatus === 'paid')
    .reduce((sum, t) => sum + t.fee, 0);

  const totalDeposited = transactions
    .filter(t => t.payoutStatus === 'Deposited')
    .reduce((sum, t) => sum + t.netPayout, 0);

  const totalScheduled = transactions
    .filter(t => t.payoutStatus === 'Scheduled (T+2)' || t.payoutStatus === 'In Transit')
    .reduce((sum, t) => sum + t.netPayout, 0);

  if (isLoading) {
    return (
      <div className="bg-white p-12 rounded-2xl border border-stone-200 text-center space-y-3">
        <RefreshCw className="w-8 h-8 text-purple-700 animate-spin mx-auto" />
        <p className="text-sm font-semibold text-stone-700">Loading Bank & Payment Payout Settings...</p>
        <p className="text-xs text-stone-400">Verifying merchant connection and bank rails</p>
      </div>
    );
  }

  const isLive = config?.mode === 'live' || (!config?.isTestMode && config?.mode !== 'test');
  const hasPayoutAccount = !!config?.payoutAccount || !!config?.payoutAccountMasked;

  return (
    <div className="space-y-8 max-w-5xl">
      {/* Page Header */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold text-purple-700 uppercase tracking-widest">
                Merchant Banking & Payout Settings
              </span>
              <span className="text-stone-300">·</span>
              <span className="text-xs font-medium text-stone-500">Private Admin Panel</span>
            </div>
            <h1 className="text-2xl font-bold text-stone-950 font-display">
              Payment & Bank Payout Settings
            </h1>
            <p className="text-xs text-stone-500 mt-1">
              Connect your verified bank account in Pakistan or internationally to receive customer purchases and manage automated payouts.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {/* Mode Indicator & Switcher */}
            <div className="flex items-center bg-stone-100 p-1 rounded-xl border border-stone-200 text-xs">
              <button
                type="button"
                onClick={() => handleToggleMode('test')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                  !isLive
                    ? 'bg-amber-500 text-white shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                Test Mode
              </button>
              <button
                type="button"
                onClick={() => handleToggleMode('live')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                  isLive
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                Live Mode
              </button>
            </div>

            {/* Test Connection Button */}
            <button
              type="button"
              disabled={isTestingConnection}
              onClick={handleTestConnection}
              className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 border border-stone-200"
              title="Ping gateway API & verify webhook listener"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTestingConnection ? 'animate-spin text-purple-700' : 'text-stone-600'}`} />
              <span>{isTestingConnection ? 'Testing...' : 'Test Connection'}</span>
            </button>
          </div>
        </div>

        {/* CORE ACTION TOOLBAR WITH ALL 5 REQUIRED BUTTONS */}
        <div className="bg-stone-900 text-white p-4 rounded-xl border border-stone-800 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
              <span className="text-xs font-bold uppercase tracking-wider text-purple-300">
                Admin Payout & Payment Controls
              </span>
            </div>

            {saveStatusMessage && (
              <div className={`px-3 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 animate-fadeIn ${
                saveStatusMessage.type === 'saving'
                  ? 'bg-amber-950/80 text-amber-200 border border-amber-600/60'
                  : saveStatusMessage.type === 'success'
                  ? 'bg-emerald-950/80 text-emerald-200 border border-emerald-600/60'
                  : 'bg-rose-950/80 text-rose-200 border border-rose-600/60'
              }`}>
                {saveStatusMessage.type === 'saving' && <RefreshCw className="w-3 h-3 animate-spin text-amber-300" />}
                {saveStatusMessage.type === 'success' && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
                {saveStatusMessage.type === 'error' && <AlertTriangle className="w-3 h-3 text-rose-400" />}
                <span>{saveStatusMessage.text}</span>
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-stone-800/80 text-xs">
            {/* Button 1: Connect Payment Gateway */}
            <button
              type="button"
              onClick={() => setIsConnectModalOpen(true)}
              className="px-3.5 py-2 bg-purple-700 hover:bg-purple-600 text-white font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-xs"
              title="Connect Safepay, Stripe, or Paymob merchant account"
            >
              <CreditCard className="w-3.5 h-3.5 text-purple-200" />
              <span>Connect Payment Gateway</span>
            </button>

            {/* Button 2: Secure Bank Payout Setup */}
            <button
              type="button"
              onClick={() => {
                const formEl = document.getElementById('bank-account-form');
                formEl?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-3.5 py-2 bg-stone-800 hover:bg-stone-700 text-stone-100 font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 border border-stone-700"
              title="Link verified bank account for customer payouts"
            >
              <Building2 className="w-3.5 h-3.5 text-amber-400" />
              <span>Secure Bank Payout Setup</span>
            </button>

            {/* Button 3: Change Payout Account */}
            <button
              type="button"
              onClick={handleOpenChangePayoutModal}
              className="px-3.5 py-2 bg-stone-800 hover:bg-emerald-950/60 text-emerald-300 hover:text-emerald-200 font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 border border-emerald-500/40"
              title="Update and verify new bank payout destination"
            >
              <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
              <span>Change Payout Account</span>
            </button>

            {/* Button 4: Verify Connection */}
            <button
              type="button"
              disabled={isTestingConnection}
              onClick={handleTestConnection}
              className="px-3.5 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 border border-stone-700"
              title="Live handshake test with payment gateway and webhook listener"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTestingConnection ? 'animate-spin text-purple-400' : 'text-stone-400'}`} />
              <span>{isTestingConnection ? 'Verifying...' : 'Verify Connection'}</span>
            </button>

            {/* Button 5: Save Settings */}
            <button
              type="button"
              disabled={isSaving}
              onClick={handleSaveSettings}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shadow-xs sm:ml-auto"
              title="Save non-sensitive payment & payout settings to persistent database"
            >
              {isSaving ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Saving...</span>
                </>
              ) : (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Save Settings</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Live / Sandbox Status Strip */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs pt-1">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-stone-500">Connection Status:</span>
            {config?.isConnected ? (
              <span className="inline-flex items-center gap-1.5 font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
                Connected ({config.provider.toUpperCase()} Gateway)
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200">
                <span className="w-2 h-2 rounded-full bg-amber-600" />
                Pending Connection
              </span>
            )}

            <span className="text-stone-300">·</span>
            <span className="font-semibold text-stone-500">Payout Status:</span>
            <span className={`font-bold ${config?.payoutStatus === 'Active' ? 'text-emerald-700' : 'text-stone-700'}`}>
              {config?.payoutStatus || 'Needs Setup'}
            </span>
          </div>

          <div className="flex items-center gap-2 text-stone-500 text-[11px]">
            <Lock className="w-3.5 h-3.5 text-stone-400" />
            <span>Encrypted via TLS 1.3 · SBP/1Link Compliant</span>
          </div>
        </div>

        {/* Connection Handshake Results Display */}
        {connectionTestResult && (
          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-950 space-y-1.5 animate-fadeIn">
            <div className="flex items-center justify-between font-bold">
              <span className="flex items-center gap-1.5 text-emerald-900">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Gateway Handshake Successful
              </span>
              <span className="font-mono text-[11px] bg-white px-2 py-0.5 rounded border border-emerald-200 text-emerald-800">
                Latency: {connectionTestResult.latencyMs}ms
              </span>
            </div>
            <p className="text-stone-600">
              Provider API <strong>{connectionTestResult.provider?.toUpperCase()}</strong> ({connectionTestResult.mode?.toUpperCase()} Mode) is responsive. Webhook endpoint <code className="bg-emerald-100/60 px-1 py-0.5 rounded font-mono text-[11px]">{connectionTestResult.webhookEndpoint}</code> is operational and ready to process real-time transaction events.
            </p>
          </div>
        )}
      </div>

      {/* Security Best Practices & Zero-Storage Guarantee Banner */}
      <div className="p-5 bg-gradient-to-r from-purple-50 via-stone-50 to-purple-50/50 border border-purple-200 rounded-2xl flex flex-col sm:flex-row items-start gap-4 text-xs">
        <div className="p-2.5 bg-purple-100 text-purple-800 rounded-xl shrink-0 mt-0.5">
          <ShieldCheck className="w-6 h-6 text-purple-700" />
        </div>
        <div className="space-y-1 text-stone-700">
          <p className="font-bold text-stone-950 text-sm">
            Bank-Grade Security & Zero-Storage Guarantee
          </p>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-1 list-disc pl-4 text-stone-600 text-[11px] leading-relaxed">
            <li>We <strong>never request or store</strong> your ATM PIN, online banking password, or card CVV.</li>
            <li>Customer debit and credit cards are tokenized directly through the payment gateway; full card numbers are never stored in the database.</li>
            <li>Disbursements are wired directly into your verified bank account via official 1Link / PRISM settlement rails.</li>
            <li>Secret API credentials are kept in secure backend environment variables and never exposed to client browsers.</li>
          </ul>
        </div>
      </div>

      {/* 5-POINT LIVE PAYMENTS SETUP CHECKLIST */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-stone-200">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold text-purple-700 uppercase tracking-wider">
                Production Readiness
              </span>
              <span className="text-stone-300">·</span>
              <span className="text-xs text-stone-500">SBP & Card Scheme Regulatory Standards</span>
            </div>
            <h2 className="text-base font-bold text-stone-900">
              Live Payments Setup Checklist
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              Before accepting real customer cards, complete these 5 steps. Saving a card does not automatically connect a bank account to receive customer payments.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {credentialsStatus?.isLiveEligible ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-xl text-xs font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                All 5 Requirements Satisfied (Live Ready)
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 text-amber-800 border border-amber-300 rounded-xl text-xs font-bold">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                Action Required ({credentialsStatus?.checklist ? credentialsStatus.checklist.filter((c: any) => c.status === 'completed').length : 0} of 5 Completed)
              </span>
            )}
          </div>
        </div>

        {/* 5 Checklist Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {(credentialsStatus?.checklist || [
            {
              id: 'merchant_account',
              title: '1. SBP-Licensed Merchant Registration',
              description: 'Official account registered with Safepay or Paymob in Pakistan.',
              status: config?.isConnected ? 'completed' : 'pending',
            },
            {
              id: 'server_keys',
              title: '2. Server-Side Secret & Public API Keys',
              description: 'Stored securely in backend environment variables. Never in frontend.',
              status: config?.apiKeyMasked ? 'completed' : 'pending',
            },
            {
              id: 'webhook_secret',
              title: '3. Cryptographic Webhook Signing Secret',
              description: 'Enables HMAC-SHA256 signature verification for real-time payment events.',
              status: config?.webhookSecret ? 'completed' : 'pending',
            },
            {
              id: 'kyc_approval',
              title: '4. Regulatory KYC & SBP Approval',
              description: 'CNIC, NTN, Bank Maintenance Certificate verified by payment provider.',
              status: config?.merchantKycStatus === 'verified' ? 'completed' : 'pending',
            },
            {
              id: 'bank_payout',
              title: '5. Verified 1Link IBAN Payout Account',
              description: 'Pakistani bank account connected for rolling T+2 automated proceeds deposit.',
              status: (config?.payoutAccount?.status === 'Verified' || config?.payoutAccount?.isVerified) ? 'completed' : 'pending',
            },
          ]).map((item: any, idx: number) => {
            const isDone = item.status === 'completed';
            return (
              <div
                key={item.id || idx}
                className={`p-4 rounded-xl border transition-all ${
                  isDone
                    ? 'bg-emerald-50/40 border-emerald-200'
                    : 'bg-stone-50 border-stone-200 hover:border-amber-300'
                }`}
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className={`p-1.5 rounded-lg ${isDone ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                    {isDone ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      isDone
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {isDone ? 'Configured' : 'Setup Required'}
                  </span>
                </div>
                <h3 className="font-bold text-stone-900 text-xs mb-1">{item.title}</h3>
                <p className="text-[11px] text-stone-500 leading-relaxed">{item.description}</p>
              </div>
            );
          })}
        </div>

        {/* Action strip for checklist */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-stone-200 text-xs">
          <div className="flex items-center gap-2 text-stone-600 text-[11px]">
            <Info className="w-4 h-4 text-purple-700 shrink-0" />
            <span>
              Live Mode is protected: transactions cannot run live until all 5 security gates are green.
            </span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={handleOpenCredsModal}
              className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Configure Server Credentials</span>
            </button>
          </div>
        </div>
      </div>

      {/* =========================================================================
          SYSTEM ARCHITECTURE & PAYMENT FLOW BLUEPRINT (OFFICIAL NOVORA BLUEPRINT)
      ========================================================================= */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold text-purple-700 uppercase tracking-widest">
                System Architecture & Operational Blueprint
              </span>
              <span className="text-stone-300">·</span>
              <span className="text-xs font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                Active System Specification
              </span>
            </div>
            <h2 className="text-xl font-bold text-stone-950 font-display">
              NOVORA — Admin Bank Card Entry & Payment Flow System
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              Visual map of how admin cards are added/changed and how customer checkout payments settle into your merchant account.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0 flex-wrap">
            <button
              type="button"
              onClick={() => setIsDiagramOpen(true)}
              className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer flex items-center gap-2"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>Enlarge Flowchart</span>
            </button>
            <a
              href="/assets/aistudio/Novora_Admin_Payment_Flow_System_3ecf585c.png"
              download="Novora_Admin_Payment_Flow_System.png"
              className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 font-semibold text-xs rounded-xl border border-stone-200 transition-colors flex items-center gap-1.5"
              title="Download Full Resolution Diagram"
            >
              <Download className="w-3.5 h-3.5 text-stone-600" />
              <span>Download PNG</span>
            </a>
            <button
              type="button"
              onClick={() => setShowDiagramSection(!showDiagramSection)}
              className="p-2 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded-xl transition-colors cursor-pointer"
              title={showDiagramSection ? 'Collapse Section' : 'Expand Section'}
            >
              {showDiagramSection ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {showDiagramSection && (
          <div className="space-y-6">
            {/* Embedded Diagram Banner View */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
              
              {/* Diagram Image Thumbnail Preview with Zoom overlay */}
              <div className="lg:col-span-7">
                <div
                  onClick={() => setIsDiagramOpen(true)}
                  className="relative aspect-16/10 w-full rounded-2xl overflow-hidden border border-stone-300 bg-stone-900 shadow-md cursor-pointer group"
                >
                  <img
                    src="/assets/aistudio/Novora_Admin_Payment_Flow_System_3ecf585c.png"
                    alt="NOVORA Admin Bank Card Entry & Payment Flow System"
                    className="w-full h-full object-cover object-top group-hover:scale-102 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-stone-950/20 group-hover:bg-stone-950/40 flex items-center justify-center transition-colors">
                    <span className="px-4 py-2 bg-stone-950/90 text-white font-bold text-xs rounded-xl shadow-lg border border-white/20 flex items-center gap-2 group-hover:scale-105 transition-transform">
                      <Eye className="w-4 h-4 text-purple-400" />
                      <span>Click to Inspect High-Resolution Blueprint</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Architecture Blueprint Key Pillars */}
              <div className="lg:col-span-5 space-y-3.5 text-xs">
                {/* Pillar 1 */}
                <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-stone-900 flex items-center gap-1.5">
                      <CreditCard className="w-4 h-4 text-purple-700" />
                      <span>1. Admin Card Management Flow</span>
                    </span>
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">Active</span>
                  </div>
                  <p className="text-[11px] text-stone-600 leading-relaxed">
                    Add business cards, validate via gateway tokenization, and switch active default card anytime. Old cards are automatically deactivated from receiving new disbursements.
                  </p>
                  <button
                    type="button"
                    onClick={handleOpenCardModal}
                    className="text-[11px] font-bold text-purple-700 hover:text-purple-900 underline cursor-pointer inline-flex items-center gap-1 pt-0.5"
                  >
                    Add / Change Card Now &rarr;
                  </button>
                </div>

                {/* Pillar 2 */}
                <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-stone-900 flex items-center gap-1.5">
                      <Banknote className="w-4 h-4 text-amber-600" />
                      <span>2. Customer Payment &rarr; Admin Card Settlement</span>
                    </span>
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">Active</span>
                  </div>
                  <p className="text-[11px] text-stone-600 leading-relaxed">
                    Customer checkout validates stock and totals &rarr; opens secure gateway &rarr; HMAC-SHA256 webhook confirms status &rarr; funds settled to your default 1Link bank account.
                  </p>
                </div>

                {/* Pillar 3 */}
                <div className="p-3.5 bg-purple-50/60 rounded-xl border border-purple-200 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-purple-950 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-purple-700" />
                      <span>3. Zero-PAN Storage Security Architecture</span>
                    </span>
                    <span className="text-[10px] font-bold text-purple-800 bg-purple-100 px-2 py-0.5 rounded">PCI-DSS</span>
                  </div>
                  <p className="text-[11px] text-purple-900 leading-relaxed">
                    CVV and full PAN are never stored in your database. Only tokenized references and masked 4 digits (e.g. <code>•••• 9922</code>) are persisted.
                  </p>
                </div>
              </div>

            </div>

            {/* Quick Flow Summary Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-center text-xs pt-2">
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <span className="text-[10px] font-bold text-stone-400 uppercase">Phase 1</span>
                <p className="font-bold text-stone-900 mt-0.5">Admin Adds Card</p>
                <p className="text-[11px] text-stone-500">Tokenized & Verified</p>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <span className="text-[10px] font-bold text-stone-400 uppercase">Phase 2</span>
                <p className="font-bold text-stone-900 mt-0.5">Customer Buys</p>
                <p className="text-[11px] text-stone-500">Cart & Price Validated</p>
              </div>

              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <span className="text-[10px] font-bold text-stone-400 uppercase">Phase 3</span>
                <p className="font-bold text-stone-900 mt-0.5">Webhook Confirms</p>
                <p className="text-[11px] text-stone-500">Instant Order Status Update</p>
              </div>

              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200">
                <span className="text-[10px] font-bold text-emerald-600 uppercase">Phase 4</span>
                <p className="font-bold text-emerald-950 mt-0.5">Proceeds Settled</p>
                <p className="text-[11px] text-emerald-800 font-semibold">Funds Wired to Admin</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* SECTION 1: CONNECT MY BANK ACCOUNT */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-stone-200">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-stone-100 text-purple-700 rounded-xl">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-stone-900">
                1. Connect My Bank Account
              </h2>
              <p className="text-xs text-stone-500">
                Link the bank account where eligible proceeds from customer purchases will be deposited.
              </p>
            </div>
          </div>

          {hasPayoutAccount && (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-full text-xs font-bold">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              Verified Payout Account
            </span>
          )}
        </div>

        {/* Masked Account Details Display if saved */}
        {hasPayoutAccount && (
          <div className="p-5 bg-stone-50 rounded-2xl border border-stone-200 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-purple-700">
                    Active Settlement Account
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                    1Link / SBP Verified
                  </span>
                </div>
                <p className="text-base font-bold text-stone-900">
                  {config?.payoutAccount?.bankName || config?.payoutAccountMasked.split('·')[0] || 'Meezan Bank Ltd'}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleOpenChangePayoutModal}
                  className="px-3.5 py-1.5 bg-purple-700 hover:bg-purple-800 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
                >
                  <RefreshCw className="w-3.5 h-3.5 text-purple-200" />
                  <span>Change Payout Account</span>
                </button>
                <button
                  type="button"
                  onClick={handleDisconnect}
                  className="px-3 py-1.5 bg-white hover:bg-rose-50 text-rose-700 border border-stone-200 hover:border-rose-300 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                >
                  Disconnect Account
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 bg-white p-4 rounded-xl border border-stone-200 text-xs">
              <div>
                <span className="text-[11px] font-medium text-stone-400 block">Beneficiary Account Title</span>
                <span className="font-bold text-stone-800">
                  {config?.payoutAccount?.accountHolderName || 'NOVORA Atelier & Retail (Pvt) Ltd'}
                </span>
              </div>

              <div>
                <span className="text-[11px] font-medium text-stone-400 block">Masked IBAN / Account #</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="font-mono font-bold text-stone-900">
                    {config?.payoutAccount?.maskedIban || config?.payoutAccountMasked || 'PK92 MEZN 0001 **** **** 4821'}
                  </span>
                </div>
                <span className="text-[10px] font-medium text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded mt-1 inline-block">
                  Ending in •••• {(config?.payoutAccount?.maskedIban || config?.payoutAccountMasked || '4821').slice(-4)}
                </span>
              </div>

              <div>
                <span className="text-[11px] font-medium text-stone-400 block">Settlement Currency</span>
                <span className="font-bold text-stone-800">
                  {config?.payoutAccount?.country || 'Pakistan'} ({config?.payoutAccount?.currency || 'PKR'})
                </span>
              </div>

              <div>
                <span className="text-[11px] font-medium text-stone-400 block">Payout Frequency</span>
                <span className="font-bold text-emerald-700 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  Rolling T+2 Days (Automated)
                </span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px] text-stone-500 pt-1 border-t border-stone-200/70">
              <span className="flex items-center gap-1.5 text-stone-600">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                Verified on {config?.payoutAccount?.verifiedAt ? new Date(config.payoutAccount.verifiedAt).toLocaleDateString() : 'Active'}. Incoming customer funds from online card checkouts settle here.
              </span>
              <span className="font-mono text-purple-800 font-bold bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                Eligible Payout Balance: PKR 184,500
              </span>
            </div>
          </div>
        )}

        {/* PAYOUT DESTINATION AUDIT TRAIL & SBP CHANGE LOG */}
        <div className="bg-stone-50 p-5 rounded-2xl border border-stone-200 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-stone-200 text-stone-700 rounded-lg">
                <History className="w-4 h-4 text-purple-700" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                  Payout Destination Audit Trail & Change Log
                </h3>
                <p className="text-[11px] text-stone-500">
                  Permanent audit record of bank destination changes and State Bank regulatory confirmations.
                </p>
              </div>
            </div>

            <span className="text-[11px] font-medium text-stone-500 bg-white px-2.5 py-1 rounded-lg border border-stone-200">
              {(config?.payoutAuditLog || []).length} Logged Action{(config?.payoutAuditLog || []).length === 1 ? '' : 's'}
            </span>
          </div>

          <div className="overflow-x-auto rounded-xl border border-stone-200 bg-white">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-100/80 text-stone-700 font-bold border-b border-stone-200 text-[11px] uppercase tracking-wider">
                <tr>
                  <th className="py-2.5 px-3">Date & Time</th>
                  <th className="py-2.5 px-3">Authorized By</th>
                  <th className="py-2.5 px-3">Action</th>
                  <th className="py-2.5 px-3">Previous Destination</th>
                  <th className="py-2.5 px-3">New Destination</th>
                  <th className="py-2.5 px-3">Confirmation Ref</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {(config?.payoutAuditLog && config.payoutAuditLog.length > 0) ? (
                  config.payoutAuditLog.map((log) => (
                    <tr key={log.id} className="hover:bg-purple-50/30 transition-colors">
                      <td className="py-2.5 px-3 text-stone-600 whitespace-nowrap">
                        {new Date(log.changedAt).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-stone-800 whitespace-nowrap">
                        {log.adminEmail}
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          log.action === 'payout_destination_updated'
                            ? 'bg-purple-100 text-purple-800'
                            : log.action === 'payout_destination_linked'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}>
                          {log.action === 'payout_destination_updated'
                            ? 'Destination Updated'
                            : log.action === 'payout_destination_linked'
                            ? 'Destination Linked'
                            : 'Disconnected'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-mono text-stone-500 whitespace-nowrap text-[11px]">
                        {log.previousAccountMasked}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-bold text-stone-900 whitespace-nowrap text-[11px]">
                        {log.newAccountMasked}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-bold text-purple-800 whitespace-nowrap text-[11px]">
                        {log.confirmationReference}
                      </td>
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 font-semibold text-emerald-700 text-[11px]">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          Verified
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="py-4 text-center text-stone-400 text-xs">
                      No payout destination change records logged yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Bank Connection Form */}
        <form id="bank-account-form" onSubmit={handleSaveAndVerifyBankAccount} className="space-y-4 text-xs">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-stone-900 text-sm">
              {hasPayoutAccount ? 'Update Bank Account Details' : 'Enter Bank Account Information'}
            </h3>
            <span className="text-[11px] text-stone-400">
              Approved Payment-Provider Secure Rail
            </span>
          </div>

          {bankFormError && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{bankFormError}</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Bank Name */}
            <div>
              <label className="block font-semibold text-stone-700 mb-1">
                Bank Name <span className="text-rose-500">*</span>
              </label>
              <select
                value={bankName}
                onChange={e => setBankName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-white text-stone-800 focus:outline-none focus:ring-2 focus:ring-purple-600"
              >
                {POPULAR_PAKISTAN_BANKS.map(b => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>

            {/* Custom Bank Name if "Other" */}
            {bankName === 'Other / International Commercial Bank' ? (
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Specify Commercial Bank Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g., Barclays Bank, Emirates NBD"
                  value={customBankName}
                  onChange={e => setCustomBankName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-stone-800 focus:outline-none focus:ring-2 focus:ring-purple-600"
                  required
                />
              </div>
            ) : (
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Branch Code (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g., 0102"
                  value={branchCode}
                  onChange={e => setBranchCode(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-stone-800 focus:outline-none focus:ring-2 focus:ring-purple-600"
                />
              </div>
            )}

            {/* Account Holder Name */}
            <div>
              <label className="block font-semibold text-stone-700 mb-1">
                Account Holder Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                placeholder="Must match NTN / CNIC / Business name"
                value={accountHolderName}
                onChange={e => setAccountHolderName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-stone-800 focus:outline-none focus:ring-2 focus:ring-purple-600"
                required
              />
              <p className="text-[10px] text-stone-400 mt-1">
                Must strictly match your corporate bank title or individual sole proprietor identity.
              </p>
            </div>

            {/* Country and Currency */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Country <span className="text-rose-500">*</span>
                </label>
                <select
                  value={country}
                  onChange={e => setCountry(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-stone-300 bg-white text-stone-800 focus:outline-none focus:ring-2 focus:ring-purple-600"
                >
                  <option value="Pakistan">Pakistan (PK)</option>
                  <option value="United Kingdom">United Kingdom (GB)</option>
                  <option value="United States">United States (US)</option>
                  <option value="United Arab Emirates">United Arab Emirates (AE)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  Currency <span className="text-rose-500">*</span>
                </label>
                <select
                  value={currency}
                  onChange={e => setCurrency(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-stone-300 bg-white text-stone-800 focus:outline-none focus:ring-2 focus:ring-purple-600 font-mono font-bold"
                >
                  <option value="PKR">PKR (Pakistani Rupee)</option>
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="AED">AED (Dirham)</option>
                </select>
              </div>
            </div>

            {/* Bank Account Number or IBAN */}
            <div className="md:col-span-2">
              <label className="block font-semibold text-stone-700 mb-1">
                Bank Account Number or IBAN <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="e.g., PK92 MEZN 0000 0001 2345 6701"
                  value={accountNumberOrIban}
                  onChange={e => setAccountNumberOrIban(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 font-mono text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600 pr-10"
                  required
                />
                <Lock className="w-4 h-4 text-stone-400 absolute right-3.5 top-3" />
              </div>
              <p className="text-[11px] text-stone-500 mt-1 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Account numbers are verified securely and masked immediately after saving. We never store debit card PINs or passwords.</span>
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              type="submit"
              disabled={isVerifyingBank}
              className="px-5 py-2.5 bg-purple-700 hover:bg-purple-800 disabled:opacity-50 text-white font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-2"
            >
              {isVerifyingBank ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Verifying Bank Account...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Save and Verify Account</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => setIsConnectModalOpen(true)}
              className="px-4 py-2.5 bg-stone-900 hover:bg-stone-800 text-white font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <CreditCard className="w-4 h-4 text-purple-300" />
              <span>Connect Payment Provider</span>
            </button>
          </div>
        </form>
      </div>

      {/* SECTION 2: MERCHANT BUSINESS CARDS (CHANGE CARD SYSTEM) */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-stone-200">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-stone-100 text-purple-700 rounded-xl">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <h2 className="text-base font-bold text-stone-900">
                  2. Merchant Business Cards & Billing Details
                </h2>
                <span className="text-[10px] font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                  Change Card Anytime
                </span>
              </div>
              <p className="text-xs text-stone-500">
                Manage your registered business card for merchant reserves, automated supplier orders, and instant payout capabilities.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleOpenCardModal}
              className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 shadow-xs"
            >
              <Edit className="w-3.5 h-3.5" />
              <span>{config?.merchantCard ? 'Change / Update Card' : 'Connect Business Card'}</span>
            </button>
            <button
              type="button"
              onClick={handleOpenCardModal}
              className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Card</span>
            </button>
          </div>
        </div>

        {/* Visual Card Display & Quick Management Panel */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Virtual Luxury Card Preview */}
          <div className="lg:col-span-5">
            <div className="relative aspect-[1.586/1] w-full max-w-sm mx-auto rounded-2xl p-6 bg-gradient-to-br from-stone-950 via-stone-900 to-purple-950 text-white shadow-xl border border-stone-800 flex flex-col justify-between overflow-hidden group">
              {/* Card Hologram & Mesh Effect */}
              <div className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-purple-500/10 blur-2xl pointer-events-none" />
              <div className="absolute top-0 right-0 w-32 h-32 bg-stone-500/10 rounded-full blur-xl pointer-events-none" />

              {/* Top Row: Chip & Contactless & Brand */}
              <div className="flex items-center justify-between z-10">
                <div className="flex items-center gap-3">
                  {/* EMV Chip Graphic */}
                  <div className="w-10 h-7 rounded-md bg-gradient-to-tr from-amber-300 via-yellow-200 to-amber-400 border border-amber-400/50 flex flex-col justify-center px-1 shadow-xs">
                    <div className="h-0.5 bg-amber-700/30 w-full mb-1" />
                    <div className="h-0.5 bg-amber-700/30 w-full" />
                  </div>
                  <Wifi className="w-4 h-4 text-stone-400 rotate-90" />
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-purple-300 bg-purple-900/60 px-2 py-0.5 rounded border border-purple-700/60">
                    Business Merchant
                  </span>
                  <span className="font-display font-black text-sm tracking-wider text-white">
                    {config?.merchantCard?.brand || 'VISA'}
                  </span>
                </div>
              </div>

              {/* Middle Row: Masked Number */}
              <div className="z-10 my-3">
                <p className="font-mono text-lg sm:text-xl tracking-widest text-stone-100 font-semibold drop-shadow-xs">
                  •••• •••• •••• {config?.merchantCard?.last4 || '4821'}
                </p>
              </div>

              {/* Bottom Row: Cardholder & Expiry */}
              <div className="flex items-end justify-between z-10 text-xs">
                <div>
                  <span className="text-[9px] uppercase tracking-widest text-stone-400 block font-medium">
                    Cardholder Name
                  </span>
                  <p className="font-bold tracking-wide uppercase text-stone-100 text-[11px] truncate max-w-[190px]">
                    {config?.merchantCard?.cardholderName || 'NOVORA Luxury E-Commerce Pvt Ltd'}
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-[9px] uppercase tracking-widest text-stone-400 block font-medium">
                    Expires
                  </span>
                  <p className="font-mono font-bold text-stone-200 text-xs">
                    {config?.merchantCard?.expiryMonth || '09'} / {config?.merchantCard?.expiryYear || '28'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Details & Actions Panel */}
          <div className="lg:col-span-7 space-y-4 text-xs">
            <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  Primary Settlement & Billing Card
                </span>
                <span className="font-mono text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  Active & Verified
                </span>
              </div>
              <p className="text-stone-600 text-[11px] leading-relaxed">
                This card is registered for automated store fees, dropshipping fulfillment dispatch, dispute protection, and instant card payout transfers.
              </p>
              <div className="pt-2 flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleOpenCardModal}
                  className="px-3.5 py-1.5 bg-white hover:bg-stone-100 text-purple-700 font-bold rounded-lg border border-purple-200 text-xs transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
                >
                  <Edit className="w-3 h-3" />
                  <span>Change Card Number / Details</span>
                </button>
                {config?.merchantCards && config.merchantCards.length > 1 && (
                  <span className="text-[11px] text-stone-400">
                    · {config.merchantCards.length} cards registered
                  </span>
                )}
              </div>
            </div>

            {/* List of multiple cards if stored */}
            {config?.merchantCards && config.merchantCards.length > 1 && (
              <div className="space-y-2">
                <span className="font-bold text-stone-800 text-[11px] block">
                  Other Registered Cards ({config.merchantCards.length}):
                </span>
                <div className="space-y-1.5 max-h-36 overflow-y-auto">
                  {config.merchantCards.map(c => (
                    <div
                      key={c.id}
                      className={`p-2.5 rounded-xl border flex items-center justify-between ${
                        c.isDefault ? 'bg-purple-50/50 border-purple-200' : 'bg-white border-stone-200'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <CreditCard className="w-4 h-4 text-stone-600" />
                        <div>
                          <span className="font-bold text-stone-900 font-mono text-xs">
                            {c.brand} •••• {c.last4}
                          </span>
                          <span className="text-[10px] text-stone-400 ml-2">
                            Exp {c.expiryMonth}/{c.expiryYear}
                          </span>
                          {c.isDefault && (
                            <span className="text-[9px] font-bold text-purple-800 bg-purple-100 px-1.5 py-0.5 rounded ml-2">
                              Primary Default
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {!c.isDefault && (
                          <button
                            type="button"
                            onClick={() => handleSetDefaultCard(c.id)}
                            className="px-2 py-0.5 text-[11px] font-semibold text-purple-700 hover:text-purple-900 bg-white border border-stone-200 rounded cursor-pointer"
                          >
                            Set Default
                          </button>
                        )}
                        <button
                          type="button"
                          disabled={isDeletingCardId === c.id}
                          onClick={() => handleDeleteCard(c.id)}
                          className="p-1 text-stone-400 hover:text-rose-600 rounded cursor-pointer"
                          title="Remove card"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex items-center gap-2 text-[11px] text-stone-500 pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <span>
                Protected under PCI-DSS Level 1 & TLS 1.3 tokenization. Your card number is never exposed or logged in plain text.
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 3: PAYMENT PROVIDER GATEWAY SETTINGS */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-stone-200">
          <div>
            <h2 className="text-base font-bold text-stone-900">
              3. Payment Gateway Configuration
            </h2>
            <p className="text-xs text-stone-500">
              Select your payment processor for credit/debit card tokenization, hosted checkouts, and customer transactions.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold text-stone-500">Provider:</span>
            <span className="font-mono font-bold text-stone-900 uppercase bg-stone-100 px-2 py-0.5 rounded border border-stone-200 text-xs">
              {config?.provider || 'safepay'}
            </span>
          </div>
        </div>

        <form onSubmit={handleSaveSettings} className="space-y-6 text-xs">
          {/* Provider Selector Cards */}
          <div className="space-y-2">
            <label className="font-bold text-stone-800 block text-xs">
              Select Active Payment Provider
            </label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {[
                {
                  id: 'safepay' as const,
                  name: 'Safepay',
                  badge: 'Licensed PSO/PSP in Pakistan',
                  desc: 'SBP regulated payment gateway. Direct PKR card checkout (Visa/Mastercard/PayPak) and bank payouts.',
                  fees: '2.5% + PKR 10 per successful transaction',
                },
                {
                  id: 'paymob' as const,
                  name: 'Paymob Pakistan',
                  badge: 'Pakistan & MENA Licensed',
                  desc: 'Multi-rail gateway supporting cards, mobile wallets (JazzCash, EasyPaisa), and QR payments.',
                  fees: '2.4% + PKR 12 per transaction',
                },
                {
                  id: 'stripe' as const,
                  name: 'Stripe',
                  badge: 'Global Processing',
                  desc: 'International payments with Apple Pay, Google Pay, and global currency conversion. Requires Stripe Atlas for PK merchants.',
                  fees: '2.9% + 30¢ per international charge',
                },
              ].map(p => (
                <div
                  key={p.id}
                  onClick={() => config && setConfig({ ...config, provider: p.id, providerName: p.name })}
                  className={`p-4 rounded-xl border cursor-pointer transition-all ${
                    config?.provider === p.id
                      ? 'border-purple-600 bg-purple-50/40 ring-2 ring-purple-600/20'
                      : 'border-stone-200 bg-white hover:bg-stone-50'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-stone-950 text-sm">{p.name}</span>
                    <span className="text-[10px] font-bold text-purple-700 bg-purple-100 px-2 py-0.5 rounded">
                      {p.badge}
                    </span>
                  </div>
                  <p className="text-stone-500 text-[11px] leading-relaxed mb-2">{p.desc}</p>
                  <div className="text-[10px] font-medium text-stone-400 border-t border-stone-200/80 pt-2">
                    Fees: {p.fees}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Masked Credentials & Webhook Listener */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-stone-50 p-4 rounded-xl border border-stone-200">
            <div>
              <label className="font-semibold text-stone-700 block mb-1">
                Merchant Account Identifier (Masked)
              </label>
              <div className="font-mono text-stone-900 bg-white px-3 py-2 rounded-lg border border-stone-200 flex items-center justify-between">
                <span>{config?.merchantIdMasked || 'mer_pk_live_****9821'}</span>
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
              </div>
              <p className="text-[10px] text-stone-400 mt-1">
                Secret keys are secured server-side in backend environment variables.
              </p>
            </div>

            <div>
              <label className="font-semibold text-stone-700 block mb-1">
                Webhook Event Receiver Endpoint
              </label>
              <div className="font-mono text-stone-700 bg-white px-3 py-2 rounded-lg border border-stone-200 flex items-center justify-between">
                <span className="truncate">/api/webhooks/payment</span>
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                  Active (200 OK)
                </span>
              </div>
              <p className="text-[10px] text-stone-400 mt-1">
                Receives signed payment intents, charge events, and refund callbacks.
              </p>
            </div>
          </div>

          {/* Enabled Customer Payment Methods */}
          <div className="space-y-3 pt-2">
            <h3 className="font-bold text-stone-900 text-sm">
              Customer Payment Methods Enabled at Checkout
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <label className="flex items-center justify-between p-3.5 bg-stone-50 rounded-xl border border-stone-200 cursor-pointer hover:bg-stone-100/60">
                <div className="flex items-center gap-2.5">
                  <CreditCard className="w-4 h-4 text-purple-700 shrink-0" />
                  <div>
                    <span className="font-bold text-stone-900 block">Credit / Debit Cards</span>
                    <span className="text-[10px] text-stone-500">Visa, Mastercard, PayPak</span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={config?.cardsEnabled ?? true}
                  onChange={e => config && setConfig({ ...config, cardsEnabled: e.target.checked })}
                  className="w-4 h-4 text-purple-600 rounded border-stone-300 accent-purple-600"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 bg-stone-50 rounded-xl border border-stone-200 cursor-pointer hover:bg-stone-100/60">
                <div className="flex items-center gap-2.5">
                  <Banknote className="w-4 h-4 text-emerald-700 shrink-0" />
                  <div>
                    <span className="font-bold text-stone-900 block">Cash on Delivery (COD)</span>
                    <span className="text-[10px] text-stone-500">Doorstep cash collection</span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={config?.codEnabled ?? true}
                  onChange={e => config && setConfig({ ...config, codEnabled: e.target.checked })}
                  className="w-4 h-4 text-purple-600 rounded border-stone-300 accent-purple-600"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 bg-stone-50 rounded-xl border border-stone-200 cursor-pointer hover:bg-stone-100/60">
                <div className="flex items-center gap-2.5">
                  <Building2 className="w-4 h-4 text-blue-700 shrink-0" />
                  <div>
                    <span className="font-bold text-stone-900 block">Bank / Mobile Wallets</span>
                    <span className="text-[10px] text-stone-500">EasyPaisa, JazzCash, Raast</span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={config?.bankTransferEnabled ?? true}
                  onChange={e => config && setConfig({ ...config, bankTransferEnabled: e.target.checked })}
                  className="w-4 h-4 text-purple-600 rounded border-stone-300 accent-purple-600"
                />
              </label>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-between pt-2 border-t border-stone-200">
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 bg-stone-900 hover:bg-purple-700 disabled:opacity-50 text-white font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-2"
            >
              {isSaving ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Saving Settings...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Save Settings</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleTestConnection}
              disabled={isTestingConnection}
              className="px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTestingConnection ? 'animate-spin' : ''}`} />
              <span>Test Connection</span>
            </button>
          </div>
        </form>
      </div>

      {/* SECTION 3: BEFORE ENABLING LIVE PAYMENTS — PAKISTAN MERCHANT GUIDE */}
      <div className="bg-stone-50 border border-stone-200 rounded-2xl overflow-hidden shadow-xs">
        <button
          type="button"
          onClick={() => setShowDocsGuide(!showDocsGuide)}
          className="w-full p-5 sm:p-6 text-left flex items-center justify-between hover:bg-stone-100/60 transition-colors cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-100 text-purple-800 rounded-xl">
              <Info className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-stone-900 text-sm">
                Before Enabling Live Payments: Merchant Onboarding Guide for Pakistan
              </h3>
              <p className="text-xs text-stone-500">
                Which payment providers support Pakistan, required verification documents, and payout configuration instructions.
              </p>
            </div>
          </div>

          <div className="p-1 rounded-lg text-stone-400">
            {showDocsGuide ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </div>
        </button>

        {showDocsGuide && (
          <div className="p-6 pt-0 border-t border-stone-200 text-xs text-stone-700 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
              {/* Pillar 1: Gateway Providers */}
              <div className="bg-white p-4 rounded-xl border border-stone-200 space-y-2">
                <span className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  1. Supported Payment Gateways
                </span>
                <p className="text-stone-600 text-[11px] leading-relaxed">
                  For businesses registered in Pakistan without foreign holding companies:
                </p>
                <ul className="list-disc pl-4 text-stone-600 text-[11px] space-y-1">
                  <li><strong>Safepay (Recommended)</strong>: State Bank of Pakistan (SBP) pilot-approved PSO/PSP. Native PKR checkout, accepts local & international Visa, Mastercard, PayPak cards, and wires payouts directly into any Pakistani bank.</li>
                  <li><strong>Paymob Pakistan</strong>: SBP regulated EMI. Supports cards and digital wallets (EasyPaisa, JazzCash).</li>
                  <li><strong>Stripe</strong>: Requires offshore entity via Stripe Atlas (US LLC or UK LTD) to open a merchant account.</li>
                </ul>
              </div>

              {/* Pillar 2: Required Documents */}
              <div className="bg-white p-4 rounded-xl border border-stone-200 space-y-2">
                <span className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  2. Required KYC Verification Documents
                </span>
                <p className="text-stone-600 text-[11px] leading-relaxed">
                  To achieve "Live Production" status with Safepay or Paymob, submit:
                </p>
                <ul className="list-disc pl-4 text-stone-600 text-[11px] space-y-1">
                  <li><strong>Sole Proprietorship</strong>: Owner's valid CNIC / NICOP, FBR NTN (National Tax Number) certificate, and Bank Account Maintenance Certificate or cancelled cheque showing 24-digit IBAN.</li>
                  <li><strong>Private Limited / LLP</strong>: SECP Certificate of Incorporation, Form II / Form 29, Company NTN, Director CNICs, and Board Resolution for payment gateway signing authority.</li>
                  <li><strong>Domain & Privacy Compliance</strong>: Active HTTPS domain, live Privacy Policy, Refund/Exchange Policy, and Terms of Service.</li>
                </ul>
              </div>

              {/* Pillar 3: How Payouts Work */}
              <div className="bg-white p-4 rounded-xl border border-stone-200 space-y-2">
                <span className="font-bold text-stone-900 text-xs flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  3. Payout Configuration & Settlement
                </span>
                <p className="text-stone-600 text-[11px] leading-relaxed">
                  How proceeds reach your Pakistani bank:
                </p>
                <ul className="list-disc pl-4 text-stone-600 text-[11px] space-y-1">
                  <li><strong>1Link / PRISM Settlement</strong>: When an order is completed, the payment provider deducts their interchange fee (2.5%) and queues the net amount for payout.</li>
                  <li><strong>Settlement Schedule</strong>: Rolling T+2 business days (funds captured Monday arrive Wednesday morning).</li>
                  <li><strong>Direct Deposit</strong>: Funds land automatically in your connected IBAN without manual withdrawal requests.</li>
                </ul>
              </div>
            </div>

            <div className="p-3 bg-purple-50/70 rounded-xl border border-purple-200 flex items-center justify-between text-[11px]">
              <span className="text-purple-900 font-medium">
                Need help with your Safepay or Paymob merchant registration in Pakistan?
              </span>
              <a
                href="https://www.getsafepay.com"
                target="_blank"
                rel="noreferrer"
                className="font-bold text-purple-700 hover:text-purple-900 flex items-center gap-1 shrink-0"
              >
                <span>Visit Safepay Merchant Portal</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        )}
      </div>

      {/* SECTION 4: PAYMENT TRANSACTIONS & PAYOUTS HISTORY */}
      <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
          <div>
            <h2 className="text-base font-bold text-stone-900">
              3. Payment Transaction History & Payouts
            </h2>
            <p className="text-xs text-stone-500">
              Track customer orders, transaction references, processing fees, settlement status, and process authorized refunds.
            </p>
          </div>

          <button
            type="button"
            onClick={loadData}
            className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh Transactions</span>
          </button>
        </div>

        {/* Metrics Row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200">
            <span className="text-[11px] font-medium text-stone-400 block">Total Volume Processed</span>
            <span className="text-lg font-bold text-stone-900 mt-1 block">
              PKR {totalProcessed.toLocaleString()}
            </span>
            <span className="text-[10px] text-stone-500">Across verified customer orders</span>
          </div>

          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200">
            <span className="text-[11px] font-medium text-stone-400 block">Deposited to Bank</span>
            <span className="text-lg font-bold text-emerald-700 mt-1 block">
              PKR {totalDeposited.toLocaleString()}
            </span>
            <span className="text-[10px] text-emerald-600">Settled in Meezan Bank</span>
          </div>

          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200">
            <span className="text-[11px] font-medium text-stone-400 block">Scheduled / In Transit</span>
            <span className="text-lg font-bold text-purple-700 mt-1 block">
              PKR {totalScheduled.toLocaleString()}
            </span>
            <span className="text-[10px] text-purple-600">Rolling T+2 payout queue</span>
          </div>

          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200">
            <span className="text-[11px] font-medium text-stone-400 block">Gateway Fees (2.5%)</span>
            <span className="text-lg font-bold text-stone-600 mt-1 block">
              PKR {totalFees.toLocaleString()}
            </span>
            <span className="text-[10px] text-stone-400">Interchange & processing</span>
          </div>
        </div>

        {/* Search & Status Filters */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
          {/* Segmented Filter Control */}
          <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-xl w-full sm:w-auto text-xs font-semibold">
            {(['all', 'paid', 'refunded', 'pending'] as const).map(tab => (
              <button
                key={tab}
                type="button"
                onClick={() => setTxFilter(tab)}
                className={`flex-1 sm:flex-none px-3.5 py-1.5 rounded-lg transition-colors capitalize cursor-pointer ${
                  txFilter === tab
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                {tab === 'all' ? 'All Transactions' : tab}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search reference, order #, customer..."
              value={txSearch}
              onChange={e => setTxSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-purple-600"
            />
          </div>
        </div>

        {/* Transactions Table */}
        <div className="overflow-x-auto border border-stone-200 rounded-xl">
          <table className="w-full text-left text-xs">
            <thead className="bg-stone-50 text-stone-500 font-semibold border-b border-stone-200">
              <tr>
                <th className="py-3 px-4">Transaction Ref</th>
                <th className="py-3 px-4">Order #</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4 text-right">Amount</th>
                <th className="py-3 px-4 text-right">Fee</th>
                <th className="py-3 px-4 text-right">Net Payout</th>
                <th className="py-3 px-4">Payment Status</th>
                <th className="py-3 px-4">Payout Status</th>
                <th className="py-3 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100 text-stone-800">
              {filteredTransactions.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-stone-400">
                    No transactions match your criteria.
                  </td>
                </tr>
              ) : (
                filteredTransactions.map(tx => (
                  <tr key={tx.id} className="hover:bg-stone-50/80 transition-colors">
                    <td className="py-3 px-4 font-mono font-medium text-stone-900">
                      {tx.transactionReference}
                    </td>
                    <td className="py-3 px-4 font-medium text-purple-700">
                      {tx.orderNumber}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-stone-900">{tx.customerName}</div>
                      <div className="text-[10px] text-stone-400">{tx.customerEmail}</div>
                    </td>
                    <td className="py-3 px-4 text-right font-bold text-stone-900">
                      {tx.currency} {tx.amount.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right text-stone-400 font-mono">
                      {tx.fee > 0 ? `${tx.currency} ${tx.fee.toLocaleString()}` : '—'}
                    </td>
                    <td className="py-3 px-4 text-right font-bold text-emerald-700 font-mono">
                      {tx.netPayout > 0 ? `${tx.currency} ${tx.netPayout.toLocaleString()}` : `${tx.currency} ${tx.netPayout.toLocaleString()}`}
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-xs font-semibold">
                        {tx.paymentStatus === 'paid' && (
                          <span className="text-emerald-700 font-bold">Paid</span>
                        )}
                        {tx.paymentStatus === 'refunded' && (
                          <span className="text-rose-700 font-bold">Refunded</span>
                        )}
                        {tx.paymentStatus === 'partially_refunded' && (
                          <span className="text-amber-700 font-bold">Partial Refund</span>
                        )}
                        {tx.paymentStatus === 'pending' && (
                          <span className="text-stone-500 font-bold">Pending</span>
                        )}
                        {tx.paymentStatus === 'declined' && (
                          <span className="text-rose-600 font-bold">Declined</span>
                        )}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-xs">
                      <span className="font-medium text-stone-600">
                        {tx.payoutStatus}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      {tx.paymentStatus === 'paid' ? (
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedTxForRefund(tx);
                            setRefundAmount(String(tx.amount));
                            setRefundReason('');
                            setRefundError(null);
                          }}
                          className="px-2.5 py-1 bg-stone-100 hover:bg-rose-50 text-stone-700 hover:text-rose-700 rounded-lg font-bold text-[11px] transition-colors cursor-pointer border border-stone-200"
                        >
                          Refund
                        </button>
                      ) : (
                        <span className="text-[11px] text-stone-300">—</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CONNECT PAYMENT PROVIDER MODAL */}
      {isConnectModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-6 shadow-xl border border-stone-200 animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-purple-700" />
                <h3 className="font-bold text-stone-900 text-base">Connect Payment Provider</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsConnectModalOpen(false)}
                className="text-stone-400 hover:text-stone-700 p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs text-stone-600">
              <p>
                Select the payment processor to connect to your NOVORA store. The provider’s official API will handle customer checkout tokenization and webhook notifications.
              </p>

              <div className="space-y-2">
                {[
                  {
                    id: 'safepay' as const,
                    name: 'Safepay Gateway (Pakistan & Global)',
                    desc: 'Fully licensed by State Bank of Pakistan. Native PKR checkout, cards (Visa/Mastercard/PayPak), and direct settlement into your Pakistani bank account.',
                    recommended: true,
                  },
                  {
                    id: 'paymob' as const,
                    name: 'Paymob Pakistan',
                    desc: 'Digital payments, cards, and mobile wallet infrastructure across Pakistan and MENA.',
                    recommended: false,
                  },
                  {
                    id: 'stripe' as const,
                    name: 'Stripe Global',
                    desc: 'International credit card processing and currency conversion. Requires Stripe Atlas / offshore entity for PK merchants.',
                    recommended: false,
                  },
                ].map(p => (
                  <label
                    key={p.id}
                    className={`block p-3.5 rounded-xl border cursor-pointer transition-all ${
                      selectedProviderToConnect === p.id
                        ? 'border-purple-600 bg-purple-50/50 ring-2 ring-purple-600/20'
                        : 'border-stone-200 hover:bg-stone-50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="providerSelection"
                          checked={selectedProviderToConnect === p.id}
                          onChange={() => setSelectedProviderToConnect(p.id)}
                          className="accent-purple-600"
                        />
                        <span className="font-bold text-stone-900">{p.name}</span>
                      </div>
                      {p.recommended && (
                        <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                          Recommended for Pakistan
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-stone-500 pl-5">{p.desc}</p>
                  </label>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-200 text-xs">
              <button
                type="button"
                onClick={() => setIsConnectModalOpen(false)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isConnecting}
                onClick={() => handleConnectProvider(selectedProviderToConnect)}
                className="px-5 py-2 bg-purple-700 hover:bg-purple-800 disabled:opacity-50 text-white font-bold rounded-xl flex items-center gap-2 cursor-pointer"
              >
                {isConnecting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Verifying Provider...</span>
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Connect & Activate Provider</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REFUND MODAL */}
      {selectedTxForRefund && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-5 shadow-xl border border-stone-200 animate-fadeIn text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <div className="flex items-center gap-2">
                <RotateCcw className="w-5 h-5 text-rose-700" />
                <h3 className="font-bold text-stone-900 text-base">Issue Payment Refund</h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedTxForRefund(null)}
                className="text-stone-400 hover:text-stone-700 p-1"
              >
                ✕
              </button>
            </div>

            {refundError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{refundError}</span>
              </div>
            )}

            <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
              <div className="flex justify-between">
                <span className="text-stone-500">Order Number:</span>
                <span className="font-bold text-purple-700">{selectedTxForRefund.orderNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Customer:</span>
                <span className="font-semibold text-stone-800">{selectedTxForRefund.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Original Total:</span>
                <span className="font-bold text-stone-900 font-mono">
                  {selectedTxForRefund.currency} {selectedTxForRefund.amount.toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Transaction Ref:</span>
                <span className="font-mono text-stone-700">{selectedTxForRefund.transactionReference}</span>
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  Refund Amount ({selectedTxForRefund.currency})
                </label>
                <input
                  type="number"
                  max={selectedTxForRefund.amount}
                  min={1}
                  value={refundAmount}
                  onChange={e => setRefundAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 font-mono text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600"
                />
                <p className="text-[10px] text-stone-400 mt-1">
                  Supports full or partial refund against captured customer funds.
                </p>
              </div>

              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  Refund Reason
                </label>
                <input
                  type="text"
                  placeholder="e.g., Customer return, out of stock, cancelled by merchant"
                  value={refundReason}
                  onChange={e => setRefundReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-200">
              <button
                type="button"
                onClick={() => setSelectedTxForRefund(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isProcessingRefund}
                onClick={handleProcessRefund}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
              >
                {isProcessingRefund ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Processing Refund...</span>
                  </>
                ) : (
                  <>
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Confirm & Issue Refund</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIGURE SERVER CREDENTIALS MODAL */}
      {isCredsModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-xl border border-stone-200 animate-fadeIn text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <div className="flex items-center gap-2">
                <Lock className="w-5 h-5 text-purple-700" />
                <div>
                  <h3 className="font-bold text-stone-900 text-base">Configure Gateway Credentials</h3>
                  <p className="text-[11px] text-stone-500">Secure server-side API keys & HMAC webhook secret</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCredsModalOpen(false)}
                className="text-stone-400 hover:text-stone-700 p-1"
              >
                ✕
              </button>
            </div>

            {credsModalError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{credsModalError}</span>
              </div>
            )}

            <div className="p-3.5 bg-purple-50/60 border border-purple-200 rounded-xl flex items-start gap-2.5 text-purple-950">
              <ShieldCheck className="w-5 h-5 text-purple-700 shrink-0 mt-0.5" />
              <div className="text-[11px] leading-relaxed">
                <strong>Zero Client-Side Exposure:</strong> Secret keys are securely handled on the backend Express server only. They are never transmitted to customer browsers or stored in frontend bundle code.
              </div>
            </div>

            <form onSubmit={handleSaveCredentials} className="space-y-4">
              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  Active Provider
                </label>
                <div className="px-3.5 py-2 bg-stone-100 rounded-xl font-bold text-stone-700 uppercase flex items-center justify-between">
                  <span>{config?.provider || 'safepay'} (SBP Licensed / PSO)</span>
                  <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Active
                  </span>
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  Public API Key / Client Identifier <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g., pub_pk_live_8917240182 or pub_test_..."
                  value={apiKeyInput}
                  onChange={e => setApiKeyInput(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-stone-300 font-mono text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600"
                  required
                />
                <p className="text-[10px] text-stone-400 mt-1">
                  Used by frontend checkout components to initialize the hosted tokenization session.
                </p>
              </div>

              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  Secret API Key (Backend Authorization) <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type={showSecretKey ? 'text' : 'password'}
                    placeholder={config?.secretKeyConfigured ? '••••••••••••••••••••••••••••••••' : 'e.g., sec_pk_live_...'}
                    value={secretKeyInput}
                    onChange={e => setSecretKeyInput(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-stone-300 font-mono text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600 pr-16"
                  />
                  <button
                    type="button"
                    onClick={() => setShowSecretKey(!showSecretKey)}
                    className="absolute right-2 top-2 px-2 py-0.5 text-[10px] font-bold text-stone-500 hover:text-stone-800 bg-stone-100 rounded border border-stone-200"
                  >
                    {showSecretKey ? 'Hide' : 'Show'}
                  </button>
                </div>
                <p className="text-[10px] text-stone-400 mt-1">
                  {config?.secretKeyConfigured
                    ? 'Secret key currently configured on server. Leave blank to keep existing key.'
                    : 'Required for backend transaction session creation and server-side capture.'}
                </p>
              </div>

              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  Cryptographic Webhook Signing Secret <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g., whsec_pk_live_0192830192"
                  value={webhookSecretInput}
                  onChange={e => setWebhookSecretInput(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-stone-300 font-mono text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600"
                />
                <p className="text-[10px] text-stone-400 mt-1">
                  Used by <code className="text-stone-700">/api/webhooks/payment</code> to verify HMAC-SHA256 signatures from the payment provider.
                </p>
              </div>

              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  Regulatory KYC & SBP Verification Status
                </label>
                <select
                  value={kycStatusInput}
                  onChange={e => setKycStatusInput(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white text-stone-800 focus:outline-none focus:ring-2 focus:ring-purple-600"
                >
                  <option value="verified">Verified (Approved for Live Card Processing & Payouts)</option>
                  <option value="pending_approval">Pending Approval (Under review with provider / SBP)</option>
                  <option value="unregistered">Unregistered / Action Required</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsCredsModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingCreds}
                  className="px-5 py-2 bg-purple-700 hover:bg-purple-800 disabled:opacity-50 text-white font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
                >
                  {isSavingCreds ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Saving Credentials...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Save & Apply Credentials</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* LIVE MODE BLOCKED / REQUIREMENTS MODAL */}
      {isLiveBlockedModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-xl border border-stone-200 animate-fadeIn text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-600" />
                <div>
                  <h3 className="font-bold text-stone-900 text-base">Live Payments Mode Blocked</h3>
                  <p className="text-[11px] text-stone-500">Regulatory & security setup must be completed first</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsLiveBlockedModalOpen(false)}
                className="text-stone-400 hover:text-stone-700 p-1"
              >
                ✕
              </button>
            </div>

            <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-2 text-amber-950">
              <p className="font-bold text-xs flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-amber-700" />
                Live Mode is Protected to Prevent Customer Checkout Failures
              </p>
              <p className="text-[11px] text-amber-900 leading-relaxed">
                State Bank of Pakistan (SBP) electronic payment regulations and Visa/Mastercard rules require verified merchant onboarding and cryptographic HMAC signatures before real customer credit or debit cards can be charged.
              </p>
            </div>

            <div className="space-y-2">
              <span className="font-bold text-stone-800 block text-xs">
                Incomplete Checklist Items:
              </span>
              <div className="space-y-1.5">
                {(credentialsStatus?.checklist || [])
                  .filter((c: any) => c.status !== 'completed')
                  .map((c: any) => (
                    <div key={c.id} className="p-2.5 bg-stone-50 rounded-lg border border-stone-200 flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-bold text-stone-900 text-xs block">{c.title}</span>
                        <span className="text-[11px] text-stone-500">{c.description}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>

            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-[11px] text-stone-600 space-y-1">
              <p>
                <strong>Testing safely:</strong> You can continue testing end-to-end checkout, card validation, order creation, and webhook callbacks immediately in <strong>Test Mode</strong> using test cards (<code className="font-mono text-purple-700 font-bold">4242 4242 4242 4242</code>).
              </p>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-200">
              <button
                type="button"
                onClick={() => setIsLiveBlockedModalOpen(false)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl cursor-pointer"
              >
                Stay in Test Mode
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsLiveBlockedModalOpen(false);
                  handleOpenCredsModal();
                }}
                className="px-5 py-2 bg-purple-700 hover:bg-purple-800 text-white font-bold rounded-xl flex items-center gap-1.5 cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Configure Credentials</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CHANGE / ADD MERCHANT BUSINESS CARD MODAL */}
      {isCardModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-5 shadow-xl border border-stone-200 animate-fadeIn text-xs max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-purple-700" />
                <div>
                  <h3 className="font-bold text-stone-900 text-base">
                    {config?.merchantCard ? 'Change Merchant Business Card' : 'Connect Business Card'}
                  </h3>
                  <p className="text-[11px] text-stone-500">
                    Update card-on-file for settlements, reserves & billing
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCardModalOpen(false)}
                className="text-stone-400 hover:text-stone-700 p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {cardModalError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{cardModalError}</span>
              </div>
            )}

            {/* Live Interactive Card Preview */}
            <div className="relative aspect-[1.586/1] w-full max-w-sm mx-auto rounded-2xl p-5 bg-gradient-to-br from-stone-950 via-stone-900 to-purple-950 text-white shadow-lg border border-stone-800 flex flex-col justify-between overflow-hidden">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-6 rounded bg-gradient-to-tr from-amber-300 via-yellow-200 to-amber-400 border border-amber-400/50" />
                  <Wifi className="w-3.5 h-3.5 text-stone-400 rotate-90" />
                </div>
                <span className="font-display font-black text-xs tracking-wider uppercase text-purple-200 bg-white/10 px-2 py-0.5 rounded">
                  {detectBrand(cardNumberInput)}
                </span>
              </div>

              <div className="my-2">
                <p className="font-mono text-base sm:text-lg tracking-widest text-stone-100 font-semibold">
                  {cardNumberInput || '•••• •••• •••• ••••'}
                </p>
              </div>

              <div className="flex items-end justify-between text-[10px]">
                <div>
                  <span className="text-[8px] uppercase tracking-widest text-stone-400 block font-medium">
                    Cardholder
                  </span>
                  <p className="font-bold tracking-wide uppercase text-stone-100 truncate max-w-[180px]">
                    {cardHolderNameInput || 'BUSINESS TITLE / OWNER'}
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-[8px] uppercase tracking-widest text-stone-400 block font-medium">
                    Expires
                  </span>
                  <p className="font-mono font-bold text-stone-200">
                    {cardExpiryMonthInput} / {cardExpiryYearInput}
                  </p>
                </div>
              </div>
            </div>

            <form onSubmit={handleSaveMerchantCard} className="space-y-4">
              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  Cardholder Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. NOVORA Atelier & Retail (Pvt) Ltd"
                  value={cardHolderNameInput}
                  onChange={e => setCardHolderNameInput(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-stone-300 font-semibold text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600"
                  required
                />
                <p className="text-[10px] text-stone-400 mt-1">
                  Must match the name printed on the card or registered business title.
                </p>
              </div>

              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  Card Number (Debit or Credit) <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="4242 •••• •••• ••••"
                    value={cardNumberInput}
                    onChange={e => handleCardNumberChange(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-stone-300 font-mono text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600 pr-20"
                    required
                  />
                  <span className="absolute right-3 top-2.5 font-bold text-[10px] text-purple-700 uppercase bg-purple-50 px-1.5 py-0.5 rounded border border-purple-200">
                    {detectBrand(cardNumberInput)}
                  </span>
                </div>
                <p className="text-[10px] text-stone-400 mt-1">
                  Visa, Mastercard, PayPak, American Express, UnionPay supported.
                </p>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-stone-800 mb-1">
                    Exp Month <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={cardExpiryMonthInput}
                    onChange={e => setCardExpiryMonthInput(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white text-stone-800 focus:outline-none focus:ring-2 focus:ring-purple-600 font-mono"
                  >
                    {['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'].map(m => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-stone-800 mb-1">
                    Exp Year <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={cardExpiryYearInput}
                    onChange={e => setCardExpiryYearInput(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white text-stone-800 focus:outline-none focus:ring-2 focus:ring-purple-600 font-mono"
                  >
                    {['26', '27', '28', '29', '30', '31', '32', '33', '34', '35'].map(y => (
                      <option key={y} value={y}>
                        20{y}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-stone-800 mb-1">
                    CVC / CVV <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type="password"
                      maxLength={4}
                      placeholder="•••"
                      value={cardCvcInput}
                      onChange={e => setCardCvcInput(e.target.value.replace(/\D/g, ''))}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 font-mono text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600 text-center"
                      required
                    />
                    <Lock className="w-3.5 h-3.5 text-stone-400 absolute right-2.5 top-2.5" />
                  </div>
                </div>
              </div>

              <div>
                <label className="block font-bold text-stone-800 mb-1">
                  Billing Postal / ZIP Code
                </label>
                <input
                  type="text"
                  placeholder="e.g. 54660"
                  value={cardZipInput}
                  onChange={e => setCardZipInput(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-stone-300 text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="default-card-toggle"
                  checked={isDefaultCardInput}
                  onChange={e => setIsDefaultCardInput(e.target.checked)}
                  className="w-4 h-4 text-purple-600 rounded border-stone-300 accent-purple-600"
                />
                <label htmlFor="default-card-toggle" className="text-stone-700 font-medium cursor-pointer">
                  Set as Primary Merchant Card for settlements & billing
                </label>
              </div>

              <div className="p-3 bg-purple-50/60 rounded-xl border border-purple-200 flex items-start gap-2 text-[11px] text-purple-900">
                <ShieldCheck className="w-4 h-4 text-purple-700 shrink-0 mt-0.5" />
                <span>
                  <strong>Zero Risk:</strong> Full card details and CVVs are verified via gateway tokenization and discarded. Only the card brand, last 4 digits, and expiry are saved in your dashboard.
                </span>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsCardModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSavingCard}
                  className="px-5 py-2 bg-purple-700 hover:bg-purple-800 disabled:opacity-50 text-white font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  {isSavingCard ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Verifying Card Token...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Save and Verify Card</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          HIGH-RESOLUTION ARCHITECTURE LIGHTBOX MODAL (PAYMENT SETTINGS)
      ========================================================================= */}
      {isDiagramOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="relative w-full max-w-6xl bg-stone-950 text-white rounded-3xl shadow-2xl border border-stone-800 flex flex-col max-h-[92vh] overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            
            {/* Modal Header */}
            <div className="p-4 sm:p-6 border-b border-stone-800 flex items-center justify-between flex-wrap gap-4 shrink-0 bg-stone-900/90">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-widest bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    Architectural Blueprint
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Live System Verified
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-black font-display text-white">
                  NOVORA — Admin Bank Card Entry & Payment Flow System
                </h3>
                <p className="text-xs text-stone-400">
                  (Add / Change Card — Customer Money Comes to This Card)
                </p>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 bg-stone-800 p-1 rounded-xl border border-stone-700 text-xs">
                  <button
                    type="button"
                    onClick={() => setDiagramZoom(prev => Math.max(0.6, prev - 0.2))}
                    className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 cursor-pointer"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => setDiagramZoom(1)}
                    className="px-2.5 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 font-mono text-xs cursor-pointer"
                  >
                    {Math.round(diagramZoom * 100)}%
                  </button>
                  <button
                    type="button"
                    onClick={() => setDiagramZoom(prev => Math.min(2.5, prev + 0.2))}
                    className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 cursor-pointer"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </button>
                </div>

                <a
                  href="/assets/aistudio/Novora_Admin_Payment_Flow_System_3ecf585c.png"
                  download="Novora_Admin_Payment_Flow_System.png"
                  className="px-3.5 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold rounded-xl border border-stone-700 transition-colors flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Download</span>
                </a>

                <button
                  type="button"
                  onClick={() => setIsDiagramOpen(false)}
                  className="p-2 rounded-xl text-stone-400 hover:text-white hover:bg-stone-800 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-4 sm:p-6 overflow-y-auto flex-1 bg-stone-900">
              <div className="bg-white rounded-2xl p-4 overflow-auto max-h-[70vh] flex justify-center items-start border border-stone-800 shadow-inner">
                <img
                  src="/assets/aistudio/Novora_Admin_Payment_Flow_System_3ecf585c.png"
                  alt="NOVORA Admin Bank Card Entry & Payment Flow System"
                  style={{ transform: `scale(${diagramZoom})`, transformOrigin: 'top center' }}
                  className="w-full max-w-4xl transition-transform duration-200 rounded-xl shadow-md"
                />
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 sm:p-5 border-t border-stone-800 flex items-center justify-between flex-wrap gap-3 bg-stone-900 text-xs">
              <span className="text-stone-400">
                100% Secure Card Tokenization · Zero Sensitive Banking Information Stored in Plaintext
              </span>
              <button
                type="button"
                onClick={() => setIsDiagramOpen(false)}
                className="px-5 py-2 bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold rounded-xl transition-colors cursor-pointer"
              >
                Close View
              </button>
            </div>

          </div>
        </div>
      )}
      {/* =========================================================================
          CHANGE BANK PAYOUT DESTINATION MODAL (MANDATORY REQUIREMENT)
      ========================================================================= */}
      {isChangePayoutModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-stone-200 text-xs my-8 animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-stone-200">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-purple-100 text-purple-800 rounded-xl">
                  <Landmark className="w-5 h-5 text-purple-700" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-stone-950 font-display">
                    Change Bank Payout Account
                  </h3>
                  <p className="text-xs text-stone-500 mt-0.5">
                    Redirect incoming customer payments to a new verified commercial bank destination.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsChangePayoutModalOpen(false)}
                className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {changeSuccessRecord ? (
              /* Success Screen */
              <div className="space-y-5 text-center py-4">
                <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600" />
                </div>
                <div className="space-y-1.5">
                  <h4 className="text-base font-bold text-stone-900">
                    Payout Destination Successfully Updated!
                  </h4>
                  <p className="text-xs text-stone-600 max-w-md mx-auto">
                    {changeSuccessRecord.message}
                  </p>
                </div>

                <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 text-left space-y-2 text-xs">
                  <div className="flex justify-between items-center pb-2 border-b border-stone-200">
                    <span className="text-stone-500 font-medium">Provider Confirmation Ref</span>
                    <span className="font-mono font-bold text-purple-800 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                      {changeSuccessRecord.confirmationReference}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-stone-500 font-medium">New Bank Destination</span>
                    <span className="font-bold text-stone-800">{changeSuccessRecord.payoutAccount.bankName}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-stone-500 font-medium">Beneficiary Account Title</span>
                    <span className="font-bold text-stone-800">{changeSuccessRecord.payoutAccount.accountHolderName}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-stone-500 font-medium">Masked Account / IBAN</span>
                    <span className="font-mono font-bold text-stone-900">{changeSuccessRecord.payoutAccount.maskedIban}</span>
                  </div>
                  <div className="flex justify-between items-center pt-1 border-t border-stone-200">
                    <span className="text-stone-500 font-medium">Settlement Rail</span>
                    <span className="font-bold text-emerald-700">1Link PRISM / SBP Direct Rolling T+2</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIsChangePayoutModalOpen(false)}
                  className="w-full py-2.5 bg-stone-900 hover:bg-stone-800 text-white font-bold rounded-xl transition-colors cursor-pointer shadow-xs"
                >
                  Done & Return to Dashboard
                </button>
              </div>
            ) : (
              /* Form */
              <form onSubmit={handleSubmitChangePayout} className="space-y-4">
                {/* Regulatory / Security Notice */}
                <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-950 flex items-start gap-2.5 leading-relaxed">
                  <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block mb-0.5">Critical Settlement Destination Notice</span>
                    <span>
                      Modifying this account changes where <strong>real customer funds</strong> are deposited upon order completion. Entering a personal credit/debit card does not establish a payout destination.
                    </span>
                  </div>
                </div>

                {/* Current Active Account Indicator */}
                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-stone-400 block">Current Active Destination</span>
                    <span className="font-mono font-bold text-stone-800">
                      {config?.payoutAccountMasked || 'No bank account linked'}
                    </span>
                  </div>
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold rounded text-[10px]">
                    Verified
                  </span>
                </div>

                {changePayoutError && (
                  <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>{changePayoutError}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                  {/* Bank Name */}
                  <div>
                    <label className="block font-bold text-stone-800 mb-1">
                      New Bank Name <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={changeBankName}
                      onChange={e => setChangeBankName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600"
                    >
                      {POPULAR_PAKISTAN_BANKS.map(b => (
                        <option key={b} value={b}>
                          {b}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Custom Bank Name if "Other" */}
                  {changeBankName === 'Other / International Commercial Bank' ? (
                    <div>
                      <label className="block font-bold text-stone-800 mb-1">
                        Commercial Bank Name <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Standard Chartered UK"
                        value={changeCustomBankName}
                        onChange={e => setChangeCustomBankName(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-stone-300 text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600"
                        required
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="block font-bold text-stone-800 mb-1">
                        Branch Code (Optional)
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. 0109"
                        value={changeBranchCode}
                        onChange={e => setChangeBranchCode(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-stone-300 text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600"
                      />
                    </div>
                  )}

                  {/* Beneficiary Account Holder Name */}
                  <div className="md:col-span-2">
                    <label className="block font-bold text-stone-800 mb-1">
                      Beneficiary Account Title <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. NOVORA Atelier & Retail (Pvt) Ltd"
                      value={changeAccountHolderName}
                      onChange={e => setChangeAccountHolderName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600 font-semibold"
                      required
                    />
                    <p className="text-[10px] text-stone-400 mt-1">
                      Must match your corporate tax entity or sole proprietor bank title registered with FBR / State Bank.
                    </p>
                  </div>

                  {/* Country & Currency */}
                  <div>
                    <label className="block font-bold text-stone-800 mb-1">
                      Country <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={changeCountry}
                      onChange={e => setChangeCountry(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600"
                    >
                      <option value="Pakistan">Pakistan (PK)</option>
                      <option value="United Kingdom">United Kingdom (GB)</option>
                      <option value="United States">United States (US)</option>
                      <option value="United Arab Emirates">United Arab Emirates (AE)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-stone-800 mb-1">
                      Settlement Currency <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={changeCurrency}
                      onChange={e => setChangeCurrency(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 bg-white text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600 font-mono font-bold"
                    >
                      <option value="PKR">PKR (Pakistani Rupee)</option>
                      <option value="USD">USD ($)</option>
                      <option value="EUR">EUR (€)</option>
                      <option value="GBP">GBP (£)</option>
                      <option value="AED">AED (Dirham)</option>
                    </select>
                  </div>

                  {/* 24-character IBAN / Account Number */}
                  <div className="md:col-span-2">
                    <label className="block font-bold text-stone-800 mb-1">
                      New Bank Account Number or 24-Character IBAN <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="e.g. PK36 HABB 0001 2345 6789 0123"
                        value={changeIban}
                        onChange={e => setChangeIban(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-stone-300 font-mono text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600 pr-9"
                        required
                      />
                      <Lock className="w-4 h-4 text-stone-400 absolute right-3 top-2.5" />
                    </div>
                    <p className="text-[10px] text-stone-400 mt-1">
                      For Pakistan banks, enter the 24-character IBAN starting with PK. The account will be verified via 1Link.
                    </p>
                  </div>

                  {/* Reason for Change */}
                  <div className="md:col-span-2">
                    <label className="block font-bold text-stone-800 mb-1">
                      Reason for Account Change (Audit Record)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Corporate Banking Migration / Account Restructuring"
                      value={changeReason}
                      onChange={e => setChangeReason(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-stone-300 text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600"
                    />
                  </div>

                  {/* Admin Security Password Clearance */}
                  <div className="md:col-span-2">
                    <label className="block font-bold text-stone-800 mb-1 flex items-center justify-between">
                      <span>Admin Security Authorization</span>
                      <span className="text-[10px] text-stone-400 font-normal">Re-enter password to authorize payout redirection</span>
                    </label>
                    <div className="relative">
                      <input
                        type="password"
                        placeholder="Enter your admin security password"
                        value={changeAdminPassword}
                        onChange={e => setChangeAdminPassword(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-stone-300 text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600 pr-9"
                      />
                      <KeyRound className="w-4 h-4 text-stone-400 absolute right-3 top-2.5" />
                    </div>
                  </div>
                </div>

                {/* Explicit Authorization Agreement Checkbox */}
                <div className="p-3 bg-purple-50/60 rounded-xl border border-purple-200 space-y-2">
                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={changeAgreed}
                      onChange={e => setChangeAgreed(e.target.checked)}
                      className="w-4 h-4 text-purple-700 rounded border-stone-300 accent-purple-700 mt-0.5 shrink-0"
                      required
                    />
                    <span className="text-stone-800 text-[11px] leading-tight">
                      <strong>I confirm this payout destination change.</strong> I certify that I am the authorized store administrator, that this bank account is legally entitled to receive customer funds, and that this change will be logged in the permanent audit trail.
                    </span>
                  </label>
                </div>

                <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-200">
                  <button
                    type="button"
                    onClick={() => setIsChangePayoutModalOpen(false)}
                    className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmittingPayoutChange || !changeAgreed}
                    className="px-5 py-2 bg-purple-700 hover:bg-purple-800 disabled:opacity-50 text-white font-bold rounded-xl flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    {isSubmittingPayoutChange ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Verifying with 1Link Rails...</span>
                      </>
                    ) : (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Confirm Payout Account Change</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>

  );
};
