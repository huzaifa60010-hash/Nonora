import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  CreditCard,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  X,
  ExternalLink,
  Building2,
  AlertTriangle,
} from 'lucide-react';
import { api } from '../services/api';
import { Order, PaymentSession } from '../types';
import { useFocusTrap } from '../hooks/useFocusTrap';

interface SecurePaymentModalProps {
  session: PaymentSession;
  order: Order;
  isOpen: boolean;
  onClose: () => void;
  onPaymentSuccess: (paidOrder: Order) => void;
  onPaymentDecline: (message: string) => void;
}

export const SecurePaymentModal: React.FC<SecurePaymentModalProps> = ({
  session,
  order,
  isOpen,
  onClose,
  onPaymentSuccess,
  onPaymentDecline,
}) => {
  const [cardNumber, setCardNumber] = useState('4242 4242 4242 4242');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvc, setCardCvc] = useState('123');
  const [cardholderName, setCardholderName] = useState(order.customer.fullName || 'NOVORA Patron');
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [simulatedOtpStep, setSimulatedOtpStep] = useState(false);
  const [otpCode, setOtpCode] = useState('123456');

  const modalRef = useFocusTrap<HTMLDivElement>({
    isOpen,
    onClose,
  });

  if (!isOpen) return null;

  const isTest = session.mode === 'test' || session.mode === 'sandbox';
  const providerTitle = session.provider === 'safepay' ? 'Safepay' : session.provider === 'stripe' ? 'Stripe' : 'Paymob';

  // Detect card brand
  const cleanCard = cardNumber.replace(/\s+/g, '');
  let cardBrand = 'Visa';
  if (cleanCard.startsWith('5')) cardBrand = 'Mastercard';
  else if (cleanCard.startsWith('6')) cardBrand = 'PayPak / Discover';
  else if (cleanCard.startsWith('3')) cardBrand = 'American Express';

  const formatCardNumber = (val: string) => {
    const raw = val.replace(/\D/g, '').substring(0, 16);
    const parts = raw.match(/[\s\S]{1,4}/g) || [];
    return parts.join(' ');
  };

  const formatExpiry = (val: string) => {
    const raw = val.replace(/\D/g, '').substring(0, 4);
    if (raw.length >= 3) {
      return `${raw.substring(0, 2)}/${raw.substring(2)}`;
    }
    return raw;
  };

  // Quick Sandbox Test Pre-fills
  const fillApprovedCard = () => {
    setCardNumber('4242 4242 4242 4242');
    setCardExpiry('12/28');
    setCardCvc('123');
    setErrorMessage(null);
  };

  const fillDeclineCard = () => {
    setCardNumber('4000 0000 0000 0002');
    setCardExpiry('10/27');
    setCardCvc('999');
    setErrorMessage(null);
  };

  const fill3dsCard = () => {
    setCardNumber('4000 0000 0000 3220');
    setCardExpiry('11/27');
    setCardCvc('888');
    setErrorMessage(null);
  };

  // Submit Authorization
  const handleAuthorizePayment = async (forceDecline: boolean = false) => {
    setErrorMessage(null);
    setIsProcessing(true);

    try {
      const last4 = cleanCard.slice(-4) || '4242';

      // Check if decline card was entered or forced
      const isDecline = forceDecline || cleanCard.endsWith('0002');

      const action = isDecline ? 'decline' : 'confirm';

      const res = await api.verifyPaymentSession({
        sessionId: session.id,
        token: session.token,
        action,
        cardLast4: last4,
        cardBrand,
      });

      if (res.success && res.order) {
        onPaymentSuccess(res.order);
      } else {
        const msg = res.error || 'Payment authorization was declined by your bank.';
        setErrorMessage(msg);
        onPaymentDecline(msg);
      }
    } catch (err: any) {
      const msg = err.message || 'Payment authorization failed.';
      setErrorMessage(msg);
      onPaymentDecline(msg);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/75 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto" role="presentation">
      <div
        ref={modalRef}
        role="dialog"
        aria-modal="true"
        aria-label="Secure Card Payment Checkout"
        tabIndex={-1}
        className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-stone-200 overflow-hidden text-xs animate-fadeIn my-6 focus:outline-none"
      >
        {/* Official Provider Header */}
        <div className="bg-gradient-to-r from-stone-900 via-purple-950 to-stone-900 text-white p-5 sm:p-6 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-purple-500/20 border border-purple-400/30 flex items-center justify-center text-purple-300">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm tracking-wide font-display text-white">
                    {providerTitle} Secure Checkout
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                    isTest ? 'bg-amber-400/20 text-amber-300 border border-amber-400/30' : 'bg-emerald-400/20 text-emerald-300'
                  }`}>
                    {isTest ? 'Sandbox Active' : 'PCI Level 1'}
                  </span>
                </div>
                <p className="text-[10px] text-stone-300">
                  {session.provider === 'safepay'
                    ? 'State Bank of Pakistan (SBP) Regulated Payment Gateway'
                    : 'Global PCI-DSS Level 1 Compliant Card Clearing'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              disabled={isProcessing}
              className="text-stone-400 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer focus-visible:ring-2 focus-visible:ring-purple-400 focus-visible:ring-offset-2 focus-visible:ring-offset-stone-900 outline-none"
              aria-label="Close payment modal"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Amount Strip */}
          <div className="p-3.5 bg-white/10 rounded-2xl border border-white/10 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-stone-300 block uppercase tracking-wider">
                Total Payable
              </span>
              <span className="text-xl font-bold font-mono text-white">
                {session.currency} {session.amount.toLocaleString()}
              </span>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-stone-300 block">Order Ref</span>
              <span className="font-mono font-bold text-purple-200">{session.orderNumber}</span>
            </div>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-5 sm:p-6 space-y-5">
          {errorMessage && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Transaction Failed</p>
                <p className="text-stone-600 text-[11px] mt-0.5">{errorMessage}</p>
              </div>
            </div>
          )}

          {/* Sandbox Test Cards Helper Bar */}
          {isTest && (
            <div className="p-3.5 bg-purple-50/70 border border-purple-200 rounded-2xl space-y-2">
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-bold text-purple-950 flex items-center gap-1.5">
                  <CreditCard className="w-3.5 h-3.5 text-purple-700" />
                  Quick Sandbox Testing Cards
                </span>
                <span className="text-[10px] text-purple-700 font-semibold">Demo Sandbox</span>
              </div>
              <p className="text-[10px] text-stone-600 leading-relaxed">
                Click any test scenario to simulate official provider webhook responses without charging real accounts:
              </p>
              <div className="flex flex-wrap gap-2 pt-0.5">
                <button
                  type="button"
                  onClick={fillApprovedCard}
                  className="px-2.5 py-1 bg-white hover:bg-emerald-50 text-emerald-800 border border-emerald-300 rounded-lg text-[10px] font-bold transition-colors cursor-pointer shadow-2xs"
                >
                  ✓ Approved Visa (Ending 4242)
                </button>
                <button
                  type="button"
                  onClick={fillDeclineCard}
                  className="px-2.5 py-1 bg-white hover:bg-rose-50 text-rose-800 border border-rose-300 rounded-lg text-[10px] font-bold transition-colors cursor-pointer shadow-2xs"
                >
                  ✕ Declined Card (Ending 0002)
                </button>
                <button
                  type="button"
                  onClick={fill3dsCard}
                  className="px-2.5 py-1 bg-white hover:bg-blue-50 text-blue-800 border border-blue-300 rounded-lg text-[10px] font-bold transition-colors cursor-pointer shadow-2xs"
                >
                  ⚡ 3D-Secure Test
                </button>
              </div>
            </div>
          )}

          {/* Card Input Fields */}
          <div className="space-y-3.5">
            <div>
              <label className="block text-[11px] font-bold text-stone-700 mb-1">
                Cardholder Name
              </label>
              <input
                type="text"
                value={cardholderName}
                onChange={e => setCardholderName(e.target.value)}
                placeholder="Name on card"
                className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 bg-stone-50/50 text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600 focus:bg-white"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-[11px] font-bold text-stone-700">
                  Card Number
                </label>
                <span className="font-semibold text-purple-700 text-[10px]">
                  Detected: {cardBrand}
                </span>
              </div>
              <div className="relative">
                <input
                  type="text"
                  maxLength={19}
                  value={cardNumber}
                  onChange={e => setCardNumber(formatCardNumber(e.target.value))}
                  placeholder="4242 •••• •••• 4242"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-stone-300 font-mono text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600"
                />
                <CreditCard className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-stone-700 mb-1">
                  Expiration Date
                </label>
                <input
                  type="text"
                  maxLength={5}
                  value={cardExpiry}
                  onChange={e => setCardExpiry(formatExpiry(e.target.value))}
                  placeholder="MM/YY"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 font-mono text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-stone-700 mb-1">
                  Security Code (CVV)
                </label>
                <input
                  type="password"
                  maxLength={4}
                  value={cardCvc}
                  onChange={e => setCardCvc(e.target.value.replace(/\D/g, ''))}
                  placeholder="•••"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 font-mono text-stone-900 focus:outline-none focus:ring-2 focus:ring-purple-600"
                />
              </div>
            </div>
          </div>

          {/* SBP Security Stamp */}
          <div className="flex items-center justify-between text-[10px] text-stone-500 pt-1 border-t border-stone-100">
            <span className="flex items-center gap-1.5 text-emerald-700 font-medium">
              <Lock className="w-3 h-3 text-emerald-600" />
              <span>TLS 1.3 Bank-Grade 256-Bit Encrypted</span>
            </span>
            <span>Customer card numbers never touch merchant servers</span>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2 pt-2">
            <button
              type="button"
              disabled={isProcessing}
              onClick={() => handleAuthorizePayment(false)}
              className="w-full py-3 bg-purple-700 hover:bg-purple-800 disabled:opacity-50 text-white font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xs"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Contacting {providerTitle} Gateway...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Authorize & Pay {session.currency} {session.amount.toLocaleString()}</span>
                </>
              )}
            </button>

            {isTest && (
              <button
                type="button"
                disabled={isProcessing}
                onClick={() => handleAuthorizePayment(true)}
                className="w-full py-2 bg-stone-100 hover:bg-rose-50 text-rose-700 hover:text-rose-800 border border-stone-200 hover:border-rose-300 font-semibold rounded-xl text-[11px] transition-colors cursor-pointer"
              >
                Simulate Card Issuer Decline (Test Failure Event)
              </button>
            )}

            <button
              type="button"
              disabled={isProcessing}
              onClick={onClose}
              className="w-full py-2 text-stone-500 hover:text-stone-800 font-medium text-[11px] cursor-pointer"
            >
              Cancel Payment & Return to Cart
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
