import React, { useState } from 'react';
import { Search, ShoppingBag, Heart, User as UserIcon, Menu, X, Shield, ArrowRight, ChevronDown, Globe } from 'lucide-react';
import { useStore, CURRENCY_RATES } from '../context/StoreContext';

export const Header: React.FC = () => {
  const {
    currentView,
    navigateTo,
    cartCount,
    wishlist,
    openCartDrawer,
    currentUser,
    isAdmin,
    logout,
    openAuthModal,
    openAdminModal,
    settings,
    searchTerm,
    setSearchTerm,
    selectedCurrency,
    setSelectedCurrency,
    products,
    formatPrice,
  } = useStore();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchExpanded, setIsSearchExpanded] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const searchMatches = React.useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q || q.length < 2) return [];
    return products
      .filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        (p.subcategory && p.subcategory.toLowerCase().includes(q)) ||
        (p.brand && p.brand.toLowerCase().includes(q))
      )
      .slice(0, 5);
  }, [searchTerm, products]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigateTo('shop');
      setIsSearchExpanded(false);
      setIsSearchFocused(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200 transition-all">
      {/* Top Promotional Bar */}
      {settings.showPromotionalBar && (
        <div className="bg-stone-900 text-stone-200 text-xs py-2 px-4 text-center tracking-wide font-medium flex items-center justify-center gap-2">
          <span>{settings.promotionalBarText}</span>
          <button
            onClick={() => navigateTo('shop')}
            className="underline underline-offset-2 hover:text-white transition-colors cursor-pointer"
          >
            Shop Now
          </button>
        </div>
      )}

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-4 sm:gap-8">
          
          {/* Mobile menu trigger */}
          <div className="flex items-center lg:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 -ml-2 text-stone-800 hover:text-purple-700 transition-colors focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Brand Logo Zone */}
          <div className="flex items-center shrink-0">
            <button
              onClick={() => navigateTo('home')}
              className="text-left group cursor-pointer flex items-baseline gap-1.5 focus:outline-none"
            >
              <span className="text-2xl sm:text-3xl font-extrabold tracking-widest text-stone-950 font-display">
                NOVORA
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-purple-600 group-hover:scale-125 transition-transform"></span>
            </button>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-stone-700">
            <button
              onClick={() => navigateTo('home')}
              className={`hover:text-purple-700 transition-colors whitespace-nowrap cursor-pointer py-1 ${
                currentView === 'home' ? 'text-purple-700 font-semibold border-b-2 border-purple-700' : ''
              }`}
            >
              Home
            </button>
            <button
              onClick={() => navigateTo('shop')}
              className={`hover:text-purple-700 transition-colors whitespace-nowrap cursor-pointer py-1 ${
                currentView === 'shop' ? 'text-purple-700 font-semibold border-b-2 border-purple-700' : ''
              }`}
            >
              Shop
            </button>
            <button
              onClick={() => navigateTo('shop', { categorySlug: 'fashion' })}
              className="hover:text-purple-700 transition-colors whitespace-nowrap cursor-pointer py-1"
            >
              Categories
            </button>
            <button
              onClick={() => navigateTo('shop')}
              className="hover:text-purple-700 transition-colors whitespace-nowrap cursor-pointer py-1"
            >
              New Arrivals
            </button>
            <button
              onClick={() => navigateTo('shop')}
              className="hover:text-purple-700 transition-colors whitespace-nowrap cursor-pointer py-1"
            >
              Best Sellers
            </button>
            <button
              onClick={() => navigateTo('contact')}
              className={`hover:text-purple-700 transition-colors whitespace-nowrap cursor-pointer py-1 ${
                currentView === 'contact' ? 'text-purple-700 font-semibold border-b-2 border-purple-700' : ''
              }`}
            >
              Contact
            </button>
          </nav>

          {/* Action Zone: Search, Wishlist, Cart, Account */}
          <div className="flex items-center gap-2 sm:gap-4 shrink-0">
            {/* Desktop Search Bar with Instant Results Dropdown */}
            <div className="relative hidden md:block">
              <form onSubmit={handleSearchSubmit} className="relative flex items-center">
                <input
                  type="text"
                  placeholder="Search products by name, category..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  onFocus={() => setIsSearchFocused(true)}
                  onBlur={() => setTimeout(() => setIsSearchFocused(false), 250)}
                  className="w-48 lg:w-72 pl-9 pr-4 py-2 text-xs bg-stone-100 hover:bg-stone-50 focus:bg-white text-stone-900 placeholder-stone-500 rounded-full border border-stone-200 focus:border-purple-600 focus:ring-1 focus:ring-purple-600 focus:outline-none transition-all shadow-xs"
                />
                <Search className="w-4 h-4 text-stone-400 absolute left-3 pointer-events-none" />
              </form>

              {/* Instant Quick Results Dropdown */}
              {isSearchFocused && searchTerm.trim().length >= 2 && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-2xl border border-stone-200 p-2 z-50 text-xs space-y-1 animate-in fade-in zoom-in-95 duration-100">
                  <div className="px-3 py-1.5 text-[10px] font-bold text-stone-400 uppercase tracking-wider flex items-center justify-between border-b border-stone-100">
                    <span>Products ({searchMatches.length})</span>
                    <button
                      type="button"
                      onMouseDown={() => {
                        navigateTo('shop');
                        setIsSearchFocused(false);
                      }}
                      className="text-purple-700 hover:underline cursor-pointer"
                    >
                      View All →
                    </button>
                  </div>

                  {searchMatches.length > 0 ? (
                    searchMatches.map(prod => (
                      <div
                        key={prod.id}
                        onMouseDown={() => {
                          navigateTo('product', { productId: prod.id });
                          setIsSearchFocused(false);
                        }}
                        className="flex items-center gap-2.5 p-2 rounded-xl hover:bg-stone-50 cursor-pointer transition-colors"
                      >
                        <img
                          src={prod.images[0] || '/src/assets/images/novora_cat_fashion_1792421786979.jpg'}
                          alt={prod.name}
                          className="w-9 h-9 object-cover rounded-lg bg-stone-100 shrink-0 border border-stone-100"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-stone-900 truncate">{prod.name}</p>
                          <p className="text-[10px] text-stone-500 truncate">
                            {prod.category} · <span className="font-bold text-purple-700">{formatPrice(prod.sellingPrice)}</span>
                          </p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-3 text-center text-stone-400 text-xs">
                      No matching products. Press Enter to view full shop.
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Mobile search toggle */}
            <button
              onClick={() => setIsSearchExpanded(!isSearchExpanded)}
              className="md:hidden p-2 text-stone-700 hover:text-purple-700 transition-colors"
              aria-label="Search"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Currency Selector */}
            <div className="relative hidden sm:flex items-center">
              <Globe className="w-3.5 h-3.5 text-stone-400 absolute left-2 pointer-events-none" />
              <select
                value={selectedCurrency}
                onChange={e => setSelectedCurrency(e.target.value)}
                className="pl-6 pr-2 py-1 text-xs font-semibold bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-lg border border-stone-200 focus:outline-none focus:border-purple-600 transition-colors cursor-pointer"
                title="Select display currency"
              >
                {Object.entries(CURRENCY_RATES).map(([code, meta]) => (
                  <option key={code} value={code}>
                    {code} ({meta.symbol.trim()})
                  </option>
                ))}
              </select>
            </div>

            {/* Wishlist */}
            <button
              onClick={() => {
                if (!currentUser) {
                  openAuthModal('login');
                } else {
                  navigateTo('account');
                }
              }}
              className="relative p-2 text-stone-700 hover:text-purple-700 transition-colors cursor-pointer"
              title="Wishlist"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-purple-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center tabular-nums">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Shopping Cart Bag */}
            <button
              onClick={openCartDrawer}
              className="relative p-2 text-stone-700 hover:text-purple-700 transition-colors cursor-pointer"
              title="Shopping Bag"
              aria-label="Shopping Bag"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-purple-700 text-white text-[10px] font-bold rounded-full flex items-center justify-center tabular-nums">
                  {cartCount}
                </span>
              )}
            </button>

            {/* User Account / Auth Dropdown */}
            <div className="relative">
              {currentUser ? (
                <div className="relative">
                  <button
                    onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                    className="flex items-center gap-1.5 p-1.5 rounded-full hover:bg-stone-100 transition-colors text-xs font-medium text-stone-800 cursor-pointer"
                  >
                    <div className="w-7 h-7 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center font-bold">
                      {currentUser.fullName.charAt(0).toUpperCase()}
                    </div>
                    <span className="hidden xl:inline max-w-[90px] truncate">{currentUser.fullName}</span>
                    <ChevronDown className="w-3.5 h-3.5 text-stone-500" />
                  </button>

                  {/* Dropdown Menu */}
                  {isUserMenuOpen && (
                    <div 
                      className="absolute right-0 mt-2 w-56 bg-white border border-stone-200 rounded-xl shadow-lg py-2 z-50 animate-in fade-in slide-in-from-top-1"
                      onClick={() => setIsUserMenuOpen(false)}
                    >
                      <div className="px-4 py-2 border-b border-stone-100">
                        <p className="text-xs text-stone-500 font-medium">Signed in as</p>
                        <p className="text-sm font-semibold text-stone-900 truncate">{currentUser.email}</p>
                        {isAdmin && (
                          <span className="inline-block mt-1 text-[10px] tracking-wide font-bold uppercase text-purple-700 bg-purple-50 px-2 py-0.5 rounded">
                            Store Administrator
                          </span>
                        )}
                      </div>

                      {isAdmin && (
                        <button
                          onClick={() => navigateTo('admin')}
                          className="w-full text-left px-4 py-2 text-sm text-purple-700 hover:bg-purple-50 font-semibold flex items-center justify-between"
                        >
                          <span className="flex items-center gap-2">
                            <Shield className="w-4 h-4" /> Admin Dashboard
                          </span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        onClick={() => navigateTo('account')}
                        className="w-full text-left px-4 py-2 text-sm text-stone-700 hover:bg-stone-50"
                      >
                        My Account & Orders
                      </button>

                      <button
                        onClick={logout}
                        className="w-full text-left px-4 py-2 text-sm text-rose-600 hover:bg-rose-50 border-t border-stone-100 mt-1"
                      >
                        Sign Out
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <button
                    onClick={() => openAuthModal('login')}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-stone-800 hover:text-purple-700 rounded-lg transition-colors cursor-pointer"
                  >
                    <UserIcon className="w-4 h-4" />
                    <span>Sign In</span>
                  </button>
                  <button
                    onClick={() => openAuthModal('register')}
                    className="hidden sm:inline-flex px-2.5 py-1.5 text-xs font-semibold text-purple-700 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors cursor-pointer"
                  >
                    <span>Register</span>
                  </button>
                </div>
              )}
            </div>

          </div>
        </div>

        {/* Mobile Search Row (expandable) */}
        {isSearchExpanded && (
          <div className="md:hidden py-3 border-t border-stone-100 space-y-2">
            <form onSubmit={handleSearchSubmit}>
              <div className="relative flex items-center">
                <input
                  type="text"
                  placeholder="Search products by name or category..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 text-sm bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-purple-600"
                  autoFocus
                />
                <Search className="w-4 h-4 text-stone-400 absolute left-3 pointer-events-none" />
              </div>
            </form>

            {searchTerm.trim().length >= 2 && searchMatches.length > 0 && (
              <div className="bg-white rounded-xl border border-stone-200 p-2 shadow-lg space-y-1">
                {searchMatches.map(prod => (
                  <div
                    key={prod.id}
                    onClick={() => {
                      navigateTo('product', { productId: prod.id });
                      setIsSearchExpanded(false);
                    }}
                    className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-stone-50 cursor-pointer"
                  >
                    <img
                      src={prod.images[0] || '/src/assets/images/novora_cat_fashion_1792421786979.jpg'}
                      alt={prod.name}
                      className="w-8 h-8 object-cover rounded bg-stone-100 shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-stone-900 text-xs truncate">{prod.name}</p>
                      <p className="text-[10px] text-stone-500 truncate">{prod.category} · {formatPrice(prod.sellingPrice)}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-stone-200 bg-white px-4 pt-3 pb-6 space-y-2 shadow-xl animate-in slide-in-from-top-2">
          <button
            onClick={() => { navigateTo('home'); setIsMobileMenuOpen(false); }}
            className="block w-full text-left py-2 text-sm font-medium text-stone-800 hover:text-purple-700"
          >
            Home
          </button>
          <button
            onClick={() => { navigateTo('shop'); setIsMobileMenuOpen(false); }}
            className="block w-full text-left py-2 text-sm font-medium text-stone-800 hover:text-purple-700"
          >
            Shop All Catalog
          </button>
          <button
            onClick={() => { navigateTo('shop', { categorySlug: 'fashion' }); setIsMobileMenuOpen(false); }}
            className="block w-full text-left py-2 text-sm font-medium text-stone-800 hover:text-purple-700"
          >
            Fashion & Tailoring
          </button>
          <button
            onClick={() => { navigateTo('shop', { categorySlug: 'electronics' }); setIsMobileMenuOpen(false); }}
            className="block w-full text-left py-2 text-sm font-medium text-stone-800 hover:text-purple-700"
          >
            Precision Audio & Tech
          </button>
          <button
            onClick={() => { navigateTo('shop', { categorySlug: 'beauty' }); setIsMobileMenuOpen(false); }}
            className="block w-full text-left py-2 text-sm font-medium text-stone-800 hover:text-purple-700"
          >
            Beauty & Skincare
          </button>
          <button
            onClick={() => { navigateTo('contact'); setIsMobileMenuOpen(false); }}
            className="block w-full text-left py-2 text-sm font-medium text-stone-800 hover:text-purple-700"
          >
            Contact & Support
          </button>

          <div className="pt-3 border-t border-stone-100 flex flex-col gap-2">
            {currentUser ? (
              <>
                <button
                  onClick={() => { navigateTo('account'); setIsMobileMenuOpen(false); }}
                  className="w-full text-left py-2 text-sm font-medium text-stone-800"
                >
                  My Account ({currentUser.fullName})
                </button>
                {isAdmin && (
                  <button
                    onClick={() => { navigateTo('admin'); setIsMobileMenuOpen(false); }}
                    className="w-full text-left py-2 text-sm font-semibold text-purple-700 flex items-center gap-2"
                  >
                    <Shield className="w-4 h-4" /> Admin Dashboard
                  </button>
                )}
                <button
                  onClick={() => { logout(); setIsMobileMenuOpen(false); }}
                  className="w-full text-left py-2 text-sm font-medium text-rose-600"
                >
                  Sign Out
                </button>
              </>
            ) : (
              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  onClick={() => { openAuthModal('login'); setIsMobileMenuOpen(false); }}
                  className="w-full py-2 text-center text-xs font-semibold border border-stone-300 rounded-lg text-stone-800"
                >
                  Sign In
                </button>
                <button
                  onClick={() => { openAdminModal(); setIsMobileMenuOpen(false); }}
                  className="w-full py-2 text-center text-xs font-semibold bg-linear-to-r from-stone-900 to-purple-900 text-white rounded-lg flex items-center justify-center gap-1.5"
                >
                  <Shield className="w-3.5 h-3.5 text-purple-300" />
                  <span>Admin Option</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
