export interface ProductVariant {
  sizes?: string[];
  colors?: { name: string; hex: string }[];
  styles?: string[];
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  description: string;
  category: string;
  subcategory?: string;
  brand: string;
  originalPrice: number;
  sellingPrice: number;
  discountPercentage: number;
  stock: number;
  status: 'draft' | 'published' | 'out_of_stock';
  featured: boolean;
  bestSeller: boolean;
  images: string[];
  variants: ProductVariant;
  rating: number;
  reviewsCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  image: string;
  description: string;
  subcategories: string[];
  displayOrder: number;
  status: 'active' | 'inactive';
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  badgeText: string;
  buttonText: string;
  linkUrl: string;
  imageUrl: string;
  displayOrder: number;
  isActive: boolean;
  startDate?: string;
  endDate?: string;
}

export interface DeliveryAddress {
  id?: string;
  fullName: string;
  email: string;
  phone: string;
  country: string;
  state: string;
  city: string;
  streetAddress: string;
  houseNumber: string;
  apartmentDetails?: string;
  postalCode: string;
  isDefault?: boolean;
}

export interface OrderItem {
  productId: string;
  productName: string;
  productImage: string;
  price: number;
  quantity: number;
  selectedVariant?: {
    size?: string;
    color?: string;
  };
}

export type OrderStatus =
  | 'Pending Payment'
  | 'Awaiting Payment'
  | 'Paid'
  | 'Confirmed'
  | 'Processing'
  | 'Sent to Supplier'
  | 'Shipped'
  | 'Delivered'
  | 'Cancelled'
  | 'Refunded';

export type PaymentStatus = 'pending' | 'paid' | 'declined' | 'refunded' | 'partially_refunded';

export interface BankPayoutAccount {
  bankName: string;
  accountHolderName: string;
  country: string;
  currency: string;
  maskedIban: string;
  ibanMasked?: string;
  branchCode?: string;
  status: 'Verified' | 'Pending Verification' | 'Disconnected';
  isVerified?: boolean;
  verifiedAt?: string;
}

export interface PayoutAuditRecord {
  id: string;
  changedAt: string;
  adminEmail: string;
  action: 'payout_destination_updated' | 'payout_destination_linked' | 'payout_destination_disconnected';
  previousAccountMasked: string;
  newAccountMasked: string;
  bankName: string;
  currency: string;
  confirmationReference: string;
  provider: string;
  notes?: string;
}

export interface PaymentTransaction {
  id: string;
  transactionReference: string;
  orderId: string;
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  amount: number;
  currency: string;
  fee: number;
  netPayout: number;
  provider: string;
  paymentMethod: string;
  paymentStatus: 'paid' | 'pending' | 'declined' | 'refunded' | 'partially_refunded';
  payoutStatus: 'Deposited' | 'In Transit' | 'Scheduled (T+2)' | 'Held' | 'Refunded';
  payoutAccount?: string;
  merchantSettlementDestination?: string;
  createdAt: string;
  refundedAmount?: number;
  refundReason?: string;
}

export interface PaymentDetails {
  transactionId?: string;
  provider: string; // e.g., 'Stripe' | 'Safepay' | 'Paymob' | 'Bank Transfer' | 'Cash on Delivery'
  paymentMethodTitle: string;
  isTestMode?: boolean;
  maskedCard?: string;
  maskedCardNumber?: string;
  cardBrand?: string;
  paidAt?: string;
  referenceNumber?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  userId?: string;
  customer: {
    fullName: string;
    email: string;
    phone: string;
  };
  deliveryAddress: DeliveryAddress;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  shippingFee: number;
  taxAmount: number;
  total: number;
  currency: string;
  paymentMethod: string;
  paymentStatus: PaymentStatus;
  orderStatus: OrderStatus;
  paymentDetails?: PaymentDetails;
  trackingNumber?: string;
  carrier?: string;
  trackingUrl?: string;
  supplierOrderId?: string;
  dropshippingStatus?: 'unfulfilled' | 'submitted' | 'processing' | 'shipped' | 'failed';
  settledToMerchantCard?: string;
  notes?: string;
  isArchived?: boolean;
  archivedAt?: string;
}

export interface User {
  id: string;
  email: string;
  fullName: string;
  role: 'admin' | 'customer';
  phone?: string;
  savedAddresses: DeliveryAddress[];
  wishlist: string[];
  createdAt?: string;
  registrationDate?: string;
  updatedAt?: string;
  isEmailVerified?: boolean;
  emailVerifiedAt?: string;
  verificationStatus?: 'verified' | 'pending_verification';
  accountStatus?: 'active' | 'pending_verification' | 'suspended';
}

export interface FolderStorageStatus {
  serverHost: string;
  folderPath: string;
  localPath: string;
  lastSyncAt: string;
  files: {
    name: string;
    size: number;
    sizeFormatted: string;
    records: number;
    description: string;
    lastModified: string;
  }[];
}

export interface CartItem {
  id: string; // unique item key
  product: Product;
  quantity: number;
  selectedVariant?: {
    size?: string;
    color?: string;
  };
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderValue: number;
  expiryDate: string;
  isActive: boolean;
  usageCount: number;
}

export interface Review {
  id: string;
  productId: string;
  productName: string;
  customerName: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
  status: 'approved' | 'pending';
}

export interface StoreSettings {
  storeName: string;
  tagline: string;
  currency: string;
  currencySymbol: string;
  shippingCharge: number;
  freeShippingThreshold: number;
  taxRatePercentage: number;
  contactEmail: string;
  contactPhone: string;
  address: string;
  seoTitle: string;
  seoDescription: string;
  showPromotionalBar: boolean;
  promotionalBarText: string;
}

export interface PaymentSession {
  id: string;
  orderId: string;
  orderNumber: string;
  amount: number;
  currency: string;
  customerEmail: string;
  customerName: string;
  provider: 'safepay' | 'stripe' | 'paymob';
  mode: 'test' | 'live' | 'sandbox' | 'production';
  status: 'pending' | 'completed' | 'failed' | 'expired';
  token: string;
  clientSecret: string;
  checkoutUrl?: string;
  createdAt: string;
  expiresAt: string;
}

export interface MerchantCardDetails {
  id: string;
  brand: string;
  last4: string;
  expiryMonth: string;
  expiryYear: string;
  cardholderName: string;
  isDefault: boolean;
  status: 'active' | 'expired';
  billingPostalCode?: string;
  addedAt: string;
}

export interface PaymentGatewayConfig {
  provider: 'stripe' | 'safepay' | 'paymob';
  providerName: string;
  isTestMode: boolean;
  mode?: 'test' | 'live';
  merchantId?: string;
  payoutDetails?: {
    bankName?: string;
    accountTitle?: string;
    maskedAccountNumber?: string;
  };
  isConnected: boolean;
  publishableKeyMasked?: string;
  merchantIdMasked?: string;
  apiKeyMasked?: string;
  secretKeyConfigured?: boolean;
  merchantKycStatus?: 'verified' | 'pending_approval' | 'unregistered';
  payoutStatus: 'Active' | 'Pending Verification' | 'Needs Setup';
  payoutAccountMasked: string;
  payoutAccount?: BankPayoutAccount;
  merchantCard?: MerchantCardDetails;
  merchantCards?: MerchantCardDetails[];
  supportedCurrencies: string[];
  cardsEnabled: boolean;
  bankTransferEnabled: boolean;
  codEnabled: boolean;
  maxCodAmount: number;
  bankDetails: {
    bankName: string;
    accountTitle: string;
    ibanMasked: string;
    branchCode: string;
    instructions: string;
  };
  webhookSecretSet: boolean;
  webhookSecret?: string;
  lastVerifiedAt?: string;
  payoutAuditLog?: PayoutAuditRecord[];
}

export interface AdminAuditEntry {
  id: string;
  timestamp: string;
  adminEmail: string;
  action: string;
  details: string;
  status: 'success' | 'failure';
  ip?: string;
}

export interface ProductChangeLogEntry {
  id: string;
  timestamp: string;
  action: 'product_created' | 'product_updated' | 'product_deleted' | 'product_archived' | 'product_restored';
  productId: string;
  productName: string;
  sku?: string;
  adminEmail: string;
  details: string;
  status: 'success' | 'failure';
}
