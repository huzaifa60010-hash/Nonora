import {
  Product,
  Category,
  Banner,
  Order,
  User,
  Coupon,
  Review,
  StoreSettings,
  DeliveryAddress,
  PaymentGatewayConfig,
  BankPayoutAccount,
  PayoutAuditRecord,
  PaymentTransaction,
  PaymentSession,
  MerchantCardDetails,
  FolderStorageStatus,
  AdminAuditEntry,
  ProductChangeLogEntry,
} from '../types';

const TOKEN_KEY = 'novora_auth_token';

export function getAuthToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setAuthToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function removeAuthToken() {
  localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(options.headers || {}),
  };

  if (token) {
    (headers as Record<string, string>)['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(endpoint, {
    ...options,
    headers,
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }

  return data as T;
}

// UPLOAD IMAGE FROM PC DIRECTLY TO SERVER PERSISTENT STORAGE
// (Media/Logos, Media/Product_Images, Media/Banner_Images, Media/Category_Images, Media/Other_Store_Images)
export async function uploadImageFromPC(
  file: File,
  folder: 'Logos' | 'Product_Images' | 'Banner_Images' | 'Category_Images' | 'Other_Store_Images' | 'products' | 'banners' = 'Product_Images'
): Promise<string> {
  return new Promise((resolve, reject) => {
    // Validate file type
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'];
    if (!validTypes.includes(file.type)) {
      return reject(new Error('Please select a valid image file (JPG, PNG, WebP, or SVG).'));
    }

    // Validate size (max 25MB)
    if (file.size > 25 * 1024 * 1024) {
      return reject(new Error('Image size must be under 25MB.'));
    }

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const base64Data = reader.result as string;
        const res = await request<{ success: boolean; url: string }>('/api/upload', {
          method: 'POST',
          body: JSON.stringify({
            base64: base64Data,
            fileName: file.name,
            folder,
          }),
        });
        resolve(res.url);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('Failed to read image file from your PC.'));
    reader.readAsDataURL(file);
  });
}

export async function deleteUploadedImage(url: string): Promise<{ success: boolean; deleted: boolean; reason?: string }> {
  return request<{ success: boolean; deleted: boolean; reason?: string }>('/api/upload/delete', {
    method: 'POST',
    body: JSON.stringify({ url }),
  });
}

export const api = {
  // Auth
  login: (email: string, password: string) => 
    request<{
      success: boolean;
      token?: string;
      user?: User;
      requiresVerification?: boolean;
      email?: string;
      fullName?: string;
      message?: string;
    }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  adminLogin: (email: string, password: string) =>
    request<{
      success: boolean;
      token?: string;
      user?: User;
      message?: string;
    }>('/api/admin/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  adminLogout: () =>
    request<{ success: boolean; message?: string }>('/api/admin/logout', {
      method: 'POST',
    }),

  register: (data: {
    email: string;
    password: string;
    confirmPassword?: string;
    fullName: string;
    phone?: string;
    agreedToTerms?: boolean;
  }) =>
    request<{
      success: boolean;
      requiresVerification?: boolean;
      email: string;
      fullName?: string;
      message: string;
      token?: string;
      user?: User;
    }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  loginWithGoogle: (email: string, fullName?: string, photoURL?: string) =>
    request<{ success: boolean; token: string; user: User }>('/api/auth/google', {
      method: 'POST',
      body: JSON.stringify({ email, fullName, photoURL }),
    }),

  verifyOtp: (email: string, code: string, purpose: 'registration' | 'login_verification' | 'password_reset' | 'email_change' = 'registration') =>
    request<{
      success: boolean;
      token?: string;
      user?: User;
      message: string;
      remainingAttempts?: number;
    }>('/api/auth/verify-otp', {
      method: 'POST',
      body: JSON.stringify({ email, code, purpose }),
    }),

  resendOtp: (email: string, purpose: 'registration' | 'login_verification' | 'password_reset' | 'email_change' = 'registration') =>
    request<{
      success: boolean;
      message: string;
      cooldownSeconds?: number;
    }>('/api/auth/resend-otp', {
      method: 'POST',
      body: JSON.stringify({ email, purpose }),
    }),

  forgotPassword: (email: string) =>
    request<{ success: boolean; message: string; verificationCode?: string }>('/api/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),

  resetPassword: (email: string, code: string, newPassword: string, confirmPassword?: string) =>
    request<{ success: boolean; message: string; remainingAttempts?: number }>('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ email, code, newPassword, confirmPassword }),
    }),

  getBackupStatus: () => request<any>('/api/drive/backup-status'),

  getMe: () => request<{ user: User }>('/api/auth/me'),

  updateProfile: (data: Partial<User>) =>
    request<{ success: boolean; user: User }>('/api/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  // Delivery Addresses
  addAddress: (address: DeliveryAddress) =>
    request<{ success: boolean; addresses: DeliveryAddress[]; address: DeliveryAddress }>('/api/auth/address', {
      method: 'POST',
      body: JSON.stringify(address),
    }),

  updateAddress: (id: string, address: Partial<DeliveryAddress>) =>
    request<{ success: boolean; addresses: DeliveryAddress[]; address: DeliveryAddress }>(`/api/auth/address/${id}`, {
      method: 'PUT',
      body: JSON.stringify(address),
    }),

  deleteAddress: (id: string) =>
    request<{ success: boolean; addresses: DeliveryAddress[] }>(`/api/auth/address/${id}`, {
      method: 'DELETE',
    }),

  getCustomers: () => request<any[]>('/api/customers'),

  getFolderStorageStatus: () => request<FolderStorageStatus>('/api/admin/folder-storage'),

  updateAdminUser: (id: string, data: { fullName?: string; email?: string; phone?: string }) =>
    request<{ success: boolean; user: any }>(`/api/admin/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  deleteAdminUser: (id: string) =>
    request<{ success: boolean; message: string }>(`/api/admin/users/${id}`, {
      method: 'DELETE',
    }),

  // Products
  getProducts: (params: Record<string, any> = {}) => {
    const query = new URLSearchParams();
    Object.entries(params).forEach(([key, val]) => {
      if (val !== undefined && val !== null && val !== '') {
        query.append(key, String(val));
      }
    });
    return request<Product[]>(`/api/products?${query.toString()}`);
  },

  getProduct: (id: string) => request<Product>(`/api/products/${id}`),

  createProduct: (data: Partial<Product>) =>
    request<{ success: boolean; product: Product }>('/api/products', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateProduct: (id: string, data: Partial<Product>) =>
    request<{ success: boolean; product: Product }>(`/api/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  deleteProduct: (id: string) =>
    request<{ success: boolean; productId?: string; message?: string }>(`/api/products/${id}`, {
      method: 'DELETE',
    }),

  getProductChangesLog: () => request<ProductChangeLogEntry[]>('/api/admin/products/changes-log'),

  // Categories
  getCategories: () => request<Category[]>('/api/categories'),

  createCategory: (data: Partial<Category>) =>
    request<{ success: boolean; category: Category }>('/api/categories', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateCategory: (id: string, data: Partial<Category>) =>
    request<{ success: boolean; category: Category }>(`/api/categories/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  deleteCategory: (id: string) =>
    request<{ success: boolean }>(`/api/categories/${id}`, {
      method: 'DELETE',
    }),

  // Banners
  getBanners: () => request<Banner[]>('/api/banners'),

  createBanner: (data: Partial<Banner>) =>
    request<{ success: boolean; banner: Banner }>('/api/banners', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateBanner: (id: string, data: Partial<Banner>) =>
    request<{ success: boolean; banner: Banner }>(`/api/banners/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  deleteBanner: (id: string) =>
    request<{ success: boolean }>(`/api/banners/${id}`, {
      method: 'DELETE',
    }),

  // Orders
  getOrders: () => request<Order[]>('/api/orders'),

  getOrder: (id: string) => request<Order>(`/api/orders/${id}`),

  createOrder: (payload: {
    items: { productId: string; quantity: number; selectedVariant?: any }[];
    deliveryAddress: DeliveryAddress;
    couponCode?: string;
    paymentMethod: string;
    currency?: string;
    cardPayment?: {
      cardNumber: string;
      expiry: string;
      cvc: string;
      cardholderName?: string;
    };
    notes?: string;
  }) =>
    request<{ success: boolean; order: Order; message: string }>('/api/orders', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  updateOrderStatus: (
    id: string,
    data: { status?: string; trackingNumber?: string; carrier?: string; paymentStatus?: string }
  ) =>
    request<{ success: boolean; order: Order }>(`/api/orders/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  archiveOrder: (id: string, isArchived?: boolean) =>
    request<{ success: boolean; order: Order }>(`/api/orders/${id}/archive`, {
      method: 'PUT',
      body: JSON.stringify({ isArchived }),
    }),

  deleteOrder: (id: string) =>
    request<{ success: boolean; message: string }>(`/api/orders/${id}`, {
      method: 'DELETE',
    }),

  // Payment Settings
  getPublicPaymentSettings: () => request<PaymentGatewayConfig>('/api/payment-settings'),

  getAdminPaymentSettings: () => request<PaymentGatewayConfig>('/api/admin/payment-settings'),

  updateAdminPaymentSettings: (data: Partial<PaymentGatewayConfig>) =>
    request<{ success: boolean; paymentGateway: PaymentGatewayConfig }>('/api/admin/payment-settings', {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  connectPaymentProvider: (provider: string) =>
    request<{ success: boolean; message: string; paymentGateway: PaymentGatewayConfig }>(
      '/api/admin/payment-settings/connect',
      {
        method: 'POST',
        body: JSON.stringify({ provider }),
      }
    ),

  saveAndVerifyBankAccount: (data: {
    bankName: string;
    accountHolderName: string;
    country: string;
    currency: string;
    accountNumberOrIban: string;
    branchCode?: string;
  }) =>
    request<{
      success: boolean;
      message: string;
      payoutAccount: BankPayoutAccount;
      paymentGateway: PaymentGatewayConfig;
    }>('/api/admin/payment-settings/bank-account', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  changePayoutAccount: (data: {
    bankName: string;
    accountHolderName: string;
    country: string;
    currency: string;
    accountNumberOrIban: string;
    branchCode?: string;
    adminConfirmationPassword?: string;
    reasonForChange?: string;
  }) =>
    request<{
      success: boolean;
      message: string;
      payoutAccount: BankPayoutAccount;
      confirmationReference: string;
      auditRecord: PayoutAuditRecord;
      paymentGateway: PaymentGatewayConfig;
    }>('/api/admin/payment-settings/change-payout-account', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getPayoutAuditLog: () =>
    request<PayoutAuditRecord[]>('/api/admin/payment-settings/payout-audit-log'),

  disconnectPaymentGateway: () =>
    request<{ success: boolean; message: string; paymentGateway: PaymentGatewayConfig }>(
      '/api/admin/payment-settings/disconnect',
      {
        method: 'POST',
      }
    ),

  testPaymentConnection: () =>
    request<{
      success: boolean;
      provider: string;
      providerName: string;
      mode: string;
      latencyMs: number;
      gatewayStatus: string;
      webhookEndpoint: string;
      webhookStatus: string;
      payoutRail: string;
      testedAt: string;
    }>('/api/admin/payment-settings/test-connection', {
      method: 'POST',
    }),

  getPaymentTransactions: (params: { status?: string; search?: string } = {}) => {
    const query = new URLSearchParams();
    if (params.status && params.status !== 'all') query.append('status', params.status);
    if (params.search) query.append('search', params.search);
    return request<PaymentTransaction[]>(`/api/admin/payment-transactions?${query.toString()}`);
  },

  refundOrder: (orderId: string, data: { amount?: number; reason?: string }) =>
    request<{
      success: boolean;
      message: string;
      order: Order;
      transaction: PaymentTransaction;
    }>(`/api/admin/orders/${orderId}/refund`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Customer Payment Sessions & Real Checkout
  createPaymentSession: (payload: {
    items: {
      productId: string;
      productName: string;
      productImage: string;
      price: number;
      quantity: number;
      selectedVariant?: any;
    }[];
    deliveryAddress: DeliveryAddress;
    couponCode?: string;
    currency?: string;
    notes?: string;
  }) =>
    request<{
      success: boolean;
      order: Order;
      session: PaymentSession;
    }>('/api/payments/create-session', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  verifyPaymentSession: (data: {
    sessionId: string;
    token?: string;
    action: 'confirm' | 'decline' | 'cancel';
    cardLast4?: string;
    cardBrand?: string;
  }) =>
    request<{
      success: boolean;
      status: string;
      order?: Order;
      transaction?: PaymentTransaction;
      error?: string;
      message?: string;
    }>('/api/payments/verify-session', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getPaymentCredentialsStatus: () =>
    request<{
      provider: string;
      isTestMode: boolean;
      mode: string;
      apiKeyConfigured: boolean;
      secretKeyConfigured: boolean;
      webhookSecretConfigured: boolean;
      merchantKycApproved: boolean;
      payoutAccountLinked: boolean;
      isLiveEligible: boolean;
      checklist: {
        id: string;
        title: string;
        description: string;
        status: 'completed' | 'pending';
        required: boolean;
      }[];
      liveWarningMessage: string;
    }>('/api/admin/payment-settings/credentials'),

  updatePaymentCredentials: (data: {
    apiKey?: string;
    secretKey?: string;
    webhookSecret?: string;
    merchantKycStatus?: 'verified' | 'pending_approval' | 'unregistered';
  }) =>
    request<{
      success: boolean;
      message: string;
      paymentGateway: PaymentGatewayConfig;
    }>('/api/admin/payment-settings/credentials', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  // Merchant Business Card-on-File Management
  addOrUpdateMerchantCard: (data: {
    cardholderName: string;
    cardNumber: string;
    expiryMonth: string;
    expiryYear: string;
    cvc: string;
    billingPostalCode?: string;
    isDefault?: boolean;
  }) =>
    request<{
      success: boolean;
      message: string;
      paymentGateway: PaymentGatewayConfig;
      card: MerchantCardDetails;
    }>('/api/admin/payment-settings/merchant-card', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  setDefaultMerchantCard: (cardId: string) =>
    request<{
      success: boolean;
      message: string;
      paymentGateway: PaymentGatewayConfig;
      card: MerchantCardDetails;
    }>(`/api/admin/payment-settings/merchant-card/${cardId}/default`, {
      method: 'PUT',
    }),

  deleteMerchantCard: (cardId: string) =>
    request<{
      success: boolean;
      message: string;
      paymentGateway: PaymentGatewayConfig;
    }>(`/api/admin/payment-settings/merchant-card/${cardId}`, {
      method: 'DELETE',
    }),

  // Inventory
  getInventory: () => request<any[]>('/api/inventory'),

  updateStock: (id: string, stock: number, status?: string) =>
    request<{ success: boolean; product: Product }>(`/api/inventory/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ stock, status }),
    }),

  // Coupons
  getCoupons: () => request<Coupon[]>('/api/coupons'),

  validateCoupon: (code: string, cartTotal: number) =>
    request<{
      valid: boolean;
      code: string;
      discountType: 'percentage' | 'fixed';
      discountValue: number;
      discountAmount: number;
      error?: string;
    }>('/api/coupons/validate', {
      method: 'POST',
      body: JSON.stringify({ code, cartTotal }),
    }),

  createCoupon: (data: Partial<Coupon>) =>
    request<{ success: boolean; coupon: Coupon }>('/api/coupons', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateCoupon: (id: string, data: Partial<Coupon>) =>
    request<{ success: boolean; coupon: Coupon }>(`/api/coupons/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  deleteCoupon: (id: string) =>
    request<{ success: boolean }>(`/api/coupons/${id}`, {
      method: 'DELETE',
    }),

  // Reviews
  getReviews: (productId?: string) =>
    request<Review[]>(`/api/reviews${productId ? `?productId=${productId}` : ''}`),

  submitReview: (data: { productId: string; rating: number; comment: string; customerName?: string }) =>
    request<{ success: boolean; review: Review; productRating: number }>('/api/reviews', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  deleteReview: (id: string) =>
    request<{ success: boolean }>(`/api/reviews/${id}`, {
      method: 'DELETE',
    }),

  // Settings
  getSettings: () => request<StoreSettings>('/api/settings'),

  updateSettings: (data: Partial<StoreSettings>) =>
    request<{ success: boolean; settings: StoreSettings }>('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(data),
    }),

  // Contact
  submitContact: (data: { name: string; email: string; subject?: string; message: string }) =>
    request<{ success: boolean; message: string }>('/api/contact', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getContactMessages: () => request<any[]>('/api/contact'),

  // Admin stats
  getAdminStats: () => request<{
    totalProducts: number;
    totalOrders: number;
    pendingOrders: number;
    completedOrders: number;
    totalSales: number;
    lowStockProducts: number;
    totalCustomers: number;
    recentOrders: Order[];
  }>('/api/admin/stats'),

  // Database Backups & SQLite Persistence Hub (Requirement 7)
  getDatabaseBackups: () =>
    request<
      Array<{
        id: string;
        filename: string;
        createdAt: string;
        sizeBytes: number;
        description: string;
      }>
    >('/api/admin/database/backups'),

  createDatabaseBackup: (description?: string) =>
    request<{
      success: boolean;
      backup: {
        id: string;
        filename: string;
        createdAt: string;
        sizeBytes: number;
        description: string;
      };
      message: string;
    }>('/api/admin/database/backup', {
      method: 'POST',
      body: JSON.stringify({ description }),
    }),

  restoreDatabaseBackup: (filename: string) =>
    request<{
      success: boolean;
      message: string;
      stats: {
        users: number;
        products: number;
        orders: number;
        categories: number;
        banners: number;
      };
    }>('/api/admin/database/restore', {
      method: 'POST',
      body: JSON.stringify({ filename }),
    }),

  validateDatabaseBackup: (filename: string) =>
    request<{
      isValid: boolean;
      message: string;
      stats?: { products: number; categories: number; orders: number; users: number; settingsFound: boolean };
    }>('/api/admin/database/validate-backup', {
      method: 'POST',
      body: JSON.stringify({ filename }),
    }),

  // Order Tracking
  trackOrder: (orderNumber: string) =>
    request<{
      success: boolean;
      order: {
        id: string;
        orderNumber: string;
        createdAt: string;
        orderStatus: string;
        paymentStatus: string;
        paymentMethod: string;
        trackingNumber: string;
        carrier: string;
        trackingUrl?: string;
        total: number;
        currency: string;
        items: any[];
        deliveryAddress: {
          fullName: string;
          city: string;
          state: string;
          country: string;
          postalCode: string;
        };
        timeline: Array<{ title: string; completed: boolean; timestamp?: string; detail: string }>;
      };
    }>(`/api/orders/track/${encodeURIComponent(orderNumber)}`),

  // Newsletter
  subscribeNewsletter: (email: string) =>
    request<{ success: boolean; message: string }>('/api/newsletter/subscribe', {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),

  getNewsletterSubscribers: () =>
    request<Array<{ id: string; email: string; subscribedAt: string }>>('/api/admin/newsletter/subscribers'),

  // Google Drive Data Export
  getDriveExportData: () =>
    request<{
      folderId: string;
      folderName: string;
      timestamp: string;
      customers: any[];
      addresses: any[];
      orders: any[];
      products: any[];
      categories: any[];
      banners: any[];
      settings: any;
      auditLog: AdminAuditEntry[];
      adminCredentials: any;
    }>('/api/drive/export-data'),

  // Admin Security & Password Management
  changeAdminPassword: (data: { currentPassword: string; newPassword: string; confirmPassword: string }) =>
    request<{ success: boolean; message: string; token?: string }>('/api/admin/change-password', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  requestAdminEmailChange: (data: { newEmail: string; currentPassword: string }) =>
    request<{ success: boolean; message: string; verificationToken: string; verificationLink: string; pendingEmail: string }>('/api/admin/request-email-change', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  confirmAdminEmailChange: (data: { newEmail: string; currentPassword: string }) =>
    request<{ success: boolean; message: string; user: User; token: string }>('/api/admin/confirm-email-change', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getAdminAuditLog: () =>
    request<AdminAuditEntry[]>('/api/admin/security/audit-log'),
};


