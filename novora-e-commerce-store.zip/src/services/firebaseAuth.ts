import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  sendEmailVerification,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithPopup,
  User as FirebaseUser,
} from 'firebase/auth';
import { getFirestore, doc, setDoc, getDoc } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const firebaseAuth = getAuth(app);
export const firestoreDb = getFirestore(app);

export interface FirebaseAuthResult {
  uid: string;
  email: string;
  fullName: string;
  photoURL?: string;
  idToken: string;
}

/**
 * Register a new customer with Firebase Authentication and save profile in Firestore
 */
export async function firebaseRegisterCustomer(
  fullName: string,
  email: string,
  password: string,
  phone?: string
): Promise<FirebaseAuthResult> {
  const cleanEmail = email.trim().toLowerCase();
  const cleanName = fullName.trim();

  const userCredential = await createUserWithEmailAndPassword(firebaseAuth, cleanEmail, password);
  const fbUser = userCredential.user;

  await updateProfile(fbUser, { displayName: cleanName });
  await sendEmailVerification(fbUser).catch(() => {});

  // Save customer profile in Firestore (strictly role: 'customer', never 'admin')
  try {
    await setDoc(doc(firestoreDb, 'users', fbUser.uid), {
      uid: fbUser.uid,
      fullName: cleanName,
      email: cleanEmail,
      phone: phone ? phone.trim() : '',
      role: 'customer',
      createdAt: new Date().toISOString(),
    });
  } catch (err) {
    console.warn('[FirebaseAuth] Firestore profile write warning:', err);
  }

  const idToken = await fbUser.getIdToken();
  return {
    uid: fbUser.uid,
    email: cleanEmail,
    fullName: cleanName,
    idToken,
  };
}

/**
 * Sign in an existing user (customer or authorized administrator) with Firebase Authentication
 */
export async function firebaseSignInUser(
  email: string,
  password: string,
  rememberMe: boolean = true
): Promise<FirebaseAuthResult> {
  const cleanEmail = email.trim().toLowerCase();
  await setPersistence(firebaseAuth, rememberMe ? browserLocalPersistence : browserSessionPersistence);
  const userCredential = await signInWithEmailAndPassword(firebaseAuth, cleanEmail, password);
  const fbUser = userCredential.user;
  const idToken = await fbUser.getIdToken();

  let fullName = fbUser.displayName || cleanEmail.split('@')[0];
  try {
    const snap = await getDoc(doc(firestoreDb, 'users', fbUser.uid));
    if (snap.exists() && snap.data().fullName) {
      fullName = snap.data().fullName;
    }
  } catch {
    // non-fatal
  }

  return {
    uid: fbUser.uid,
    email: fbUser.email || cleanEmail,
    fullName,
    photoURL: fbUser.photoURL || undefined,
    idToken,
  };
}

/**
 * Sign in with Google using Firebase Authentication (profile & email only)
 */
export async function firebaseSignInWithGoogle(
  rememberMe: boolean = true
): Promise<FirebaseAuthResult> {
  await setPersistence(firebaseAuth, rememberMe ? browserLocalPersistence : browserSessionPersistence);
  const provider = new GoogleAuthProvider();
  provider.addScope('profile');
  provider.addScope('email');
  provider.setCustomParameters({ prompt: 'select_account' });

  const result = await signInWithPopup(firebaseAuth, provider);
  const fbUser = result.user;
  const idToken = await fbUser.getIdToken();
  const cleanEmail = (fbUser.email || '').trim().toLowerCase();
  const fullName = fbUser.displayName || cleanEmail.split('@')[0] || 'NOVORA Patron';

  return {
    uid: fbUser.uid,
    email: cleanEmail,
    fullName,
    photoURL: fbUser.photoURL || undefined,
    idToken,
  };
}

/**
 * Send password reset email via Firebase Authentication
 */
export async function firebaseSendPasswordReset(email: string): Promise<void> {
  const cleanEmail = email.trim().toLowerCase();
  await sendPasswordResetEmail(firebaseAuth, cleanEmail);
}

/**
 * Sign out from Firebase Authentication
 */
export async function firebaseSignOutUser(): Promise<void> {
  await signOut(firebaseAuth);
}

/**
 * Subscribe to Firebase Authentication state changes
 */
export function subscribeToFirebaseAuth(
  callback: (user: FirebaseUser | null) => void
): () => void {
  return onAuthStateChanged(firebaseAuth, callback);
}
