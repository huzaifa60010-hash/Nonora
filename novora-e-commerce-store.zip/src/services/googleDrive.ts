import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  User as FirebaseUser,
  signOut,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

// Target Google Drive Root Folder specified by user: NOVORA_Project
export const TARGET_DRIVE_FOLDER_ID = '1q_B8QGCYgzRgVzT4r3f-NH2PN1XaU34m';
export const TARGET_DRIVE_FOLDER_URL = `https://drive.google.com/drive/folders/${TARGET_DRIVE_FOLDER_ID}?dmr=1&ec=wgc-drive-%5Bmodule%5D-goto`;
export const TARGET_DRIVE_FOLDER_NAME = 'NOVORA_Project';

// 1. Initialize Firebase App singleton
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);

// 2. Configure Google Auth Provider with Google Drive scope
const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/drive');

// In-memory token cache (never stored in localStorage or sessionStorage per security guidelines)
let cachedAccessToken: string | null = null;
let isSigningIn = false;

// 3. Initialize Auth State Listener
export const initGoogleDriveAuth = (
  onAuthSuccess?: (user: FirebaseUser, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: FirebaseUser | null) => {
    if (user && cachedAccessToken) {
      if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
    } else if (user && !cachedAccessToken && !isSigningIn) {
      if (onAuthFailure) onAuthFailure();
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

// 4. Connect / Sign In with Google
export const signInWithGoogleDrive = async (): Promise<{
  user: FirebaseUser;
  accessToken: string;
}> => {
  isSigningIn = true;
  console.log('[GoogleDrive:Auth] Initiating Google Drive OAuth popup with scope https://www.googleapis.com/auth/drive...');
  try {
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to obtain Google Drive authorization token from credential result.');
    }
    cachedAccessToken = credential.accessToken;
    console.log('[GoogleDrive:Auth] Successfully obtained Google Drive access token for user:', result.user.email);
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('[GoogleDrive:Auth] OAuth sign-in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

// 5. Disconnect / Sign out
export const disconnectGoogleDrive = async () => {
  console.log('[GoogleDrive:Auth] Disconnecting Google Drive and clearing in-memory token cache.');
  await signOut(auth);
  cachedAccessToken = null;
};

// 6. Get cached access token
export const getDriveAccessToken = (): string | null => {
  return cachedAccessToken;
};

// Helper: search if a file or folder exists inside parent folder
export async function findItemInFolder(
  token: string,
  name: string,
  parentId: string,
  mimeType?: string
): Promise<string | null> {
  let queryParts = [`'${parentId}' in parents`, `name = '${name.replace(/'/g, "\\'")}'`, `trashed = false`];
  if (mimeType) {
    queryParts.push(`mimeType = '${mimeType}'`);
  }
  const query = encodeURIComponent(queryParts.join(' and '));
  try {
    const res = await fetch(`https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name,mimeType,webViewLink)`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) {
      const errText = await res.text();
      console.warn(`[GoogleDrive:Query] Find item query failed for "${name}" (HTTP ${res.status}): ${errText}`);
      return null;
    }
    const data = await res.json();
    if (data.files && data.files.length > 0) {
      return data.files[0].id;
    }
  } catch (err) {
    console.warn(`[GoogleDrive:Query] Network exception while querying "${name}":`, err);
  }
  return null;
}

// Helper: find or create a Google Drive subfolder
export async function findOrCreateFolder(
  token: string,
  folderName: string,
  parentId: string
): Promise<string> {
  const existingId = await findItemInFolder(token, folderName, parentId, 'application/vnd.google-apps.folder');
  if (existingId) {
    console.log(`[GoogleDrive:Folder] Found existing folder "${folderName}" (${existingId}) in parent ${parentId}`);
    return existingId;
  }

  console.log(`[GoogleDrive:Folder] Creating new folder "${folderName}" in parent ${parentId}...`);
  const res = await fetch('https://www.googleapis.com/drive/v3/files', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      name: folderName,
      mimeType: 'application/vnd.google-apps.folder',
      parents: [parentId],
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    console.error(`[GoogleDrive:Folder] Failed to create folder "${folderName}":`, errText);
    throw new Error(`Failed to create Google Drive folder "${folderName}" (HTTP ${res.status}): ${errText}`);
  }

  const created = await res.json();
  console.log(`[GoogleDrive:Folder] Successfully created folder "${folderName}" (ID: ${created.id})`);
  return created.id;
}

// Helper: create or update JSON file in a specific folder
export async function uploadOrUpdateJsonFile(
  token: string,
  fileName: string,
  folderId: string,
  jsonData: any,
  description: string
): Promise<{ fileId: string; webViewLink?: string }> {
  const existingFileId = await findItemInFolder(token, fileName, folderId);
  const jsonContent = JSON.stringify(jsonData, null, 2);

  if (existingFileId) {
    const uploadUrl = `https://www.googleapis.com/upload/drive/v3/files/${existingFileId}?uploadType=media`;
    const uploadRes = await fetch(uploadUrl, {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: jsonContent,
    });

    if (!uploadRes.ok) {
      const errText = await uploadRes.text();
      throw new Error(`Failed to update ${fileName} in Google Drive (HTTP ${uploadRes.status}): ${errText}`);
    }

    const updated = await uploadRes.json();
    return {
      fileId: updated.id || existingFileId,
      webViewLink: `https://drive.google.com/file/d/${existingFileId}/view`,
    };
  } else {
    const metadata = {
      name: fileName,
      description,
      parents: [folderId],
      mimeType: 'application/json',
    };

    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const multipartRequestBody =
      delimiter +
      'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
      JSON.stringify(metadata) +
      delimiter +
      'Content-Type: application/json\r\n\r\n' +
      jsonContent +
      closeDelimiter;

    const createUrl = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink';
    const createRes = await fetch(createUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: multipartRequestBody,
    });

    if (!createRes.ok) {
      const errText = await createRes.text();
      throw new Error(`Failed to create ${fileName} in Google Drive folder (HTTP ${createRes.status}): ${errText}`);
    }

    const created = await createRes.json();
    return {
      fileId: created.id,
      webViewLink: created.webViewLink || `https://drive.google.com/file/d/${created.id}/view`,
    };
  }
}

// 7. Complete Folder Structure Definition for NOVORA_Project
export interface NovoraDriveFolderMap {
  root: string;
  admin: string;
  customers: string;
  addresses: string;
  orders: string;
  storeSettings: string;
  backups: string;
  logs: string;
  products: string;
  categories: string;
  productImages: string;
  storeContent: string;
  media: string;
  mediaLogos: string;
  mediaProductImages: string;
  mediaBannerImages: string;
  mediaCategoryImages: string;
  mediaOtherStoreImages: string;
  paymentData: string;
}

// Helper: ensure the complete NOVORA_Project folder hierarchy exists
export async function ensureNovoraFolderStructure(
  token: string,
  rootFolderId: string = TARGET_DRIVE_FOLDER_ID
): Promise<NovoraDriveFolderMap> {
  console.log(`[GoogleDrive:Init] Ensuring complete NOVORA_Project folder hierarchy in ${rootFolderId}...`);

  // 1. Top level folders inside NOVORA_Project
  const [admin, customers, addresses, orders, storeSettings, backups, logs, products, categories, productImages, storeContent, media, paymentData] = await Promise.all([
    findOrCreateFolder(token, 'Admin', rootFolderId),
    findOrCreateFolder(token, 'Customers', rootFolderId),
    findOrCreateFolder(token, 'Addresses', rootFolderId),
    findOrCreateFolder(token, 'Orders', rootFolderId),
    findOrCreateFolder(token, 'Store_Settings', rootFolderId),
    findOrCreateFolder(token, 'Backups', rootFolderId),
    findOrCreateFolder(token, 'Logs', rootFolderId),
    findOrCreateFolder(token, 'Products', rootFolderId),
    findOrCreateFolder(token, 'Categories', rootFolderId),
    findOrCreateFolder(token, 'Product_Images', rootFolderId),
    findOrCreateFolder(token, 'Store_Content', rootFolderId),
    findOrCreateFolder(token, 'Media', rootFolderId),
    findOrCreateFolder(token, 'Payment_Data', rootFolderId),
  ]);

  // 2. Media subfolders inside Media
  const [mediaLogos, mediaProductImages, mediaBannerImages, mediaCategoryImages, mediaOtherStoreImages] = await Promise.all([
    findOrCreateFolder(token, 'Logos', media),
    findOrCreateFolder(token, 'Product_Images', media),
    findOrCreateFolder(token, 'Banner_Images', media),
    findOrCreateFolder(token, 'Category_Images', media),
    findOrCreateFolder(token, 'Other_Store_Images', media),
  ]);

  const map: NovoraDriveFolderMap = {
    root: rootFolderId,
    admin,
    customers,
    addresses,
    orders,
    storeSettings,
    backups,
    logs,
    products,
    categories,
    productImages,
    storeContent,
    media,
    mediaLogos,
    mediaProductImages,
    mediaBannerImages,
    mediaCategoryImages,
    mediaOtherStoreImages,
    paymentData,
  };

  console.log('[GoogleDrive:Init] NOVORA_Project folder hierarchy verified:', map);
  return map;
}

// 8. Result interface for Google Drive Sync
export interface GoogleDriveSyncResult {
  success: boolean;
  timestamp: string;
  folderUrl: string;
  folderId: string;
  folderName: string;
  folderMap?: NovoraDriveFolderMap;
  syncedFiles: Array<{
    fileName: string;
    folder: string;
    fileId: string;
    recordsCount: number;
    sanitization: string;
  }>;
  files: {
    usersFileName: string;
    usersFileId: string;
    usersCount: number;
    addressesFileName: string;
    addressesFileId: string;
    addressesCount: number;
    ordersFileName: string;
    ordersFileId: string;
    ordersCount: number;
    productsFileName?: string;
    productsFileId?: string;
    productsCount?: number;
    settingsFileName?: string;
    settingsFileId?: string;
  };
  message: string;
}

// 9. Sync All Data Files across NOVORA_Project Subfolders
export async function syncUserDataToGoogleDrive(
  tokenOverride?: string
): Promise<GoogleDriveSyncResult> {
  const token = tokenOverride || cachedAccessToken;
  if (!token) {
    throw new Error('Google Drive authorization required. Please connect your Google account or click "Connect Google Drive".');
  }

  console.log(`[GoogleDrive:Sync:Start] Starting full sync to target folder: ${TARGET_DRIVE_FOLDER_NAME} (${TARGET_DRIVE_FOLDER_ID})...`);

  // 1. Fetch latest server-side database records from unified export endpoint
  const exportRes = await fetch('/api/drive/export-data');
  if (!exportRes.ok) {
    const errText = await exportRes.text();
    throw new Error(`Failed to fetch database export payload from backend (HTTP ${exportRes.status}): ${errText}`);
  }

  const exportData = await exportRes.json();
  const customers = exportData.customers || [];
  const addresses = exportData.addresses || [];
  const orders = exportData.orders || [];
  const products = exportData.products || [];
  const categories = exportData.categories || [];
  const banners = exportData.banners || [];
  const settings = exportData.settings || {};
  const auditLog = exportData.auditLog || [];
  const productChangesLog = exportData.productChangesLog || [];
  const registrationLog = exportData.registrationLog || [];
  const accountActivityLog = exportData.accountActivityLog || [];
  const navigation = exportData.navigation || {};
  const homepageContent = exportData.homepageContent || {};
  const paymentSettingsBackup = exportData.paymentSettingsBackup || {};
  const paymentTransactions = exportData.paymentTransactions || [];
  const payoutSettingsBackup = exportData.payoutSettingsBackup || {};

  // 2. Ensure all folders exist in Google Drive
  const folderMap = await ensureNovoraFolderStructure(token, TARGET_DRIVE_FOLDER_ID);
  const now = new Date().toISOString();
  const schemaVersion = '1.0.0';

  // 3. Prepare Payloads for Managed Files
  // Store_Settings & Store_Content
  const fileStoreSettings = { schemaVersion, source: 'NOVORA Luxury E-Commerce', lastUpdated: now, settings };
  const fileHomepage = { schemaVersion, source: 'NOVORA Luxury E-Commerce', lastUpdated: now, ...homepageContent };
  const fileCategoriesBackup = { schemaVersion, source: 'NOVORA Luxury E-Commerce', lastUpdated: now, totalCategories: categories.length, categories };
  const fileNavigation = { schemaVersion, source: 'NOVORA Luxury E-Commerce', lastUpdated: now, ...navigation };

  // Products
  const fileProductsBackup = { schemaVersion, source: 'NOVORA Luxury E-Commerce Authoritative Catalog', lastUpdated: now, totalProducts: products.length, products };

  // Product Changes Log
  const fileProductChangesLog = { schemaVersion, source: 'NOVORA Product Changes Engine', lastUpdated: now, totalChanges: productChangesLog.length, changes: productChangesLog };

  // Customers & Registration Log
  const fileCustomers = { schemaVersion, source: 'NOVORA Luxury E-Commerce', lastUpdated: now, totalCustomers: customers.length, customers };
  const fileRegistrationLog = { schemaVersion, source: 'NOVORA Luxury E-Commerce Customer Registration Audit Engine', lastUpdated: now, totalRegistrations: registrationLog.length, registrations: registrationLog };

  // Addresses
  const fileAddresses = { schemaVersion, source: 'NOVORA Luxury E-Commerce', lastUpdated: now, totalAddresses: addresses.length, addresses };

  // Backups: Customer Backup Snapshot (Strictly zero credentials or tokens)
  const fileCustomerBackup = {
    schemaVersion,
    source: 'NOVORA Luxury E-Commerce Customer Database Snapshot',
    createdAt: now,
    lastUpdated: now,
    totalCustomers: customers.length,
    totalAddresses: addresses.length,
    customers,
    addresses,
  };

  // Logs: Account Activity Log
  const fileAccountActivityLog = { schemaVersion, source: 'NOVORA Luxury E-Commerce Account Activity Engine', lastUpdated: now, totalEntries: accountActivityLog.length, activities: accountActivityLog };

  // Orders
  const fileOrders = { schemaVersion, source: 'NOVORA Luxury E-Commerce', lastUpdated: now, totalOrders: orders.length, orders };

  // Payment_Data
  const filePaymentSettings = { schemaVersion, source: 'NOVORA Luxury E-Commerce', lastUpdated: now, gatewayConfig: paymentSettingsBackup };
  const filePaymentTransactions = { schemaVersion, source: 'NOVORA Luxury E-Commerce', lastUpdated: now, totalTransactions: paymentTransactions.length, transactions: paymentTransactions };
  const filePayoutSettings = { schemaVersion, source: 'NOVORA Luxury E-Commerce', lastUpdated: now, ...payoutSettingsBackup };

  // Admin
  const fileAudit = { schemaVersion, source: 'NOVORA Luxury E-Commerce', lastUpdated: now, totalAuditEntries: auditLog.length, auditLog };

  // Backups (Dated Snapshot)
  const dateStr = now.replace(/[:.]/g, '-').slice(0, 19);
  const backupFilename = `backup_${dateStr}.json`;
  const fileBackup = {
    schemaVersion,
    source: 'NOVORA Luxury E-Commerce Backup Snapshot',
    createdAt: now,
    databaseSnapshot: {
      settings,
      products,
      categories,
      banners,
      orders,
      customers,
      addresses,
      paymentTransactions,
      auditLog,
    },
  };

  const syncedFiles: Array<{ fileName: string; folder: string; fileId: string; recordsCount: number; sanitization: string }> = [];

  // 4. Upload Files to Corresponding Folders
  // Store_Settings & Store_Content
  const resSettings = await uploadOrUpdateJsonFile(token, 'store_settings.json', folderMap.storeSettings, fileStoreSettings, 'NOVORA Store Settings');
  syncedFiles.push({ fileName: 'store_settings.json', folder: 'Store_Settings', fileId: resSettings.fileId, recordsCount: 1, sanitization: 'Clean' });
  await uploadOrUpdateJsonFile(token, 'store_settings.json', folderMap.storeContent, fileStoreSettings, 'NOVORA Store Settings');

  const resHome = await uploadOrUpdateJsonFile(token, 'homepage_content.json', folderMap.storeContent, fileHomepage, 'NOVORA Homepage Content');
  syncedFiles.push({ fileName: 'homepage_content.json', folder: 'Store_Content', fileId: resHome.fileId, recordsCount: banners.length, sanitization: 'Clean' });

  // Categories/categories_backup.json & Store_Content/categories.json
  const resCatBackup = await uploadOrUpdateJsonFile(token, 'categories_backup.json', folderMap.categories, fileCategoriesBackup, 'NOVORA Categories Backup');
  syncedFiles.push({ fileName: 'categories_backup.json', folder: 'Categories', fileId: resCatBackup.fileId, recordsCount: categories.length, sanitization: 'Clean' });
  await uploadOrUpdateJsonFile(token, 'categories.json', folderMap.storeContent, fileCategoriesBackup, 'NOVORA Categories Taxonomy');

  const resNav = await uploadOrUpdateJsonFile(token, 'navigation.json', folderMap.storeContent, fileNavigation, 'NOVORA Store Navigation Menu');
  syncedFiles.push({ fileName: 'navigation.json', folder: 'Store_Content', fileId: resNav.fileId, recordsCount: 1, sanitization: 'Clean' });

  // Products/products_backup.json & Products/products.json
  const resProdBackup = await uploadOrUpdateJsonFile(token, 'products_backup.json', folderMap.products, fileProductsBackup, 'NOVORA Products Authoritative Backup');
  syncedFiles.push({ fileName: 'products_backup.json', folder: 'Products', fileId: resProdBackup.fileId, recordsCount: products.length, sanitization: 'Clean' });
  await uploadOrUpdateJsonFile(token, 'products.json', folderMap.products, fileProductsBackup, 'NOVORA Products Catalog');

  // Logs/product_changes_log.json
  const resProdChanges = await uploadOrUpdateJsonFile(token, 'product_changes_log.json', folderMap.logs, fileProductChangesLog, 'NOVORA Product Changes Log');
  syncedFiles.push({ fileName: 'product_changes_log.json', folder: 'Logs', fileId: resProdChanges.fileId, recordsCount: productChangesLog.length, sanitization: 'Audit Trail' });

  // 1. Customers/customers_export.json (Strictly zero passwords or hashes)
  const resCust = await uploadOrUpdateJsonFile(token, 'customers_export.json', folderMap.customers, fileCustomers, 'NOVORA Sanitized Customers Export');
  syncedFiles.push({ fileName: 'customers_export.json', folder: 'Customers', fileId: resCust.fileId, recordsCount: customers.length, sanitization: 'Zero-Password Scrubbed' });

  // 2. Customers/registration_log.json (Registration audit events)
  const resRegLog = await uploadOrUpdateJsonFile(token, 'registration_log.json', folderMap.customers, fileRegistrationLog, 'NOVORA Customer Registration Audit Log');
  syncedFiles.push({ fileName: 'registration_log.json', folder: 'Customers', fileId: resRegLog.fileId, recordsCount: registrationLog.length, sanitization: 'Audit Trail' });
  await uploadOrUpdateJsonFile(token, 'registration_log.json', folderMap.logs, fileRegistrationLog, 'NOVORA Customer Registration Audit Log');

  // 3. Addresses/addresses_export.json
  const resAddr = await uploadOrUpdateJsonFile(token, 'addresses_export.json', folderMap.addresses, fileAddresses, 'NOVORA Customer Delivery Addresses');
  syncedFiles.push({ fileName: 'addresses_export.json', folder: 'Addresses', fileId: resAddr.fileId, recordsCount: addresses.length, sanitization: 'Zero-Secret Scrubbed' });
  await uploadOrUpdateJsonFile(token, 'addresses_export.json', folderMap.customers, fileAddresses, 'NOVORA Customer Delivery Addresses');

  // 4. Backups/customer_backup.json (Customer disaster recovery backup without credentials)
  const resCustBackup = await uploadOrUpdateJsonFile(token, 'customer_backup.json', folderMap.backups, fileCustomerBackup, 'NOVORA Customer Database Disaster Recovery Backup');
  syncedFiles.push({ fileName: 'customer_backup.json', folder: 'Backups', fileId: resCustBackup.fileId, recordsCount: customers.length + addresses.length, sanitization: 'Credentials Scrubbed' });

  // 5. Logs/account_activity_log.json
  const resActLog = await uploadOrUpdateJsonFile(token, 'account_activity_log.json', folderMap.logs, fileAccountActivityLog, 'NOVORA Account Security Activity Log');
  syncedFiles.push({ fileName: 'account_activity_log.json', folder: 'Logs', fileId: resActLog.fileId, recordsCount: accountActivityLog.length, sanitization: 'Security Audit' });

  // Orders
  const resOrd = await uploadOrUpdateJsonFile(token, 'orders.json', folderMap.orders, fileOrders, 'NOVORA Customer Orders');
  syncedFiles.push({ fileName: 'orders.json', folder: 'Orders', fileId: resOrd.fileId, recordsCount: orders.length, sanitization: 'Zero-PAN Scrubbed' });

  // Payment_Data (Strictly zero secrets/card numbers)
  const resPaySet = await uploadOrUpdateJsonFile(token, 'payment_settings_backup.json', folderMap.paymentData, filePaymentSettings, 'NOVORA Safe Payment Settings');
  syncedFiles.push({ fileName: 'payment_settings_backup.json', folder: 'Payment_Data', fileId: resPaySet.fileId, recordsCount: 1, sanitization: 'Zero-Key Scrubbed' });

  const resPayTx = await uploadOrUpdateJsonFile(token, 'payment_transactions.json', folderMap.paymentData, filePaymentTransactions, 'NOVORA Payment Transactions Log');
  syncedFiles.push({ fileName: 'payment_transactions.json', folder: 'Payment_Data', fileId: resPayTx.fileId, recordsCount: paymentTransactions.length, sanitization: 'Masked' });

  const resPayout = await uploadOrUpdateJsonFile(token, 'payout_settings_backup.json', folderMap.paymentData, filePayoutSettings, 'NOVORA Safe Payout Destination Backup');
  syncedFiles.push({ fileName: 'payout_settings_backup.json', folder: 'Payment_Data', fileId: resPayout.fileId, recordsCount: 1, sanitization: 'Masked IBAN' });

  // Admin & Logs (Zero passwords or hashes)
  const resAudit = await uploadOrUpdateJsonFile(token, 'admin_audit_log.json', folderMap.admin, fileAudit, 'NOVORA Administrator Security Audit Trail');
  syncedFiles.push({ fileName: 'admin_audit_log.json', folder: 'Admin', fileId: resAudit.fileId, recordsCount: auditLog.length, sanitization: 'Zero-Credential Scrubbed' });
  await uploadOrUpdateJsonFile(token, 'admin_audit_log.json', folderMap.logs, fileAudit, 'NOVORA Administrator Security Audit Trail');

  // 6. Backups/backup_status.json
  const fileBackupStatus = {
    schemaVersion,
    source: 'NOVORA Luxury E-Commerce',
    lastUpdated: now,
    targetGoogleDriveFolder: TARGET_DRIVE_FOLDER_NAME,
    googleDriveFolderId: TARGET_DRIVE_FOLDER_ID,
    foldersConfigured: ['Customers', 'Addresses', 'Backups', 'Logs', 'Products', 'Categories', 'Store_Settings', 'Admin'],
    filesManaged: [
      'Customers/customers_export.json',
      'Customers/registration_log.json',
      'Addresses/addresses_export.json',
      'Backups/customer_backup.json',
      'Backups/backup_status.json',
      'Logs/account_activity_log.json',
      'products_backup.json',
      'categories_backup.json',
      'store_settings.json',
      'product_changes_log.json',
      'orders.json',
      'admin_audit_log.json',
    ],
    integrityStatus: 'healthy',
    securityCompliance: {
      plainTextPasswordsStored: false,
      passwordHashesInDrive: false,
      otpCodesInDrive: false,
      sessionTokensInDrive: false,
      creditCardCvvsStored: false,
      bcryptSaltedHashedLocalAuth: true,
    },
    counts: {
      totalCustomers: customers.length,
      totalAddresses: addresses.length,
      totalRegistrations: registrationLog.length,
      totalAccountActivities: accountActivityLog.length,
      totalOrders: orders.length,
      totalProducts: products.length,
      totalAuditEntries: auditLog.length,
    },
  };
  const resStatus = await uploadOrUpdateJsonFile(token, 'backup_status.json', folderMap.backups, fileBackupStatus, 'NOVORA Backup Status and Integrity Record');
  syncedFiles.push({ fileName: 'backup_status.json', folder: 'Backups', fileId: resStatus.fileId, recordsCount: 1, sanitization: 'Integrity Report' });
  await uploadOrUpdateJsonFile(token, 'backup_status.json', folderMap.logs, fileBackupStatus, 'NOVORA Backup Status and Integrity Record');

  // Backups (Dated Snapshot)
  const resBackup = await uploadOrUpdateJsonFile(token, backupFilename, folderMap.backups, fileBackup, `NOVORA Disaster Recovery Snapshot (${dateStr})`);
  syncedFiles.push({ fileName: backupFilename, folder: 'Backups', fileId: resBackup.fileId, recordsCount: products.length + orders.length, sanitization: 'Full Sanitized Snapshot' });

  const result: GoogleDriveSyncResult = {
    success: true,
    timestamp: now,
    folderUrl: TARGET_DRIVE_FOLDER_URL,
    folderId: TARGET_DRIVE_FOLDER_ID,
    folderName: TARGET_DRIVE_FOLDER_NAME,
    folderMap,
    syncedFiles,
    files: {
      usersFileName: 'customers_export.json',
      usersFileId: resCust.fileId,
      usersCount: customers.length,
      addressesFileName: 'addresses_export.json',
      addressesFileId: resAddr.fileId,
      addressesCount: addresses.length,
      ordersFileName: 'orders.json',
      ordersFileId: resOrd.fileId,
      ordersCount: orders.length,
      productsFileName: 'products_backup.json',
      productsFileId: resProdBackup.fileId,
      productsCount: products.length,
      settingsFileName: 'store_settings.json',
      settingsFileId: resSettings.fileId,
    },
    message: `Synchronized all 12 auto-managed files across Store_Content, Products, Customers, Orders, Payment_Data, Admin, and Backups in Google Drive folder "${TARGET_DRIVE_FOLDER_NAME}".`,
  };

  console.log('[GoogleDrive:Sync:Complete] Full NOVORA_Project hierarchy synchronized successfully:', result);
  return result;
}
